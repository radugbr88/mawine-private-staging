CREATE TABLE `admin_access_audit` (
	`id` text PRIMARY KEY NOT NULL,
	`profile_id` text NOT NULL,
	`admin` text NOT NULL,
	`expires_at` integer NOT NULL,
	`created_at` integer NOT NULL
);
CREATE TABLE admin_accounts (
 username TEXT PRIMARY KEY NOT NULL,
 password TEXT,
 created_at INTEGER NOT NULL
);
INSERT INTO "admin_accounts" VALUES('radugbr88@gmail.com',NULL,1793992153000);
CREATE TABLE `admin_challenges` (
	`device_hash` text PRIMARY KEY NOT NULL,
	`username` text NOT NULL,
	`token_hash` text NOT NULL,
	`expires` integer NOT NULL
);
CREATE TABLE admin_sessions (
 id TEXT PRIMARY KEY NOT NULL,
 username TEXT NOT NULL REFERENCES admin_accounts(username),
 expires INTEGER NOT NULL
);
CREATE TABLE `attempts` (
	`id` text PRIMARY KEY NOT NULL,
	`count` integer NOT NULL,
	`since` integer NOT NULL
);
CREATE TABLE `billing_checkouts` (
	`profile_id` text NOT NULL,
	`environment` text NOT NULL,
	`provider_account_id` text NOT NULL,
	`id` text NOT NULL,
	`plan` text NOT NULL,
	`params` text NOT NULL,
	`created_at` integer NOT NULL,
	`session_id` text,
	PRIMARY KEY(`profile_id`, `environment`, `provider_account_id`),
	FOREIGN KEY (`profile_id`) REFERENCES `profiles`(`id`) ON UPDATE no action ON DELETE cascade
);
CREATE TABLE `billing_customers` (
	`id` text PRIMARY KEY NOT NULL,
	`profile_id` text,
	`provider` text NOT NULL,
	`environment` text NOT NULL,
	`provider_account_id` text NOT NULL,
	`provider_customer_id` text NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`profile_id`) REFERENCES `profiles`(`id`) ON UPDATE no action ON DELETE set null,
	CONSTRAINT "billing_customer_provider" CHECK("billing_customers"."provider" IN ('stripe','apple','google')),
	CONSTRAINT "billing_customer_environment" CHECK("billing_customers"."environment" IN ('test','live'))
);
CREATE TABLE `billing_events` (
	`provider` text NOT NULL,
	`environment` text NOT NULL,
	`provider_account_id` text NOT NULL,
	`provider_event_id` text NOT NULL,
	`event_type` text NOT NULL,
	`provider_object_id` text,
	`provider_created_at` integer NOT NULL,
	`received_at` integer NOT NULL,
	`processed_at` integer,
	`processing_status` text DEFAULT 'pending' NOT NULL,
	`attempts` integer DEFAULT 0 NOT NULL,
	`last_error_code` text,
	PRIMARY KEY(`provider`, `environment`, `provider_account_id`, `provider_event_id`),
	CONSTRAINT "billing_event_provider" CHECK("billing_events"."provider" IN ('stripe','apple','google')),
	CONSTRAINT "billing_event_environment" CHECK("billing_events"."environment" IN ('test','live')),
	CONSTRAINT "billing_event_status" CHECK("billing_events"."processing_status" IN ('pending','processed','failed','ignored')),
	CONSTRAINT "billing_event_attempts" CHECK("billing_events"."attempts" >= 0)
);
CREATE TABLE `billing_locks` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`expires_at` integer NOT NULL
);
CREATE TABLE `billing_operations` (
	`id` text PRIMARY KEY NOT NULL,
	`created_at` integer NOT NULL
);
CREATE TABLE `billing_subscriptions` (
	`id` text PRIMARY KEY NOT NULL,
	`profile_id` text,
	`provider` text NOT NULL,
	`environment` text NOT NULL,
	`provider_account_id` text NOT NULL,
	`provider_subscription_id` text NOT NULL,
	`provider_customer_id` text,
	`provider_price_id` text,
	`plan_key` text NOT NULL,
	`billing_interval` text NOT NULL,
	`provider_status` text NOT NULL,
	`current_period_start` integer,
	`current_period_end` integer,
	`access_expires_at` integer,
	`cancel_at_period_end` integer DEFAULT 0 NOT NULL,
	`canceled_at` integer,
	`ended_at` integer,
	`last_synced_at` integer,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL, `risk_blocked` integer DEFAULT 0 NOT NULL, `risk_reason` text,
	FOREIGN KEY (`profile_id`) REFERENCES `profiles`(`id`) ON UPDATE no action ON DELETE set null,
	CONSTRAINT "billing_subscription_provider" CHECK("billing_subscriptions"."provider" IN ('stripe','apple','google')),
	CONSTRAINT "billing_subscription_environment" CHECK("billing_subscriptions"."environment" IN ('test','live')),
	CONSTRAINT "billing_subscription_interval" CHECK("billing_subscriptions"."billing_interval" IN ('monthly','annual')),
	CONSTRAINT "billing_subscription_cancel_flag" CHECK("billing_subscriptions"."cancel_at_period_end" IN (0,1))
);
CREATE TABLE `collection_retention_policy` (
	`id` integer PRIMARY KEY NOT NULL,
	`started_at` integer NOT NULL
);
INSERT INTO collection_retention_policy(id,started_at) VALUES(1,CAST(strftime('%s','now') AS INTEGER)*1000);
CREATE TABLE `complimentary_access` (
	`profile_id` text PRIMARY KEY NOT NULL,
	`expires_at` integer NOT NULL,
	`granted_by` text NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`profile_id`) REFERENCES `profiles`(`id`) ON UPDATE no action ON DELETE cascade
);
CREATE TABLE `email_verifications` (
	`profile_id` text PRIMARY KEY NOT NULL,
	`email` text NOT NULL,
	`password_hash` text NOT NULL,
	`token_hash` text NOT NULL,
	`identity` text NOT NULL,
	`expires` integer NOT NULL
);
CREATE TABLE `events` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`title` text NOT NULL,
	`date` text NOT NULL,
	`mode` text NOT NULL,
	`status` text NOT NULL,
	`code` text NOT NULL,
	`wines` text NOT NULL,
	`revealed` integer DEFAULT 0 NOT NULL
, collection_wine_ids TEXT NOT NULL DEFAULT '[]', revealed_wine_ids TEXT NOT NULL DEFAULT '[]');
CREATE TABLE `grape_varieties` (`id` integer PRIMARY KEY NOT NULL, `name` text NOT NULL, `color` text NOT NULL, `search_key` text NOT NULL);
INSERT INTO "grape_varieties" VALUES(100001,'Cabernet Sauvignon','NOIR','cabernetsauvignon');
INSERT INTO "grape_varieties" VALUES(100002,'Merlot','NOIR','merlot');
INSERT INTO "grape_varieties" VALUES(100003,'Tempranillo','NOIR','tempranillo tintaroriz aragonez aragones');
INSERT INTO "grape_varieties" VALUES(100004,'Airén','BLANC','airen');
INSERT INTO "grape_varieties" VALUES(100005,'Chardonnay','BLANC','chardonnay');
INSERT INTO "grape_varieties" VALUES(100007,'Syrah','NOIR','syrah shiraz');
INSERT INTO "grape_varieties" VALUES(100008,'Grenache','NOIR','grenache garnachatinta grenachenoir garnacha');
INSERT INTO "grape_varieties" VALUES(100010,'Sauvignon Blanc','BLANC','sauvignonblanc');
INSERT INTO "grape_varieties" VALUES(100011,'Trebbiano Toscano','BLANC','trebbianotoscano ugniblanc trebbiano');
INSERT INTO "grape_varieties" VALUES(100012,'Pinot Noir','NOIR','pinotnoir');
INSERT INTO "grape_varieties" VALUES(100013,'Sangiovese','NOIR','sangiovese');
INSERT INTO "grape_varieties" VALUES(100014,'Riesling','BLANC','riesling');
INSERT INTO "grape_varieties" VALUES(100015,'Bobal','NOIR','bobal');
INSERT INTO "grape_varieties" VALUES(100016,'Cabernet Franc','NOIR','cabernetfranc');
INSERT INTO "grape_varieties" VALUES(100017,'Malbec','NOIR','malbec cot');
INSERT INTO "grape_varieties" VALUES(100018,'Monastrell','NOIR','monastrell mourvedre monastrellmourvedre');
INSERT INTO "grape_varieties" VALUES(100019,'Rkatsiteli','BLANC','rkatsiteli');
INSERT INTO "grape_varieties" VALUES(100020,'Pinot Gris','GRIS','pinotgris pinotgrigio');
INSERT INTO "grape_varieties" VALUES(100021,'Mazuelo','NOIR','mazuelo carignan');
INSERT INTO "grape_varieties" VALUES(100022,'Macabeo','BLANC','macabeo viura');
INSERT INTO "grape_varieties" VALUES(100023,'Cayetana Blanca','BLANC','cayetanablanca');
INSERT INTO "grape_varieties" VALUES(100024,'Alicante Henri Bouschet','NOIR','alicantehenribouschet alicantebouschet');
INSERT INTO "grape_varieties" VALUES(100025,'Muscat of Alexandria','BLANC','muscatofalexandria');
INSERT INTO "grape_varieties" VALUES(100026,'Muscat Blanc à Petits Grains','BLANC','muscatblancapetitsgrains muscatblanc');
INSERT INTO "grape_varieties" VALUES(100027,'Tribidrag','NOIR','tribidrag zinfandel primitivo zinfandelprimitivo');
INSERT INTO "grape_varieties" VALUES(100028,'Montepulciano','NOIR','montepulciano');
INSERT INTO "grape_varieties" VALUES(100029,'Chenin Blanc','BLANC','cheninblanc');
INSERT INTO "grape_varieties" VALUES(100030,'Colombard','BLANC','colombard');
INSERT INTO "grape_varieties" VALUES(100031,'Cereza','GRIS','cereza');
INSERT INTO "grape_varieties" VALUES(100032,'Catarratto Bianco','BLANC','catarrattobianco catarratto');
INSERT INTO "grape_varieties" VALUES(100033,'Aligoté','BLANC','aligote');
INSERT INTO "grape_varieties" VALUES(100034,'Gamay Noir','NOIR','gamaynoir gamay');
INSERT INTO "grape_varieties" VALUES(100035,'Graševina','BLANC','grasevina welschriesling');
INSERT INTO "grape_varieties" VALUES(100036,'Palomino Fino','BLANC','palominofino');
INSERT INTO "grape_varieties" VALUES(100037,'Cinsaut','NOIR','cinsaut cinsault');
INSERT INTO "grape_varieties" VALUES(100038,'Carmenère','NOIR','carmenere');
INSERT INTO "grape_varieties" VALUES(100039,'Glera','BLANC','prosecco glera glera prosecco');
INSERT INTO "grape_varieties" VALUES(100040,'Douce Noire','NOIR','doucenoire bonarda charbono');
INSERT INTO "grape_varieties" VALUES(100041,'Müller-Thurgau','BLANC','mullerthurgau');
INSERT INTO "grape_varieties" VALUES(100042,'Grüner Veltliner','BLANC','grunerveltliner');
INSERT INTO "grape_varieties" VALUES(100043,'Trebbiano Romagnolo','BLANC','trebbianoromagnolo');
INSERT INTO "grape_varieties" VALUES(100044,'Sémillon','BLANC','semillon');
INSERT INTO "grape_varieties" VALUES(100045,'Verdejo','BLANC','verdejo');
INSERT INTO "grape_varieties" VALUES(100046,'Barbera','NOIR','barbera');
INSERT INTO "grape_varieties" VALUES(100047,'Isabella','NOIR','isabella');
INSERT INTO "grape_varieties" VALUES(100048,'Blaufränkisch','NOIR','blaufrankisch');
INSERT INTO "grape_varieties" VALUES(100049,'Viognier','BLANC','viognier');
INSERT INTO "grape_varieties" VALUES(100050,'Criolla Grande','NOIR','criollagrande');
INSERT INTO "grape_varieties" VALUES(100051,'Pedro Giménez','BLANC','pedrogimenez');
INSERT INTO "grape_varieties" VALUES(100052,'Pinot Meunier','NOIR','pinotmeunier');
INSERT INTO "grape_varieties" VALUES(100053,'Nero d''Avola','NOIR','nerodavola');
INSERT INTO "grape_varieties" VALUES(100054,'Touriga Franca','NOIR','tourigafranca');
INSERT INTO "grape_varieties" VALUES(100055,'Pinot Blanc','BLANC','pinotblanc');
INSERT INTO "grape_varieties" VALUES(100056,'Fetească Albă','BLANC','feteascaalba');
INSERT INTO "grape_varieties" VALUES(100057,'Fetească Regală','BLANC','feteascaregala');
INSERT INTO "grape_varieties" VALUES(100058,'Gewürztraminer','BLANC','gewurztraminer');
INSERT INTO "grape_varieties" VALUES(100059,'Castelão','NOIR','castelao');
INSERT INTO "grape_varieties" VALUES(100060,'Muscat Ottonel','BLANC','muscatottonel');
INSERT INTO "grape_varieties" VALUES(100062,'Fernão Pires','BLANC','fernaopires');
INSERT INTO "grape_varieties" VALUES(100063,'Touriga Nacional','NOIR','touriganacional');
INSERT INTO "grape_varieties" VALUES(100064,'Vermentino','BLANC','vermentino');
INSERT INTO "grape_varieties" VALUES(100065,'Negroamaro','NOIR','negroamaro');
INSERT INTO "grape_varieties" VALUES(100066,'Mencía','NOIR','mencia');
INSERT INTO "grape_varieties" VALUES(100067,'Concord','NOIR','concord');
INSERT INTO "grape_varieties" VALUES(100068,'Trincadeira','NOIR','trincadeira');
INSERT INTO "grape_varieties" VALUES(100069,'Savatiano','BLANC','savatiano');
INSERT INTO "grape_varieties" VALUES(100070,'Listán Prieto','NOIR','listanprieto pais');
INSERT INTO "grape_varieties" VALUES(100071,'Pamid','NOIR','pamid');
INSERT INTO "grape_varieties" VALUES(100072,'Bianca','BLANC','bianca');
INSERT INTO "grape_varieties" VALUES(100073,'Aglianico','NOIR','aglianico');
INSERT INTO "grape_varieties" VALUES(100074,'Dimyat','BLANC','dimyat');
INSERT INTO "grape_varieties" VALUES(100075,'Malvasia Bianca di Candia','BLANC','malvasiabiancadicandia');
INSERT INTO "grape_varieties" VALUES(100076,'Melon','BLANC','melon melondebourgogne');
INSERT INTO "grape_varieties" VALUES(100077,'Vranac','NOIR','vranac');
INSERT INTO "grape_varieties" VALUES(100078,'Zweigelt','NOIR','zweigelt');
INSERT INTO "grape_varieties" VALUES(100079,'Torrontés Riojano','BLANC','torrontesriojano torrontes');
INSERT INTO "grape_varieties" VALUES(100080,'Pedro Ximénez','BLANC','pedroximenez');
INSERT INTO "grape_varieties" VALUES(100082,'Garganega','BLANC','garganega');
INSERT INTO "grape_varieties" VALUES(100083,'Xarello','BLANC','xarello');
INSERT INTO "grape_varieties" VALUES(100084,'Roditis','GRIS','roditis');
INSERT INTO "grape_varieties" VALUES(100086,'Petit Verdot','NOIR','petitverdot');
INSERT INTO "grape_varieties" VALUES(100087,'Nebbiolo','NOIR','nebbiolo');
INSERT INTO "grape_varieties" VALUES(100088,'Tsolikouri','BLANC','tsolikouri');
INSERT INTO "grape_varieties" VALUES(100089,'Dornfelder','NOIR','dornfelder');
INSERT INTO "grape_varieties" VALUES(100090,'Muscat of Hamburg','NOIR','muscatofhamburg');
INSERT INTO "grape_varieties" VALUES(100091,'Garnacha Blanca','BLANC','garnachablanca grenacheblanc');
INSERT INTO "grape_varieties" VALUES(100092,'Grillo','BLANC','grillo');
INSERT INTO "grape_varieties" VALUES(100093,'Chasselas','BLANC','chasselas');
INSERT INTO "grape_varieties" VALUES(100094,'Parellada','BLANC','parellada');
INSERT INTO "grape_varieties" VALUES(100095,'Pinotage','NOIR','pinotage');
INSERT INTO "grape_varieties" VALUES(100096,'Síria','BLANC','siria');
INSERT INTO "grape_varieties" VALUES(100097,'Baga','NOIR','baga');
INSERT INTO "grape_varieties" VALUES(100098,'Blauer Portugieser','NOIR','blauerportugieser portugieser');
INSERT INTO "grape_varieties" VALUES(100099,'Saperavi','NOIR','saperavi');
INSERT INTO "grape_varieties" VALUES(100100,'Corvina Veronese','NOIR','corvinaveronese corvina');
INSERT INTO "grape_varieties" VALUES(100101,'Lambrusco Salamino','NOIR','lambruscosalamino');
INSERT INTO "grape_varieties" VALUES(100102,'Silvaner','BLANC','silvaner silvanersylvaner sylvaner');
INSERT INTO "grape_varieties" VALUES(100103,'Bonarda Piemontese','NOIR','bonardapiemontese');
INSERT INTO "grape_varieties" VALUES(100104,'Lambrusco Maestri','NOIR','lambruscomaestri');
INSERT INTO "grape_varieties" VALUES(100105,'Tannat','NOIR','tannat');
INSERT INTO "grape_varieties" VALUES(100106,'Alvarinho','BLANC','alvarinho albarino albarinoalvarinho');
INSERT INTO "grape_varieties" VALUES(100107,'Arinto de Bucelas','BLANC','arintodebucelas arinto');
INSERT INTO "grape_varieties" VALUES(100108,'Tinto Velasco','NOIR','tintovelasco');
INSERT INTO "grape_varieties" VALUES(100109,'Sultaniye','BLANC','sultaniye');
INSERT INTO "grape_varieties" VALUES(100110,'Ruby Cabernet','NOIR','rubycabernet');
INSERT INTO "grape_varieties" VALUES(100111,'Caladoc','NOIR','caladoc');
INSERT INTO "grape_varieties" VALUES(100112,'Italia','BLANC','italia');
INSERT INTO "grape_varieties" VALUES(100113,'Chelva','BLANC','chelva');
INSERT INTO "grape_varieties" VALUES(100114,'Tinta Barroca','NOIR','tintabarroca');
INSERT INTO "grape_varieties" VALUES(100115,'Rubired','NOIR','rubired');
INSERT INTO "grape_varieties" VALUES(100116,'Durif','NOIR','durif petitesirah');
INSERT INTO "grape_varieties" VALUES(100117,'Yan 73','NOIR','yan73');
INSERT INTO "grape_varieties" VALUES(100118,'Inzolia','BLANC','inzolia');
INSERT INTO "grape_varieties" VALUES(100119,'Loureiro','BLANC','loureiro');
INSERT INTO "grape_varieties" VALUES(100120,'Marufo','NOIR','marufo');
INSERT INTO "grape_varieties" VALUES(100121,'Verdicchio Bianco','BLANC','verdicchiobianco verdicchio');
INSERT INTO "grape_varieties" VALUES(100122,'Gaglioppo','NOIR','gaglioppo');
INSERT INTO "grape_varieties" VALUES(100123,'Dolcetto','NOIR','dolcetto');
INSERT INTO "grape_varieties" VALUES(100124,'Vinhao','NOIR','vinhao');
INSERT INTO "grape_varieties" VALUES(100125,'Furmint','BLANC','furmint');
INSERT INTO "grape_varieties" VALUES(100126,'Alarije','BLANC','alarije');
INSERT INTO "grape_varieties" VALUES(100127,'Misket Cherven','GRIS','misketcherven');
INSERT INTO "grape_varieties" VALUES(100128,'Cserszegi Fűszeres','GRIS','cserszegifuszeres');
INSERT INTO "grape_varieties" VALUES(100129,'Prieto Picudo','NOIR','prietopicudo');
INSERT INTO "grape_varieties" VALUES(100130,'Aspiran Bouschet','NOIR','aspiranbouschet');
INSERT INTO "grape_varieties" VALUES(100131,'Zalema','BLANC','zalema');
INSERT INTO "grape_varieties" VALUES(100132,'Marselan','NOIR','marselan');
INSERT INTO "grape_varieties" VALUES(100133,'Sauvignonasse','BLANC','sauvignonasse friulano fruilano');
INSERT INTO "grape_varieties" VALUES(100134,'Torrontés Sanjuanino','BLANC','torrontessanjuanino');
INSERT INTO "grape_varieties" VALUES(100135,'Tsitska','BLANC','tsitska');
INSERT INTO "grape_varieties" VALUES(100136,'Falanghina Flegrea','BLANC','falanghinaflegrea falanghina');
INSERT INTO "grape_varieties" VALUES(100137,'Pardillo','BLANC','pardillo');
INSERT INTO "grape_varieties" VALUES(100138,'Malvasia Fina','BLANC','malvasiafina');
INSERT INTO "grape_varieties" VALUES(100139,'Agiorgitiko','NOIR','agiorgitiko');
INSERT INTO "grape_varieties" VALUES(100140,'Sankt Laurent','NOIR','sanktlaurent stlaurent');
INSERT INTO "grape_varieties" VALUES(100141,'Niagara','BLANC','niagara');
INSERT INTO "grape_varieties" VALUES(100142,'Fetească Neagră','NOIR','feteascaneagra');
INSERT INTO "grape_varieties" VALUES(100143,'Mavro','NOIR','mavro');
INSERT INTO "grape_varieties" VALUES(100144,'Gros Manseng','BLANC','grosmanseng');
INSERT INTO "grape_varieties" VALUES(100145,'Negramoll','NOIR','negramoll');
INSERT INTO "grape_varieties" VALUES(100146,'Graciano','NOIR','graciano');
INSERT INTO "grape_varieties" VALUES(100147,'Alvarelhão','NOIR','alvarelhao');
INSERT INTO "grape_varieties" VALUES(100148,'Kerner','BLANC','kerner');
INSERT INTO "grape_varieties" VALUES(100149,'Auxerrois','BLANC','auxerrois');
INSERT INTO "grape_varieties" VALUES(100150,'Listan Negro','NOIR','listannegro');
INSERT INTO "grape_varieties" VALUES(100151,'Malvazija Istarska','BLANC','malvazijaistarska');
INSERT INTO "grape_varieties" VALUES(100153,'Pervenets Magaracha','BLANC','pervenetsmagaracha');
INSERT INTO "grape_varieties" VALUES(100154,'Ancellotta','NOIR','ancellotta');
INSERT INTO "grape_varieties" VALUES(100155,'Seyval Blanc','BLANC','seyvalblanc');
INSERT INTO "grape_varieties" VALUES(100156,'Băbească Neagră','NOIR','babeascaneagra');
INSERT INTO "grape_varieties" VALUES(100157,'Croatina','NOIR','croatina');
INSERT INTO "grape_varieties" VALUES(100158,'Rondinella','NOIR','rondinella');
INSERT INTO "grape_varieties" VALUES(100159,'Liatiko','NOIR','liatiko');
INSERT INTO "grape_varieties" VALUES(100160,'Trebbiano d''Abruzzo','BLANC','trebbianodabruzzo');
INSERT INTO "grape_varieties" VALUES(100161,'Beba','BLANC','beba');
INSERT INTO "grape_varieties" VALUES(100162,'Nero di Troia','NOIR','neroditroia');
INSERT INTO "grape_varieties" VALUES(100163,'Odessky Cherny','NOIR','odesskycherny');
INSERT INTO "grape_varieties" VALUES(100164,'Trajadura','BLANC','trajadura');
INSERT INTO "grape_varieties" VALUES(100165,'Clairette','BLANC','clairette');
INSERT INTO "grape_varieties" VALUES(100166,'Cortese','BLANC','cortese');
INSERT INTO "grape_varieties" VALUES(100167,'Merseguera','BLANC','merseguera');
INSERT INTO "grape_varieties" VALUES(100168,'Trebbiano Giallo','BLANC','trebbianogiallo');
INSERT INTO "grape_varieties" VALUES(100169,'Savagnin Blanc','BLANC','savagninblanc');
INSERT INTO "grape_varieties" VALUES(100170,'Schiava Grossa','NOIR','schiavagrossa schiava');
INSERT INTO "grape_varieties" VALUES(100171,'Fiano','BLANC','fiano');
INSERT INTO "grape_varieties" VALUES(100172,'Malvasia','BLANC','malvasia');
INSERT INTO "grape_varieties" VALUES(100173,'Roussanne','BLANC','roussanne');
INSERT INTO "grape_varieties" VALUES(100174,'Couderc Noir','NOIR','coudercnoir');
INSERT INTO "grape_varieties" VALUES(100175,'Xinomavro','NOIR','xinomavro');
INSERT INTO "grape_varieties" VALUES(100176,'Greco Bianco','BLANC','grecobianco');
INSERT INTO "grape_varieties" VALUES(100177,'Regent','NOIR','regent');
INSERT INTO "grape_varieties" VALUES(100178,'Rabigato','BLANC','rabigato');
INSERT INTO "grape_varieties" VALUES(100179,'Grolleau Noir','NOIR','grolleaunoir');
INSERT INTO "grape_varieties" VALUES(100180,'Xynisteri','BLANC','xynisteri');
INSERT INTO "grape_varieties" VALUES(100181,'Vidal','BLANC','vidal');
INSERT INTO "grape_varieties" VALUES(100182,'Malvasia Preta','NOIR','malvasiapreta');
INSERT INTO "grape_varieties" VALUES(100183,'Rufete','NOIR','rufete');
INSERT INTO "grape_varieties" VALUES(100184,'Marsanne','BLANC','marsanne');
INSERT INTO "grape_varieties" VALUES(100185,'Grechetto di Orvieto','BLANC','grechettodiorvieto grechetto');
INSERT INTO "grape_varieties" VALUES(100187,'Nerello Mascalese','NOIR','nerellomascalese');
INSERT INTO "grape_varieties" VALUES(100188,'Irsai Olivér','BLANC','irsaioliver');
INSERT INTO "grape_varieties" VALUES(100189,'Assyrtiko','BLANC','assyrtiko');
INSERT INTO "grape_varieties" VALUES(100190,'Antao Vaz','BLANC','antaovaz');
INSERT INTO "grape_varieties" VALUES(100191,'Bacchus','BLANC','bacchus');
INSERT INTO "grape_varieties" VALUES(100192,'Pecorino','BLANC','pecorino');
INSERT INTO "grape_varieties" VALUES(100193,'Plavac Mali','NOIR','plavacmali');
INSERT INTO "grape_varieties" VALUES(100194,'Brachetto del Piemonte','NOIR','brachettodelpiemonte brachetto');
INSERT INTO "grape_varieties" VALUES(100195,'Fer','NOIR','fer');
INSERT INTO "grape_varieties" VALUES(100196,'Aletta','BLANC','aletta');
INSERT INTO "grape_varieties" VALUES(100197,'Cococciola','BLANC','cococciola');
INSERT INTO "grape_varieties" VALUES(100199,'Mavrouda','NOIR','mavrouda');
INSERT INTO "grape_varieties" VALUES(100200,'Moscato Giallo','BLANC','moscatogiallo');
INSERT INTO "grape_varieties" VALUES(100201,'Scheurebe','BLANC','scheurebe');
INSERT INTO "grape_varieties" VALUES(100202,'Kadarka','NOIR','kadarka');
INSERT INTO "grape_varieties" VALUES(100203,'Damaschino','BLANC','damaschino');
INSERT INTO "grape_varieties" VALUES(100204,'Hárslevelű','BLANC','harslevelu');
INSERT INTO "grape_varieties" VALUES(100205,'Öküzgözü','NOIR','okuzgozu');
INSERT INTO "grape_varieties" VALUES(100206,'Beibinghong','NOIR','beibinghong');
INSERT INTO "grape_varieties" VALUES(100207,'Folle Blanche','BLANC','folleblanche');
INSERT INTO "grape_varieties" VALUES(100208,'Piquepoul Blanc','BLANC','piquepoulblanc picpoul picpoulblanc');
INSERT INTO "grape_varieties" VALUES(100209,'Juan García','NOIR','juangarcia');
INSERT INTO "grape_varieties" VALUES(100210,'Mauzac Blanc','BLANC','mauzacblanc');
INSERT INTO "grape_varieties" VALUES(100211,'Verdelho','BLANC','verdelho');
INSERT INTO "grape_varieties" VALUES(100212,'Muscadelle','BLANC','muscadelle');
INSERT INTO "grape_varieties" VALUES(100213,'Garnacha Roja (Gris)','GRIS','garnacharojagris');
INSERT INTO "grape_varieties" VALUES(100214,'Glera Lunga','BLANC','proseccolungo gleralunga proseccolungo');
INSERT INTO "grape_varieties" VALUES(100215,'Azal','BLANC','azal');
INSERT INTO "grape_varieties" VALUES(100216,'Jacquez','NOIR','jacquez');
INSERT INTO "grape_varieties" VALUES(100218,'Boğazkere','NOIR','bogazkere');
INSERT INTO "grape_varieties" VALUES(100219,'Godello','BLANC','godello');
INSERT INTO "grape_varieties" VALUES(100220,'Prokupac','NOIR','prokupac');
INSERT INTO "grape_varieties" VALUES(100221,'Refosco','NOIR','refosco');
INSERT INTO "grape_varieties" VALUES(100222,'Kotsifali','NOIR','kotsifali');
INSERT INTO "grape_varieties" VALUES(100223,'Biancame','BLANC','biancame');
INSERT INTO "grape_varieties" VALUES(100224,'Petit Manseng','BLANC','petitmanseng');
INSERT INTO "grape_varieties" VALUES(100225,'Refosco dal Peduncolo Rosso','NOIR','refoscodalpeduncolorosso');
INSERT INTO "grape_varieties" VALUES(100226,'Malvasia Nera di Brindisi','NOIR','malvasianeradibrindisi');
INSERT INTO "grape_varieties" VALUES(100227,'Trousseau','NOIR','trousseau');
INSERT INTO "grape_varieties" VALUES(100228,'Zalagyöngye','BLANC','zalagyongye');
INSERT INTO "grape_varieties" VALUES(100229,'Malvasia Bianca Lunga','BLANC','malvasiabiancalunga');
INSERT INTO "grape_varieties" VALUES(100230,'Chinuri','BLANC','chinuri');
INSERT INTO "grape_varieties" VALUES(100231,'Blauburger','NOIR','blauburger');
INSERT INTO "grape_varieties" VALUES(100232,'Alfrocheiro','NOIR','alfrocheiro');
INSERT INTO "grape_varieties" VALUES(100233,'Malvasia di Candia Aromatica','BLANC','malvasiadicandiaaromatica');
INSERT INTO "grape_varieties" VALUES(100234,'Shiroka Melnishka','NOIR','shirokamelnishka');
INSERT INTO "grape_varieties" VALUES(100235,'Monica Nera','NOIR','monicanera');
INSERT INTO "grape_varieties" VALUES(100236,'Trepat','NOIR','trepat');
INSERT INTO "grape_varieties" VALUES(100237,'Mavrud','NOIR','mavrud');
INSERT INTO "grape_varieties" VALUES(100238,'Aramon Noir','NOIR','aramonnoir');
INSERT INTO "grape_varieties" VALUES(100239,'Arneis','BLANC','arneis');
INSERT INTO "grape_varieties" VALUES(100240,'Pignoletto','BLANC','pignoletto');
INSERT INTO "grape_varieties" VALUES(100241,'Albillo Mayor','BLANC','albillomayor');
INSERT INTO "grape_varieties" VALUES(100242,'Bombino Bianco','BLANC','bombinobianco');
INSERT INTO "grape_varieties" VALUES(100244,'Corvinone','NOIR','corvinone');
INSERT INTO "grape_varieties" VALUES(100245,'Romeiko','NOIR','romeiko');
INSERT INTO "grape_varieties" VALUES(100246,'Tinta Carvalha','NOIR','tintacarvalha');
INSERT INTO "grape_varieties" VALUES(100247,'Négrette','NOIR','negrette');
INSERT INTO "grape_varieties" VALUES(100248,'Diagalves','BLANC','diagalves');
INSERT INTO "grape_varieties" VALUES(100249,'Moschofilero','GRIS','moschofilero');
INSERT INTO "grape_varieties" VALUES(100251,'Bical','BLANC','bical');
INSERT INTO "grape_varieties" VALUES(100252,'Lambrusco Marani','NOIR','lambruscomarani');
INSERT INTO "grape_varieties" VALUES(100253,'Canaiolo Nero','NOIR','canaiolonero');
INSERT INTO "grape_varieties" VALUES(100254,'Sagrantino','NOIR','sagrantino');
INSERT INTO "grape_varieties" VALUES(100255,'Nuragus','BLANC','nuragus');
INSERT INTO "grape_varieties" VALUES(100256,'Longyan','NOIR','longyan');
INSERT INTO "grape_varieties" VALUES(100257,'Kunleány','BLANC','kunleany');
INSERT INTO "grape_varieties" VALUES(100258,'Elbling','BLANC','elbling');
INSERT INTO "grape_varieties" VALUES(100259,'Chambourcin','NOIR','chambourcin');
INSERT INTO "grape_varieties" VALUES(100260,'Ribolla Gialla','BLANC','ribollagialla');
INSERT INTO "grape_varieties" VALUES(100261,'Lambrusco Grasparossa','NOIR','lambruscograsparossa');
INSERT INTO "grape_varieties" VALUES(100262,'Passerina','BLANC','passerina');
INSERT INTO "grape_varieties" VALUES(100263,'Mandilaria','NOIR','mandilaria');
INSERT INTO "grape_varieties" VALUES(100264,'Viosinho','BLANC','viosinho');
INSERT INTO "grape_varieties" VALUES(100265,'Verdeca','BLANC','verdeca');
INSERT INTO "grape_varieties" VALUES(100266,'Mammolo','NOIR','mammolo');
INSERT INTO "grape_varieties" VALUES(100267,'Grignolino','NOIR','grignolino');
INSERT INTO "grape_varieties" VALUES(100268,'Garnacha Peluda','NOIR','garnachapeluda');
INSERT INTO "grape_varieties" VALUES(100269,'Ciliegiolo','NOIR','ciliegiolo');
INSERT INTO "grape_varieties" VALUES(100270,'Levokumskij','NOIR','levokumskij');
INSERT INTO "grape_varieties" VALUES(100271,'Planta Nova','BLANC','plantanova');
INSERT INTO "grape_varieties" VALUES(100273,'Vernaccia di San Gimignano','BLANC','vernacciadisangimignano');
INSERT INTO "grape_varieties" VALUES(100274,'Terret','BLANC','terret');
INSERT INTO "grape_varieties" VALUES(100275,'Bombino Nero','NOIR','bombinonero');
INSERT INTO "grape_varieties" VALUES(100276,'Lambrusco di Sorbara','NOIR','lambruscodisorbara');
INSERT INTO "grape_varieties" VALUES(100278,'Žametovka','NOIR','zametovka');
INSERT INTO "grape_varieties" VALUES(100279,'Çalkarası','NOIR','calkaras');
INSERT INTO "grape_varieties" VALUES(100280,'Narince','BLANC','narince');
INSERT INTO "grape_varieties" VALUES(100281,'Marzemino','NOIR','marzemino');
INSERT INTO "grape_varieties" VALUES(100282,'Duras','NOIR','duras');
INSERT INTO "grape_varieties" VALUES(100283,'Gibi','BLANC','gibi');
INSERT INTO "grape_varieties" VALUES(100284,'Királyleányka','BLANC','kiralyleanyka');
INSERT INTO "grape_varieties" VALUES(100285,'Albana','BLANC','albana');
INSERT INTO "grape_varieties" VALUES(100286,'Alb de Suruceni','BLANC','albdesuruceni');
INSERT INTO "grape_varieties" VALUES(100287,'Villard Noir','NOIR','villardnoir');
INSERT INTO "grape_varieties" VALUES(100288,'Teroldego','NOIR','teroldego');
INSERT INTO "grape_varieties" VALUES(100289,'Perruno','BLANC','perruno');
INSERT INTO "grape_varieties" VALUES(100290,'Muscat','BLANC','muscat');
INSERT INTO "grape_varieties" VALUES(100291,'Villard Blanc','BLANC','villardblanc');
INSERT INTO "grape_varieties" VALUES(100292,'Rojal Tinta','NOIR','rojaltinta');
INSERT INTO "grape_varieties" VALUES(100293,'Baco Noir','NOIR','baconoir');
INSERT INTO "grape_varieties" VALUES(100294,'Santarena','NOIR','santarena');
INSERT INTO "grape_varieties" VALUES(100295,'Leányka','BLANC','leanyka');
INSERT INTO "grape_varieties" VALUES(100296,'Ortrugo','BLANC','ortrugo');
INSERT INTO "grape_varieties" VALUES(100297,'Grand Noir','NOIR','grandnoir');
INSERT INTO "grape_varieties" VALUES(100298,'Kalecik Karası','NOIR','kalecikkaras');
INSERT INTO "grape_varieties" VALUES(100299,'Dimrit','NOIR','dimrit');
INSERT INTO "grape_varieties" VALUES(100300,'Schiava Lombarda','NOIR','schiavalombarda');
INSERT INTO "grape_varieties" VALUES(100301,'Avesso','BLANC','avesso');
INSERT INTO "grape_varieties" VALUES(100302,'Koshu','GRIS','koshu');
INSERT INTO "grape_varieties" VALUES(100303,'Verduzzo Friulano','BLANC','verduzzofriulano');
INSERT INTO "grape_varieties" VALUES(100305,'Plavina','NOIR','plavina');
INSERT INTO "grape_varieties" VALUES(100306,'Moscato Embrapa','BLANC','moscatoembrapa');
INSERT INTO "grape_varieties" VALUES(100307,'Malvasia del Lazio','BLANC','malvasiadellazio');
INSERT INTO "grape_varieties" VALUES(100308,'Magliocco Canino','NOIR','maglioccocanino');
INSERT INTO "grape_varieties" VALUES(100309,'Raboso Piave','NOIR','rabosopiave');
INSERT INTO "grape_varieties" VALUES(100310,'Zenit','BLANC','zenit');
INSERT INTO "grape_varieties" VALUES(100311,'Vital','BLANC','vital');
INSERT INTO "grape_varieties" VALUES(100312,'Kövidinka','GRIS','kovidinka');
INSERT INTO "grape_varieties" VALUES(100313,'Torrontes Mendocino','BLANC','torrontesmendocino');
INSERT INTO "grape_varieties" VALUES(100314,'Vilana','BLANC','vilana');
INSERT INTO "grape_varieties" VALUES(100315,'Symphony','BLANC','symphony');
INSERT INTO "grape_varieties" VALUES(100316,'Bayanshira','BLANC','bayanshira');
INSERT INTO "grape_varieties" VALUES(100317,'Violeta','NOIR','violeta');
INSERT INTO "grape_varieties" VALUES(100318,'Ezerjó','BLANC','ezerjo');
INSERT INTO "grape_varieties" VALUES(100319,'Alphonse Lavallée','NOIR','alphonselavallee');
INSERT INTO "grape_varieties" VALUES(100320,'Grasă de Cotnari','BLANC','grasadecotnari');
INSERT INTO "grape_varieties" VALUES(100321,'Catawba','NOIR','catawba');
INSERT INTO "grape_varieties" VALUES(100322,'Hondarribi Zuri','BLANC','hondarribizuri');
INSERT INTO "grape_varieties" VALUES(100323,'Jacquere','BLANC','jacquere');
INSERT INTO "grape_varieties" VALUES(100325,'Béquignol Noir','NOIR','bequignolnoir');
INSERT INTO "grape_varieties" VALUES(100326,'Molinara','NOIR','molinara');
INSERT INTO "grape_varieties" VALUES(100327,'Jurançon Noir','NOIR','juranconnoir');
INSERT INTO "grape_varieties" VALUES(100328,'Len de l''El','BLANC','lendelel');
INSERT INTO "grape_varieties" VALUES(100329,'Albillo Real','BLANC','albilloreal');
INSERT INTO "grape_varieties" VALUES(100330,'Piedirosso','NOIR','piedirosso');
INSERT INTO "grape_varieties" VALUES(100331,'Arany Sárfehér','BLANC','aranysarfeher');
INSERT INTO "grape_varieties" VALUES(100332,'Gouveio Real','BLANC','gouveioreal');
INSERT INTO "grape_varieties" VALUES(100333,'Frappato','NOIR','frappato');
INSERT INTO "grape_varieties" VALUES(100334,'Neuburger','BLANC','neuburger');
INSERT INTO "grape_varieties" VALUES(100335,'Athiri','BLANC','athiri');
INSERT INTO "grape_varieties" VALUES(100336,'Cora','NOIR','cora');
INSERT INTO "grape_varieties" VALUES(100337,'Riton','BLANC','riton');
INSERT INTO "grape_varieties" VALUES(100338,'Montonico Bianco','BLANC','montonicobianco');
INSERT INTO "grape_varieties" VALUES(100339,'Rabo de Ovelha','BLANC','rabodeovelha');
INSERT INTO "grape_varieties" VALUES(100340,'Krasnostop Zolotovsky','NOIR','krasnostopzolotovsky');
INSERT INTO "grape_varieties" VALUES(100341,'Viorika','BLANC','viorika');
INSERT INTO "grape_varieties" VALUES(100342,'Chasan','BLANC','chasan');
INSERT INTO "grape_varieties" VALUES(100343,'Uva Longanesi','NOIR','uvalonganesi');
INSERT INTO "grape_varieties" VALUES(100344,'Aubun','NOIR','aubun');
INSERT INTO "grape_varieties" VALUES(100345,'Forcallat Tinta','NOIR','forcallattinta');
INSERT INTO "grape_varieties" VALUES(100346,'Ortega','BLANC','ortega');
INSERT INTO "grape_varieties" VALUES(100347,'Verduzzo Trevigiano','BLANC','verduzzotrevigiano');
INSERT INTO "grape_varieties" VALUES(100348,'Baco Blanc','BLANC','bacoblanc');
INSERT INTO "grape_varieties" VALUES(100349,'Freisa','NOIR','freisa');
INSERT INTO "grape_varieties" VALUES(100350,'Borraçal','NOIR','borracal');
INSERT INTO "grape_varieties" VALUES(100351,'Carrega Branco','BLANC','carregabranco');
INSERT INTO "grape_varieties" VALUES(100352,'Cornifesto','NOIR','cornifesto');
INSERT INTO "grape_varieties" VALUES(100353,'Župljanka','BLANC','zupljanka');
INSERT INTO "grape_varieties" VALUES(100354,'Bourboulenc','BLANC','bourboulenc');
INSERT INTO "grape_varieties" VALUES(100355,'Sheridan','NOIR','sheridan');
INSERT INTO "grape_varieties" VALUES(100356,'Lorena','BLANC','lorena');
INSERT INTO "grape_varieties" VALUES(100357,'Onitskanskii Belyi','BLANC','onitskanskiibelyi');
INSERT INTO "grape_varieties" VALUES(100358,'Arinarnoa','NOIR','arinarnoa');
INSERT INTO "grape_varieties" VALUES(100359,'Dunavski Lazur','BLANC','dunavskilazur');
INSERT INTO "grape_varieties" VALUES(100360,'Seibel','NOIR','seibel');
INSERT INTO "grape_varieties" VALUES(100361,'Durella','BLANC','durella');
INSERT INTO "grape_varieties" VALUES(100362,'Acolon','NOIR','acolon');
INSERT INTO "grape_varieties" VALUES(100363,'Couderc 13','BLANC','couderc13');
INSERT INTO "grape_varieties" VALUES(100364,'Seara Nova','BLANC','searanova');
INSERT INTO "grape_varieties" VALUES(100365,'Fortana','NOIR','fortana');
INSERT INTO "grape_varieties" VALUES(100366,'Niagara Red','NOIR','niagarared');
INSERT INTO "grape_varieties" VALUES(100367,'Listain de Huelva','BLANC','listaindehuelva');
INSERT INTO "grape_varieties" VALUES(100368,'Huxelrebe','BLANC','huxelrebe');
INSERT INTO "grape_varieties" VALUES(100369,'Codega de Larinho','BLANC','codegadelarinho');
INSERT INTO "grape_varieties" VALUES(100370,'Chenanson','NOIR','chenanson');
INSERT INTO "grape_varieties" VALUES(100371,'Tsimlyansky Cherny','NOIR','tsimlyanskycherny');
INSERT INTO "grape_varieties" VALUES(100372,'Crimposie','BLANC','crimposie');
INSERT INTO "grape_varieties" VALUES(100373,'Cesanese','NOIR','cesanese');
INSERT INTO "grape_varieties" VALUES(100374,'Gamaret','NOIR','gamaret');
INSERT INTO "grape_varieties" VALUES(100375,'Morio-Muskat','BLANC','moriomuskat');
INSERT INTO "grape_varieties" VALUES(100376,'Greco Nero','NOIR','greconero');
INSERT INTO "grape_varieties" VALUES(100377,'Blauer Wildbacher','NOIR','blauerwildbacher');
INSERT INTO "grape_varieties" VALUES(100378,'Tibouren','NOIR','tibouren');
INSERT INTO "grape_varieties" VALUES(100379,'Nouvelle','BLANC','nouvelle');
INSERT INTO "grape_varieties" VALUES(100380,'Delaware','GRIS','delaware');
INSERT INTO "grape_varieties" VALUES(100381,'Plantet','NOIR','plantet');
INSERT INTO "grape_varieties" VALUES(100382,'Counoise','NOIR','counoise');
INSERT INTO "grape_varieties" VALUES(100383,'Galbenă de Odobești','BLANC','galbenadeodobesti');
INSERT INTO "grape_varieties" VALUES(100384,'Pineau d''Aunis','NOIR','pineaudaunis');
INSERT INTO "grape_varieties" VALUES(100385,'Triplett Blanc','BLANC','triplettblanc');
INSERT INTO "grape_varieties" VALUES(100386,'Sukholimansky Bely','BLANC','sukholimanskybely');
INSERT INTO "grape_varieties" VALUES(100387,'Stanušina Crna','NOIR','stanusinacrna');
INSERT INTO "grape_varieties" VALUES(100388,'Frühroter Veltliner','NOIR','fruhroterveltliner');
INSERT INTO "grape_varieties" VALUES(100389,'Kuldzhinskii','GRIS','kuldzhinskii');
INSERT INTO "grape_varieties" VALUES(100390,'Domina','NOIR','domina');
INSERT INTO "grape_varieties" VALUES(100391,'Tinto Cão','NOIR','tintocao');
INSERT INTO "grape_varieties" VALUES(100392,'Vijariego','BLANC','vijariego');
INSERT INTO "grape_varieties" VALUES(100393,'Frâncușă','BLANC','francusa');
INSERT INTO "grape_varieties" VALUES(100394,'Espadeiro','NOIR','espadeiro');
INSERT INTO "grape_varieties" VALUES(100395,'Cabinda','NOIR','cabinda');
INSERT INTO "grape_varieties" VALUES(100397,'Tinta da Barca','NOIR','tintadabarca');
INSERT INTO "grape_varieties" VALUES(100398,'Lairen','BLANC','lairen');
INSERT INTO "grape_varieties" VALUES(100399,'Salvador','NOIR','salvador');
INSERT INTO "grape_varieties" VALUES(100400,'Busuioacă de Bohotin','GRIS','busuioacadebohotin');
INSERT INTO "grape_varieties" VALUES(100401,'Manzoni Bianco','BLANC','manzonibianco');
INSERT INTO "grape_varieties" VALUES(100402,'Faberrebe','BLANC','faberrebe');
INSERT INTO "grape_varieties" VALUES(100403,'Quebranta','NOIR','quebranta');
INSERT INTO "grape_varieties" VALUES(100404,'Traminer','BLANC','traminer');
INSERT INTO "grape_varieties" VALUES(100405,'Areni noir','NOIR','areninoir');
INSERT INTO "grape_varieties" VALUES(100406,'Encruzado','BLANC','encruzado');
INSERT INTO "grape_varieties" VALUES(100407,'Erbaluce','BLANC','erbaluce');
INSERT INTO "grape_varieties" VALUES(100408,'Norton','NOIR','norton');
INSERT INTO "grape_varieties" VALUES(100409,'Picolit','BLANC','picolit');
INSERT INTO "grape_varieties" VALUES(100410,'Picapoll Blanc','BLANC','picapollblanc picapoll');
INSERT INTO "grape_varieties" VALUES(100411,'Goruli Mtsvane','BLANC','gorulimtsvane');
INSERT INTO "grape_varieties" VALUES(100412,'Mtsvane Kakhuri','BLANC','mtsvanekakhuri kakhurimtsvane');
INSERT INTO "grape_varieties" VALUES(100413,'Khikhvi','BLANC','khikhvi');
INSERT INTO "grape_varieties" VALUES(100414,'Kisi','BLANC','kisi');
INSERT INTO "grape_varieties" VALUES(100415,'Krakhuna','BLANC','krakhuna');
INSERT INTO "grape_varieties" VALUES(100416,'Rachuli Tetra','BLANC','rachulitetra rachulitsulukidzistetra tsulukidzistetra');
INSERT INTO "grape_varieties" VALUES(100417,'Sakmiela','BLANC','sakmiela');
INSERT INTO "grape_varieties" VALUES(100418,'Tavkveri','NOIR','tavkveri');
INSERT INTO "grape_varieties" VALUES(100419,'Shavkapito','NOIR','shavkapito');
INSERT INTO "grape_varieties" VALUES(100420,'Ojaleshi','NOIR','ojaleshi');
INSERT INTO "grape_varieties" VALUES(100421,'Aleksandrouli','NOIR','aleksandrouli alexandrouli');
INSERT INTO "grape_varieties" VALUES(100422,'Mujuretuli','NOIR','mujuretuli mudjuretuli');
INSERT INTO "grape_varieties" VALUES(100423,'Chkhaveri','ROSE','chkhaveri');
INSERT INTO "grape_varieties" VALUES(100424,'Shesh i Zi','NOIR','sheshizi');
INSERT INTO "grape_varieties" VALUES(100425,'Serina e Zezë','NOIR','serinaezeze');
INSERT INTO "grape_varieties" VALUES(100426,'Vlosh','NOIR','vlosh');
INSERT INTO "grape_varieties" VALUES(100427,'Haghtanak','NOIR','haghtanak akhtanak');
INSERT INTO "grape_varieties" VALUES(100428,'Karmrahyut','NOIR','karmrahyut');
INSERT INTO "grape_varieties" VALUES(100429,'Khndoghni','NOIR','khndoghni khindogni sireni');
INSERT INTO "grape_varieties" VALUES(100430,'Kakhet','NOIR','kakhet milagh');
INSERT INTO "grape_varieties" VALUES(100431,'Rösler','NOIR','rosler');
INSERT INTO "grape_varieties" VALUES(100432,'Cabernet Cortis','NOIR','cabernetcortis');
INSERT INTO "grape_varieties" VALUES(100433,'Cabernet Dorsa','NOIR','cabernetdorsa');
INSERT INTO "grape_varieties" VALUES(100434,'Cabaret Noir','NOIR','cabaretnoir');
INSERT INTO "grape_varieties" VALUES(100435,'Pinotin','NOIR','pinotin');
INSERT INTO "grape_varieties" VALUES(100436,'Bordô','NOIR','bordo ives ivesseedling');
INSERT INTO "grape_varieties" VALUES(100437,'Babić','NOIR','babic');
INSERT INTO "grape_varieties" VALUES(100438,'Maratheftiko','NOIR','maratheftiko');
INSERT INTO "grape_varieties" VALUES(100439,'Lefkada','NOIR','lefkada');
INSERT INTO "grape_varieties" VALUES(100440,'Ofthalmo','NOIR','ofthalmo');
INSERT INTO "grape_varieties" VALUES(100441,'Cabernet Moravia','NOIR','cabernetmoravia');
INSERT INTO "grape_varieties" VALUES(100442,'Rondo','NOIR','rondo');
INSERT INTO "grape_varieties" VALUES(100443,'Léon Millot','NOIR','leonmillot');
INSERT INTO "grape_varieties" VALUES(100444,'Pinot Noir Précoce','NOIR','pinotnoirprecoce fruhburgunder');
INSERT INTO "grape_varieties" VALUES(100445,'Argaman','NOIR','argaman');
INSERT INTO "grape_varieties" VALUES(100446,'Muscat Bailey A','NOIR','muscatbaileya');
INSERT INTO "grape_varieties" VALUES(100447,'Campbell Early','NOIR','campbellearly');
INSERT INTO "grape_varieties" VALUES(100448,'Yama Sauvignon','NOIR','yamasauvignon');
INSERT INTO "grape_varieties" VALUES(100449,'Marquette','NOIR','marquette');
INSERT INTO "grape_varieties" VALUES(100450,'Maréchal Foch','NOIR','marechalfoch');
INSERT INTO "grape_varieties" VALUES(100451,'Cabernet Cantor','NOIR','cabernetcantor');
INSERT INTO "grape_varieties" VALUES(100452,'Zilga','NOIR','zilga');
INSERT INTO "grape_varieties" VALUES(100453,'Saint Croix','NOIR','saintcroix stcroix');
INSERT INTO "grape_varieties" VALUES(100454,'Garanoir','NOIR','garanoir');
INSERT INTO "grape_varieties" VALUES(100455,'Diolinoir','NOIR','diolinoir');
INSERT INTO "grape_varieties" VALUES(100456,'Cornalin du Valais','NOIR','cornalinduvalais rougedupays landroter');
INSERT INTO "grape_varieties" VALUES(100457,'Humagne Rouge','NOIR','humagnerouge cornalindaoste');
INSERT INTO "grape_varieties" VALUES(100458,'Blatina','NOIR','blatina');
INSERT INTO "grape_varieties" VALUES(100459,'Trnjak','NOIR','trnjak');
INSERT INTO "grape_varieties" VALUES(100460,'Ġellewża','NOIR','gellewza');
INSERT INTO "grape_varieties" VALUES(100461,'Madrasa','NOIR','madrasa matrasa');
INSERT INTO "grape_varieties" VALUES(100462,'Vischoqueña','NOIR','vischoquena');
INSERT INTO "grape_varieties" VALUES(100463,'Limnio','NOIR','limnio');
INSERT INTO "grape_varieties" VALUES(100464,'Mavrodaphne','NOIR','mavrodaphne');
INSERT INTO "grape_varieties" VALUES(100465,'Mavrotragano','NOIR','mavrotragano');
INSERT INTO "grape_varieties" VALUES(100466,'Shesh i Bardhë','BLANC','sheshibardhe');
INSERT INTO "grape_varieties" VALUES(100467,'Pulës','BLANC','pules');
INSERT INTO "grape_varieties" VALUES(100468,'Debinë e Bardhë','BLANC','debineebardhe');
INSERT INTO "grape_varieties" VALUES(100469,'Kangun','BLANC','kangun');
INSERT INTO "grape_varieties" VALUES(100470,'Voskehat','BLANC','voskehat voskeat');
INSERT INTO "grape_varieties" VALUES(100471,'Lalvari','BLANC','lalvari');
INSERT INTO "grape_varieties" VALUES(100472,'Chilar','BLANC','chilar');
INSERT INTO "grape_varieties" VALUES(100473,'Garan Dmak','BLANC','garandmak garandmak');
INSERT INTO "grape_varieties" VALUES(100474,'Johanniter','BLANC','johanniter');
INSERT INTO "grape_varieties" VALUES(100475,'Solaris','BLANC','solaris');
INSERT INTO "grape_varieties" VALUES(100476,'Muscaris','BLANC','muscaris');
INSERT INTO "grape_varieties" VALUES(100477,'Sauvignac','BLANC','sauvignac');
INSERT INTO "grape_varieties" VALUES(100478,'Bronner','BLANC','bronner');
INSERT INTO "grape_varieties" VALUES(100479,'Pošip','BLANC','posip posipbijeli');
INSERT INTO "grape_varieties" VALUES(100480,'Debit','BLANC','debit');
INSERT INTO "grape_varieties" VALUES(100481,'Kujundžuša','BLANC','kujundzusa');
INSERT INTO "grape_varieties" VALUES(100482,'Promara','BLANC','promara');
INSERT INTO "grape_varieties" VALUES(100483,'Morokanela','BLANC','morokanela');
INSERT INTO "grape_varieties" VALUES(100484,'Pálava','ROSE','palava');
INSERT INTO "grape_varieties" VALUES(100485,'Muškát moravský','BLANC','muskatmoravsky muskatmoravsky');
INSERT INTO "grape_varieties" VALUES(100486,'Orion','BLANC','orion');
INSERT INTO "grape_varieties" VALUES(100487,'Phoenix','BLANC','phoenix');
INSERT INTO "grape_varieties" VALUES(100488,'Malagousia','BLANC','malagousia');
INSERT INTO "grape_varieties" VALUES(100489,'Emerald Riesling','BLANC','emeraldriesling');
INSERT INTO "grape_varieties" VALUES(100490,'Frontenac Blanc','BLANC','frontenacblanc');
INSERT INTO "grape_varieties" VALUES(100491,'Saint Pepin','BLANC','saintpepin stpepin');
INSERT INTO "grape_varieties" VALUES(100492,'La Crescent','BLANC','lacrescent');
INSERT INTO "grape_varieties" VALUES(100493,'Villaris','BLANC','villaris');
INSERT INTO "grape_varieties" VALUES(100494,'Hibernal','BLANC','hibernal');
INSERT INTO "grape_varieties" VALUES(100495,'Petite Arvine','BLANC','petitearvine arvine');
INSERT INTO "grape_varieties" VALUES(100496,'Emir','BLANC','emir');
INSERT INTO "grape_varieties" VALUES(100497,'Vasilaki','BLANC','vasilaki');
INSERT INTO "grape_varieties" VALUES(100498,'Reichensteiner','BLANC','reichensteiner');
INSERT INTO "grape_varieties" VALUES(100499,'Șarba','BLANC','sarba');
INSERT INTO "grape_varieties" VALUES(100500,'Plăvaie','BLANC','plavaie');
INSERT INTO "grape_varieties" VALUES(100501,'Mustoasă de Măderat','BLANC','mustoasademaderat');
INSERT INTO "grape_varieties" VALUES(100502,'Băbească Gri','GRIS','babeascagri');
INSERT INTO "grape_varieties" VALUES(100503,'Žilavka','BLANC','zilavka');
INSERT INTO "grape_varieties" VALUES(100504,'Krstač','BLANC','krstac');
INSERT INTO "grape_varieties" VALUES(100505,'Žižak','BLANC','zizak');
INSERT INTO "grape_varieties" VALUES(100506,'Girgentina','BLANC','girgentina ghirgentina');
INSERT INTO "grape_varieties" VALUES(100507,'Robola','BLANC','robola');
INSERT INTO "grape_varieties" VALUES(100508,'Vidiano','BLANC','vidiano');
CREATE TABLE guest_sessions (id text PRIMARY KEY NOT NULL, expires integer NOT NULL);
CREATE TABLE `identities` (
	`identity` text PRIMARY KEY NOT NULL,
	`profile_id` text NOT NULL
);
CREATE TABLE `managed_prices` (
	`id` text PRIMARY KEY NOT NULL,
	`environment` text NOT NULL,
	`account` text NOT NULL,
	`plan` text NOT NULL,
	`amount` integer NOT NULL,
	`active` integer NOT NULL,
	`created_at` integer NOT NULL
);
CREATE TABLE `members` (
	`event_id` text NOT NULL,
	`profile_id` text NOT NULL, `completed` integer DEFAULT 0 NOT NULL, history_hidden INTEGER NOT NULL DEFAULT 0, history_favorite INTEGER NOT NULL DEFAULT 0,
	PRIMARY KEY(`event_id`, `profile_id`)
);
CREATE TABLE password_reset_limits(id text PRIMARY KEY NOT NULL,count integer NOT NULL,since integer NOT NULL);
CREATE TABLE password_resets(token_hash text PRIMARY KEY NOT NULL,profile_id text NOT NULL,password_snapshot text NOT NULL,email_snapshot text NOT NULL,expires integer NOT NULL);
CREATE TABLE `profile_reminders` (
	`profile_id` text NOT NULL,
	`kind` text NOT NULL,
	`shown_day` text NOT NULL,
	`shown_at` integer NOT NULL,
	PRIMARY KEY(`profile_id`, `kind`),
	FOREIGN KEY (`profile_id`) REFERENCES `profiles`(`id`) ON UPDATE no action ON DELETE cascade
);
CREATE TABLE `profiles` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`dob` text NOT NULL,
	`gender` text NOT NULL,
	`host` integer DEFAULT 0 NOT NULL,
	`username` text,
	`password` text,
	`recovery` text NOT NULL,
	`catalog` text DEFAULT '[]' NOT NULL
, recovery_code text, created_at INTEGER, last_active_at INTEGER, blocked INTEGER NOT NULL DEFAULT 0, recovery_email text, trial_started_at integer, `language` text, `primary_email` text, `email_verified_at` integer, `recovery_cipher` text);
CREATE TABLE `push_deliveries` (
	`subscription_id` text NOT NULL,
	`day` text NOT NULL,
	`kind` text NOT NULL,
	`sent_at` integer NOT NULL,
	PRIMARY KEY(`subscription_id`, `day`, `kind`),
	FOREIGN KEY (`subscription_id`) REFERENCES `push_subscriptions`(`id`) ON UPDATE no action ON DELETE cascade
);
CREATE TABLE `push_subscriptions` (
	`id` text PRIMARY KEY NOT NULL,
	`profile_id` text NOT NULL,
	`identity` text NOT NULL,
	`endpoint` text NOT NULL,
	`p256dh` text NOT NULL,
	`auth` text NOT NULL,
	`next_check` integer DEFAULT 0 NOT NULL,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`profile_id`) REFERENCES `profiles`(`id`) ON UPDATE no action ON DELETE cascade
);
CREATE TABLE `reviews` (
	`event_id` text NOT NULL,
	`profile_id` text NOT NULL,
	`wine_id` text NOT NULL,
	`data` text NOT NULL,
	PRIMARY KEY(`event_id`, `profile_id`, `wine_id`)
);
CREATE TABLE `trial_email_ledger` (
	`fingerprint` text PRIMARY KEY NOT NULL,
	`used_at` integer NOT NULL
);
CREATE TABLE `wine_catalog` (
	`id` text PRIMARY KEY NOT NULL,
	`data` text NOT NULL,
	`source_url` text NOT NULL,
	`checked_at` text NOT NULL
);
CREATE UNIQUE INDEX `events_code_unique` ON `events` (`code`);
CREATE UNIQUE INDEX `profiles_username_unique` ON `profiles` (`username`);
CREATE INDEX password_resets_profile ON password_resets(profile_id);
CREATE UNIQUE INDEX `billing_customer_remote_unique` ON `billing_customers` (`provider`,`environment`,`provider_account_id`,`provider_customer_id`);
CREATE UNIQUE INDEX `billing_customer_profile_unique` ON `billing_customers` (`profile_id`,`provider`,`environment`,`provider_account_id`);
CREATE INDEX `billing_event_retry_idx` ON `billing_events` (`processing_status`,`received_at`);
CREATE UNIQUE INDEX `billing_subscription_remote_unique` ON `billing_subscriptions` (`provider`,`environment`,`provider_account_id`,`provider_subscription_id`);
CREATE INDEX `billing_subscription_profile_idx` ON `billing_subscriptions` (`profile_id`,`environment`,`access_expires_at`);
CREATE INDEX `billing_subscription_customer_idx` ON `billing_subscriptions` (`provider`,`environment`,`provider_account_id`,`provider_customer_id`);
CREATE UNIQUE INDEX `billing_checkouts_id_unique` ON `billing_checkouts` (`id`);
CREATE UNIQUE INDEX `push_subscriptions_endpoint_unique` ON `push_subscriptions` (`endpoint`);
CREATE UNIQUE INDEX `email_verifications_email_unique` ON `email_verifications` (`email`);
CREATE UNIQUE INDEX `email_verifications_token_hash_unique` ON `email_verifications` (`token_hash`);
CREATE UNIQUE INDEX `profiles_primary_email_unique` ON `profiles` (`primary_email`) WHERE "profiles"."primary_email" IS NOT NULL;
CREATE UNIQUE INDEX `admin_challenges_token_hash_unique` ON `admin_challenges` (`token_hash`);
