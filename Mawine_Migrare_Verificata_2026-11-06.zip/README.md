# Mawine — pachet complet pentru migrare curată

Destinație: https://mawine.app · Expeditor: no-reply@mawine.app

## Stare reală

Pachetul este pregătit pentru Cloudflare Workers + D1. NU este un instalator pentru
un VPS Node/PHP/MySQL. Dacă serverul final este un VPS, trebuie ales adaptorul de
rulare și portată integrarea `cloudflare:workers`/D1 înainte de lansare.
Nu s-au modificat conturi sau date în baza de date curentă.
Nu conține secrete, parole existente, sesiuni, clienți Stripe sau utilizatori existenți.
Conține sursa fără istoricul Git, resurse, build, schema și catalogul de soiuri,
baza curată, verificări SHA-256, ghid și procedură de inițializare admin.
Fișierele Excel demonstrative din testele de import nu sunt incluse.

Singurul cont inițial: **radugbr88@gmail.com**, administrator separat, fără profil gazdă și fără
parolă implicită. Contul este blocat până la setarea parolei pe mașina destinație.
Se importă baza curată furnizată; nu se reaplică migrațiile peste ea.

## Instalare pe infrastructura compatibilă

1. Verifică integritatea arhivei: `sha256sum -c SHA256SUMS` din directorul extras.
2. Instalează Node >=22.13, pnpm 11.25.0, Python 3. În `source`:
   `pnpm install --frozen-lockfile`.
3. Autentifică Wrangler în contul Cloudflare destinație. Creează o bază D1 NOUĂ:
   `pnpm exec wrangler d1 create mawine-production`.
4. Completează ID-ul D1 în `source/wrangler.migration.json`. Nu folosi baza actuală.
5. Din `source`, importă numai în baza nouă goală:
   `pnpm exec wrangler d1 execute mawine-production --remote --config wrangler.migration.json --file ../database-clean.sql`.
   Nu executa apoi `d1 migrations apply` pentru migrațiile deja incluse: schema e deja completă.
6. Verifică în D1: `profiles`, `events`, `members`, `reviews`, `identities`,
   `guest_sessions`, `admin_sessions`, toate tabelele billing: zero rânduri;
   `admin_accounts`: exact `radugbr88@gmail.com`, parola NULL; catalog soiuri: vezi VERIFICATION.json.
7. Pe mașina privată rulează `python3 migration/set-admin-password.py`, introdu parola
   fără a o pune în comandă/chat, apoi aplică SQL-ul rezultat numai în baza nouă:
   `pnpm exec wrangler d1 execute mawine-production --remote --config wrangler.migration.json --file admin-password-once.sql`.
   Șterge fișierul imediat după utilizare. Nu este necesară cheia veche de activare admin.
8. Completează variabilele non-secrete cu datele verificate ale conturilor destinație.
   Câmpurile REPLACE sunt intenționat necompletate; nu sunt valori funcționale.
   Fișierul pornește în mod test, încasările reale sunt dezactivate.
9. Secretele nu sunt introduse de acest pachet: STRIPE_SECRET_KEY,
   STRIPE_WEBHOOK_SECRET, CLOUDFLARE_EMAIL_API_TOKEN se introduc separat, securizat.
10. Build-ul existent se poate publica cu
    `pnpm exec wrangler deploy --config wrangler.migration.json`.
    Pentru reconstrucție: `pnpm run build`, apoi aceeași comandă deploy.
11. Configurează domeniul în contul Cloudflare, verifică DNS și HTTPS. `workers_dev`
    este oprit; domeniul nou nu trebuie expus public înainte de verificările de lansare.
12. Verifică login admin, înregistrare 18+, logout/login, cele patru limbi,
    colecție/import, degustare/invitații, recuperare, plăți și notificări.

## Stripe — ce mai trebuie în afara cheilor

Contul configurat anterior: acct_1UWKZuPCFCfe1Mff. În această sesiune este conectat
numai alt cont live, BestFoodImporters; nu s-au accesat/modificat obiectele lui.
Prețurile configurate anterior (NEVERIFICATE remote):
- lunar: price_1UXM97PCFCfe1MffEJWBmSgB, 999 cenți USD/lună;
- anual: price_1UXMBFPCFCfe1MffqTxlVOcK, 9900 cenți USD/an;
- portal: bpc_1UXOTIPCFCfe1MfflvC4nihJ.

În contul CORECT trebuie verificate/realizate:
- un produs activ Plan Gazdă și cele două prețuri recurente active, aceeași monedă;
- ambele prețuri ale ACELUIAȘI produs pentru schimbare programată anual → lunar;
- portal activ cu ambele prețuri permise, anulare `at_period_end`, actualizare
  de preț și `schedule_at_period_end.conditions` cu `shortening_interval`;
- anual → lunar la sfârșitul anului plătit, fără rambursare automată;
- lunar → anual imediat la confirmare, cu ajustare pentru timpul lunar nefolosit;
  portalul trebuie să aibă `subscription_update.proration_behavior=always_invoice`,
  `billing_cycle_anchor=now`, `default_allowed_updates=["price"]`, ambele prețuri în același produs și DOAR
  condiția `shortening_interval` în `schedule_at_period_end.conditions`;
  Stripe calculează și prezintă suma înainte de confirmare. Configurațiile care
  elimină ajustarea sau programează altă direcție sunt refuzate de aplicație;
- setări de facturare, chitanțe, recuperare plăți, taxe și datele firmei;
- linkuri termeni/confidențialitate ale domeniului final, branding, monedă USD;
- webhook https://mawine.app/api/stripe/webhook, evenimente snapshot/API
  2026-09-30.endive. Lista exactă: `STRIPE_EVENTS` din `source/app/billing.ts`;
- return Checkout: https://mawine.app/?billing=success și ?billing=cancel;
  return Portal: https://mawine.app/?billing=portal;
- un profil de test gazdă creat pe baza nouă, înscris în STRIPE_TEST_USERNAMES.
  Adminul separat nu este client Stripe și nu este automat gazdă.
- test real Sandbox pentru Checkout, 3DS/refuz, webhook/retry, reînnoire, anulare,
  schimbare anual/lunar și revenire la participant; mock-urile nu verifică Stripe remote.
- lansare: identificatori LIVE distinct verificați, apoi STRIPE_MODE=live și
  STRIPE_LIVE_ENABLED=true; STRIPE_ENFORCE_ACCESS=true este deja în șablon.

Documentație Stripe verificată: https://docs.stripe.com/customer-management/configure-portal
și https://docs.stripe.com/changelog/acacia/2024-10-28/customer-portal-schedule-downgrades .
Nu sunt necesare linkuri Payment Links statice: aplicația creează Checkout și Portal
pe server pentru profilul autentificat.
Ultimele 48 de ore sunt acceptate: Checkout folosește `billing_cycle_anchor` la
sfârșitul gratuității și `proration_behavior=none`. Pentru o gratuitate mai lungă
folosește `trial_end`. Nu se încasează anticipat și nu se prelungește gratuitatea.
Referință: https://docs.stripe.com/billing/subscriptions/billing-cycle .
Scenariile sunt testate local cu Stripe simulat; trebuie rulate și în Sandbox.

## Domeniu, e-mail, date și restaurare

Verifică DNS/HTTPS, SPF/DKIM/DMARC și autorizarea serviciului Cloudflare Email Sending
pentru `no-reply@mawine.app`. Nu sunt confirmate în acest audit.
Recuperarea existentă trimite un LINK unic valabil o oră, nu un cod numeric.
Confirmă livrarea în inbox și invalidarea după utilizare pe un cont controlat.
Nu importa utilizatorii, facturile sau sesiunile vechi. Cookie-urile vechi nu se mută.
Rutele demo sunt păstrate; `/api/demo` creează o gazdă fictivă numai la solicitarea
unei demonstrații, nu la importul bazei. Vizitarea site-ului poate crea sesiuni noi.
Politica actuală păstrează datele la anulare/expirare, cu 3 zile de grație după
perioada achitată/trial și apoi participant. Notificările apar în aplicație.

Nu publica simultan două baze independente pentru același trafic real. Păstrează
vechea aplicație pentru rollback, fără a redirecționa invitații vechi către baza goală:
acele coduri nu există pe noua instalație. Configurează backupuri D1 după lansare.
Pachetul acesta este un backup al aplicației pentru instalare CURATĂ, nu un export
al datelor actualilor utilizatori, excluse explicit la cerere.

Verdict: pachet verificat local; lansarea finală rămâne condiționată de alegerea
hostingului compatibil, verificarea contului Stripe corect și configurarea serviciilor.

## Verificare înainte de lansare

Din `source`, după completarea identificatorilor:
`node migration/preflight.mjs wrangler.migration.json --local-only`.
Pentru verificările remote, rulează fără `--local-only`, într-un mediu securizat
care are secretele în variabile de mediu. Scriptul este exclusiv read-only: nu
trimite e-mailuri, nu creează produse și nu face plăți. Nu afișează cheile.
El verifică identitatea contului Stripe înainte de a citi produsele, cele două
prețuri, portalul, evenimentele webhook și paginile HTTPS ale domeniului final.
Un identificator lipsă sau neconform produce FAIL și cod de ieșire 1.
Nu ocoli verificările și nu înlocui identificatorii cu valori inventate.

Termenii în toate patru limbile sunt aliniați cu trialul de la activarea gazdei,
3 zile de grație, păstrarea datelor și schimbarea anual → lunar la sfârșitul anului.
Cererea de ștergere înainte de încheierea abonamentului se gestionează prin asistență;
închiderea automată rămâne blocată până la încheierea abonamentului Stripe.

Prețurile afișate sunt finale, în USD. Configurați prețurile Stripe cu
`tax_behavior=inclusive`, în acord cu termenii. Aceasta nu calculează singură
obligațiile fiscale: configurarea Stripe Tax sau a taxelor aplicabile depinde de
înregistrările fiscale ale firmei și de țările de vânzare. Nu activați încasările
până când acestea sunt confirmate. Nu sunt inventate cote sau înregistrări fiscale.

Secretul webhook nu poate fi verificat prin API read-only. După instalare,
trimiteți din Stripe un eveniment de test semnat către endpoint și confirmați 2xx
și actualizarea stării locale. Testați lunar/anual, card refuzat/3DS, retry,
anulare la finalul perioadei, schimbare anual → lunar și expirare + 72 ore.

Pentru e-mail, publicați exact înregistrările SPF/DKIM furnizate de serviciul de
trimitere și politica DMARC a domeniului. Nu adăugați un al doilea SPF separat.
Verificați recuperarea pe un cont controlat, livrarea și rezultatele autentificării
în antetul mesajului. `contact@mawine.app` din documentele legale trebuie să aibă
și el o căsuță funcțională sau redirecționare către asistență.

Arhiva nu configurează automat domeniul, contul Stripe ori serviciul de e-mail:
identificatorii și înregistrările furnizorilor nu pot fi deduși din cod. Tot ce
necesită aceste conturi este documentat și verificabil după conectare.

## Copiere în GitHub și notificări push

Copiază conținutul directorului `source/` la rădăcina repository-ului GitHub.
Păstrează separat `database-clean.sql`, `VERIFICATION.json` și `SHA256SUMS` pentru
importul inițial și verificarea kitului. Nu încărca parole, fișierul temporar
`admin-password-once.sql`, chei Stripe sau cheia privată push în GitHub.

Pentru notificări, configurează MAWINE_PUSH_PUBLIC_KEY și secretul
MAWINE_PUSH_PRIVATE_JWK ca pereche VAPID validă, persistentă. Nu schimba perechea
după înregistrarea dispozitivelor. Configurația livrată include Cron la 10 minute.
După mutarea domeniului, utilizatorii trebuie să permită notificările pe noul
domeniu; abonările push de pe vechiul domeniu nu sunt transferate. Pe iPhone/iPad,
instalează Mawine de pe noul domeniu pe Home Screen. Verifică livrarea reală pe
un dispozitiv Android și unul iOS, inclusiv cu aplicația închisă.

Reamintirile trialului fără abonament confirmat sunt la 15, 12, 9, 6, 3, 2 și 1
zile rămase, apoi zilnic în cele trei zile de grație. Testele locale nu certifică
livrarea serviciilor externe. Rezultatele suitei sunt în `docs/regression-v235.md`.

## Conturi cu e-mail verificat și cod guest permanent

Înregistrările noi folosesc adresa principală de e-mail și parola; nu se mai cere
un e-mail alternativ de recuperare. Confirmarea adresei și recuperarea parolei
necesită configurarea reală a serviciului de e-mail înainte de lansare. Nu activa
înregistrările publice fără un test de livrare și confirmare complet.

Configurează secretul `MAWINE_RECOVERY_ENCRYPTION_KEY` cu 32 de octeți aleatorii,
codificați Base64. Păstrează această cheie într-un manager de secrete: codurile guest
sunt criptate cu ea. La migrarea unei baze cu profiluri existente, trebuie păstrată
aceeași cheie. Pentru baza curată din acest pachet se poate genera o cheie nouă.
Nu include cheia în GitHub, SQL sau arhiva publică.

Codurile guest vechi stocate numai ca hash rămân valide, dar nu pot fi reconstituite.
Utilizatorul autentificat poate introduce codul original pentru a permite afișarea
lui ulterioară în Profil. Nu se înlocuiește automat codul și nu se invalidează cel vechi.

Reamintirile de expirare se afișează numai dacă reînnoirea abonamentului este anulată.
Abonamentele cu reînnoire automată activă nu primesc reamintiri de expirare.

Verificarea e-mailului: link valabil 10 minute, o singură utilizare, confirmare explicită. Resetarea parolei rămâne valabilă o oră. Conturile în așteptare nu au acces la funcțiile aplicației; loginul cu parola corectă deschide ecranul de verificare.
Evidența HMAC a gratuității expiră la 365 de zile de la acordare. Cron-ul o elimină automat; înregistrarea și confirmarea execută și curățarea de siguranță. După expirare, aceeași adresă poate deveni din nou eligibilă într-un cont nou.

## Administrare: confirmare prin e-mail și prețuri Stripe

Administratorul unic se autentifică folosind radugbr88@gmail.com și parola,
apoi confirmă linkul primit prin e-mail în același browser. Linkul expiră în
10 minute și sesiunea confirmată durează 24 de ore. Migrarea 0033 revocă
sesiunile admin existente. Configurați serviciul de e-mail, inclusiv
CLOUDFLARE_EMAIL_API_TOKEN, înainte de a folosi acest login; nu există ocolire
a confirmării dacă livrarea e-mailului este indisponibilă.

În administrare, salvarea unui preț lunar/anual cere confirmare și creează
un Price nou în Stripe. Configurația portalului este actualizată înainte ca
prețul nou să fie activat în aplicație. Abonamentele existente nu sunt
repricuite automat. Prețurile, economiile și Checkout folosesc configurația
activă din baza de date; păstrați tabela managed_prices la migrare.
Aplicațiile deschise preiau actualizarea la sincronizarea automată
(în mod normal în cel mult 15 secunde), fără republicare.

Activarea/dezactivarea unui cod existent actualizează Promotion Code în Stripe,
după confirmare. Cheia Stripe trebuie să permită citirea și modificarea acestor
resurse și a configurației Customer Portal. Verificați fluxul complet în
sandbox înainte de utilizarea în modul live.


### Acces temporar admin în timpul dezvoltării
Exclusiv pe server, MAWINE_ADMIN_TEMPORARY_PASSWORD_LOGIN=true permite
administratorului existent radugbr88@gmail.com să intre cu parola sa, fără
linkul pe e-mail. Nu activează conturi noi și nu ocolește parola sau limitarea
încercărilor. Sesiunile durează cel mult 24 de ore.
La finalizare, eliminați variabila sau setați false și aplicați configurația
prin redeploy. Sesiunile temporare devin atunci inutilizabile imediat;
loginul standard cu confirmare prin e-mail rămâne obligatoriu.
Nu includeți această activare în configurația de migrare.

## Verificări obligatorii înainte de deschiderea domeniului

Rulați `node migration/preflight.mjs wrangler.migration.json` din `source/`,
cu secretele furnizate prin mediul securizat al procesului, niciodată în GitHub.
Verificarea nu încasează bani, nu trimite e-mailuri și nu creează coduri Stripe.
Controlează cheia de criptare (32 octeți), semnarea/verificarea perechii VAPID,
cron-ul, absența bypass-ului admin și a identității proxy, prețurile și webhook-ul.
`--local-only` omite verificările externe, dar nu omite lipsurile de securitate.
Un rezultat local bun nu confirmă că aceleași valori sunt instalate pe server.

Prețurile nu mai sunt presupuse obligatoriu 9,99/99 USD: pot fi modificate din admin.
Pentru verificarea sumelor exacte folosiți MAWINE_EXPECTED_MONTHLY_CENTS și
MAWINE_EXPECTED_ANNUAL_CENTS. Dacă managed_prices conține prețuri active,
verificați ID-urile efective din acea tabelă, nu numai valorile inițiale din env.

Pe hosting standalone, autentificarea temporară admin este respinsă inclusiv dacă
variabila a fost copiată accidental ca true. Configurați și testați e-mailul înainte
să activați domeniul. Antetele de identitate proxy sunt ignorate implicit.
Parolele nou create/resetate folosesc PBKDF2-SHA256 cu 600.000 de iterații;
cele vechi rămân compatibile. Sesiunile conturilor cu parolă expiră după 30 de
zile de inactivitate; guest păstrează persistența existentă, admin maximum 24h.
Resetarea/schimbarea parolei invalidează și elimină materialul vechi de recuperare.

Arhiva este un KIT DE MIGRARE, nu un backup al datelor de producție.
Pentru utilizatorii existenți: opriți temporar scrierile, exportați D1 complet,
verificați importul într-o bază separată și restaurați aceeași cheie de criptare.
Păstrați datele managed_prices, trial_email_ledger și collection_retention_policy.
Nu importați database-clean.sql peste baza cu utilizatori. Nu reconstruiți backup-ul
folosind pagini trunchiate din vizualizatorul bazei. Închideți migrarea numai după
reconcilierea numărului de înregistrări și testarea revenirii la versiunea anterioară.
