import { sql } from 'drizzle-orm';
import { sqliteTable, text, integer, primaryKey, uniqueIndex, index, check } from 'drizzle-orm/sqlite-core';
export const profiles=sqliteTable('profiles',{id:text('id').primaryKey(),name:text('name').notNull(),createdAt:integer('created_at'),lastActiveAt:integer('last_active_at'),blocked:integer('blocked').notNull().default(0),dob:text('dob').notNull(),gender:text('gender').notNull(),host:integer('host').notNull().default(0),username:text('username').unique(),password:text('password'),recovery:text('recovery').notNull(),recoveryCode:text('recovery_code'),recoveryEmail:text('recovery_email'),primaryEmail:text('primary_email'),emailVerifiedAt:integer('email_verified_at'),recoveryCipher:text('recovery_cipher'),language:text('language'),trialStartedAt:integer('trial_started_at'),catalog:text('catalog').notNull().default('[]')},t=>[uniqueIndex('profiles_primary_email_unique').on(t.primaryEmail).where(sql`${t.primaryEmail} IS NOT NULL`)]);
export const identities=sqliteTable('identities',{identity:text('identity').primaryKey(),profileId:text('profile_id').notNull()});
export const events=sqliteTable('events',{id:text('id').primaryKey(),owner:text('owner').notNull(),title:text('title').notNull(),date:text('date').notNull(),mode:text('mode').notNull(),status:text('status').notNull(),code:text('code').notNull().unique(),wines:text('wines').notNull(),collectionWineIds:text('collection_wine_ids').notNull().default('[]'),revealedWineIds:text('revealed_wine_ids').notNull().default('[]'),revealed:integer('revealed').notNull().default(0)});
export const members=sqliteTable('members',{eventId:text('event_id').notNull(),profileId:text('profile_id').notNull(),completed:integer('completed').notNull().default(0),historyHidden:integer('history_hidden').notNull().default(0),historyFavorite:integer('history_favorite').notNull().default(0)},t=>[primaryKey({columns:[t.eventId,t.profileId]})]);
export const reviews=sqliteTable('reviews',{eventId:text('event_id').notNull(),profileId:text('profile_id').notNull(),wineId:text('wine_id').notNull(),data:text('data').notNull()},t=>[primaryKey({columns:[t.eventId,t.profileId,t.wineId]})]);
export const attempts=sqliteTable('attempts',{id:text('id').primaryKey(),count:integer('count').notNull(),since:integer('since').notNull()});
export const wineCatalog=sqliteTable('wine_catalog',{id:text('id').primaryKey(),data:text('data').notNull(),sourceUrl:text('source_url').notNull(),checkedAt:text('checked_at').notNull()});

export const grapeVarieties=sqliteTable('grape_varieties',{id:integer('id').primaryKey(),name:text('name').notNull(),color:text('color').notNull(),searchKey:text('search_key').notNull()});

export const guestSessions=sqliteTable('guest_sessions',{id:text('id').primaryKey(),expires:integer('expires').notNull()});
export const adminAccounts=sqliteTable('admin_accounts',{username:text('username').primaryKey(),password:text('password'),createdAt:integer('created_at').notNull()});
export const adminSessions=sqliteTable('admin_sessions',{id:text('id').primaryKey(),username:text('username').notNull().references(()=>adminAccounts.username),expires:integer('expires').notNull()});
export const passwordResets=sqliteTable('password_resets',{tokenHash:text('token_hash').primaryKey(),profileId:text('profile_id').notNull(),passwordSnapshot:text('password_snapshot').notNull(),emailSnapshot:text('email_snapshot').notNull(),expires:integer('expires').notNull()});
export const passwordResetLimits=sqliteTable('password_reset_limits',{id:text('id').primaryKey(),count:integer('count').notNull(),since:integer('since').notNull()});

// Server-owned billing records. Scope IDs distinguish merchant accounts/apps and sandboxes.
// All timestamps are Unix milliseconds. No card data, secrets or webhook payloads belong here.
const billingScope = () => ({
 provider: text('provider', {enum:['stripe','apple','google']}).notNull(),
 environment: text('environment', {enum:['test','live']}).notNull(),
 providerAccountId: text('provider_account_id').notNull(),
});
export const billingCustomers = sqliteTable('billing_customers', {
 id: text('id').primaryKey(),
 profileId: text('profile_id').references(()=>profiles.id, {onDelete:'set null'}),
 ...billingScope(),
 providerCustomerId: text('provider_customer_id').notNull(),
 createdAt: integer('created_at').notNull(),
 updatedAt: integer('updated_at').notNull(),
}, t=>[
 uniqueIndex('billing_customer_remote_unique').on(t.provider,t.environment,t.providerAccountId,t.providerCustomerId),
 uniqueIndex('billing_customer_profile_unique').on(t.profileId,t.provider,t.environment,t.providerAccountId),
 check('billing_customer_provider',sql`${t.provider} IN ('stripe','apple','google')`),
 check('billing_customer_environment',sql`${t.environment} IN ('test','live')`),
]);
export const billingSubscriptions = sqliteTable('billing_subscriptions', {
 id: text('id').primaryKey(),
 profileId: text('profile_id').references(()=>profiles.id, {onDelete:'set null'}),
 ...billingScope(),
 providerSubscriptionId: text('provider_subscription_id').notNull(),
 providerCustomerId: text('provider_customer_id'),
 providerPriceId: text('provider_price_id'),
 planKey: text('plan_key').notNull(),
 billingInterval: text('billing_interval', {enum:['monthly','annual']}).notNull(),
 providerStatus: text('provider_status').notNull(),
 riskBlocked: integer('risk_blocked').notNull().default(0),
 riskReason: text('risk_reason'),
 currentPeriodStart: integer('current_period_start'),
 currentPeriodEnd: integer('current_period_end'),
 // Separate from provider status: only verified fulfillment may grant access.
 accessExpiresAt: integer('access_expires_at'),
 cancelAtPeriodEnd: integer('cancel_at_period_end').notNull().default(0),
 canceledAt: integer('canceled_at'),
 endedAt: integer('ended_at'),
 lastSyncedAt: integer('last_synced_at'),
 createdAt: integer('created_at').notNull(),
 updatedAt: integer('updated_at').notNull(),
}, t=>[
 uniqueIndex('billing_subscription_remote_unique').on(t.provider,t.environment,t.providerAccountId,t.providerSubscriptionId),
 index('billing_subscription_profile_idx').on(t.profileId,t.environment,t.accessExpiresAt),
 index('billing_subscription_customer_idx').on(t.provider,t.environment,t.providerAccountId,t.providerCustomerId),
 check('billing_subscription_provider',sql`${t.provider} IN ('stripe','apple','google')`),
 check('billing_subscription_environment',sql`${t.environment} IN ('test','live')`),
 check('billing_subscription_interval',sql`${t.billingInterval} IN ('monthly','annual')`),
 check('billing_subscription_cancel_flag',sql`${t.cancelAtPeriodEnd} IN (0,1)`),
]);
export const billingEvents = sqliteTable('billing_events', {
 ...billingScope(),
 providerEventId: text('provider_event_id').notNull(),
 eventType: text('event_type').notNull(),
 providerObjectId: text('provider_object_id'),
 providerCreatedAt: integer('provider_created_at').notNull(),
 receivedAt: integer('received_at').notNull(),
 processedAt: integer('processed_at'),
 processingStatus: text('processing_status', {enum:['pending','processed','failed','ignored']}).notNull().default('pending'),
 attempts: integer('attempts').notNull().default(0),
 // Sanitized code only, never an exception containing secrets or personal data.
 lastErrorCode: text('last_error_code'),
}, t=>[
 primaryKey({columns:[t.provider,t.environment,t.providerAccountId,t.providerEventId]}),
 index('billing_event_retry_idx').on(t.processingStatus,t.receivedAt),
 check('billing_event_provider',sql`${t.provider} IN ('stripe','apple','google')`),
 check('billing_event_environment',sql`${t.environment} IN ('test','live')`),
 check('billing_event_status',sql`${t.processingStatus} IN ('pending','processed','failed','ignored')`),
 check('billing_event_attempts',sql`${t.attempts} >= 0`),
]);

// Per-profile leases serialize checkout, lifecycle reconciliation and account closure.
export const billingLocks=sqliteTable('billing_locks',{id:text('id').primaryKey(),owner:text('owner').notNull(),expiresAt:integer('expires_at').notNull()});
export const billingOperations=sqliteTable('billing_operations',{id:text('id').primaryKey(),createdAt:integer('created_at').notNull()});
export const billingCheckouts=sqliteTable('billing_checkouts',{
 profileId:text('profile_id').notNull().references(()=>profiles.id,{onDelete:'cascade'}),
 environment:text('environment').notNull(),providerAccountId:text('provider_account_id').notNull(),
 id:text('id').notNull().unique(),plan:text('plan').notNull(),params:text('params').notNull(),
 createdAt:integer('created_at').notNull(),sessionId:text('session_id')
},t=>[primaryKey({columns:[t.profileId,t.environment,t.providerAccountId]})]);

// One presentation per profile, reminder kind and calendar day, across devices.
export const profileReminders=sqliteTable('profile_reminders',{
 profileId:text('profile_id').notNull().references(()=>profiles.id,{onDelete:'cascade'}),
 kind:text('kind').notNull(),shownDay:text('shown_day').notNull(),shownAt:integer('shown_at').notNull()
},t=>[primaryKey({columns:[t.profileId,t.kind]})]);

// Complimentary access is an application entitlement, never a Stripe subscription.
export const complimentaryAccess=sqliteTable('complimentary_access',{
 profileId:text('profile_id').primaryKey().references(()=>profiles.id,{onDelete:'cascade'}),
 expiresAt:integer('expires_at').notNull(),grantedBy:text('granted_by').notNull(),updatedAt:integer('updated_at').notNull()
});
export const adminAccessAudit=sqliteTable('admin_access_audit',{
 id:text('id').primaryKey(),profileId:text('profile_id').notNull(),admin:text('admin').notNull(),expiresAt:integer('expires_at').notNull(),createdAt:integer('created_at').notNull()
});

// A device subscription is bound to the authenticated identity that opted in.
export const pushSubscriptions=sqliteTable('push_subscriptions',{
 id:text('id').primaryKey(),profileId:text('profile_id').notNull().references(()=>profiles.id,{onDelete:'cascade'}),
 identity:text('identity').notNull(),endpoint:text('endpoint').notNull().unique(),p256dh:text('p256dh').notNull(),auth:text('auth').notNull(),
 nextCheck:integer('next_check').notNull().default(0),createdAt:integer('created_at').notNull()
});
export const pushDeliveries=sqliteTable('push_deliveries',{
 subscriptionId:text('subscription_id').notNull().references(()=>pushSubscriptions.id,{onDelete:'cascade'}),
 day:text('day').notNull(),kind:text('kind').notNull(),sentAt:integer('sent_at').notNull()
},t=>[primaryKey({columns:[t.subscriptionId,t.day,t.kind]})]);

export const emailVerifications=sqliteTable('email_verifications',{profileId:text('profile_id').primaryKey(),email:text('email').notNull().unique(),passwordHash:text('password_hash').notNull(),tokenHash:text('token_hash').notNull().unique(),identity:text('identity').notNull(),expires:integer('expires').notNull()});
export const trialEmailLedger=sqliteTable('trial_email_ledger',{fingerprint:text('fingerprint').primaryKey(),usedAt:integer('used_at').notNull()});

export const adminChallenges=sqliteTable('admin_challenges',{deviceHash:text('device_hash').primaryKey(),username:text('username').notNull(),tokenHash:text('token_hash').notNull().unique(),expires:integer('expires').notNull()});
export const managedPrices=sqliteTable('managed_prices',{id:text('id').primaryKey(),environment:text('environment').notNull(),account:text('account').notNull(),plan:text('plan').notNull(),amount:integer('amount').notNull(),active:integer('active').notNull(),createdAt:integer('created_at').notNull()});

// Rollout floor for the 365-day personal collection retention policy.
export const collectionRetentionPolicy=sqliteTable('collection_retention_policy',{id:integer('id').primaryKey(),startedAt:integer('started_at').notNull()});
