import {createRequire} from 'node:module';
const sharp=createRequire(import.meta.url)('sharp');
import {writeFile,readFile} from 'node:fs/promises';
const source='public/brand/mawine-icon-source.png';
await sharp('public/brand/mawine-wordmark-source.png').extract({left:291,top:1124,width:2250,height:518}).png().toFile('public/brand/mawine-wordmark-hd.png');
const sizes=[16,20,29,32,36,40,48,58,60,72,76,80,87,96,120,144,152,167,180,192,256,384,512,1024];
for(const size of sizes){await sharp(source).resize(size,size).toColourspace('srgb').png().toFile(`public/icons/mawine-${size}.png`);}
// Keep the wordmark inside the safe circle used by Android adaptive masks.
for(const size of [192,512]){
 const inset=Math.round(size*.05);const inner=size-2*inset;
 const padded=await sharp(source).resize(inner,inner).toColourspace('srgb').png().toBuffer();
 await sharp({create:{width:size,height:size,channels:3,background:'#b00032'}}).composite([{input:padded,left:inset,top:inset}]).png().toFile(`public/icons/mawine-maskable-${size}.png`);
}
await writeFile('public/apple-touch-icon.png',await readFile('public/icons/mawine-180.png'));
const frames=await Promise.all([16,32,48].map(size=>readFile(`public/icons/mawine-${size}.png`)));
const header=Buffer.alloc(6+16*frames.length);header.writeUInt16LE(1,2);header.writeUInt16LE(frames.length,4);
let offset=header.length;
frames.forEach((frame,i)=>{const p=6+16*i;header[p]=[16,32,48][i];header[p+1]=header[p];header.writeUInt16LE(1,p+4);header.writeUInt16LE(32,p+6);header.writeUInt32LE(frame.length,p+8);header.writeUInt32LE(offset,p+12);offset+=frame.length;});
await writeFile('public/favicon.ico',Buffer.concat([header,...frames]));
const png=await readFile('public/icons/mawine-512.png');
await writeFile('public/favicon.svg',`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><image width="512" height="512" href="data:image/png;base64,${png.toString('base64')}"/></svg>\n`);
console.log('Exported 24 square sizes, 2 maskable sizes, HD wordmark, Apple icon and browser favicons.');
