"""Snapshot VIVC wine-grape passport facts, with source ID and berry colour.
Source: Julius Kühn-Institut https://www.vivc.de/ (retrieved 2026-10-29).
Only publicly listed factual names/IDs/colours, no images or descriptions.
"""
import concurrent.futures,urllib.request,urllib.parse,re,html,json,pathlib,time
root=pathlib.Path('.sites-runtime/vivc-pages');root.mkdir(exist_ok=True)
def fetch(page):
 path=root/f'{page}.html'
 if path.exists():data=path.read_text()
 else:
  params={'r':'passport/result','PassportSearch[utilization2][]':'wine grape','per-page':500,'page':page}
  url='https://www.vivc.de/index.php?'+urllib.parse.urlencode(params)
  for attempt in range(3):
   try:data=urllib.request.urlopen(url,timeout=45).read().decode();break
   except Exception:
    if attempt==2:raise
  path.write_text(data)
 rows=[]
 for row in re.findall(r'<tr[^>]*data-key="\d+".*?</tr>',data,re.S):
  cols=re.findall(r'<td[^>]*>(.*?)</td>',row,re.S)
  if len(cols)<4:continue
  clean=lambda v:html.unescape(re.sub('<[^>]*>','',v)).strip()
  name,color,id,usage=[clean(c) for c in cols[:4]]
  if id.isdigit() and 'WINE GRAPE' in usage:rows.append({'id':int(id),'name':name,'color':color})
 print(page,len(rows),flush=True)
 return rows
first=fetch(1)
data=(root/'1.html').read_text();total=int(re.search(r'of <b>([\d,]+)</b> items',data).group(1).replace(',',''));pages=(total+499)//500
allrows=first
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 for rows in pool.map(fetch,range(2,pages+1)):allrows+=rows
records={r['id']:r for r in allrows};assert len(records)==total,(len(records),total)
pathlib.Path('app/grape-data.json').write_text(json.dumps(sorted(records.values(),key=lambda r:r['name']),ensure_ascii=False,separators=(',',':')))
print('COMPLETE',len(records),flush=True)
