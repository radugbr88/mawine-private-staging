import fitz,collections,json
pdf=fitz.open('.sites-runtime/winegrapes.pdf');rows=[]
for page in list(pdf)[148:161]:

 grouped=collections.defaultdict(list)
 for w in page.get_text('words'):
  grouped[round(w[0]/3)*3].append((841.92-w[3],w[4]))
 for y,words in grouped.items():
  name=' '.join(t for x,t in sorted(words) if x<145)
  color=''.join(t for x,t in words if 145<=x<175)
  area=''.join(t for x,t in words if 445<=x<490)
  rank=''.join(t for x,t in words if 548<=x<575)
  if color in ['R','W','G'] and rank.isdigit() and area.isdigit() and int(rank)<=410:rows.append(dict(name=name,color=color,area=int(area),rank=int(rank)))
print(len(rows));print(rows[:8]);print(rows[-8:]);print('missing',set(range(1,401))-{r['rank'] for r in rows})
open('.sites-runtime/ranked.json','w').write(json.dumps(rows,ensure_ascii=False,indent=2))
