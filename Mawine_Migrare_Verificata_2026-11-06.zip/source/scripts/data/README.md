# VIVC wine grape snapshot

Source: Vitis International Variety Catalogue, Julius Kühn-Institut (JKI),
https://www.vivc.de/index.php?r=passport%2Findex
Retrieved 2026-10-29. Filter: utilization = wine grape.

The 23 result pages (500 entries/page) contained 11,342 distinct VIVC IDs.
The snapshot includes 4,561 BLANC, 5,620 NOIR, 436 ROUGE, 341 ROSE,
63 GRIS, and 321 entries without specified berry colour. Wine-grape records
can include breeding selections; this is not a claim that every entry is a
commercial variety, nor that the snapshot captures all varieties in existence.
Only names, VIVC identifiers and berry-colour facts are copied. No descriptive
text or images are used. Individual source: https://www.vivc.de/index.php?r=passport%2Fview&id=ID

`fetch-grapes.py` reproduces the factual source snapshot in app/grape-data.json.
The release migration loads it into grape_varieties. Search uses this database,
60 rows per page, with colour filters and diacritic-insensitive search.
Romanian orthography is added for Fetească Albă/Neagră/Regală.
Pinot Grigio = Pinot Gris and Shiraz = Syrah aliases are also documented in
Ontario's official authorised varieties table:
https://www.ontario.ca/laws/regulation/000406

Unknown names may be entered explicitly; they are not silently labelled as
verified VIVC records. Exact blend scoring compares normalized names and the
supported aliases, not individual partial matches.

## Wine-only refinement, 2026-10-29

`filter-wine-only.py` uses the same downloaded passport pages to exclude
any record also marked TABLE GRAPE, RAISIN GRAPE, or ROOTSTOCK, and the
identified wild-vine records (V. vinifera subsp. sylvestris or species-name
entries). Named wine cultivars and hybrids remain; a non-vinifera species
assignment alone is not evidence that a cultivar is a wild plant.

1,621 records excluded; 9,721 remain: 3,747 BLANC, 5,069 NOIR, 300 ROUGE,
250 ROSE, 51 GRIS, 304 unspecified. Dual-use varieties are intentionally
excluded, even when they can also make wine. This is a source-based usage
filter, not a guarantee of current commercial production for every entry.

Run fetch-grapes.py then filter-wine-only.py to reproduce the release snapshot.
The exclusion audit is in excluded-grapes.json; migration 0004 changes only
the reference list, leaving users' wines, collections and tasting history intact.

## Active list: 400 common winegrapes (2026-10-29)
Replaces the VIVC reference list only. User collections/events/reviews are not changed.
Source: Anderson & Nelgen, Which Winegrape Varieties are Grown Where?, revised 2020, Table 6 (2016 global bearing area). First 400 named winegrape rows by published 2016 rank; source ranks have gaps (6, 9, 81 are not rows in this winegrape table), so final source rank is 403. 195 W, 192 R, 13 G. G is shown as “Altele”, referring to berry colour, not wine style.
PDF: https://adelaide.edu.au/content/dam/adelaideuniversity/documents/library/about-the-library/university-press/pdfs/winegrapes-revised-ebook-0920.pdf
2023 spreadsheet download was unavailable during this update. Do not label these rankings as 2023/2026.
`extract-common-400.py` reproduces factual row extraction from `.sites-runtime/winegrapes.pdf`. App JSON retains source rank and hectares. Names remain source prime names, with common search aliases. Migration 0006 replaces the reference table; no personal data is deleted.

## Catalogue refresh, 2026-10-31
408 reference entries. Added 12 missing cultivars from the attached Wine Folly workbook and Georgian screenshot. Synonyms are searchable aliases, including Shiraz (displayed alongside Syrah); primary names and aliases share one canonicalization table. The workbook has 171 entries; 42 are wine styles/appellations or the species-level Muscadine entry, excluded from the cultivar list. Audit decisions are recorded in catalogue-import-2026-10-31.json.

Sources checked: https://wine.gov.ge/En/VarietyWhite, https://wine.gov.ge/En/WineMakingRegions, https://fps.ucdavis.edu/FGRfamilies.cfm?varietyid=3394 (Picapoll Blanc distinct from Piquepoul Blanc), https://grapes.winefolly.com/bonarda, https://winefolly.com/grapes/muscadine/. Generic Wine Folly names such as Torrontés and Trebbiano resolve to the specific cultivar represented by that source, rather than adding a second generic row.

Migration 0016 synchronizes only the reference catalogue, including previously added Traminer and Areni noir. User wines and historical tasting records are untouched. The selector uses the bundled JSON, ten items per page; the API uses the synchronized D1 catalogue.

## Georgian screenshot additions, 2026-10-31
Migration 0017 adds Tavkveri, Shavkapito, Ojaleshi, Aleksandrouli, Mujuretuli (NOIR), and Chkhaveri (ROSE, pink-violet berry skin, shown under Altele). Saperavi was already present and is not duplicated. Total: 414 cultivars. Sources: National Wine Agency https://wine.gov.ge/En/VarietyRed and https://wine.gov.ge/En/VarietyRed?page=2&pageSize=5.
# Cultivar naming correction (2026-10-31)

Display Glera and Glera Lunga instead of the historical Prosecco and Prosecco Lungo cultivar names. Preserve IDs and historical names as search/scoring aliases; do not rewrite user-entered wine records. Reference: https://www.prosecco.wine/en/prosecco/ and https://vitisdb.it/varieties/show/1338 . Migration 0023 updates the API lookup catalogue as well as the bundled choices.

