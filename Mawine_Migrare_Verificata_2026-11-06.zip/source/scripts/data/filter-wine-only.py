"""Filter the dated VIVC snapshot to wine-only usage; exclude identified wild vines.
Uses the cached public passport result pages downloaded by fetch-grapes.py.
Keeps named wine cultivars of non-vinifera species and wine hybrids: species
membership alone does not establish that a cultivar is a wild plant.
"""
import re,html,json,pathlib,collections
records={}
for path in pathlib.Path('.sites-runtime/vivc-pages').glob('*.html'):
 for row in re.findall(r'<tr[^>]*data-key="\d+".*?</tr>',path.read_text(),re.S):
  cols=re.findall(r'<td[^>]*>(.*?)</td>',row,re.S)
  if len(cols)<6:continue
  vals=[re.sub(r'\s+',' ',html.unescape(re.sub('<[^>]*>',' ',c))).strip() for c in cols[:6]]
  name,color,id,usage,origin,species=vals
  if id.isdigit():records[int(id)]={'id':int(id),'name':name,'color':color,'usage':usage,'species':species}
assert len(records)==11342
kept=[];removed=[]
for r in records.values():
 wine_only=r['usage']=='WINE GRAPE'
 wild='SUBSP. SYLVESTRIS' in r['species'] or r['name'].startswith(('VITIS ','MUSCADINIA '))
 if wine_only and not wild:kept.append(r)
 else:removed.append(r)
kept.sort(key=lambda r:r['name']);removed.sort(key=lambda r:r['id'])
pathlib.Path('app/grape-data.json').write_text(json.dumps(kept,ensure_ascii=False,separators=(',',':')))
pathlib.Path('scripts/data/excluded-grapes.json').write_text(json.dumps(removed,ensure_ascii=False,separators=(',',':')))
statements=[]
for start in range(0,len(removed),100):statements.append('DELETE FROM grape_varieties WHERE id IN ('+','.join(str(r['id']) for r in removed[start:start+100])+');')
pathlib.Path('drizzle/0004_wine_only.sql').write_text('\n--> statement-breakpoint\n'.join(statements))
print(json.dumps({'remaining':len(kept),'removed':len(removed),'colors':dict(collections.Counter(r['color'] for r in kept))}))
