import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
const files=fs.readdirSync('tests').filter(file=>/\.(mjs|cjs)$/.test(file)&&file!=='run-all.mjs').sort();
const failures=[];
for(const file of files){
 console.log('\nTEST '+file);
 const result=spawnSync(process.execPath,['tests/'+file],{stdio:'inherit',timeout:120000});
 if(result.error||result.status!==0)failures.push(file);
}
console.log(`\n${files.length-failures.length}/${files.length} test suites passed.`);
if(failures.length){console.error('Failed: '+failures.join(', '));process.exitCode=1;}
