import assert from 'node:assert/strict';
import fs from 'node:fs';
const data=JSON.parse(fs.readFileSync('app/grape-data.json','utf8'));
const key=s=>s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]/g,'');
const lookup=new Map();const ids=new Set();
for(const g of data){assert(!ids.has(g.id));ids.add(g.id);for(const name of [g.name,...g.aliases]){assert(!lookup.has(key(name))||lookup.get(key(name))===g.name,`Conflicting alias: ${name}`);lookup.set(key(name),g.name)}}
for(const n of ['Traminer','Areni noir','Shiraz','Chinuri','Goruli Mtsvane','Kakhuri Mtsvane','Khikhvi','Kisi','Krakhuna','Mtsvane Kakhuri','Rachuli (Tsulukidzis) Tetra','Sakmiela','Tsitska','Tsolikouri'])assert(lookup.has(key(n)),n);
assert.equal(lookup.get(key('Shiraz')),'Syrah');
assert.equal(lookup.get(key('Prosecco')),'Glera');
assert.equal(lookup.get(key('Prosecco Lungo')),'Glera Lunga');
assert(!data.some(g=>/^Prosecco/.test(g.name)));
assert.equal(data.filter(g=>g.name==='Glera').length,1);
assert.equal(data.filter(g=>g.name==='Glera Lunga').length,1);
assert.equal(lookup.get(key('Kakhuri Mtsvane')),lookup.get(key('Mtsvane Kakhuri')));
assert.notEqual(lookup.get(key('Picapoll')),lookup.get(key('Picpoul')));
assert.notEqual(lookup.get(key('Bonarda')),lookup.get(key('Bonarda Piemontese')));
const audit=JSON.parse(fs.readFileSync('scripts/data/catalogue-import-2026-10-31.json'));
const removed=JSON.parse(fs.readFileSync('scripts/data/removed-table-grapes.json'));
for(const g of removed)assert(!ids.has(g.id));
const excluded=new Set([...audit.excluded,...removed].map(x=>x.name));
for(const n of audit.checkedEntries)assert(lookup.has(key(n))||excluded.has(n),`Unaccounted workbook row: ${n}`);
assert.equal(data.length,492);
console.log('492 records checked; all workbook rows accounted for; no normalized name/alias or ID duplicates.');

for(const name of ['Saperavi','Tavkveri','Shavkapito','Ojaleshi','Aleksandrouli','Mujuretuli','Chkhaveri'])assert.equal(data.filter(g=>g.name===name).length,1);
assert.equal(data.find(g=>g.name==='Chkhaveri').color,'ROSE');

const approved=JSON.parse(fs.readFileSync("scripts/data/approved-grapes-2026-10-31.json"));
for(const n of approved.approvedNames)assert(lookup.has(key(n)),n);
assert.equal(lookup.get(key("Tinta Roriz")),"Tempranillo");
