import assert from 'node:assert/strict';
import fs from 'node:fs';
import {DatabaseSync} from 'node:sqlite';

const db=new DatabaseSync(':memory:');
db.exec('PRAGMA foreign_keys=ON');
const files=fs.readdirSync('drizzle').filter(f=>f.endsWith('.sql')).sort();
for(const f of files.filter(f=>f<'0025_'))db.exec(fs.readFileSync('drizzle/'+f,'utf8'));
db.prepare("INSERT INTO profiles(id,name,dob,gender,recovery,catalog,trial_started_at) VALUES (?,?,?,?,?,?,?)").run('owner','Existing owner','1990-01-01','','recovery','[{"name":"Wine"}]',123456);
db.prepare("INSERT INTO profiles(id,name,dob,gender,recovery) VALUES (?,?,?,?,?)").run('other','Other owner','1990-01-01','','recovery');
const tables=db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").all().map(t=>t.name);
const before=new Map(tables.map(t=>[t,db.prepare(`SELECT * FROM "${t}"`).all()]));
for(const f of files.filter(f=>f.startsWith('0025_')))db.exec(fs.readFileSync('drizzle/'+f,'utf8'));
for(const [table,rows] of before)assert.deepEqual(db.prepare(`SELECT * FROM "${table}"`).all(),rows,`${table} unchanged`);
for(const f of files.filter(f=>f>='0026_'))db.exec(fs.readFileSync('drizzle/'+f,'utf8'));
for(const table of ['billing_customers','billing_subscriptions','billing_events'])assert.equal(db.prepare(`SELECT count(*) n FROM ${table}`).get().n,0);

const customer=db.prepare('INSERT INTO billing_customers(id,profile_id,provider,environment,provider_account_id,provider_customer_id,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)');
customer.run('c1','owner','stripe','live','acct_1','cus_1',1,1);
assert.throws(()=>customer.run('c2','other','stripe','live','acct_1','cus_1',1,1),/UNIQUE/);
assert.throws(()=>customer.run('c3','owner','stripe','live','acct_1','cus_2',1,1),/UNIQUE/);
assert.throws(()=>customer.run('bad','missing','stripe','live','acct_1','cus_bad',1,1),/FOREIGN KEY/);
assert.throws(()=>customer.run('bad','other','stripe','production','acct_1','cus_bad',1,1),/CHECK/);
customer.run('ctest','owner','stripe','test','acct_1','cus_1',1,1);
customer.run('csandbox','owner','stripe','test','acct_sandbox','cus_1',1,1);

const sub=db.prepare('INSERT INTO billing_subscriptions(id,profile_id,provider,environment,provider_account_id,provider_subscription_id,plan_key,billing_interval,provider_status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)');
sub.run('s1','owner','stripe','live','acct_1','sub_1','host','annual','incomplete',1,1);
assert.equal(db.prepare('SELECT access_expires_at FROM billing_subscriptions WHERE id=?').get('s1').access_expires_at,null);
assert.throws(()=>sub.run('dup','other','stripe','live','acct_1','sub_1','host','annual','active',1,1),/UNIQUE/);
assert.throws(()=>sub.run('bad','owner','stripe','live','acct_1','sub_2','host','weekly','active',1,1),/CHECK/);
for(const provider of ['apple','google'])sub.run(provider,'owner',provider,'test','app-id','remote-id','host','monthly','active',1,1);

const event=db.prepare('INSERT INTO billing_events(provider,environment,provider_account_id,provider_event_id,event_type,provider_created_at,received_at) VALUES(?,?,?,?,?,?,?)');
event.run('stripe','live','acct_1','evt_1','invoice.paid',1,1);
assert.throws(()=>event.run('stripe','live','acct_1','evt_1','invoice.paid',1,1),/UNIQUE/);
event.run('stripe','test','acct_1','evt_1','invoice.paid',1,1);
event.run('stripe','test','acct_sandbox','evt_1','invoice.paid',1,1);
assert.equal(db.prepare("SELECT processing_status FROM billing_events WHERE environment='live'").get().processing_status,'pending');
// Failed processing must not leave a partial entitlement update or completion marker.
db.exec('BEGIN');
try {
 db.exec("UPDATE billing_subscriptions SET access_expires_at=999 WHERE id='s1'");
 db.exec("UPDATE billing_events SET processing_status='invalid' WHERE environment='live'");
 assert.fail('invalid state accepted');
} catch(error) { db.exec('ROLLBACK');assert.match(error.message,/CHECK/); }
assert.equal(db.prepare("SELECT access_expires_at FROM billing_subscriptions WHERE id='s1'").get().access_expires_at,null);
db.prepare('DELETE FROM profiles WHERE id=?').run('owner');
assert.equal(db.prepare('SELECT count(*) n FROM billing_customers WHERE profile_id IS NOT NULL').get().n,0);
assert.equal(db.prepare('SELECT count(*) n FROM billing_subscriptions WHERE profile_id IS NOT NULL').get().n,0);
assert.equal(db.prepare('SELECT count(*) n FROM billing_subscriptions').get().n,3);
assert.deepEqual(db.prepare('PRAGMA foreign_key_check').all(),[]);
assert.equal(db.prepare('PRAGMA integrity_check').get().integrity_check,'ok');
console.log('Billing migration: existing data preserved; isolation, uniqueness, constraints, rollback and account deletion passed.');
