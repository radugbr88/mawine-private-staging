import assert from 'node:assert/strict';
import React from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {compileTree} from './helpers/compile.mjs';
const dir='.sites-runtime/collection-sort-tests';
const {sortCollection,CollectionSortBar}=await import(compileTree('app/collection-sort.tsx',dir));
const {setLanguage}=await import(compileTree('app/i18n.ts',dir));
const wines=[{id:'old',winery:'Zulu',name:'Alpha',year:2020,grapes:['Syrah']},{id:'new',winery:'Alpha',name:'Zulu',year:2024,grapes:['Merlot']}];
for(const lang of ['ro','en','it','fr']){
 setLanguage(lang);assert.equal(sortCollection(wines,null)[0].id,'new');
 for(const key of ['winery','name','year','grapes']){const asc=sortCollection(wines,{key,direction:1});const desc=sortCollection(wines,{key,direction:-1});assert.equal(asc[0].id,desc[1].id)}
 const closed=renderToStaticMarkup(React.createElement(CollectionSortBar,{open:false,value:null,onToggle(){},onChange(){}}));assert(closed.includes('hidden=""'));assert(closed.includes('aria-expanded="false"'));
 const open=renderToStaticMarkup(React.createElement(CollectionSortBar,{open:true,value:{key:'name',direction:-1},onToggle(){},onChange(){}}));assert(open.includes('aria-pressed="true"'));assert(!open.includes('lucide-arrow-')); 
}
assert.equal(wines[0].id,'old');console.log('PASS collection order, four sort criteria in both directions, locale coverage and menu states');
