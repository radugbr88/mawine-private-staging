import assert from 'node:assert/strict';
import React from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {compileTree} from './helpers/compile.mjs';
const dir='.sites-runtime/subscription-layout';
const {SubscriptionPanel}=await import(compileTree('app/subscription-panel.tsx',dir));
const {setLanguage,t}=await import(compileTree('app/i18n.ts',dir));
const props={choosing:false,startedAt:Date.now()-31*86400000,busy:false,onChoose(){},onUnavailable(){},onDowngrade(){}};
for(const language of ['ro','en','it','fr']){
 setLanguage(language);
 const free=renderToStaticMarkup(React.createElement(SubscriptionPanel,props));assert.equal((free.match(/class="trialCard"/g)||[]).length,1);assert(free.includes(t('Prima lună gratuită')));
 for(const plan of ['monthly','annual'])for(const status of ['active','past_due','canceled'])for(const cancelAtPeriodEnd of [false,true]){
  const billing={enabled:true,mode:'simulation',hasCustomer:true,subscription:{plan,status,paid:status==='active',cancelAtPeriodEnd,periodEnd:Date.now()+86400000}};
  billing.grace={inGrace:true,graceDay:1,graceEndsAt:Date.now()+3*86400000};
  const html=renderToStaticMarkup(React.createElement(SubscriptionPanel,{...props,billing}));
  assert(!html.includes(t('Vezi abonamentele')),'No duplicate grace selection panel');
  assert.equal((html.match(/class="trialCard"/g)||[]).length,1);assert(!html.includes('<h2>'+t('Prima lună gratuită')+'</h2>'));
  assert(html.indexOf('subscriptionSubtitle')<html.indexOf('trialCard'));assert(html.indexOf('trialCard')<html.indexOf(t('Gestionează abonamentul')));
  if(status==='active'){assert(!html.includes(t('Schimbă perioada de abonare')));assert(!html.includes('href="/terms-'),'No duplicate purchase confirmation link for active subscription');assert(html.includes(t(plan==='monthly'?'Trecerea de la lunar la anual se aplică imediat după confirmarea în Stripe, cu ajustarea valorii pentru timpul nefolosit din luna plătită. Stripe afișează suma de plată înainte de confirmare.':'Trecerea de la anual la lunar se aplică la sfârșitul anului deja plătit, fără rambursare automată.')));}
  assert(html.includes('class="trialHeading"'));assert(html.includes('class="trialPrice"'));assert(plan==='annual'?html.includes('$99 USD'):/\$9[,.]99 USD/.test(html));
 }
}
console.log('PASS: single in-place subscription card across four languages, both plans, cancellation and billing states');

setLanguage('ro');
const updated=renderToStaticMarkup(React.createElement(SubscriptionPanel,{...props,choosing:true,billing:{enabled:true,prices:{monthly:1299,annual:12900}}}));
assert(updated.includes('$12,99 USD'));assert(updated.includes('$129 USD'));assert(updated.includes('$26,88 USD'));assert(updated.includes('17%'));
