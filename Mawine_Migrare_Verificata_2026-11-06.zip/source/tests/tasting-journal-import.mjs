import {compileTree} from './helpers/compile.mjs';
import assert from 'node:assert/strict';
import Excel from 'exceljs';
compileTree('app/wine-import.ts','.sites-runtime/journal-tests');
compileTree('app/identify-wine.ts','.sites-runtime/journal-tests');
const {wineIdentifier}=await import('../.sites-runtime/journal-tests/identify-wine.mjs');
const {parseWineRows,wineImportGroups,importGrapes}=await import('../.sites-runtime/journal-tests/wine-import.mjs');
assert.deepEqual(importGrapes('CS(66)+M(29)+PV(5)'),['Cabernet Sauvignon','Merlot','Petit Verdot']);
assert.deepEqual(importGrapes('M(95)+CFr(4,5)+CS(0,5)'),['Merlot','Cabernet Franc','Cabernet Sauvignon']);
assert.deepEqual(importGrapes('FN; CS; M; Unknown'),['Fetească Neagră','Cabernet Sauvignon','Merlot','Unknown']);
assert.deepEqual(importGrapes('GSM (70+20+10)'),['Grenache','Syrah','Mourvèdre']);
// User-supplied shorthand, dotted forms, case and accents work in grape columns.
const common={FA:'Fetească Albă',FR:'Fetească Regală',SB:'Sauvignon Blanc',CH:'Chardonnay',Chard:'Chardonnay',RI:'Riesling Italian',RhR:'Riesling',TA:'Tămâioasă Românească',MO:'Muscat Ottonel',GB:'Grasă de Cotnari',PG:'Pinot Gris',Alig:'Aligoté',FN:'Fetească Neagră',CS:'Cabernet Sauvignon',M:'Merlot',PN:'Pinot Noir',Sy:'Syrah',Sh:'Shiraz',CF:'Cabernet Franc',Bus:'Busuioacă de Bohotin',Băb:'Băbească Neagră',ML:'Merlot',Merl:'Merlot',SHZ:'Shiraz',GN:'Grenache',PV:'Petit Verdot',MB:'Malbec',ZN:'Zinfandel',TP:'Tempranillo',SG:'Sangiovese',CM:'Carménère',TN:'Tannat',GM:'Gamay',NB:'Nebbiolo',BA:'Barbera',Ries:'Riesling',RD:'Riesling',CB:'Chenin Blanc',VI:'Viognier',PGS:'Pinot Grigio',PB:'Pinot Blanc',GW:'Gewürztraminer',GEW:'Gewürztraminer',GV:'Grüner Veltliner',AB:'Albariño',MT:'Muscat'};
for(const [alias,name] of Object.entries(common)){
 for(const variant of [alias,alias.toLowerCase(),alias.split('').join('.')+'.'])assert.deepEqual(importGrapes(variant),[name],variant);
 const wine=parseWineRows([['Vin','Soiuri'],['Example',alias]],60)[0];assert.deepEqual(wine.grapes,[name]);
}
assert.deepEqual(importGrapes('F.A.(50%)+S.B.(30%)+Chard(20%)'),['Fetească Albă','Sauvignon Blanc','Chardonnay']);
assert.deepEqual(importGrapes('RI + Rh.R.'),['Riesling Italian','Riesling']);
assert.deepEqual(importGrapes('SY / SHZ'),['Syrah','Shiraz']);
assert.deepEqual(importGrapes('Muscat Ottonel; Unknown; Unknown'),['Muscat Ottonel','Unknown']);
const row=(number,grapes='CS',year=2020)=>[number,'Producer','Romania','rosu','sec',grapes,'Wine',year,13.5,,,,,30.456,,,new Date('2026-10-09')];
const rows=[['Journal'],[],row(1),[],row('', 'FN'),[,,,,,,,,,,,,,,,,,'Private attendee'],row(2,'M','NV'),row('CV','CS+M')];
const groups=wineImportGroups(rows);
assert.equal(groups.length,2);assert.equal(groups[0].rows.length,3);assert.equal(groups[0].date,'2026-10-09');
assert.equal(groups[1].rows.length,3);
const solera=parseWineRows([...rows,row('', 'M','1942 solera')],60).at(-1);assert.equal(solera.year,null);assert.ok(solera.name.includes('Solera 1942'));
const wines=parseWineRows(rows,60);assert.equal(wines.length,4);assert.equal(wines[0].country,'România');assert.equal(wines[0].price,'30.46');assert.equal(wines[2].year,null);
assert.ok(!JSON.stringify(groups).includes('Private attendee'));
assert.throws(()=>parseWineRows(rows,3),/Mai poți/);
assert.throws(()=>parseWineRows([...rows,row('', 'M',1800)],60),/anul/);
assert.equal(wineImportGroups([['Winery','Wine'],['A','B']]).length,0);
if(process.argv[2]){
 const wb=new Excel.Workbook();await wb.xlsx.readFile(process.argv[2]);const actual=[];
 wb.worksheets[0].eachRow({includeEmpty:true},r=>actual.push(r.values.slice(1).map(v=>v instanceof Date?v:typeof v==='object'&&v!==null?('result'in v?v.result:'richText'in v?v.richText.map(t=>t.text).join(''):'text'in v?v.text:''):v)));
 const groups=wineImportGroups(actual);assert.equal(groups.length,23);
 const all=parseWineRows(actual,1000);console.log('Real workbook:',all.length,'wines;',groups.map(g=>g.rows.length-1).join(', '),'per tasting');
 assert.equal(groups[0].rows.length-1,12);assert.equal(all[0].winery,'Chandon');assert.equal(all[2].name,'Redoma Tinto');assert.equal(all[3].name,'Vina Ardanza');assert.equal(all[5].name,'Cannubi');assert.equal(all[0].year,null);assert.deepEqual(all[0].grapes,['Chardonnay','Pinot Noir']);
 assert.equal(all.length,groups.reduce((sum,g)=>sum+parseWineRows(g.rows,60).length,0));
 assert.throws(()=>parseWineRows(actual,60),/Mai poți/);
}
console.log('Journal import passed: blank rows, groups, abbreviations, proportions, validation and privacy.');

const explicit=parseWineRows([['Cramă','Vin','Soiuri'],['Estate','Merlot Reserve','M']],60)[0];
assert.equal(wineIdentifier([{name:'Merlot'}],[],true)(explicit).name,'Merlot Reserve');
assert.equal(wineIdentifier([{name:'Merlot'}])(explicit).name,'Reserve');
