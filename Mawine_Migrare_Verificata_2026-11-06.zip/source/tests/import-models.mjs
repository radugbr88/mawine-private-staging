import {compileTree} from './helpers/compile.mjs';
import assert from 'node:assert/strict';import fs from 'node:fs';import Excel from 'exceljs';
const dir='.sites-runtime/models-tests';compileTree('app/wine-import.ts',dir);compileTree('app/identify-wine.ts',dir);
const {parseWineRows}=await import('../'+dir+'/wine-import.mjs');const {wineIdentifier}=await import('../'+dir+'/identify-wine.mjs');
const grapes=JSON.parse(fs.readFileSync('app/grape-data.json','utf8'));
const flatten=rows=>rows.map(r=>r.map(v=>v instanceof Date?v:v&&typeof v==='object'?('result'in v?v.result:'richText'in v?v.richText.map(t=>t.text).join(''):'text'in v?v.text:''):v));
const identify=wineIdentifier(grapes,[],true);
const read=(name,filename)=>parseWineRows(flatten(JSON.parse(fs.readFileSync('tests/fixtures/'+name,'utf8'))),1000,[],filename).map(identify);
const sa=read('south-africa-import.json','Degustare Africa de sud.xlsx');assert.equal(sa.length,12);
assert.equal(sa[0].name,'Cabernet Sauvignon Franschhoek');assert.equal(sa[0].winery,'Boekenhoutskloof');assert.equal(sa[2].name,"Director's Reserve White");assert.equal(sa[2].winery,'Tokara');assert.equal(sa[11].winery,'Boekenhoutskloof');assert.ok(sa.every(w=>w.country==='Africa de Sud'&&w.name&&w.winery));assert.ok(sa[0].grapes.includes('Cabernet Sauvignon'));
const pt=read('portugal-import.json','LISTA VINURI PORTUGHEZE.xlsx');assert.equal(pt.length,9);assert.equal(pt[0].winery,'Anselmo Mendes');assert.equal(pt[0].name,'Muros Antigos');assert.equal(pt[0].year,2015);assert.equal(pt[0].price,'30.50 RON');assert.ok(pt.every(w=>w.country==='Portugalia'&&w.year&&w.grapes.length));assert.deepEqual(pt[3].grapes,['Fernão Pires','Baga']);assert.equal(pt[5].name,'TN');assert.deepEqual(pt[5].grapes,['Touriga Nacional']);
const combined={...sa[0],name:'Boekenhoutskloof - The Chocolate Block',winery:''};assert.equal(wineIdentifier(grapes,['Boekenhoutskloof'],true)(combined).name,'The Chocolate Block');
if(process.argv[2])for(const [file,count] of [['0. Degustari de (T)VINeri(2).xlsx',269],['TABEL VINURI(1).xlsx',12],['Degustare Africa de sud.xlsx',12],['DEGUSTARE MARTIENI FEBR2023 ISRAEL(2).xlsx',9],['LISTA VINURI PORTUGHEZE.xlsx',9]]){
 const wb=new Excel.Workbook();await wb.xlsx.readFile(process.argv[2]+'/'+file);const rows=[];wb.worksheets[0].eachRow({includeEmpty:true},r=>rows.push(r.values.slice(1)));
 const wines=parseWineRows(flatten(rows),1000,[],file).map(identify);assert.equal(wines.length,count);
 if(file.startsWith('TABEL'))assert.ok(wines.every(w=>w.winery&&!w.name));
 if(file.startsWith('DEGUSTARE MARTIENI')){assert.equal(wines[3].name,'RESERVE CABERNET SAUVIGNON');assert.equal(wines[3].winery,'FLAM')}
 console.log(file+': '+wines.length+' wines OK');
}
console.log('All import layouts: split names, explicit labels, grapes, vintage, currencies, totals and empty cells passed.');
