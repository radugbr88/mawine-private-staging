import assert from 'node:assert/strict';
import fs from 'node:fs';
import ts from 'typescript';
fs.mkdirSync('.sites-runtime/tests',{recursive:true});
fs.writeFileSync('.sites-runtime/tests/reset-email.mjs',ts.transpileModule(fs.readFileSync('app/reset-email.ts','utf8'),{compilerOptions:{module:ts.ModuleKind.ES2022,target:ts.ScriptTarget.ES2022}}).outputText);
const {resetEmailConfig,sendResetEmail}=await import('../.sites-runtime/tests/reset-email.mjs');
const env={CLOUDFLARE_EMAIL_API_TOKEN:'test-only',CLOUDFLARE_ACCOUNT_ID:'a'.repeat(32),MAWINE_EMAIL_FROM:'no-reply@mawine.app',MAWINE_PUBLIC_ORIGIN:'https://mawine.app'};
for(const key of Object.keys(env))assert.equal(resetEmailConfig({...env,[key]:''}),null);
for(const origin of ['http://mawine.app','https://user:pass@mawine.app','https://mawine.app/evil','https://mawine.app/?q=x','https://mawine.app/#x'])assert.equal(resetEmailConfig({...env,MAWINE_PUBLIC_ORIGIN:origin}),null);
assert.equal(resetEmailConfig({...env,CLOUDFLARE_ACCOUNT_ID:'../evil'}),null);
const config=resetEmailConfig(env);assert.equal(config.origin,'https://mawine.app');
for(const result of [{delivered:['user@example.com']},{queued:['user@example.com']}]){
 globalThis.fetch=async(_url,options)=>{assert.equal(options.redirect,'error');assert(options.signal);return Response.json({success:true,result})};
 await sendResetEmail(config,'user@example.com','Reset','Link');
}
for(const payload of [{success:false},{success:true},{success:true,result:{delivered:['someoneelse@example.com']}},{success:true,result:{delivered:['user@example.com'],permanent_bounces:['user@example.com']}}]){
 globalThis.fetch=async()=>Response.json(payload);
 await assert.rejects(sendResetEmail(config,'user@example.com','Reset','Link'));
}
globalThis.fetch=async()=>new Response('not JSON');await assert.rejects(sendResetEmail(config,'user@example.com','Reset','Link'));
console.log('PASS: missing secret/config, safe HTTPS origin, delivered/queued, bounce, wrong recipient and malformed API responses.');
