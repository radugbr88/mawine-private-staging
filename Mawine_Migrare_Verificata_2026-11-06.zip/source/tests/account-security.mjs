import assert from 'node:assert/strict';
import fs from 'node:fs';
import {pathToFileURL} from 'node:url';
import {DatabaseSync} from 'node:sqlite';
import {compileTree} from './helpers/compile.mjs';
const dir='.sites-runtime/account-security';
const routeFile=compileTree('app/api/app/route.ts',dir);
fs.writeFileSync(routeFile,fs.readFileSync(routeFile,'utf8').replace("import { env } from 'cloudflare:workers';",'const env=globalThis.testAccountEnv;'));
const db=new DatabaseSync(':memory:');for(const file of fs.readdirSync('drizzle').filter(f=>f.endsWith('.sql')).sort())db.exec(fs.readFileSync('drizzle/'+file,'utf8'));
const prepare=sql=>{const stmt=db.prepare(sql);let args=[];const q={bind(...v){args=v;return q},async first(){return stmt.get(...args)||null},async all(){return{results:stmt.all(...args)}},async run(){return{meta:{changes:stmt.run(...args).changes}}}};return q};
const config={DB:{prepare,async batch(qs){db.exec('BEGIN');try{const result=[];for(const q of qs)result.push(await q.run());db.exec('COMMIT');return result}catch(e){db.exec('ROLLBACK');throw e}}},MAWINE_RECOVERY_ENCRYPTION_KEY:Buffer.alloc(32,42).toString('base64'),CLOUDFLARE_EMAIL_API_TOKEN:'fake-test-token',CLOUDFLARE_ACCOUNT_ID:'a'.repeat(32),MAWINE_EMAIL_FROM:'no-reply@example.com',MAWINE_PUBLIC_ORIGIN:'https://test.local'};
globalThis.testAccountEnv=config;
const sent=[];globalThis.fetch=async(url,init)=>{assert.match(String(url),/^https:\/\/api.cloudflare.com\//);const payload=JSON.parse(init.body);sent.push(payload);return Response.json({success:true,result:{queued:[payload.to]}})};
const {GET,POST}=await import(pathToFileURL(routeFile));
const cookies=new Map();
async function api(user,action,data={},status=200){const response=await(action?POST:GET)(new Request('https://test.local/api/app',{method:action?'POST':'GET',headers:{origin:'https://test.local','cf-connecting-ip':user,cookie:cookies.get(user)||'','content-type':'application/json'},...(action?{body:JSON.stringify({action,...(action==='activateHost'?{confirm:data.password}:{}),...data})}:{})}));if(response.headers.get('set-cookie'))cookies.set(user,response.headers.get('set-cookie').split(';')[0]);const result=await response.json();assert.equal(response.status,status,JSON.stringify(result));return result}
const create=user=>api(user,'createProfile',{name:user,dob:'1990-01-01',gender:'',termsAccepted:'yes',language:'ro'});
const activate=(user,email)=>api(user,'activateHost',{email,password:'secret-password-123',termsAccepted:'yes'});
const token=()=>sent.at(-1).text.match(/#verify=([a-f0-9]{64})/)[1];
const guest=await create('guest');const code=guest.recoveryCode;assert.ok(code);assert.equal(guest.profile.recoveryCode,code);assert.equal((await api('guest','recovery')).recoveryCode,code);assert.equal((await api('guest')).profile.recoveryCode,code);assert.equal((await api('guest-other','recover',{code})).profile.recoveryCode,code);assert.equal(db.prepare('SELECT recovery_cipher FROM profiles WHERE id=?').get(guest.profile.id).recovery_cipher.includes(code),false);
// Installation reminder is once per day in the first three calendar days.
assert.equal((await api('guest','claimInstallReminder')).reminder.kind,'install-app');assert.equal((await api('guest','claimInstallReminder')).reminder,null);db.prepare('UPDATE profiles SET created_at=? WHERE id=?').run(Date.now()-4*86400000,guest.profile.id);assert.equal((await api('guest','claimInstallReminder')).reminder,null);
const pending=await activate('guest','User@Example.com');assert.equal(pending.profile.host,false);assert.equal(pending.pendingVerification.email,'user@example.com');assert.equal(db.prepare('SELECT trial_started_at FROM profiles WHERE id=?').get(guest.profile.id).trial_started_at,null);
assert.ok(Math.abs(db.prepare('SELECT expires FROM email_verifications WHERE profile_id=?').get(guest.profile.id).expires-Date.now()-600000)<2000);
assert.ok((await api('pending-login','login',{email:'user@example.com',password:'secret-password-123'})).pendingVerification);
await api('pending-login','updateProfile',{name:'Blocked'},403);
await api('pending-wrong','login',{email:'user@example.com',password:'wrong'},400);
const verifyToken=token();assert.equal((await api('stranger','confirmEmail',{token:verifyToken})).requiresPassword,true);await api('stranger','confirmEmail',{token:verifyToken,password:'wrong'},400);
const confirmed=await api('guest','confirmEmail',{token:verifyToken});assert.equal(confirmed.profile.host,true);assert.match(db.prepare('SELECT password FROM profiles WHERE id=?').get(guest.profile.id).password,/^v2\$/);assert.equal(confirmed.profile.email,'user@example.com');assert.equal(confirmed.profile.emailVerified,true);const authCookie=cookies.get('guest').split('=')[1];const sid=Buffer.from(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(authCookie))).toString('hex');assert(db.prepare('SELECT expires FROM guest_sessions WHERE id=?').get(sid).expires<=Date.now()+30*86400000);assert.equal(confirmed.profile.recoveryCode,null);assert.ok(confirmed.profile.trialStartedAt);await api('guest','confirmEmail',{token:verifyToken},400);
await api('new','recover',{code},400);await api('new','login',{email:'USER@example.com',password:'secret-password-123'});await api('new','saveRecoveryEmail',{email:'changed@example.com'},403);
const other=await create('second');await activate('second','second@example.com');const secondToken=token();const cross=await api('cross','confirmEmail',{token:secondToken,password:'secret-password-123'});assert.equal(cross.profile.id,other.profile.id);assert.equal(cross.profile.host,true);
const noEmail=await create('no-email');delete config.CLOUDFLARE_EMAIL_API_TOKEN;await api('no-email','activateHost',{email:'no@example.com',password:'secret-password-123',termsAccepted:'yes'},503);assert.equal(db.prepare('SELECT count(*) AS n FROM email_verifications WHERE profile_id=?').get(noEmail.profile.id).n,0);config.CLOUDFLARE_EMAIL_API_TOKEN='fake';
const expired=await create('expired');await activate('expired','expired@example.com');const expiredToken=token();db.prepare('UPDATE email_verifications SET expires=0 WHERE profile_id=?').run(expired.profile.id);await api('expired','confirmEmail',{token:expiredToken},400);
assert.ok((await api('expired-login','login',{email:'expired@example.com',password:'secret-password-123'})).pendingVerification);
// A deleted account cannot acquire another introductory trial with the same email.
await api('guest','deleteProfile',{current:'secret-password-123'});await create('repeat');await activate('repeat','user@example.com');const repeat=await api('repeat','confirmEmail',{token:token()});assert.ok(repeat.profile.trialStartedAt<=Date.now()-33*86400000);assert.equal(repeat.profile.host,false);
// Retention expiry removes the fingerprint after 365 days and restores eligibility.
await create('retention');await activate('retention','retention@example.com');await api('retention','confirmEmail',{token:token()});await api('retention','deleteProfile',{current:'secret-password-123'});db.prepare('UPDATE trial_email_ledger SET used_at=?').run(Date.now()-366*86400000);await create('retention-new');await activate('retention-new','retention@example.com');const fresh=await api('retention-new','confirmEmail',{token:token()});assert.ok(fresh.profile.trialStartedAt>Date.now()-60000);
// Legacy hash-only codes remain valid and are only restored from the original secret.
const old=await create('old');db.prepare('UPDATE profiles SET recovery_cipher=NULL WHERE id=?').run(old.profile.id);assert.equal((await api('old')).profile.recoveryCodeUnavailable,true);await api('old','recovery',{code:'WRONG'},400);assert.equal((await api('old','recovery',{code:old.recoveryCode})).recoveryCode,old.recoveryCode);
const resetFile=compileTree('app/api/password-reset/route.ts',dir);
fs.writeFileSync(resetFile,fs.readFileSync(resetFile,'utf8').replace("import { env } from 'cloudflare:workers';",'const env=globalThis.testAccountEnv;'));
const resetRoute=await import(pathToFileURL(resetFile));
async function reset(data,status=200){const r=await resetRoute.POST(new Request('https://test.local/api/password-reset',{method:'POST',headers:{origin:'https://test.local','cf-connecting-ip':'reset-tests','content-type':'application/json'},body:JSON.stringify(data)}));const result=await r.json();assert.equal(r.status,status,JSON.stringify(result));return result}
const unknown=await reset({action:'request',email:'unknown@example.com'});const known=await reset({action:'request',email:'second@example.com'});assert.equal(unknown.message,known.message);assert.equal(sent.at(-1).to,'second@example.com');
const resetToken=sent.at(-1).text.match(/#reset=([a-f0-9]{64})/)[1];await reset({action:'validate',token:resetToken});await reset({action:'reset',token:resetToken,password:'replacement-secret',confirm:'replacement-secret'});await reset({action:'validate',token:resetToken},400);
assert.equal(db.prepare('SELECT recovery_cipher FROM profiles WHERE id=?').get(other.profile.id).recovery_cipher,null,'password reset must erase obsolete recovery ciphertext');
await api('reset-login','login',{email:'second@example.com',password:'replacement-secret'});await api('reset-old','login',{email:'second@example.com',password:'secret-password-123'},400);
console.log('PASS permanent encrypted guest codes, email verification, other-device password, replay/expiry protection, unavailable delivery, immutable email, login and trial reuse.');
