import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import ts from 'typescript';
import {compileTree} from './helpers/compile.mjs';
compileTree('app/i18n.ts','.sites-runtime/entry-defaults');
const i18n=await import('../.sites-runtime/entry-defaults/i18n.mjs');
assert.equal(i18n.getLanguage(),'en');assert.equal(i18n.getServerLanguage(),'en');
const source=fs.readFileSync('app/page.tsx','utf8');
assert(!source.includes('useEffect(loadLanguage'));
const effect=source.match(/\/\/ A saved profile preference[\s\S]*?useEffect\(\(\)=>\{([\s\S]*?)\},\[loaded,p\?\.id,p\?\.language\]\);/)[1];
const run=new vm.Script(ts.transpile(`(function(){${effect}})()`));
for(const profile of [null,{id:'fr-profile',language:'fr'},null,{id:'it-profile',language:'it'},null]){
 const context=vm.createContext({loaded:true,p:profile,setLanguage:i18n.setLanguage,getEntryLanguage:i18n.getEntryLanguage});run.runInContext(context);assert.equal(i18n.getLanguage(),profile?.language||'en');
}
for(const text of ['Cum vrei să începi?','Creează profilul','Ai uitat parola?','Alege o parolă nouă','Pregătim spațiul tău de degustare…'])assert.notEqual(i18n.t(text),text,text);
const manifest=JSON.parse(fs.readFileSync('public/manifest.webmanifest','utf8'));assert.equal(manifest.name,'Mawine');assert.equal(manifest.short_name,'Mawine');
const layout=fs.readFileSync('app/layout.tsx','utf8');assert(layout.includes("appleWebApp:{capable:true,title:'Mawine'"));assert(layout.includes('lang="en"'));
console.log('PASS: English first visit and signed-out screens; French/Italian restored per profile; logout returns to English; install name Mawine on manifest and Apple metadata.');
