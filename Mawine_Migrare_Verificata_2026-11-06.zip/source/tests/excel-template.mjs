import assert from 'node:assert/strict';
import fs from 'node:fs';
import {compileTree} from './helpers/compile.mjs';
const dir='.sites-runtime/template-tests';
compileTree('app/excel-import.ts',dir);
compileTree('app/wine-import.ts',dir);
const {readWineWorkbook}=await import(`../${dir}/excel-import.mjs`);
const {parseWineRows}=await import(`../${dir}/wine-import.mjs`);
for(const file of ['tests/fixtures/wine-template-prefixed.xlsx',...['ro','en','it','fr'].map(l=>`public/templates/model-vinuri-${l}.xlsx`)]){
 const b=fs.readFileSync(file);const rows=await readWineWorkbook(b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength));
 for(const limit of [60,300]){
 const wines=parseWineRows(rows,limit);assert.equal(wines.length,1,file);
 const w=wines[0];assert.ok(w.winery);assert.ok(w.name);assert.equal(w.year,2022);assert.equal(w.alcohol,'14');assert.equal(w.price,'90');assert.equal(w.grapes.length,2);assert.equal(w.country,'România');assert.equal(w.type,'Roșu sec');
 }
}
const mixed=[['Prix','Nome del vino','Year','Cramă','Pays','Vitigni','Alcohol','Type'],[42,'Reserve',2021,'Estate','France','Merlot, Cabernet Sauvignon',13.5,'Dry red']];
const w=parseWineRows(mixed,60)[0];assert.equal(w.name,'Reserve');assert.equal(w.price,'42');assert.equal(w.winery,'Estate');assert.equal(w.year,2021);assert.equal(w.grapes.length,2);
console.log('PASS: attached prefixed workbook, four localized templates, both import limits and mixed/reordered headers.');
