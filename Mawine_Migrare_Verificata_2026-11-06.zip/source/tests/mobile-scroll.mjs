import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import ts from 'typescript';
const source=fs.readFileSync('app/mobile-ui.tsx','utf8');
const fn=source.slice(source.indexOf('export function revealField'),source.indexOf('export function revealImportTabs')).replace('export ','');
const moves=[];
const context={scrollAppBy:x=>moves.push(x.top),appScrollContainer:()=>null,window:{visualViewport:{offsetTop:0,height:500},innerHeight:800,matchMedia:()=>({matches:true}),scrollBy:x=>moves.push(x.top)}};
vm.createContext(context);vm.runInContext(ts.transpile(fn),context);
const element=(top,bottom,modal=null)=>({closest:selector=>selector==='.modal'?modal:null,getBoundingClientRect:()=>({top,bottom,height:bottom-top})});
context.revealField(element(200,250));assert.deepEqual(moves,[]);
context.revealField(element(390,450));assert.deepEqual(moves,[38]);
context.revealField(element(5,55));assert.deepEqual(moves,[38,-11]);
const modal={querySelector:()=>null,scrollTop:0,getBoundingClientRect:()=>({top:100,bottom:400})};
context.revealField(element(350,420,modal));assert.equal(modal.scrollTop,36);assert.equal(moves.length,2);
console.log('PASS: visible fields stay still; hidden fields move only by the missing space; modal scrolling stays local.');
context.revealField(element(250,900,modal),true);assert.equal(modal.scrollTop,170);assert.equal(moves.length,2);
console.log('PASS: opening a selector aligns its top inside the modal without scrolling the page.');

const clipped={scrollTop:0,querySelector:()=>null,getBoundingClientRect:()=>({top:-50,bottom:700})};
context.revealField(element(450,550,clipped));assert.equal(clipped.scrollTop,66);
console.log('PASS: modal fields respect the keyboard viewport even if modal bounds extend beyond it.');

const tabFn=source.slice(source.indexOf('export function revealImportTabs'),source.indexOf('export function useVisibleField')).replace('export ','');
context.document={querySelector:()=>({getBoundingClientRect:()=>({height:88})})};
vm.runInContext(ts.transpile(tabFn),context);
moves.length=0;
context.revealImportTabs(element(400,450));
assert.equal(moves[0],388);
context.revealImportTabs(element(12,62));
assert.equal(moves.length,1);
context.window.visualViewport.offsetTop=40;
context.revealImportTabs(element(400,450));
assert.equal(moves[1],348);
context.window.matchMedia=()=>({matches:false});
context.revealImportTabs(element(400,450));
assert.equal(moves.length,3);
console.log('PASS: import tabs use one stable mobile anchor, respect viewport offset and also align desktop content.');

// A zero-origin internal scroller must not inherit Safari's viewport offset.
context.appScrollContainer=()=>({getBoundingClientRect:()=>({top:0})});
moves.length=0;
context.revealImportTabs(element(400,450),'excel');assert.equal(moves[0],352);
context.revealImportTabs(element(400,450),'catalog');assert.equal(moves[1],388);
context.revealImportTabs(element(48,98),'excel');assert.equal(moves.length,2);
console.log('PASS: Excel and collection reference insets are stable inside the app scroller.');
