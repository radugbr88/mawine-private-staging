import assert from 'node:assert/strict';
import {compileTree} from './helpers/compile.mjs';
compileTree('app/recovery-export.ts','.sites-runtime/export-tests');
const {copyRecoveryCode,saveRecoveryCode}=await import('../.sites-runtime/export-tests/recovery-export.mjs');
const {setLanguage}=await import('../.sites-runtime/export-tests/i18n.mjs');
const originalTimers={setTimeout,clearTimeout};let timers=[];
globalThis.setTimeout=(fn,ms)=>{timers.push({fn,ms});return timers.length};globalThis.clearTimeout=()=>{};
const nav={};Object.defineProperty(globalThis,'navigator',{value:nav,configurable:true});
try{
 let copied;nav.clipboard={writeText:async value=>{copied=value}};await copyRecoveryCode('test-code');assert.equal(copied,'test-code');
 nav.clipboard=undefined;await assert.rejects(copyRecoveryCode('test-code'),/unavailable/);
 nav.clipboard={writeText:()=>Promise.reject(Error('permission denied'))};await assert.rejects(copyRecoveryCode('test-code'),/permission/);
 nav.clipboard={writeText:()=>new Promise(()=>{})};const hanging=copyRecoveryCode('test-code');timers.at(-1).fn();await assert.rejects(hanging,/timeout/);
 let downloaded,removed=false,appended=false;
 globalThis.document={documentElement:{},createElement:()=>({click(){downloaded=this.download},remove(){removed=true}})};
 const container={appendChild(){appended=true}};
 for(const lang of ['ro','en','it','fr']){
  setLanguage(lang);let shared;
  nav.canShare=()=>true;nav.share=async data=>{shared=data};
  assert.equal(await saveRecoveryCode('test-code',container),'shared');
  const text=await shared.files[0].text();assert(text.includes('test-code'));assert(text.includes(lang==='ro'?'Păstrează-l privat':lang==='en'?'Keep':lang==='it'?'privato':'privé'));
 }
 nav.share=async()=>{throw new DOMException('Cancelled','AbortError')};assert.equal(await saveRecoveryCode('test-code',container),'cancelled');assert.equal(appended,false);
 nav.share=async()=>{throw Error('share failed')};assert.equal(await saveRecoveryCode('test-code',container),'downloaded');assert(appended&&removed);assert(downloaded.endsWith('.txt'));
 timers.filter(t=>t.ms===60000).forEach(t=>t.fn());
 console.log('PASS: copy success, missing/denied clipboard, timeout, translated recovery files in four languages, share cancel and download fallback.');
}finally{Object.assign(globalThis,originalTimers)}
