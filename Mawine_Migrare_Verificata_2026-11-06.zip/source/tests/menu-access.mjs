import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import ts from 'typescript';
const source=fs.readFileSync('app/page.tsx','utf8');
const go=source.slice(source.indexOf(' function go('),source.indexOf(' async function action('));
const all=['home','events','wines','statistics','catalog','profile','notifications','language','recoveryEmail','subscription','subscriptionPeriod','recovery','profileEdit','password','createEvent','manage','invite','tasting','results','welcomeTasting','join','welcome','createProfile','hostSignup','recover','login','access','forgotPassword','resetPassword','verifyEmail','entryLanguage'];
const publicPages=['welcome','createProfile','hostSignup','recover','login','access','forgotPassword','resetPassword','verifyEmail','entryLanguage'];
const hostPages=['catalog','statistics','createEvent','manage','invite','subscription','subscriptionPeriod'];
let count=0;
for(const role of ['host','participant','signedOut'])for(const destination of all){
 let actual;const profile=role==='signedOut'?null:{host:role==='host'};
 const ctx={leaveSignup:()=>true,stateRef:{current:{profile}},page:'home',hostSignupOrigin:{current:{}},appScrollTop:()=>125,setCatalogTab(){},setNotice(){},setCamera(){},setPage:value=>actual=value,setError(){},setQuery(){},setImported(){},setPaste(){}};
 vm.createContext(ctx);vm.runInContext(ts.transpile(go),ctx);ctx.go(destination);
 const expected=!profile&&!publicPages.includes(destination)?'welcome':hostPages.includes(destination)&&!profile?.host?'home':destination;
 assert.equal(actual,expected,role+': '+destination);count++;
}
console.log(`PASS: ${count} menu access cases for host, participant and signed-out visitors.`);

// Reopening the collection after an Excel import must restore its saved list.
for(const origin of ['catalog','wines','profile','events']){
 let catalogTab='excel',query='old search';const catalog=[{id:'saved-wine',name:'Reserve'}];
 const ctx={leaveSignup:()=>true,stateRef:{current:{profile:{host:true,catalog}}},page:origin,hostSignupOrigin:{current:{}},appScrollTop:()=>0,setNotice(){},setCamera(){},setPage(){},setError(){},setQuery:value=>query=value,setImported(){},setPaste(){},setCatalogTab:value=>catalogTab=value};
 vm.createContext(ctx);vm.runInContext(ts.transpile(go),ctx);ctx.go('catalog');
 assert.equal(catalogTab,'personal');assert.equal(query,'');assert.equal(ctx.stateRef.current.profile.catalog,catalog);assert.equal(catalog.length,1);
}
console.log('PASS: collection re-entry exits Excel mode, restores list/filter visibility and preserves saved wines');
