import {compileTree} from './helpers/compile.mjs';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import ts from 'typescript';
import Excel from 'exceljs';
const inlineGrapeData=s=>s.replace("import grapeData from './grape-data.json';",'const grapeData='+fs.readFileSync('app/grape-data.json','utf8')+';');
const dir='.sites-runtime/import-tests';fs.mkdirSync(dir,{recursive:true});
compileTree('app/wine-import.ts',dir);
const {parseWineRows,parseDelimited}=await import(`../${dir}/wine-import.mjs`);
const fixture=JSON.parse(fs.readFileSync('tests/fixtures/israel-import.json','utf8'));
const flatten=rows=>rows.map(row=>row.map(v=>v&&typeof v==='object'?'result'in v?v.result:'richText'in v?v.richText.map(t=>t.text).join(''):'text'in v?v.text:'':v));
let rows=flatten(fixture);
if(process.argv[2]){
 const wb=new Excel.Workbook();await wb.xlsx.readFile(process.argv[2]);const actual=[];
 wb.worksheets[0].eachRow({includeEmpty:true},r=>actual.push(r.values.slice(1)));
 rows=flatten(actual);assert.deepEqual(JSON.parse(JSON.stringify(rows)),flatten(fixture));
}
for(const limit of [60,300]){
 const wines=parseWineRows(rows,limit);
 assert.equal(wines.length,9);
 assert.equal(wines[0].winery,'SPHERA');assert.equal(wines[0].name,'WHITE CONCEPTS FIRST PAGE');
 assert.equal(wines[0].year,2020);assert.equal(wines[0].alcohol,'13.5');assert.equal(wines[0].price,'38.85 EUR');
 assert.equal(wines[0].country,'');assert.equal(wines[0].type,'ALB');
 assert.deepEqual(wines[0].grapes,['SEMILLON','ROUSSANNE','CHENIN BLANC']);
 assert.deepEqual(wines[8].grapes,['CABERNET SAUVIGNON','SHIRAZ','PETIT VERDOT','CABERNET FRANC']);
 assert.equal(wines[8].winery,'MATAR');assert.equal(wines[8].name,'CB');
 assert.ok(wines.every(w=>w.name&&w.winery&&w.alcohol&&w.grapes.length));
}
assert.throws(()=>parseWineRows(rows,8),/Mai poți/);
assert.throws(()=>parseWineRows([['Vin','An','Preț'],['',2020,20]],60),/lipsește numele/);
assert.throws(()=>parseWineRows([['Vin','An'],['A',1800]],60),/anul/);
assert.throws(()=>parseWineRows([['Vin','Name'],['A','B']],60),/ambigue/);
const named=parseWineRows([['Vin','An','Cramă'],['Total',2020,'Crama']],60);assert.equal(named.length,1);
const csv=parseWineRows(parseDelimited('DENUMIRE CRAMA;DENUMIRE VIN;SOI/SOIURI;ALC (%);Țara\nCrama;Vin A;Merlot;14;România'),60);
assert.equal(csv[0].country,'România');assert.equal(csv[0].alcohol,'14');assert.deepEqual(csv[0].grapes,['Merlot']);
const countryRows=[['Degustare AFRICA DE SUD'],['Vin','Țara'],['Rezerva',''],['Alt vin','Israel']];
assert.deepEqual(parseWineRows(countryRows,60).map(w=>w.country),['Africa de Sud','Israel']);
assert.equal(parseWineRows([['Degustare Israel'],['Vin'],['Rezerva']],60,[],'Africa de Sud.xlsx')[0].country,'Israel');
assert.equal(parseWineRows([['Degustare Israel și România'],['Vin'],['Rezerva']],60,[],'Israel.xlsx')[0].country,'');
assert.equal(parseWineRows([['Vin'],['Israel Reserve']],60)[0].country,'');
assert.equal(parseWineRows([['Degustare South Africa'],['Vin'],['Rezerva']],60)[0].country,'Africa de Sud');
assert.equal(parseWineRows([['Degustare România'],['Vin'],['Rezerva']],60)[0].country,'România');
assert.equal(parseWineRows([['Degustare Israeliană'],['Vin'],['Rezerva']],60)[0].country,'');
assert.ok(parseWineRows(rows,60,[],'DEGUSTARE MARTIENI FEBR2023 ISRAEL(1).xlsx').every(w=>w.country==='Israel'));
console.log('Country context OK: preamble, filename, explicit row priority, multiple-country ambiguity, accent and word boundaries.');
console.log('Import OK: attached Excel, 9 wines, both limits, aliases, summary, currency, grape qualifiers and malformed rows.');
const georgia=flatten(JSON.parse(fs.readFileSync('tests/fixtures/georgia-import.json','utf8')));
const {mergeWineCollection}=await import(`../${dir}/wine-identity.mjs`);
for(const limit of [60,300]){
 const wines=parseWineRows(georgia,limit,[],'TABEL VINURI.xlsx');
 assert.equal(wines.length,12);assert.ok(wines.every(w=>w.name===''&&w.winery&&w.country==='Georgia'));
 assert.equal(wines[0].alcohol,'12.5');assert.equal(wines[2].alcohol,'13.5');assert.equal(wines[9].price,'35.95 EUR');
 const merged=mergeWineCollection([],wines);assert.equal(merged.length,12);
 assert.equal(mergeWineCollection(merged,wines.map(w=>({...w,id:crypto.randomUUID()}))).length,12);
}
assert.equal(parseWineRows([['Cramă','Vin','An'],['Crama A','',2020]],60)[0].name,'');
assert.throws(()=>parseWineRows([['Cramă','An'],['',2020]],60),/lipsește/);
assert.equal(parseWineRows(parseDelimited('Cramă;An\nCrama A;2020'),60)[0].name,'');
console.log('Winery-only import OK: attached 12-row Georgia workbook, blank names, percentages, prices, no collection collisions.');
