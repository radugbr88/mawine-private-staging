import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import ts from 'typescript';
import {compileTree} from './helpers/compile.mjs';
compileTree('app/lib.ts','.sites-runtime/audit');compileTree('app/wine-import.ts','.sites-runtime/audit');
const {matchesWine}=await import('../.sites-runtime/audit/lib.mjs');
const {parseWineRows}=await import('../.sites-runtime/audit/wine-import.mjs');
const {setLanguage}=await import('../.sites-runtime/audit/i18n.mjs');
const failures=[];
async function audit(name,run){try{await run();console.log('PASS: '+name)}catch(error){failures.push(name+': '+error.message)}}
await audit('localized wine type and country search',()=>{
 const wine={name:'Reserve',winery:'Estate',year:2020,grapes:[],country:'Franța',type:'Alb sec'};
 for(const [lang,query] of [['ro','alb sec franta'],['en','dry white france'],['it','bianco secco francia'],['fr','blanc sec france']]){setLanguage(lang);assert(matchesWine(wine,query),lang)}
});
await audit('French and Italian spreadsheet headers',()=>{
 for(const header of [['Vin','Domaine','Année','Pays','Cépages','Type','Alcool','Prix'],['Vino','Cantina','Anno','Paese','Vitigni','Tipo','Alcol','Prezzo']]){
  const wines=parseWineRows([header,['Reserve','Estate',2020,'România','Merlot','Roșu sec',14,90]],60);
  assert.equal(wines[0].winery,'Estate');assert.equal(wines[0].year,2020);assert.equal(wines[0].price,'90');
 }
});
await audit('failed collection save keeps its error visible and editor open',async()=>{
 const source=fs.readFileSync('app/page.tsx','utf8');const fn=source.slice(source.indexOf(' async function saveWine('),source.indexOf(' function eventPayload'));
 let error='',closed=false;
 const wine={id:'w',name:'Reserve',winery:'Estate'};
 const context={editWine:wine,wineTarget:'catalog',p:{catalog:[]},setError:value=>error=value,setEditWine:()=>closed=true,setCatalogTab(){},setNotice(){},action:async action=>{if(action==='identifyWines')return{identifiedWines:[wine]};error='Maximum 300 de vinuri.';return null}};
 vm.createContext(context);vm.runInContext(ts.transpile(fn),context);await context.saveWine();assert.equal(error,'Maximum 300 de vinuri.');assert.equal(closed,false);
});
assert.deepEqual(failures,[]);
