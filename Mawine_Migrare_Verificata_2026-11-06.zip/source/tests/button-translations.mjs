import assert from 'node:assert/strict';
import fs from 'node:fs';
import React from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {compileTree} from './helpers/compile.mjs';
const dir='.sites-runtime/button-translations';
const {CollectionSortBar}=await import(compileTree('app/collection-sort.tsx',dir));
const {SubscriptionPanel}=await import(compileTree('app/subscription-panel.tsx',dir));
const {setLanguage}=await import(compileTree('app/i18n.ts',dir));
const labels={ro:['Cramă','Vin','An','Soi'],en:['Winery','Wine','Year','Grape'],it:['Cantina','Vino','Anno','Vitigno'],fr:['Domaine','Vin','Année','Cépage']};
for(const [lang,expected] of Object.entries(labels)){
 setLanguage(lang);
 const html=renderToStaticMarkup(React.createElement(CollectionSortBar,{open:true,value:null,onToggle(){},onChange(){}}));
 for(const label of expected)assert(html.includes(label),lang+': '+label);
 for(const plan of ['monthly','annual']){
  const panel=renderToStaticMarkup(React.createElement(SubscriptionPanel,{choosing:true,startedAt:Date.now(),busy:false,onChoose(){},onUnavailable(){},onDowngrade(){},billing:{enabled:true,mode:'simulation',hasCustomer:true,subscription:{plan,paid:true,status:'active'}}}));
  assert(panel.includes(`checked="" value="${plan}"`)||panel.includes(`value="${plan}" checked=""`),plan);
 }
}
// Literal UI translations across every top-level component, including button labels.
for(const lang of ['en','it','fr']){
 const dict=JSON.parse(fs.readFileSync(`app/i18n-${lang}.json`));
 for(const f of fs.readdirSync('app').filter(f=>f.endsWith('.tsx'))){
  const source=fs.readFileSync('app/'+f,'utf8');
  for(const m of source.matchAll(/(?:translate|\bt)\(['"]([^'"]+)['"]/g)){
   const label=m[1].trim();if(label.length<2||['/ 10','/1','Vivino'].includes(label))continue;
   assert(dict[label],`${lang} ${f}: ${label}`);
  }
 }
}
console.log('PASS button translation coverage, actual four-language sorting controls and active monthly/annual radio selection');
