import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import ts from 'typescript';
const source=fs.readFileSync('app/page.tsx','utf8');
const fn=source.slice(source.indexOf(' function requestWineReveal'),source.indexOf(' function backToEvents'));
for(const scenario of ['owner','guest','visitingHost','ended','normal','revealed','busy']){
 const calls=[];let confirmation;
 const event={id:'event1',owner:'owner',status:scenario==='ended'?'ended':'active',mode:scenario==='normal'?'normal':'blind'};
 const wine={id:'wine2',winery:'Crama',name:''};
 const ctx={busy:scenario==='busy',p:{host:scenario!=='guest',id:['guest','visitingHost'].includes(scenario)?'visitor':'owner'},isWineRevealed:()=>scenario==='revealed',setConfirm:c=>{confirmation=c},action:async(a,payload)=>calls.push([a,payload.id,payload.wineId])};
 vm.createContext(ctx);vm.runInContext(ts.transpile(fn+';globalThis.reveal=requestWineReveal;'),ctx);
 ctx.reveal(event,wine);
 assert.equal(calls.length,0,'Revealing requires confirmation');
 if(scenario==='owner'){
  assert.equal(confirmation.title,'Dezvălui acest vin?');
  await confirmation.run();
  assert.deepEqual(calls,[['revealWine','event1','wine2']]);
  assert.equal(confirmation,null);
 }else assert.equal(confirmation,undefined,scenario);
}
assert(source.includes('onClick={()=>requestWineReveal(ev,wine)}'));
assert(source.includes('onClick={()=>requestWineReveal(ev,w)}'));
console.log('PASS: list and detail share confirmed, owner-only, individual wine reveal.');
