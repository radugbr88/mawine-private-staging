import assert from 'node:assert/strict';
import {createECDH,hkdfSync,createDecipheriv,verify,createPublicKey} from 'node:crypto';
import {DatabaseSync} from 'node:sqlite';
import fs from 'node:fs';
import {compileTree} from './helpers/compile.mjs';
const {encryptPush,vapidAuthorization,pushEndpoint,base64url}=await import(compileTree('app/web-push.ts','.sites-runtime/push-tests'));
const {pushAction,dispatchPush}=await import(compileTree('app/push.ts','.sites-runtime/push-tests'));
const {translateForLanguage}=await import(compileTree('app/i18n.ts','.sites-runtime/push-tests'));
const pair=await crypto.subtle.generateKey({name:'ECDSA',namedCurve:'P-256'},true,['sign','verify']);
const publicKey=await crypto.subtle.exportKey('jwk',pair.publicKey);
const env={MAWINE_PUSH_PUBLIC_KEY:base64url(new Uint8Array(await crypto.subtle.exportKey('raw',pair.publicKey))),MAWINE_PUSH_PRIVATE_JWK:JSON.stringify(await crypto.subtle.exportKey('jwk',pair.privateKey))};
const client=createECDH('prime256v1');client.generateKeys();const auth=crypto.getRandomValues(new Uint8Array(16));
const sub={endpoint:'https://fcm.googleapis.com/fcm/send/example-test-token',p256dh:client.getPublicKey().toString('base64url'),auth:base64url(auth)};
// Independent Node crypto decryption checks the RFC wire format, ECDH, both HKDF stages and delimiter.
const wire=Buffer.from(await encryptPush(sub.p256dh,sub.auth,'{"test":"Mawine"}'));
assert.equal(wire.readUInt32BE(16),4096);assert.equal(wire[20],65);
const sender=wire.subarray(21,86),salt=wire.subarray(0,16),shared=client.computeSecret(sender);
const ikm=hkdfSync('sha256',shared,auth,Buffer.concat([Buffer.from('WebPush: info\0'),client.getPublicKey(),sender]),32);
const key=hkdfSync('sha256',ikm,salt,Buffer.from('Content-Encoding: aes128gcm\0'),16),nonce=hkdfSync('sha256',ikm,salt,Buffer.from('Content-Encoding: nonce\0'),12);
const decipher=createDecipheriv('aes-128-gcm',key,nonce);decipher.setAuthTag(wire.subarray(-16));const plain=Buffer.concat([decipher.update(wire.subarray(86,-16)),decipher.final()]);assert.equal(plain.at(-1),2);assert.equal(plain.subarray(0,-1).toString(),'{"test":"Mawine"}');
const header=await vapidAuthorization(sub.endpoint,env);const jwt=header.match(/vapid t=([^,]+)/)[1];const [h,b,s]=jwt.split('.');assert(verify('sha256',Buffer.from(h+'.'+b),{key:createPublicKey({key:publicKey,format:'jwk'}),dsaEncoding:'ieee-p1363'},Buffer.from(s,'base64url')));assert.equal(JSON.parse(Buffer.from(b,'base64url')).aud,'https://fcm.googleapis.com');
for(const url of ['https://evil.example/push','http://fcm.googleapis.com/push','https://fcm.googleapis.com.evil.example/push','https://user@fcm.googleapis.com/push','https://127.0.0.1/push','https://fcm.googleapis.com:444/push'])assert.throws(()=>pushEndpoint(url));
const sqlite=new DatabaseSync(':memory:');sqlite.exec('PRAGMA foreign_keys=ON');for(const f of fs.readdirSync('drizzle').filter(f=>f.endsWith('.sql')).sort())sqlite.exec(fs.readFileSync('drizzle/'+f,'utf8'));
const prepare=sql=>{let args=[];const stmt=sqlite.prepare(sql);const q={bind(...a){args=a;return q},async first(){return stmt.get(...args)||null},async all(){return{results:stmt.all(...args)}},async run(){return{meta:{changes:stmt.run(...args).changes}}}};return q};const db={prepare,batch:async list=>Promise.all(list.map(q=>q.run()))};
const now=Date.now(),day=86400000;
sqlite.prepare("INSERT INTO profiles(id,name,dob,gender,recovery,created_at,host,username,trial_started_at,language) VALUES('p','Test','1990-01-01','','test',?,1,'push-test',?,'en')").run(now-35*day,now-15*day);
sqlite.prepare("INSERT INTO guest_sessions(id,expires) VALUES('session',?)").run(now+50*day);sqlite.exec("INSERT INTO identities(identity,profile_id) VALUES('guest:session','p')");
let p=sqlite.prepare("SELECT * FROM profiles WHERE id='p'").get();
const body={subscription:{endpoint:sub.endpoint,keys:{p256dh:sub.p256dh,auth:sub.auth}}};
assert.equal((await (await pushAction(db,env,p,'guest:session','pushConfig',{})).json()).subscribed,false);
await pushAction(db,env,p,'guest:session','pushSubscribe',body);
let sent=0;globalThis.fetch=async(url,options)=>{assert.equal(url,sub.endpoint);assert(options.headers.Authorization.startsWith('vapid '));sent++;return new Response('',{status:201})};
await dispatchPush(db,env);assert.equal(sent,1);
sqlite.exec('UPDATE push_subscriptions SET next_check=0');await dispatchPush(db,env);assert.equal(sent,1,'same-day duplicate prevented');
await pushAction(db,env,p,'guest:session','pushSubscribe',body);sqlite.exec('UPDATE push_subscriptions SET next_check=0');await dispatchPush(db,env);assert.equal(sent,1,'re-registration does not reset delivery history');
// Days 1,2,3 of grace are actually eligible, not just the expired trial state.
for(let grace=1;grace<=3;grace++){
 sqlite.prepare('UPDATE profiles SET trial_started_at=?').run(Date.now()-(29+grace)*day-1000);sqlite.exec('DELETE FROM push_deliveries; UPDATE push_subscriptions SET next_check=0');await dispatchPush(db,env);assert.equal(sent,1+grace);
}
sqlite.prepare('UPDATE profiles SET trial_started_at=?').run(Date.now()-34*day);sqlite.exec('DELETE FROM push_deliveries; UPDATE push_subscriptions SET next_check=0');await dispatchPush(db,env);assert.equal(sent,4,'no payment reminder beyond grace');
// Active administrator grant suppresses reminders, revoked session removes device.
sqlite.prepare('UPDATE profiles SET trial_started_at=?').run(now-15*day);sqlite.prepare("INSERT INTO complimentary_access VALUES('p',?,'admin',?)").run(now+day,now);sqlite.exec('UPDATE push_subscriptions SET next_check=0');await dispatchPush(db,env);assert.equal(sent,4);sqlite.exec('DELETE FROM complimentary_access');
await pushAction(db,env,p,'guest:session','pushTest',{});assert.equal(sent,5);
await pushAction(db,env,p,'guest:session','pushDisable',{});assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM push_subscriptions').get().n,0);
await pushAction(db,env,p,'guest:session','pushSubscribe',body);sqlite.exec('DELETE FROM identities');await dispatchPush(db,env);assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM push_subscriptions').get().n,0);
// Provider expiry removes the endpoint; temporary failure releases the daily claim for retry.
sqlite.exec("INSERT INTO identities(identity,profile_id) VALUES('guest:session','p')");
await pushAction(db,env,p,'guest:session','pushSubscribe',body);
globalThis.fetch=async()=>new Response('',{status:503});await dispatchPush(db,env);assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM push_deliveries').get().n,0);
sqlite.exec('UPDATE push_subscriptions SET next_check=0');globalThis.fetch=async()=>new Response('',{status:410});await dispatchPush(db,env);assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM push_subscriptions').get().n,0);
for(const lang of ['en','it','fr'])assert.notEqual(translateForLanguage(lang,'Ziua 2 din 3 de grație. Alege un abonament pentru a rămâne gazdă.'),'Ziua 2 din 3 de grație. Alege un abonament pentru a rămâne gazdă.');
console.log('PASS: encrypted push payload, VAPID verification, endpoint restrictions, consent registration, daily dedup, grace days 1–3, complimentary suppression, test send, opt-out and revoked sessions');
