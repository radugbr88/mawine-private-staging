import {compileTree as compilePush} from './helpers/compile.mjs';
compilePush('app/push.ts','.sites-runtime/eight-participants');
import {compileTree as compileFeatures} from './helpers/compile.mjs';
compileFeatures('app/admin-features.ts','.sites-runtime/eight-participants');
import {compileTree} from './helpers/compile.mjs';
compileTree('app/account-security.ts','.sites-runtime/eight-participants');
compileTree('app/security.ts','.sites-runtime/eight-participants');
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import fs from 'node:fs';
import ts from 'typescript';
import {mock} from 'node:test';
// Keep date-sensitive fixtures stable as the real calendar advances.
mock.timers.enable({apis:['Date'],now:new Date('2026-10-29T12:00:00Z')});
const inlineGrapeData=s=>s.replace("import grapeData from './grape-data.json';",'const grapeData='+fs.readFileSync('app/grape-data.json','utf8')+';');
const dir='.sites-runtime/eight-participants';fs.mkdirSync(dir,{recursive:true});compileTree('app/i18n.ts',dir);
function compile(file,out,replace=s=>s){fs.writeFileSync(dir+'/'+out,ts.transpileModule(replace(fs.readFileSync(file,'utf8')).replace(/from '(?:\.\/|\.\.\/\.\.\/)i18n'/g,"from './i18n.mjs'"),{compilerOptions:{module:ts.ModuleKind.ES2022,target:ts.ScriptTarget.ES2022}}).outputText)}
compile('app/subscription.ts','subscription.mjs');compileTree('app/billing.ts',dir);
compile('app/wine-identity.ts','wine-identity.mjs');compile('app/identify-wine.ts','identify-wine.mjs',s=>s.replace("from './wine-identity'","from './wine-identity.mjs'").replace("from './grape-names'","from './grape-names.mjs'"));compile('app/grape-names.ts','grape-names.mjs',inlineGrapeData);compile('app/lib.ts','lib.mjs',s=>s.replace("from './grape-names'","from './grape-names.mjs'"));compile('app/api/app/route.ts','route.mjs',s=>s.replace("import {env} from 'cloudflare:workers';","const env=globalThis.testEnv;").replace("from '../../account-security'","from './account-security.mjs'").replace("from '../../security'","from './security.mjs'").replace("from '../../push'","from './push.mjs'").replace("from '../../billing'","from './billing.mjs'").replace("from '../../admin-features'","from './admin-features.mjs'").replace("from '../../subscription'","from './subscription.mjs'").replace("from '../../lib'","from './lib.mjs'").replace("from '../../wine-identity'","from './wine-identity.mjs'").replace("from '../../identify-wine'","from './identify-wine.mjs'").replace("from '../../grape-names'","from './grape-names.mjs'"));
const db=new DatabaseSync(':memory:');for(const file of fs.readdirSync('drizzle').filter(x=>x.endsWith('.sql')).sort())db.exec(fs.readFileSync('drizzle/'+file,'utf8'));
const prepare=(sql)=>{const stmt=db.prepare(sql);let args=[];const out={bind(...a){args=a;return out},async first(){return stmt.get(...args)||null},async all(){return{results:stmt.all(...args)}},async run(){const r=stmt.run(...args);return{meta:{changes:r.changes}}}};return out};
const aliases=new Map();let verificationMail;
const emailTransport=async(url,options)=>{verificationMail=JSON.parse(options.body);return Response.json({success:true,result:{queued:[verificationMail.to]}})};
globalThis.fetch=emailTransport;
globalThis.testEnv={MAWINE_RECOVERY_ENCRYPTION_KEY:Buffer.alloc(32,7).toString('base64'),CLOUDFLARE_EMAIL_API_TOKEN:'test',CLOUDFLARE_ACCOUNT_ID:'a'.repeat(32),MAWINE_EMAIL_FROM:'no-reply@mawine.app',MAWINE_PUBLIC_ORIGIN:'https://test.local',DB:{prepare,batch:async qs=>Promise.all(qs.map(q=>q.run()))}};
compile('app/catalog-seed.ts','catalog-seed.mjs');compile('app/api/catalog/route.ts','catalog-route.mjs',s=>s.replace("import {env} from 'cloudflare:workers';","const env=globalThis.testEnv;").replace("from '../../catalog-seed'","from './catalog-seed.mjs'"));
const catalogRoute=await import('../'+dir+'/catalog-route.mjs');await catalogRoute.POST();await catalogRoute.POST();const catalog=await(await catalogRoute.GET()).json();assert.equal(catalog.wines.length,12);assert.equal(new Set(catalog.wines.map(w=>w.id)).size,12);assert.ok(catalog.wines.every(w=>w.sourceUrl.startsWith('https://www.vivino.com/')&&w.price===''));assert.equal(catalog.wines.find(w=>w.id==='vivino-1984742').year,null);
compile('app/api/demo/route.ts','demo-route.mjs',s=>s.replace("import {env} from 'cloudflare:workers';","const env=globalThis.testEnv;").replace("from '../../account-security'","from './account-security.mjs'").replace("from '../../security'","from './security.mjs'").replace("from '../../push'","from './push.mjs'").replace("from '../../billing'","from './billing.mjs'").replace("from '../../admin-features'","from './admin-features.mjs'").replace("from '../../subscription'","from './subscription.mjs'").replace("from '../../lib'","from './lib.mjs'"));const demoRoute=await import('../'+dir+'/demo-route.mjs');await demoRoute.POST();await demoRoute.POST();
const {GET,POST}=await import('../'+dir+'/route.mjs');const {guessScore,emptyReview,score}=await import('../'+dir+'/lib.mjs');
const testPasswords=new Map();
const browserCookies=new Map();
async function cookieIdentity(user){const cookie=browserCookies.get(user);if(!cookie)return "";const raw=cookie.split("=")[1];return "guest:"+Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256",new TextEncoder().encode(raw)))).map(x=>x.toString(16).padStart(2,"0")).join("")}
async function api(user,action,data={},expected=200){
 const existing=db.prepare('SELECT profile_id FROM identities WHERE identity=?').get(await cookieIdentity(user));
 if(action==='deleteProfile'&&!Object.hasOwn(data,'current'))data={current:testPasswords.get(existing?.profile_id),...data};
 if(action==='activateHost'){const email=data.email??(data.username+'@example.com');if(expected===200)aliases.set(data.username,email);data={...data,email};}
 if(action==='login'&&aliases.has(data.username))data={...data,email:aliases.get(data.username)};
 const r=await(action?POST:GET)(new Request('https://test.local/api/app',{method:action?'POST':'GET',headers:{cookie:browserCookies.get(user)||'','cf-connecting-ip':user,'origin':'https://test.local','content-type':'application/json'},...(action?{body:JSON.stringify({action,...(action==='activateHost'?{confirm:data.password}:{}),...(['createProfile','activateHost'].includes(action)?{termsAccepted:'yes'}:{}),...data})}:{})}));
 const updatedCookie=r.headers.get('set-cookie');if(updatedCookie)browserCookies.set(user,updatedCookie.split(';')[0]);
 const s=await r.json();assert.equal(r.status,expected,JSON.stringify(s));
 if(r.ok&&action==='activateHost'){assert.equal(s.profile.host,false);assert(s.pendingVerification);const token=verificationMail.text.match(/#verify=([a-f0-9]{64})/)[1];const confirmed=await api(user,'confirmEmail',{token});testPasswords.set(confirmed.profile.id,data.password);return confirmed;}
 if(r.ok&&['login','changePassword'].includes(action))testPasswords.set(s.profile.id,data.password);return s;
}
// Real anonymous cookie sessions: two host accounts and six passwordless guest profiles.
const cookies=new Map();
async function client(index,action,data={},expected=200){
 if(action==='login'&&data.username)data={...data,email:aliases.get(data.username)};
 const headers={'content-type':'application/json',origin:'https://test.local','cf-connecting-ip':`192.0.2.${index+1}`};
 if(cookies.has(index))headers.cookie=cookies.get(index);
 const response=await(action?POST:GET)(new Request('https://test.local/api/app',{method:action?'POST':'GET',headers,...(action?{body:JSON.stringify({action,...(action==='activateHost'?{confirm:data.password}:{}),...(['createProfile','activateHost'].includes(action)?{termsAccepted:'yes'}:{}),...data})}:{})}));
 const cookie=response.headers.get('set-cookie');if(cookie)cookies.set(index,cookie.split(';')[0]);
 const result=await response.json();assert.equal(response.status,expected,JSON.stringify(result));if(action==='activateHost'&&expected===200){aliases.set(data.username,data.email);assert.equal(result.profile.host,false);return client(index,'confirmEmail',{token:verificationMail.text.match(/#verify=([a-f0-9]{64})/)[1]});}return result;
}
const users=[];
for(let i=0;i<8;i++){
 const user=await client(i,'createProfile',{name:`Participant ${i+1}`,dob:'1990-01-01',language:['en','ro','it','fr'][i%4]});
 users.push({id:user.profile.id,recovery:user.recoveryCode});
 if(i<2)await client(i,'activateHost',{username:`simulationhost${i}`,password:'Simulation-password-123',email:`host${i}@example.com`});
}
assert.equal(new Set(users.map(u=>u.id)).size,8);assert.equal(new Set(cookies.values()).size,8);
const wines=Array.from({length:3},(_,i)=>({id:`simulation-wine-${i}`,winery:'Test Estate',name:`Reserve ${i}`,year:2022,grapes:['Merlot'],country:'România',type:'Roșu sec',price:'80',alcohol:'14'}));
const event=await client(0,'saveEvent',{title:'Eight participant blind tasting',date:'2026-10-29',mode:'blind',wines});const id=event.eventId;
await client(0,'start',{id});const code=(await client(0)).events.find(e=>e.id===id).code;
await Promise.all(Array.from({length:7},(_,n)=>client(n+1,'join',{code})));
await client(7,'join',{code}); // Joining twice must not duplicate membership.
let state=await client(0);let tasting=state.events.find(e=>e.id===id);assert.equal(tasting.count,8);assert.equal(tasting.participants.length,8);
for(let i=1;i<8;i++){
 const s=await client(i);const e=s.events.find(e=>e.id===id);assert(e.wines.every(w=>Object.keys(w).length===1));assert.equal(e.participants,undefined);
 await client(i,'reveal',{id},400);await client(i,'end',{id},400);
}
for(const wine of wines){
 await Promise.all(Array.from({length:8},(_,i)=>client(i,'review',{eventId:id,wineId:wine.id,review:{...emptyReview(),scores:[i+1,24,24,16,8],notes:`private note ${i}`,country:'România',year:'2022',grapes:['Merlot'],favorite:i%2===0}})));
}
state=await client(0);tasting=state.events.find(e=>e.id===id);
for(const w of wines){assert.equal(tasting.progress[w.id],8);assert(Math.abs(tasting.averages[w.id]-7.65)<1e-9);}
for(let i=0;i<8;i++){
 const s=await client(i);assert.equal(Object.keys(s.reviews).length,3);assert(Object.values(s.reviews).every(r=>r.notes===`private note ${i}`));assert.equal(s.profile.language,['en','ro','it','fr'][i%4]);
}
await client(0,'revealWine',{id,wineId:wines[0].id});
const revealed=(await client(2)).events.find(e=>e.id===id);assert.equal(revealed.wines[0].name,'Reserve 0');assert.equal(revealed.wines[1].name,undefined);
await client(7,'finishParticipation',{id});assert.equal((await client(7)).events.find(e=>e.id===id).participationCompleted,true);assert.equal((await client(6)).events.find(e=>e.id===id).participationCompleted,false);
await client(0,'end',{id});
for(let i=0;i<8;i++){const e=(await client(i)).events.find(e=>e.id===id);assert.equal(e.status,'ended');assert(e.wines.every(w=>w.name));assert.equal(e.count,8);assert(Math.abs(e.averages[wines[0].id]-7.65)<1e-9);}
await client(1,'logout');assert.equal((await client(1)).profile,null);await client(1,'login',{username:'simulationhost1',password:'Simulation-password-123'});assert.equal((await client(1)).profile.id,users[1].id);
await client(6,'logout');await client(6,'recover',{code:users[6].recovery});assert.equal((await client(6)).profile.id,users[6].id);
assert.equal(db.prepare('SELECT COUNT(*) AS n FROM reviews WHERE event_id=?').get(id).n,24);
console.log('PASS: 8 separate cookie sessions (organizing host, visiting host, 6 guests), 3 wines, 24 reviews, concurrency, blind privacy, access control, averages, selective reveal, completion/history, four profile languages, host login and guest recovery.');
