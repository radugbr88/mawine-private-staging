// Regression test in workerd, including Request construction and the real fetch API.
// Outbound requests terminate in a local fixture; no notification reaches a device.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import ts from 'typescript';
const dependency=fs.readdirSync('node_modules/.pnpm').find(n=>n.startsWith('miniflare@'));
const {Miniflare}=await import(pathToFileURL(path.resolve('node_modules/.pnpm',dependency,'node_modules/miniflare/dist/src/index.js')));
const source=ts.transpileModule(fs.readFileSync('app/web-push.ts','utf8'),{compilerOptions:{module:ts.ModuleKind.ES2022,target:ts.ScriptTarget.ES2022}}).outputText;
const script=source+`
export default {async fetch(){try{
 const signing=await crypto.subtle.generateKey({name:'ECDSA',namedCurve:'P-256'},true,['sign','verify']);
 const env={MAWINE_PUSH_PRIVATE_JWK:JSON.stringify(await crypto.subtle.exportKey('jwk',signing.privateKey)),MAWINE_PUSH_PUBLIC_KEY:base64url(new Uint8Array(await crypto.subtle.exportKey('raw',signing.publicKey)))};
 const client=await crypto.subtle.generateKey({name:'ECDH',namedCurve:'P-256'},true,['deriveBits']);
 const sub={endpoint:'https://web.push.apple.com/test-fixture',p256dh:base64url(new Uint8Array(await crypto.subtle.exportKey('raw',client.publicKey))),auth:base64url(crypto.getRandomValues(new Uint8Array(16)))};
 const result=await sendPush(env,sub,{title:'Mawine',body:'Test'});
 return Response.json({ok:result.ok,status:result.status});
 }catch(e){return Response.json({error:e.message},{status:500})}}};`;
let calls=0,status=201;
const mf=new Miniflare({modules:true,script,compatibilityDate:'2026-05-15',compatibilityFlags:['nodejs_compat'],outboundService:async request=>{
 calls++;assert.equal(request.url,'https://web.push.apple.com/test-fixture');assert.equal(request.method,'POST');assert.match(request.headers.get('authorization'),/^vapid t=/);assert.equal(request.headers.get('content-encoding'),'aes128gcm');assert((await request.arrayBuffer()).byteLength>100);
 return new Response('',{status,headers:status===302?{Location:'https://example.com/do-not-follow'}:{}});
}});
try{
 let r=await mf.dispatchFetch('http://localhost');assert.equal(r.status,200,await r.clone().text());assert.deepEqual(await r.json(),{ok:true,status:201});assert.equal(calls,1);
 status=302;r=await mf.dispatchFetch('http://localhost');assert.deepEqual(await r.json(),{ok:false,status:302});assert.equal(calls,2,'redirect must not be followed');
 console.log('PASS: workerd encrypted push + VAPID transport, supported redirect mode, redirects never followed');
}finally{await mf.dispose()}
