import assert from 'node:assert/strict';
import fs from 'node:fs';
import {compileTree} from './helpers/compile.mjs';
const dir='.sites-runtime/wine-type-tests';
const {wineTypeGroups,wineTypeOptionLabel}=await import(compileTree('app/mobile-ui.tsx',dir));
const {setLanguage,translateForLanguage}=await import('../'+dir+'/i18n.mjs');
assert.ok(wineTypeGroups.some(g=>g.name==='Fortificat'));
const values=wineTypeGroups.flatMap(g=>g.values);assert.equal(new Set(values).size,values.length);
for(const lang of ['ro','en','it','fr']){
 setLanguage(lang);
 assert.ok(!wineTypeGroups.flatMap(g=>g.values).map(wineTypeOptionLabel).includes(translateForLanguage(lang,'Nespecificat')));
 assert.equal(translateForLanguage(lang,'Vin desert'),lang==='ro'?'Desert':'Dessert');
 for(const group of wineTypeGroups){const labels=group.values.map(wineTypeOptionLabel);assert.equal(new Set(labels).size,labels.length);if(group.values.length>1)assert.ok(!labels.includes(translateForLanguage(lang,group.name)));}
 if(lang!=='ro'){const dictionary=JSON.parse(fs.readFileSync(`app/i18n-${lang}.json`,'utf8'));for(const value of values)assert.ok(dictionary[value],`${lang}: ${value}`)}
}
console.log('PASS four-language wine categories, every wine type translated, no repeated options/headings, legacy dessert display.');
