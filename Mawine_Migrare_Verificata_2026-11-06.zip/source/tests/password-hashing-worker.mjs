import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';import {pathToFileURL} from 'node:url';
import {pbkdf2Sync} from 'node:crypto';import ts from 'typescript';
const dependency=fs.readdirSync('node_modules/.pnpm').find(n=>n.startsWith('miniflare@'));
const {Miniflare}=await import(pathToFileURL(path.resolve('node_modules/.pnpm',dependency,'node_modules/miniflare/dist/src/index.js')));
for(const file of ['app/api/app/route.ts','app/api/admin/route.ts']){
 const fn=fs.readFileSync(file,'utf8').split('\n').find(x=>x.startsWith('async function password('));
 const source=ts.transpileModule(fn,{compilerOptions:{target:ts.ScriptTarget.ES2022}}).outputText;
 const mf=new Miniflare({modules:true,compatibilityDate:'2026-05-15',compatibilityFlags:['nodejs_compat'],script:`import {pbkdf2Sync} from 'node:crypto';${source}\nexport default{async fetch(){return Response.json({current:await password('fixture','v2$fixture'),legacy:await password('fixture','legacy-fixture')})}}`});
 try{const result=await(await mf.dispatchFetch('http://localhost')).json();for(const [name,salt,iterations] of [['current','v2$fixture',600000],['legacy','legacy-fixture',100000]])assert.equal(result[name],salt+':'+pbkdf2Sync('fixture',salt,iterations,32,'sha256').toString('hex'))}finally{await mf.dispose()}
}
console.log('PASS workerd password hashing: 600,000 iterations and backward-compatible 100,000 hashes');
