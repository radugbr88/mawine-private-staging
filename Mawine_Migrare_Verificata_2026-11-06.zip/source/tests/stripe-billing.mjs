import assert from 'node:assert/strict';
import fs from 'node:fs';
import {DatabaseSync} from 'node:sqlite';
import {compileTree} from './helpers/compile.mjs';
import Stripe from 'stripe';
const compiled=compileTree('app/billing.ts','.sites-runtime/billing-tests');
const {billingConfig,billingAction,billingSummary,billingLock,enforceHostAccess,processStripeEvent,reconcileSubscription,assertBillingCanClose}=await import(compiled);
const sqlite=new DatabaseSync(':memory:');sqlite.exec('PRAGMA foreign_keys=ON');
for(const f of fs.readdirSync('drizzle').filter(x=>x.endsWith('.sql')).sort())sqlite.exec(fs.readFileSync('drizzle/'+f,'utf8'));
const db={prepare(sql){const stmt=sqlite.prepare(sql);let values=[];return {bind(...args){values=args;return this},async first(){return stmt.get(...values)||null},async all(){return{results:stmt.all(...values)}},async run(){return{meta:{changes:stmt.run(...values).changes}}}}}};
const e={STRIPE_MODE:'test',STRIPE_SECRET_KEY:['rk','test','fixture'].join('_'),STRIPE_WEBHOOK_SECRET:'whsec_fixture',STRIPE_ACCOUNT_ID:'acct_sandbox',STRIPE_PRICE_MONTHLY:'price_month',STRIPE_PRICE_ANNUAL:'price_year',STRIPE_TEST_USERNAMES:'tester',STRIPE_PORTAL_CONFIGURATION_ID:'bpc_fixture',MAWINE_PUBLIC_ORIGIN:'https://mawine.app'};
const c=billingConfig(e);assert(c);assert.equal(billingConfig({...e,STRIPE_MODE:'live'}),null);assert.equal(billingConfig({...e,MAWINE_PUBLIC_ORIGIN:'http://test.local'}),null);
const p={id:'owner',name:'Test',username:'tester',host:1,language:'fr',trial_started_at:Date.now()-31*86400000};
sqlite.prepare("INSERT INTO profiles(id,name,dob,gender,recovery,host,username,trial_started_at,language) VALUES(?,?,'1990-01-01','','recovery',1,?,?,?)").run(p.id,p.name,p.username,p.trial_started_at,p.language);
let createCalls=0,params,requestKey,remoteSubs=[],sessions=new Map(),failCreate=false,failLookup=false;
const s={accounts:{retrieve:async()=>({id:c.account})},customers:{create:async()=>({id:'cus_owner',livemode:false})},prices:{retrieve:async price=>({id:price,active:true,livemode:false,currency:'usd',unit_amount:price==='price_month'?999:9900,recurring:{interval:price==='price_month'?'month':'year',interval_count:1}})},subscriptions:{list:async()=>({data:remoteSubs,has_more:false}),retrieve:async id=>{if(failLookup)throw Error('temporary');return structuredClone(remoteSubs.find(x=>x.id===id))}},checkout:{sessions:{create:async(p,o)=>{createCalls++;if(params&&requestKey===o.idempotencyKey)assert.deepEqual(p,params);params=p;requestKey=o.idempotencyKey;const session={id:'cs_'+o.idempotencyKey,url:'https://checkout.stripe.com/c/pay/fixture',status:'open',livemode:false,subscription:null};sessions.set(session.id,session);if(failCreate){failCreate=false;throw Error('timeout after creation')}return session},retrieve:async id=>sessions.get(id),expire:async id=>{sessions.get(id).status='expired'},list:async()=>({data:[...sessions.values()].filter(x=>x.status==='open'),has_more:false})}},billingPortal:{configurations:{retrieve:async()=>({active:true,features:{subscription_cancel:{enabled:true,mode:'at_period_end'},subscription_update:{enabled:true,proration_behavior:'always_invoice',billing_cycle_anchor:'now',default_allowed_updates:['price'],products:[{product:'prod_host',prices:['price_month','price_year']}],schedule_at_period_end:{conditions:[{type:'shortening_interval'}]}}}})},sessions:{create:async args=>{assert.equal(args.customer,'cus_owner');assert.equal(args.locale,'fr');assert.equal(args.return_url,'https://mawine.app/?billing=portal');return{url:'https://billing.stripe.com/p/session/fixture'}}}},invoices:{retrieve:async()=>structuredClone(invoice),listLineItems:async()=>({has_more:false,data:[{amount:999,pricing:{price_details:{price:'price_month'}},parent:{subscription_item_details:{subscription_item:'si_owner'}},period:{end:periodEnd}}]})},charges:{retrieve:async()=>({id:'ch_fixture',payment_intent:'pi_fixture',refunded:true})},invoicePayments:{list:async()=>({data:[{invoice:'in_owner'}],has_more:false})}};
await assert.rejects(()=>billingAction(db,{},p,'stripeCheckout','monthly',s));
await assert.rejects(()=>billingAction(db,e,{...p,username:'outsider'},'stripeCheckout','monthly',s));
await assert.rejects(()=>billingAction(db,e,p,'stripeCheckout','injected-price',s));
failCreate=true;await assert.rejects(()=>billingAction(db,e,p,'stripeCheckout','monthly',s));
const result=await billingAction(db,e,p,'stripeCheckout','monthly',s);assert(result.billingUrl.startsWith('https://checkout.stripe.com/'));assert.equal(createCalls,2);assert.equal(params.locale,'fr');assert.equal(params.line_items[0].price,'price_month');assert.equal(params.mode,'subscription');assert.equal(params.success_url,'https://mawine.app/?billing=success');assert.equal(params.cancel_url,'https://mawine.app/?billing=cancel');assert(!('payment_method_types' in params));assert.match(params.integration_identifier,/^mawine_host_[a-z]{8}$/);
await billingAction(db,e,p,'stripeCheckout','monthly',s);assert.equal(createCalls,2);
const lock=await billingLock(db,p.id);await assert.rejects(()=>billingAction(db,e,p,'stripeCheckout','monthly',s),{status:409});await lock.release();
const periodStart=Math.floor(Date.now()/1000),periodEnd=periodStart+30*86400;
let invoice={id:'in_owner',status:'paid',customer:'cus_owner',parent:{subscription_details:{subscription:'sub_owner'}}};
remoteSubs=[{id:'sub_owner',customer:'cus_owner',livemode:false,status:'active',items:{has_more:false,data:[{id:'si_owner',quantity:1,price:{id:'price_month'},current_period_start:periodStart,current_period_end:periodEnd}]},latest_invoice:invoice,cancel_at_period_end:false,canceled_at:null,ended_at:null}];
await assert.rejects(()=>billingAction(db,e,p,'stripeCheckout','annual',s));
assert((await billingAction(db,e,p,'stripePortal',undefined,s)).billingUrl.startsWith('https://billing.stripe.com/'));
let counter=0;const event=(type,obj)=>({id:'evt_'+(++counter),type,data:{object:obj},created:periodStart,livemode:false});
const paidEvent=event('invoice.paid',{id:'in_owner'});await processStripeEvent(db,c,paidEvent,s);
let summary=await billingSummary(db,e,p);assert.equal(summary.subscription.paid,true);assert.equal(summary.subscription.accessUntil,periodEnd*1000);
sqlite.prepare('INSERT INTO managed_prices VALUES(?,?,?,?,?,?,?)').run('price_new','test','acct_sandbox','monthly',1299,1,Date.now());
assert.equal((await billingSummary(db,e,p)).prices.monthly,1299);await reconcileSubscription(db,c,s,'sub_owner');assert.equal((await billingSummary(db,e,p)).subscription.amount,999);
sqlite.prepare("DELETE FROM managed_prices WHERE id='price_new'").run();
sqlite.prepare('INSERT INTO managed_prices VALUES(?,?,?,?,?,?,?)').run('price_old_year','test','acct_sandbox','annual',8900,0,Date.now());
remoteSubs[0].items.data[0].price.id='price_old_year';
await reconcileSubscription(db,c,s,'sub_owner');
assert.equal((await billingSummary(db,e,p)).subscription.plan,'annual');
assert.equal((await billingSummary(db,e,p)).subscription.amount,8900);
remoteSubs[0].items.data[0].price.id='price_month';
await reconcileSubscription(db,c,s,'sub_owner');
await processStripeEvent(db,c,paidEvent,s);assert.equal(sqlite.prepare('SELECT count(*) n FROM billing_events').get().n,1);
await assert.rejects(()=>processStripeEvent(db,c,{...paidEvent,id:'evt_live',livemode:true},s));await assert.rejects(()=>processStripeEvent(db,c,{...paidEvent,id:'evt_connect',account:'acct_other'},s));
// Failed reconciliation remains retryable and never produces a completion marker.
const retry=event('customer.subscription.updated',{id:'sub_owner'});failLookup=true;await assert.rejects(()=>processStripeEvent(db,c,retry,s));assert.equal(sqlite.prepare('SELECT processing_status FROM billing_events WHERE provider_event_id=?').get(retry.id).processing_status,'failed');failLookup=false;await processStripeEvent(db,c,retry,s);assert.equal(sqlite.prepare('SELECT processing_status FROM billing_events WHERE provider_event_id=?').get(retry.id).processing_status,'processed');
// Cancellation preserves verified paid-through time; a delayed payload cannot extend it.
remoteSubs[0].status='canceled';await processStripeEvent(db,c,event('invoice.paid',{id:'in_owner',status:'paid'}),s);assert.equal((await billingSummary(db,e,p)).subscription.paid,true);assert.equal((await billingSummary(db,e,p)).subscription.accessUntil,periodEnd*1000);
remoteSubs[0].status='active';remoteSubs[0].cancel_at_period_end=true;await processStripeEvent(db,c,event('customer.subscription.updated',{id:'sub_owner'}),s);summary=await billingSummary(db,e,p);assert.equal(summary.subscription.paid,true);assert.equal(summary.subscription.cancelAtPeriodEnd,true);
// Failed renewal retains only previously verified expiry; never grants the next unpaid period.
remoteSubs[0].status='past_due';remoteSubs[0].latest_invoice={...invoice,status:'open'};remoteSubs[0].items.data[0].current_period_end=periodEnd+30*86400;await processStripeEvent(db,c,event('invoice.payment_failed',{id:'in_owner'}),s);assert.equal((await billingSummary(db,e,p)).subscription.accessUntil,periodEnd*1000);
// Risk suspension survives later paid/lifecycle notifications.
await processStripeEvent(db,c,event('charge.refunded',{id:'ch_fixture'}),s);await processStripeEvent(db,c,event('customer.subscription.updated',{id:'sub_owner'}),s);summary=await billingSummary(db,e,p);assert.equal(summary.subscription.riskBlocked,true);assert.equal(summary.subscription.paid,false);
// Test rows never grant live entitlement. Missing configuration fails closed when enforced.
const live={...e,STRIPE_MODE:'live',STRIPE_SECRET_KEY:['rk','live','fixture'].join('_'),STRIPE_LIVE_ENABLED:'true',STRIPE_ENFORCE_ACCESS:'true'};
assert.equal((await billingSummary(db,live,p)).subscription,null);const expired={...p,trial_started_at:Date.now()-34*86400000};assert.equal((await billingSummary(db,live,expired)).hostAccess,false);await assert.rejects(()=>enforceHostAccess(db,live,expired),{status:402});assert.equal((await billingSummary(db,{STRIPE_ENFORCE_ACCESS:'true'},p)).hostAccess,false);
await assert.rejects(()=>assertBillingCanClose(db,{},p));
// Official SDK verifies timestamp, raw body and signatures; tampered and stale events fail.
const stripe=new Stripe(e.STRIPE_SECRET_KEY);const payload=JSON.stringify(paidEvent);const header=stripe.webhooks.generateTestHeaderString({payload,secret:e.STRIPE_WEBHOOK_SECRET});
assert.equal((await stripe.webhooks.constructEventAsync(payload,header,e.STRIPE_WEBHOOK_SECRET,300,Stripe.createSubtleCryptoProvider())).id,paidEvent.id);
await assert.rejects(()=>stripe.webhooks.constructEventAsync(payload+' ',header,e.STRIPE_WEBHOOK_SECRET,300,Stripe.createSubtleCryptoProvider()));
const stale=stripe.webhooks.generateTestHeaderString({payload,secret:e.STRIPE_WEBHOOK_SECRET,timestamp:Math.floor(Date.now()/1000)-600});await assert.rejects(()=>stripe.webhooks.constructEventAsync(payload,stale,e.STRIPE_WEBHOOK_SECRET,300,Stripe.createSubtleCryptoProvider()));

// Trial end is carried over exactly, not restarted, and the final 48 hours cannot be charged early.
remoteSubs=[];sessions.clear();sqlite.prepare('DELETE FROM billing_checkouts').run();
const originalTrial=Date.now()-5*86400000;sqlite.prepare('UPDATE profiles SET trial_started_at=? WHERE id=?').run(originalTrial,p.id);
await billingAction(db,e,p,'stripeCheckout','annual',s);
assert.equal(params.subscription_data.trial_end,Math.floor((originalTrial+30*86400000)/1000));assert.equal(params.line_items[0].price,'price_year');
// Switching an open session expires it before making another with a different price.
const annualSession=[...sessions.values()][0];await billingAction(db,e,p,'stripeCheckout','monthly',s);assert.equal(annualSession.status,'expired');assert.equal(params.line_items[0].price,'price_month');
sessions.clear();sqlite.prepare('DELETE FROM billing_checkouts').run();sqlite.prepare('UPDATE profiles SET trial_started_at=? WHERE id=?').run(Date.now()-29*86400000,p.id);
const lateStart=sqlite.prepare('SELECT trial_started_at FROM profiles WHERE id=?').get(p.id).trial_started_at;
for(const plan of ['monthly','annual']){
 await billingAction(db,e,p,'stripeCheckout',plan,s);
 assert.equal(params.subscription_data.billing_cycle_anchor,Math.floor((lateStart+30*86400000)/1000));
 assert.equal(params.subscription_data.proration_behavior,'none');assert(!('trial_end' in params.subscription_data));
}
// No invoice means no paid entitlement, even when Stripe reports the anchored subscription as active.
sqlite.prepare("UPDATE billing_subscriptions SET provider_status='active',access_expires_at=NULL,risk_blocked=0 WHERE profile_id=?").run(p.id);
const pending=await billingSummary(db,e,{...p,trial_started_at:lateStart});assert.equal(pending.subscription.status,'trialing');assert.equal(pending.subscription.paid,false);
sessions.clear();sqlite.prepare('DELETE FROM billing_checkouts').run();
sqlite.prepare('UPDATE profiles SET trial_started_at=? WHERE id=?').run(Date.now()-30*86400000-1000,p.id);
await billingAction(db,e,p,'stripeCheckout','monthly',s);assert(!params.subscription_data);

// Bad configured amount and account are rejected before any Checkout is created.
sqlite.prepare('UPDATE profiles SET trial_started_at=? WHERE id=?').run(p.trial_started_at,p.id);
const oldRetrieve=s.prices.retrieve;s.prices.retrieve=async()=>({active:true,livemode:false,currency:'usd',unit_amount:1,recurring:{interval:'month',interval_count:1}});
await assert.rejects(()=>billingAction(db,e,p,'stripeCheckout','monthly',s),{status:503});s.prices.retrieve=oldRetrieve;
const oldAccount=s.accounts.retrieve;s.accounts.retrieve=async()=>({id:'acct_wrong'});await assert.rejects(()=>billingAction(db,e,p,'stripeCheckout','monthly',s),{status:503});s.accounts.retrieve=oldAccount;
// Unmapped customers cannot create local entitlements, even with signed metadata claiming ownership.
remoteSubs=[{id:'sub_foreign',customer:'cus_foreign',metadata:{profileId:p.id}}];await reconcileSubscription(db,c,s,'sub_foreign');assert.equal(sqlite.prepare('SELECT count(*) n FROM billing_subscriptions').get().n,1);
assert.deepEqual(sqlite.prepare('PRAGMA foreign_key_check').all(),[]);
console.log('PASS Stripe: configuration guards, test allowlist, trusted prices, frozen retries, duplicate checkout prevention, lock contention, portal ownership, paid invoices, replay, retries, out-of-order cancellation, failed renewal, refund holds, live/test isolation and signature verification.');

// Refuse a portal that could cancel immediately or shorten the already-paid year.
sqlite.prepare("DELETE FROM attempts WHERE id=?").run('billing-rate:'+p.id);
const correctPortal=s.billingPortal.configurations.retrieve;
s.billingPortal.configurations.retrieve=async()=>({active:true,features:{subscription_cancel:{enabled:true,mode:'immediately'},subscription_update:{enabled:true,schedule_at_period_end:{conditions:[]}}}});
await assert.rejects(()=>billingAction(db,e,p,'stripePortal',undefined,s),{status:503});
s.billingPortal.configurations.retrieve=correctPortal;
await billingAction(db,e,p,'stripePortal',undefined,s);
console.log('PASS portal policy guard: cancellation at period end and annual-to-monthly scheduling required');

// Never open a portal which discards the unused monthly credit or schedules the wrong direction.
for(const mutate of [u=>u.billing_cycle_anchor='unchanged',u=>u.proration_behavior='none',u=>u.proration_behavior='create_prorations',u=>u.default_allowed_updates=[],u=>u.products=[],u=>u.schedule_at_period_end.conditions.push({type:'decreasing_item_amount'})]){
 s.billingPortal.configurations.retrieve=async()=>{const portal=await correctPortal();mutate(portal.features.subscription_update);return portal};
 await assert.rejects(()=>billingAction(db,e,p,'stripePortal',undefined,s),{status:503});
}
s.billingPortal.configurations.retrieve=correctPortal;
console.log('PASS: portal requires immediate invoiced prorations and only scheduled shortening intervals, with both allowed prices');

// Promotion codes are resolved server-side and passed to hosted Checkout, never as arbitrary IDs.
sqlite.exec('DELETE FROM attempts; DELETE FROM billing_checkouts; DELETE FROM billing_subscriptions');remoteSubs=[];sessions.clear();
sqlite.prepare('UPDATE profiles SET trial_started_at=? WHERE id=?').run(Date.now()-40*86400000,p.id);
const oldPrice=s.prices.retrieve;s.prices.retrieve=async id=>({...await oldPrice(id),product:'prod_host'});
let promo={id:'promo_host',code:'MAWINE20',active:true,livemode:false,customer:null,customer_account:null,expires_at:null,max_redemptions:null,times_redeemed:0,promotion:{type:'coupon',coupon:{id:'coupon_host',valid:true,percent_off:20,redeem_by:null,applies_to:{products:['prod_host']}}},restrictions:{first_time_transaction:false,minimum_amount:null,minimum_amount_currency:null}};
s.promotionCodes={list:async args=>{assert.equal(args.active,true);return{data:args.code.toLowerCase()==='mawine20'?[structuredClone(promo)]:[]}}};
s.paymentIntents={list:async()=>({data:[],has_more:false})};s.invoices.list=async()=>({data:[],has_more:false});
assert.equal((await billingAction(db,e,p,'applyPromotion',undefined,s,'mawine20')).promotion.code,'MAWINE20');
await billingAction(db,e,p,'stripeCheckout','monthly',s,'MAWINE20');assert.deepEqual(params.discounts,[{promotion_code:'promo_host'}]);
const withPromo=[...sessions.values()].find(x=>x.status==='open');
await billingAction(db,e,p,'stripeCheckout','monthly',s);assert.equal(withPromo.status,'expired');assert(!params.discounts,'Removing code must replace stale Checkout');
await assert.rejects(()=>billingAction(db,e,p,'applyPromotion',undefined,s,'INVENTED'),{status:400});
for(const mutate of [x=>x.customer='cus_other',x=>x.expires_at=1,x=>x.active=false,x=>x.livemode=true,x=>{x.max_redemptions=1;x.times_redeemed=1},x=>x.promotion.coupon.valid=false,x=>x.promotion.coupon.applies_to.products=['prod_other']]){
 const original=structuredClone(promo);mutate(promo);await assert.rejects(()=>billingAction(db,e,p,'stripeCheckout','monthly',s,'MAWINE20'),{status:400});promo=original;
}
promo.restrictions={first_time_transaction:false,minimum_amount:5000,minimum_amount_currency:'usd'};
await assert.rejects(()=>billingAction(db,e,p,'stripeCheckout','monthly',s,'MAWINE20'),{status:400});
await billingAction(db,e,p,'stripeCheckout','annual',s,'MAWINE20');assert.equal(params.discounts[0].promotion_code,'promo_host');
sqlite.prepare('UPDATE profiles SET trial_started_at=? WHERE id=?').run(Date.now(),p.id);
await assert.rejects(()=>billingAction(db,e,p,'applyPromotion',undefined,s,'MAWINE20'),{status:400},'Minimum amount checks initial free payment');
sqlite.exec('DELETE FROM attempts');promo.restrictions={first_time_transaction:true,minimum_amount:null,minimum_amount_currency:null};
s.invoices.list=async()=>({data:[{status:'paid'}],has_more:false});
await assert.rejects(()=>billingAction(db,e,p,'applyPromotion',undefined,s,'MAWINE20'),{status:400});
console.log('PASS: Stripe promotion lookup, customer/product/mode/expiry/usage restrictions, minimum payment, first purchase, checkout discount transmission and stale session replacement');
