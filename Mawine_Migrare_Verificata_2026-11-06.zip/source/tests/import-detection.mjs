import assert from 'node:assert/strict';import {compileTree} from './helpers/compile.mjs';import fs from 'node:fs';import Excel from 'exceljs';
const dir='.sites-runtime/detection-tests';compileTree('app/import-detection.ts',dir);
const {detectImportColumns,mapImportRows,importDate}=await import('../'+dir+'/import-detection.mjs');const {parseWineRows,hasWineHeaders}=await import('../'+dir+'/wine-import.mjs');
const rows=[['Archive'],[],['Crama A','Reserve',2020,'România','CS+M','roșu',13.5,80,'2026-01-20',1],['Crama A','Classic',2021,'Franța','PN','roșu',12.5,100],[],['Crama B','Selection',2019,'Italia','M','roșu',14.5,90,'2026-02-20',2],['Crama B','Special',2022,'Spania','SB','alb',11.5,95]];
for(const order of [[0,1,2,3,4,5,6,7,8,9],[9,8,7,6,5,4,3,2,1,0],[4,6,1,7,3,9,0,8,2,5]]){
 const permuted=rows.map(r=>order.map(i=>r[i]));const mapping=detectImportColumns(permuted);
 for(const [index,field] of ['winery','name','year','country','grapes','type','alcohol','price','date','event'].entries())assert.equal(mapping.fields[order.indexOf(index)],field,JSON.stringify(mapping));
 const result=mapImportRows(permuted,mapping);assert.equal(result.groups.length,2);assert.equal(result.groups[0].date,'2026-01-20');const wines=parseWineRows(result.rows,60);assert.equal(wines.length,4);assert.equal(wines[0].winery,'Crama A');assert.equal(wines[0].name,'Reserve');assert.equal(wines[0].year,2020);assert.deepEqual(wines[0].grapes,['Cabernet Sauvignon','Merlot']);assert.equal(parseWineRows(result.groups[1].rows,60).length,2);
}
assert.equal(importDate('31.02.2026'),'');assert.equal(importDate('20/01/2026'),'2026-01-20');
assert.throws(()=>mapImportRows(rows,{start:2,fields:['name','name']}),/singură/);assert.throws(()=>mapImportRows(rows,{start:2,fields:['ignore']}),/vin sau/);
assert.equal(hasWineHeaders([['Cramă','Vin','An']]),true);assert.equal(hasWineHeaders(rows),false);
// Headerless attached formats remain manually correctable; numeric annotations aren't grapes.
assert.equal(detectImportColumns([['A','unknown 2020'],['B','unknown 2021'],['C','unknown 2022']]).fields.includes('grapes'),false);
if(process.argv[2]){
 const wb=new Excel.Workbook();await wb.xlsx.readFile(process.argv[2]);const source=[];wb.worksheets[0].eachRow({includeEmpty:true},r=>source.push(r.values.slice(1).map(v=>v instanceof Date?v.toISOString().slice(0,10):v&&typeof v==='object'?v.result??'':v)));
 const order=[6,8,2,5,7,1,3,4,13,16,0];const data=source.map(r=>order.map(i=>r[i]));const mapping=detectImportColumns(data);console.log('Reordered real journal:',mapping);const result=mapImportRows(data,mapping);assert.equal(result.groups.length,23);const wines=parseWineRows(result.rows,1000);assert.equal(wines.length,269);assert.equal(wines[2].winery,'Niepoort');assert.equal(wines[2].name,'Redoma Tinto');console.log('Groups:',result.groups.length,'Wines:',wines.length);
}
console.log('Headerless detection: reordered columns, blank rows, groups, manual corrections and validation passed.');
compileTree('app/import-column-review.tsx',dir);
const React=await import('react');const {renderToStaticMarkup}=await import('react-dom/server');const {ImportColumnReview}=await import('../'+dir+'/import-column-review.mjs');const {setLanguage}=await import('../'+dir+'/i18n.mjs');
for(const [lang,title] of [['ro','Verifică coloanele'],['en','Review columns'],['it','Verifica le colonne'],['fr','Vérifier les colonnes']]){setLanguage(lang);const html=renderToStaticMarkup(React.createElement(ImportColumnReview,{rows,onConfirm:()=>{},onCancel:()=>{}}));assert.ok(html.includes(title));assert.ok(html.includes('Crama A'));assert.ok(html.includes('role="dialog"'));assert.equal((html.match(/<select/g)||[]).length,10)}
console.log('Column review rendered in all four languages.');
