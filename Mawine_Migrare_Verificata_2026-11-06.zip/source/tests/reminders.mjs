import assert from 'node:assert/strict';
import React from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {pathToFileURL} from 'node:url';
import {compileTree} from './helpers/compile.mjs';
import fs from 'node:fs';
const modulePath=compileTree('app/subscription.ts','.sites-runtime/reminder-tests');
const {dueReminders,reminderDay}=await import(pathToFileURL(modulePath));
const at=s=>Date.parse(s),day=86400000;
const created=at('2026-11-03T21:59:00Z'); // 23:59 in Romania
const guest={created_at:created};
assert.equal(dueReminders(guest,null,created)[0].kind,'recovery-code');
assert.equal(dueReminders(guest,null,created+120000)[0].day,'2026-11-04');
assert.equal(dueReminders(guest,null,at('2026-11-05T21:59:59Z')).length,1);
assert.equal(dueReminders(guest,null,at('2026-11-05T22:00:00Z')).length,0);
assert.deepEqual(dueReminders(guest,null,created-1),[]);
assert.deepEqual(dueReminders({...guest,created_at:NaN},null,created),[]);
// Accounts never receive the removed recovery-email reminder.
const account={created_at:created-10*day,trial_started_at:created,host:true,username:'host',password:'hash'};
assert.deepEqual(dueReminders(account,null,created),[]);
assert.deepEqual(dueReminders({...account,recovery_email:'a@example.com'},null,created),[]);
assert.deepEqual(dueReminders({...account,host:false},null,created),[]);
assert.deepEqual(dueReminders({...account,trial_started_at:null},null,created),[]);
for(const days of [3,2,1]){
 const now=created+(30-days)*day;
 assert.equal(dueReminders(account,null,now)[0].remainingDays,days);
 assert.deepEqual(dueReminders(account,{paid:true,status:'active'},now),[]);
 assert.deepEqual(dueReminders(account,{paid:false,status:'trialing'},now),[]);
 assert.deepEqual(dueReminders({...account,host:false},null,now),[]);
}
assert.equal(dueReminders(account,null,created+30*day)[0].kind,'payment-grace');
assert.deepEqual(dueReminders(account,null,created+33*day),[]);
assert.deepEqual(dueReminders(account,null,created+27*day-1),[]);
for(let n=0;n<30;n++){const due=dueReminders({...account,recovery_email:'a@example.com'},null,created+n*day);assert.equal(due.some(r=>r.kind==='trial-ending'),[15,12,9,6,3,2,1].includes(30-n),'trial day '+n)}

// Paid renewals are silent; only an explicitly cancelled renewal gets expiry reminders.
const paidEnd=created+60*day;
for(const remainingDays of [3,2,1]){
 const now=paidEnd-remainingDays*day;
 assert.deepEqual(dueReminders(account,{paid:true,status:'active',accessUntil:paidEnd,cancelAtPeriodEnd:false},now),[]);
 assert.deepEqual(dueReminders(account,{paid:true,status:'active',accessUntil:paidEnd},now),[]);
 const reminders=dueReminders(account,{paid:true,status:'active',accessUntil:paidEnd,cancelAtPeriodEnd:true},now);
 assert.equal(reminders.length,1);assert.equal(reminders[0].kind,'paid-ending');assert.equal(reminders[0].remainingDays,remainingDays);
 assert.deepEqual(dueReminders(account,{paid:true,status:'active',accessUntil:paidEnd,cancelAtPeriodEnd:true,riskBlocked:true},now),[]);
}
for(let n=0;n<3;n++){
 const reminders=dueReminders(account,{paid:false,status:'canceled',accessUntil:paidEnd,cancelAtPeriodEnd:true},paidEnd+n*day);
 assert.equal(reminders[0].kind,'payment-grace');assert.equal(reminders[0].graceDay,n+1);
}
assert.deepEqual(dueReminders(account,{paid:false,status:'canceled',accessUntil:paidEnd,cancelAtPeriodEnd:true},paidEnd+3*day),[]);

// DST's repeated hour does not create another day, and calendar windows span DST safely.
assert.equal(reminderDay(at('2026-10-25T00:30:00Z')),reminderDay(at('2026-10-25T01:30:00Z')));
assert.equal(dueReminders({created_at:at('2026-10-24T12:00:00Z')},null,at('2026-10-26T21:59:59Z')).length,1);
assert.equal(dueReminders({created_at:at('2026-10-24T12:00:00Z')},null,at('2026-10-26T22:00:00Z')).length,0);
const componentPath=compileTree('app/app-reminders.tsx','.sites-runtime/reminder-tests');
const {reminderCanOpen}=await import(pathToFileURL(componentPath));
globalThis.document={visibilityState:'hidden',querySelector:()=>null,activeElement:null};
assert.equal(reminderCanOpen(false),false);
document.visibilityState='visible';assert.equal(reminderCanOpen(false),true);assert.equal(reminderCanOpen(true),false);
document.activeElement={tagName:'INPUT'};assert.equal(reminderCanOpen(false),false);
document.activeElement=null;document.querySelector=()=>({open:true});assert.equal(reminderCanOpen(false),false);
delete globalThis.document;
const {t,setLanguage}=await import(pathToFileURL(componentPath.replace('app-reminders.mjs','i18n.mjs')));
for(const language of ['en','it','fr']){
 setLanguage(language);
 for(const text of ['Mai ai o zi gratuită','Mai ai 2 zile gratuite','Mai ai 3 zile gratuite','Deschide codul de recuperare','Vezi abonamentele'])assert.notEqual(t(text),text,language+': '+text);
}
const {PaidExpiryNotice}=await import(pathToFileURL(compileTree('app/paid-expiry-notice.tsx','.sites-runtime/reminder-tests')));
assert.equal(renderToStaticMarkup(React.createElement(PaidExpiryNotice,{endsAt:paidEnd,days:1,cancelled:false,onManage(){}})),'');
assert.notEqual(renderToStaticMarkup(React.createElement(PaidExpiryNotice,{endsAt:paidEnd,days:1,cancelled:true,onManage(){}})),'');
console.log('PASS reminder creation windows, trial expiry, paid exclusions, calendar/DST, visibility/modal/form guards and translations.');
