const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),ts=require('typescript'),React=require('react'),{renderToStaticMarkup}=require('react-dom/server');
const cache=new Map();function load(file){file=path.resolve(file);if(cache.has(file))return cache.get(file);const exports={};cache.set(file,exports);const code=ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,jsx:ts.JsxEmit.ReactJSX,target:ts.ScriptTarget.ES2022,esModuleInterop:true,resolveJsonModule:true}}).outputText;new Function('require','exports','module',code)(name=>{if(!name.startsWith('.'))return require(name);const target=path.resolve(path.dirname(file),name);if(target.endsWith('.json'))return require(target);return load(['.ts','.tsx'].map(ext=>target+ext).find(fs.existsSync))},exports,{exports});return exports}
let saved={};global.localStorage={setItem:(k,v)=>saved[k]=v,getItem:k=>saved[k]};global.document={documentElement:{lang:'ro'},title:''};
const i=load('app/i18n.ts');assert.equal(i.getServerLanguage(),'en');assert.equal(i.getLanguage(),'en');assert.equal(i.t('Acasă'),'Home');i.setLanguage('en');assert.equal(i.t('Acasă'),'Home');assert.equal(i.t('Bună, Radu'),'Hi, Radu');assert.equal(i.t('2020 · Chardonnay · Alb sec'),'2020 · Chardonnay · Dry white');assert.equal(i.t('„Dealu Mare” și lista sa de vinuri vor fi șterse.'),'“Dealu Mare” and its wine list will be deleted.');assert.equal(i.t('România'),'Romania');assert.equal(i.t('Franța'),'France');assert.equal(i.locale(),'en-GB');assert.equal(document.documentElement.lang,'en');assert.equal(saved['mawine.language'],'en');
const {SubscriptionPanel}=load('app/subscription-panel.tsx');const plan=renderToStaticMarkup(React.createElement(SubscriptionPanel,{choosing:true,startedAt:Date.now(),onChoose(){},onUnavailable(){},onDowngrade(){},busy:false}));assert(plan.includes('Host plan'));assert(plan.includes('9.99 USD'));assert(!plan.includes('Perioada'));
const {WineTypeSelect}=load('app/mobile-ui.tsx');const type=renderToStaticMarkup(React.createElement(WineTypeSelect,{value:'Alb sec',onChange(){}}));assert(type.includes('Dry white'));
const {GuessDetails}=load('app/guess-details.tsx');const guesses=renderToStaticMarkup(React.createElement(GuessDetails,{wine:{country:'România',year:2020,grapes:['Chardonnay']},review:{country:'România',year:'2020',grapes:['Chardonnay']}}));assert(guesses.includes('Romania'));assert(guesses.includes('Correct answer'));assert(guesses.includes('of 3 points'));
i.setLanguage('ro');assert.equal(i.t('Acasă'),'Acasă');assert.equal(i.locale(),'ro-RO');saved['mawine.language']='en';i.loadLanguage();assert.equal(i.getLanguage(),'en');
console.log('PASS: language persistence, switching back, dates, dynamic copy, countries, subscription, grape guesses and wine styles.');
const {WineStatistics}=load('app/wine-statistics.tsx');
const statsHtml=renderToStaticMarkup(React.createElement(WineStatistics,{events:[{id:'e',title:'Acasă',status:'ended',wines:[{id:'w',winery:'Alb',name:'Data',year:2020,type:'Alb sec'}]}],reviews:{'e:w':{scores:[10,30,30,20,10]}}}));
assert(statsHtml.includes('Highest score'));assert(statsHtml.includes('>Alb</strong>'));assert(statsHtml.includes('>Acasă</small>'));assert(statsHtml.includes('Data'));
assert.equal(i.pluralLabel(1,'vinuri'),' wine');assert.equal(i.pluralLabel(2,'vinuri'),' wines');assert.equal(i.t('În desfășurare','subscription'),'Active');
const page=fs.readFileSync('app/page.tsx','utf8');assert(page.includes("go('language')"));assert(page.includes("action('saveLanguage',{language:value,profileId:p.id})")); assert(/<option[^>]*value=\{c\}/.test(page));
for(const label of ['Acasă','Degustări','Vinurile mele','Profil','În desfășurare','În pregătire','Încheiate','Vinuri favorite','Colecția mea'])assert(i.t(label).length<=label.length+2, label);
console.log('PASS: user content stays unchanged, canonical country values, singular/plural and compact navigation labels.');
// Every supported translation has the same keys and interpolation slots.
const en=require('../app/i18n-en.json');
for(const lang of ['it','fr']){
 const dict=require('../app/i18n-'+lang+'.json');
 assert.deepEqual(Object.keys(dict).sort(),Object.keys(en).sort());
 for(const [key,value] of Object.entries(dict)){
  assert(value.trim(),lang+': '+key);
  assert.deepEqual((value.match(/\{\d+\}/g)||[]).sort(),(key.match(/\{\d+\}/g)||[]).sort(),lang+': '+key);
 }
 i.setLanguage(lang);assert.equal(saved['mawine.language'],lang);assert.equal(document.documentElement.lang,lang);
 assert.equal(i.locale(),lang==='it'?'it-IT':'fr-FR');
 assert.equal(i.t('Bună, Radu'),lang==='it'?'Ciao, Radu':'Bonjour, Radu');
 assert.equal(i.t('România'),lang==='it'?'Romania':'Roumanie');
 assert.equal(i.t('2020 · Chardonnay · Alb sec'),lang==='it'?'2020 · Chardonnay · Bianco secco':'2020 · Chardonnay · Blanc sec');
 assert.equal(i.pluralLabel(1,'vinuri'),lang==='it'?' vino':' vin');
 assert.equal(i.pluralLabel(2,'vinuri'),lang==='it'?' vini':' vins');
 assert.equal((9.99).toLocaleString(i.locale()),'9,99');
 const html=renderToStaticMarkup(React.createElement(SubscriptionPanel,{choosing:true,startedAt:Date.now(),onChoose(){},onUnavailable(){},onDowngrade(){},busy:false}));
 assert(html.includes(lang==='it'?'Piano Organizzatore':'Offre Organisateur'));assert(html.includes('9,99 USD'));assert(!html.includes('Plan Gazdă'));
 const stats=renderToStaticMarkup(React.createElement(WineStatistics,{events:[{id:'e',title:'Acasă',status:'ended',wines:[{id:'w',winery:'Alb',name:'Data',year:2020,type:'Alb sec'}]}],reviews:{'e:w':{scores:[10,30,30,20,10]}}}));
 assert(stats.includes(lang==='it'?'Voto più alto':'Meilleure note'));assert(stats.includes('>Alb</strong>'));assert(stats.includes('>Acasă</small>'));assert(stats.includes('Data'));
 i.setLanguage('ro');saved['mawine.language']=lang;i.loadLanguage();assert.equal(i.getLanguage(),lang);
 // Fixed mobile labels stay within the width budget already used by "Vinurile mele".
 for(const label of ['Acasă','Degustări','Vinurile mele','Profil','În desfășurare','În pregătire','Încheiate','Vinuri favorite','Colecția mea'])assert(i.t(label).length<=13,lang+': '+label);
}
const current=i.getLanguage();assert.equal(i.translateForLanguage('it','Salvează'),'Salva');assert.equal(i.translateForLanguage('fr','Salvează'),'Enregistrer');assert.equal(i.getLanguage(),current);
saved['mawine.language']='unknown';i.loadLanguage();assert.equal(i.getLanguage(),'ro');assert.equal(i.t('Acasă'),'Acasă');
console.log('PASS: Italian and French coverage, placeholders, persistence, canonical data, compact navigation, subscription and statistics rendering, request-isolated email translations.');
const {wineTypeOptionLabel,revealImportTabs}=load('app/mobile-ui.tsx');
for(const lang of ['ro','en','it','fr']){
 i.setLanguage(lang);
 assert.equal(wineTypeOptionLabel('Spumant'),i.t('Spumant'));
 assert.equal(wineTypeOptionLabel('Spumant brut'),'Brut');
 assert.equal(wineTypeOptionLabel('Spumant extra dry'),'Extra dry');
 assert(!wineTypeOptionLabel('Spumant sec').includes(i.t('Spumant')));
 assert.equal(i.t('Spumant brut'),{ro:'Spumant brut',en:'Brut sparkling',it:'Spumante brut',fr:'Effervescent brut'}[lang]);
}
// Keep the intended heading/tabs visible regardless of initial scroll position or panel height.
let scrolled;const container={getBoundingClientRect:()=>({top:20}),scrollBy:options=>scrolled=options.top};
global.window={matchMedia:()=>({matches:true}),visualViewport:{offsetTop:0}};document.querySelector=()=>container;
for(const offset of [0,-300,400]){
 const headingTop=480+offset,tabsTop=550+offset;
 const heading={getBoundingClientRect:()=>({top:headingTop})};
 const tabs={getBoundingClientRect:()=>({top:tabsTop}),parentElement:{querySelector:selector=>selector==='.wineListHeading'?heading:null}};
 revealImportTabs(tabs,'excel');assert.equal(tabsTop-scrolled,68);assert(headingTop-scrolled<0);
 revealImportTabs(tabs,'catalog');assert.equal(tabsTop-scrolled,32);
 revealImportTabs(tabs,'manual');assert.equal(tabsTop-scrolled,32);
}
console.log('PASS: Excel and collection align their source tabs to the reference insets at every starting scroll position.');

const {LanguageSettings}=load('app/language-settings.tsx');
for(const language of ['ro','en','it','fr']){
 const html=renderToStaticMarkup(React.createElement(LanguageSettings,{language,onChange(){}}));
 assert.equal((html.match(/checked=""/g)||[]).length,1);
 assert(html.includes('value="'+language+'" checked=""')||html.includes('checked="" value="'+language+'"'));
 for(const label of ['Română','English','Italiano','Français'])assert(html.includes(label));
 assert(html.includes('role="radiogroup"'));
}
console.log('PASS: language submenu has four native names and exactly one selected radio in every language.');

// Render every standalone user-facing form/panel in each supported language.
const {DateInput,BirthDate}=load('app/mobile-ui.tsx');
const {GrapeSelect}=load('app/grape-select.tsx');
const {RecoveryPrompt}=load('app/recovery-prompt.tsx');
const {EmailRecoveryForm}=load('app/email-recovery.tsx');
const {PasswordResetForm}=load('app/password-reset-form.tsx');
const {SwipeHistoryRow}=load('app/swipe-history-row.tsx');
const noop=()=>{};
let renders=0;
for(const lang of ['ro','en','it','fr']){
 i.setLanguage(lang);
 for(const [component,props,phrase] of [
  [DateInput,{value:'2026-10-31',min:'2026-10-31',onValueChange:noop},'Renunță'],
  [BirthDate,{defaultValue:'1990-05-14'},null],
  [GrapeSelect,{value:[],onChange:noop},'Selectează unul sau mai multe soiuri'],
  [RecoveryPrompt,{code:'ABCDEF123456',onContinue:noop},'Salvează codul de acces'],
  [EmailRecoveryForm,{email:'test@example.com',onSave:async()=>true},'Salvează adresa de e-mail'],
  [PasswordResetForm,{onLogin:noop},'Trimite linkul de resetare'],
  [PasswordResetForm,{token:'a'.repeat(64),onLogin:noop},'Salvează parola'],
  [SubscriptionPanel,{choosing:false,startedAt:Date.now(),onChoose:noop,onUnavailable:noop,onDowngrade:noop,busy:false},'Prima lună gratuită'],
  [WineStatistics,{events:[],reviews:{}},null],
  [SwipeHistoryRow,{title:'Estate',favorite:false,onFavorite:noop,onDelete:noop,children:'Estate'},'Șterge'],
 ]){
  const html=renderToStaticMarkup(React.createElement(component,props));
  assert(html.length>0);assert(!html.includes('[object Object]'));if(phrase)assert(html.includes(i.t(phrase)),lang+': '+phrase);renders++;
 }
}
console.log(`PASS: ${renders} component render scenarios across Romanian, English, Italian and French.`);
for(const lang of ['ro','en','it','fr']){i.setLanguage(lang);const html=renderToStaticMarkup(React.createElement(EmailRecoveryForm,{email:'example@example.com',requirePassword:true,onSave:async()=>true}));assert(html.includes('type="password"'));assert(html.includes('autoComplete="current-password"'));assert(html.includes(i.t('Parola actuală')))}
console.log('PASS: sensitive email form requires a current password in all four languages.');
