import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import ts from 'typescript';
const page=fs.readFileSync('app/page.tsx','utf8');
const lib=fs.readFileSync('app/lib.ts','utf8');
const section=lib.slice(lib.indexOf('export function tastingSection'),lib.indexOf('export function newestTastings')).replace('export ','');
const back=page.slice(page.indexOf(' function backToEvents'),page.indexOf(' function openTasting'));
for(const [owner,host,status,completed,expected] of [
 ['host',true,'active',false,['manageTab:wines','manage']],
 ['host',true,'active',true,['manageTab:wines','manage']],
 ['host',true,'ended',true,['ended','events',640]],
 ['other',true,'active',false,['active','events',640]],
 ['other',false,'active',false,['active','events',640]],
 ['other',false,'active',true,['ended','events',640]],
]){
 const calls=[];const ctx={ev:{owner,status,participationCompleted:completed},p:{id:'host',host},eventsScroll:{current:640},setManageTab:t=>calls.push('manageTab:'+t),setTab:t=>calls.push(t),go:p=>calls.push(p),requestAnimationFrame:fn=>fn(),scrollAppTo:v=>calls.push(v.top)};
 vm.createContext(ctx);vm.runInContext(ts.transpile(section+back+';backToEvents();'),ctx);
 assert.deepEqual(calls,expected);
}
// The visible Back button was intentionally removed; browser history is
// exercised separately in browser-navigation.mjs.
console.log('PASS: active organizing hosts return to management; visiting hosts, guests and ended tastings return to the appropriate list.');
