import assert from 'node:assert/strict';import fs from 'node:fs';
const source=fs.readFileSync('app/push-notifications.tsx','utf8');
const fn=source.slice(source.indexOf('async function enable()'),source.indexOf('async function disable()'));
async function run({permission='granted',fail='',double=false}={}){
 const actions=[],states=[],messages=[],activating={current:false};let resolve;
 const paused=new Promise(r=>resolve=r);
 const registration={pushManager:{getSubscription:async()=>({toJSON:()=>({endpoint:'fixture'})})}};
 const api=async action=>{actions.push(action);if(double&&action==='pushSubscribe')await paused;if(action===fail)throw Error('fixture')};
 const enable=new Function('config','activating','setBusy','setMessage','Notification','navigator','api','setActive','dismiss',fn+';return enable;')({enabled:true},activating,()=>{},s=>messages.push(s),{requestPermission:async()=>permission},{serviceWorker:{ready:Promise.resolve(registration)}},api,s=>states.push(s),()=>{});
 const first=enable();if(double){await enable();resolve()}await first;return{actions,states,messages,activating};
}
assert.deepEqual((await run()).actions,['pushSubscribe','pushTest']);
assert.deepEqual((await run({permission:'denied'})).actions,[]);
assert.deepEqual((await run({fail:'pushSubscribe'})).actions,['pushSubscribe']);
const failed=await run({fail:'pushTest'});assert.deepEqual(failed.states,[true]);assert.match(failed.messages.at(-1),/nu a putut fi trimis/);
assert.deepEqual((await run({double:true})).actions,['pushSubscribe','pushTest']);
assert.equal((await run()).messages.at(-1),'Notificările sunt acum active.');
assert(!source.includes("onClick={()=>api('pushTest')"));
for(const lang of ['en','it','fr'])assert(JSON.parse(fs.readFileSync('app/i18n-'+lang+'.json','utf8'))['Notificările sunt acum active.']);
console.log('PASS automatic activation push: only after saved consent, no duplicate taps, no send on denial/failure, truthful delivery failure and translations');
