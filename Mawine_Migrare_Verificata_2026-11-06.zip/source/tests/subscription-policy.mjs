import assert from 'node:assert/strict';
import {compileTree} from './helpers/compile.mjs';
const {subscriptionAccess,dueReminders,nextBillingDate}=await import(compileTree('app/subscription.ts','.sites-runtime/policy-tests'));
const day=86400000,start=Date.parse('2026-01-01T10:00:00Z');
const profile={host:true,username:'host',created_at:start,trial_started_at:start};
for(const end of [nextBillingDate(start,'monthly'),nextBillingDate(start,'annual')]){
 assert(subscriptionAccess(start,end,end-1).hostAccess);
 assert(subscriptionAccess(start,end,end).hostAccess);
 assert(!subscriptionAccess(start,end,end+3*day).hostAccess);
 assert(subscriptionAccess(start,end,end+day).inGrace);
 for(const n of [3,2,1]){
  const reminders=dueReminders(profile,{paid:true,status:'active',accessUntil:end,cancelAtPeriodEnd:true},end-n*day);
  assert.equal(reminders[0].kind,'paid-ending');assert.equal(reminders[0].remainingDays,n);
 }
 assert.equal(dueReminders(profile,{paid:false,status:'canceled',accessUntil:end},end)[0].kind,'payment-grace');
 assert(!subscriptionAccess(start,end,end-day,true).hostAccess);
 assert(subscriptionAccess(start,end+30*day,end+day).hostAccess);
}
const end=start+30*day;
for(let n=0;n<3;n++){
 const a=subscriptionAccess(start,null,end+n*day);assert(a.hostAccess);assert(a.inGrace);assert.equal(a.graceDay,n+1);
 const reminders=dueReminders(profile,null,end+n*day);assert.equal(reminders[0].kind,'payment-grace');assert.equal(reminders[0].graceDay,n+1);
}
assert(!subscriptionAccess(start,null,end+3*day).hostAccess);
assert.equal(new Date(nextBillingDate(Date.parse('2028-01-31T12:00:00Z'),'monthly')).toISOString(),'2028-02-29T12:00:00.000Z');
assert.equal(new Date(nextBillingDate(Date.parse('2028-02-29T12:00:00Z'),'annual')).toISOString(),'2029-02-28T12:00:00.000Z');
console.log('PASS paid expiry with grace, 3/2/1 paid reminders, 72-hour grace and calendar billing');
