import assert from 'node:assert/strict';import fs from 'node:fs';import ts from 'typescript';
const source=ts.transpileModule(fs.readFileSync('worker/index.ts','utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ES2022}}).outputText.replace(/^import .*;$/gm,'').replaceAll('import.meta.env.DEV','false');
const prelude=`const handler={async fetch(req){return new Response(req.headers.get('oai-authenticated-user-id')||'no identity',{headers:{'Content-Type':new URL(req.url).pathname.startsWith('/api/')?'application/json':'text/html','Content-Security-Policy':"default-src 'self'; script-src 'self' 'unsafe-inline'"}})}};const runWithConnectorBinding=(_,fn)=>fn();`;
const {default:worker}=await import('data:text/javascript;base64,'+Buffer.from(prelude+source).toString('base64'));
for(const env of [{},{MAWINE_DEPLOYMENT:'standalone',MAWINE_TRUST_PROXY_IDENTITY:'true'}]){
 const r=await worker.fetch(new Request('https://mawine.app/',{headers:{'oai-authenticated-user-id':'spoofed'}}),env,{});
 assert.equal(await r.text(),'no identity');assert.match(r.headers.get('cache-control'),/no-store/);
 if(env.MAWINE_DEPLOYMENT){assert.match(r.headers.get('content-security-policy'),/frame-ancestors 'none'/);assert.equal(r.headers.get('x-frame-options'),'DENY');assert(r.headers.has('strict-transport-security'));}
 const api=await worker.fetch(new Request('https://mawine.app/api/admin'),env,{});assert.equal(api.headers.get('cache-control'),'private, no-store');
}
console.log('PASS runtime boundaries: default header distrust, standalone distrust overrides flag, CSP/frame/HSTS and private API cache');
