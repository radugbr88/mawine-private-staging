import {compileTree as compilePush} from './helpers/compile.mjs';
compilePush('app/push.ts','.sites-runtime/tests');
import {compileTree as compileFeatures} from './helpers/compile.mjs';
compileFeatures('app/admin-features.ts','.sites-runtime/tests');
import {compileTree} from './helpers/compile.mjs';
compileTree('app/account-security.ts','.sites-runtime/tests');
compileTree('app/security.ts','.sites-runtime/tests');
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import fs from 'node:fs';
import ts from 'typescript';
import {mock} from 'node:test';
// Keep date-sensitive fixtures stable as the real calendar advances.
mock.timers.enable({apis:['Date'],now:new Date('2026-10-29T12:00:00Z')});
const inlineGrapeData=s=>s.replace("import grapeData from './grape-data.json';",'const grapeData='+fs.readFileSync('app/grape-data.json','utf8')+';');
const dir='.sites-runtime/tests';fs.mkdirSync(dir,{recursive:true});compileTree('app/i18n.ts',dir);
function compile(file,out,replace=s=>s){fs.writeFileSync(dir+'/'+out,ts.transpileModule(replace(fs.readFileSync(file,'utf8')).replace(/from '(?:\.\/|\.\.\/\.\.\/)i18n'/g,"from './i18n.mjs'"),{compilerOptions:{module:ts.ModuleKind.ES2022,target:ts.ScriptTarget.ES2022}}).outputText)}
compile('app/subscription.ts','subscription.mjs');compileTree('app/billing.ts',dir);
compile('app/wine-identity.ts','wine-identity.mjs');compile('app/identify-wine.ts','identify-wine.mjs',s=>s.replace("from './wine-identity'","from './wine-identity.mjs'").replace("from './grape-names'","from './grape-names.mjs'"));compile('app/grape-names.ts','grape-names.mjs',inlineGrapeData);compile('app/lib.ts','lib.mjs',s=>s.replace("from './grape-names'","from './grape-names.mjs'"));compile('app/api/app/route.ts','route.mjs',s=>s.replace("import {env} from 'cloudflare:workers';","const env=globalThis.testEnv;").replace("from '../../account-security'","from './account-security.mjs'").replace("from '../../security'","from './security.mjs'").replace("from '../../push'","from './push.mjs'").replace("from '../../billing'","from './billing.mjs'").replace("from '../../admin-features'","from './admin-features.mjs'").replace("from '../../subscription'","from './subscription.mjs'").replace("from '../../lib'","from './lib.mjs'").replace("from '../../wine-identity'","from './wine-identity.mjs'").replace("from '../../identify-wine'","from './identify-wine.mjs'").replace("from '../../grape-names'","from './grape-names.mjs'"));
const db=new DatabaseSync(':memory:');for(const file of fs.readdirSync('drizzle').filter(x=>x.endsWith('.sql')).sort())db.exec(fs.readFileSync('drizzle/'+file,'utf8'));
const prepare=(sql)=>{const stmt=db.prepare(sql);let args=[];const out={bind(...a){args=a;return out},async first(){return stmt.get(...args)||null},async all(){return{results:stmt.all(...args)}},async run(){const r=stmt.run(...args);return{meta:{changes:r.changes}}}};return out};
const aliases=new Map();let verificationMail;
const emailTransport=async(url,options)=>{verificationMail=JSON.parse(options.body);return Response.json({success:true,result:{queued:[verificationMail.to]}})};
globalThis.fetch=emailTransport;
globalThis.testEnv={MAWINE_RECOVERY_ENCRYPTION_KEY:Buffer.alloc(32,7).toString('base64'),CLOUDFLARE_EMAIL_API_TOKEN:'test',CLOUDFLARE_ACCOUNT_ID:'a'.repeat(32),MAWINE_EMAIL_FROM:'no-reply@mawine.app',MAWINE_PUBLIC_ORIGIN:'https://test.local',DB:{prepare,batch:async qs=>Promise.all(qs.map(q=>q.run()))}};
compile('app/catalog-seed.ts','catalog-seed.mjs');compile('app/api/catalog/route.ts','catalog-route.mjs',s=>s.replace("import {env} from 'cloudflare:workers';","const env=globalThis.testEnv;").replace("from '../../catalog-seed'","from './catalog-seed.mjs'"));
const catalogRoute=await import('../'+dir+'/catalog-route.mjs');await catalogRoute.POST();await catalogRoute.POST();const catalog=await(await catalogRoute.GET()).json();assert.equal(catalog.wines.length,12);assert.equal(new Set(catalog.wines.map(w=>w.id)).size,12);assert.ok(catalog.wines.every(w=>w.sourceUrl.startsWith('https://www.vivino.com/')&&w.price===''));assert.equal(catalog.wines.find(w=>w.id==='vivino-1984742').year,null);
compile('app/api/demo/route.ts','demo-route.mjs',s=>s.replace("import {env} from 'cloudflare:workers';","const env=globalThis.testEnv;").replace("from '../../account-security'","from './account-security.mjs'").replace("from '../../security'","from './security.mjs'").replace("from '../../push'","from './push.mjs'").replace("from '../../billing'","from './billing.mjs'").replace("from '../../admin-features'","from './admin-features.mjs'").replace("from '../../subscription'","from './subscription.mjs'").replace("from '../../lib'","from './lib.mjs'"));const demoRoute=await import('../'+dir+'/demo-route.mjs');await demoRoute.POST();await demoRoute.POST();
const {GET,POST}=await import('../'+dir+'/route.mjs');const {guessScore,emptyReview,score}=await import('../'+dir+'/lib.mjs');
const testPasswords=new Map();
const browserCookies=new Map();
async function cookieIdentity(user){const cookie=browserCookies.get(user);if(!cookie)return "";const raw=cookie.split("=")[1];return "guest:"+Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256",new TextEncoder().encode(raw)))).map(x=>x.toString(16).padStart(2,"0")).join("")}
async function api(user,action,data={},expected=200){
 const existing=db.prepare('SELECT profile_id FROM identities WHERE identity=?').get(await cookieIdentity(user));
 if(action==='deleteProfile'&&!Object.hasOwn(data,'current'))data={current:testPasswords.get(existing?.profile_id),...data};
 if(action==='activateHost'){const email=data.email??(data.username+'@example.com');if(expected===200)aliases.set(data.username,email);data={...data,email};}
 if(action==='login'&&aliases.has(data.username))data={...data,email:aliases.get(data.username)};
 const r=await(action?POST:GET)(new Request('https://test.local/api/app',{method:action?'POST':'GET',headers:{cookie:browserCookies.get(user)||'','cf-connecting-ip':user,'origin':'https://test.local','content-type':'application/json'},...(action?{body:JSON.stringify({action,...(action==='activateHost'?{confirm:data.password}:{}),...(['createProfile','activateHost'].includes(action)?{termsAccepted:'yes'}:{}),...data})}:{})}));
 const updatedCookie=r.headers.get('set-cookie');if(updatedCookie)browserCookies.set(user,updatedCookie.split(';')[0]);
 const s=await r.json();assert.equal(r.status,expected,JSON.stringify(s));
 if(r.ok&&action==='activateHost'){assert.equal(s.profile.host,false);assert(s.pendingVerification);const token=verificationMail.text.match(/#verify=([a-f0-9]{64})/)[1];const confirmed=await api(user,'confirmEmail',{token});testPasswords.set(confirmed.profile.id,data.password);return confirmed;}
 if(r.ok&&['login','changePassword'].includes(action))testPasswords.set(s.profile.id,data.password);return s;
}
assert.equal((await GET(new Request('https://test.local/api/app'))).status,200);
let host=await api('a','createProfile',{name:'Host',dob:'1990-05-14',gender:''});const hostId=host.profile.id;const recovery=host.recoveryCode;
await api('a','activateHost',{username:'testhost',password:'test-secret-long'});
await api('a','catalog',{wines:[{...catalog.wines[0],year:0}]},400);await api('a','catalog',{wines:[{...catalog.wines[0],year:2021}]});assert.equal((await api('a')).profile.catalog[0].sourceUrl,catalog.wines[0].sourceUrl);
const wine={id:'w1',winery:'Crama test',name:'Cuvee',year:2022,grapes:['Merlot','Cabernet Sauvignon'],country:'România',type:'Roșu sec',price:'80',alcohol:'14'};
const created=await api('a','saveEvent',{title:'Blind',date:'2026-10-29',mode:'blind',wines:[wine]});const eid=created.eventId;
await api('a','start',{id:eid});const started=await api('a');const code=started.events[0].code;
await api('b','createProfile',{name:'Guest',dob:'1991-03-10',gender:''});
const joinedDemo=await api('b','join',{code:'DEMO2026'});assert.equal(joinedDemo.events.find(e=>e.code==='DEMO2026').wines.length,6);
const blindDemo=await api('b','join',{code:'ORB2026'});const blindEvent=blindDemo.events.find(e=>e.code==='ORB2026');assert.equal(blindEvent.mode,'blind');assert.equal(blindEvent.revealed,false);assert.equal(blindEvent.wines.length,6);assert.ok(blindEvent.wines.every(w=>Object.keys(w).length===1&&w.id));assert.equal(db.prepare("SELECT COUNT(*) AS n FROM events WHERE code='ORB2026'").get().n,1);
const demoWineId=blindEvent.wines[0].id;
await api('b','review',{eventId:blindEvent.id,wineId:demoWineId,review:{...emptyReview(),country:'România',year:'2019',grapes:['Chardonnay'],scores:[8,25,25,17,8]}});
const finishedDemo=await api('b','finishParticipation',{id:blindEvent.id});const demoResults=finishedDemo.events.find(e=>e.id===blindEvent.id);
assert.equal(demoResults.revealed,true);assert.equal(demoResults.isDemo,true);assert.equal(demoResults.wines[0].name,'Chardonnay');assert.equal(guessScore(finishedDemo.reviews[blindEvent.id+':'+demoWineId],demoResults.wines[0]),3);
await api('otherDemo','createProfile',{name:'Demo newcomer',dob:'1990-01-01',gender:''});const otherDemo=await api('otherDemo','join',{code:'ORB2026'});assert.equal(otherDemo.events.find(e=>e.id===blindEvent.id).revealed,false);assert.ok(otherDemo.events.find(e=>e.id===blindEvent.id).wines.every(w=>Object.keys(w).length===1));
assert.equal(db.prepare('SELECT revealed FROM events WHERE id=?').get(blindEvent.id).revealed,0);
await api('b','review',{eventId:blindEvent.id,wineId:demoWineId,review:{...emptyReview(),country:'Franța',year:'2020',grapes:['Merlot'],scores:[10,30,30,20,10]}});const lockedDemo=(await api('b')).reviews[blindEvent.id+':'+demoWineId];assert.equal(lockedDemo.country,'România');assert.equal(score(lockedDemo),8.3);
await api('b','reveal',{id:eid},400);await api('b','review',{eventId:eid,wineId:'w1',review:emptyReview()},400);
let guest=await api('b','join',{code});assert.deepEqual(guest.events.find(e=>e.id===eid).wines,[{id:'w1'}]);assert.equal(guest.events.find(e=>e.id===eid).hostName,'Host');assert.equal(guest.events.find(e=>e.id===eid).participants,undefined);assert.equal(guest.events.find(e=>e.id===eid).progress,undefined);
const review={...emptyReview(),scores:[8,25,25,17,8],notes:'Fresh',country:'România',year:'2022',grapes:['Cabernet Sauvignon','Merlot'],favorite:true};
await api('b','review',{eventId:eid,wineId:'w1',review});assert.equal(score(review),8.3);assert.equal(guessScore(review,wine),3);assert.equal(guessScore({...review,grapes:['Merlot']},wine),2.5);assert.equal(guessScore({...review,grapes:['Merlot','Cabernet Sauvignon','Syrah']},wine),3);
await api('b','review',{eventId:eid,wineId:'w1',review:{...review,scores:[11,25,25,17,8]}},400);
await api('stranger','createProfile',{name:'Other guest',dob:'1990-01-01',gender:''});
await api('stranger','finishParticipation',{id:eid},400);
await api('stranger','join',{code});
// Group means include host and complete guest votes, never partial votes or duplicates.
await api('a','review',{eventId:eid,wineId:'w1',review:{...emptyReview(),scores:[9,27,27,18,9]}});
await api('stranger','review',{eventId:eid,wineId:'w1',review:{...emptyReview(),scores:[8,null,null,null,null]}});
let group=(await api('a')).events.find(e=>e.id===eid);
assert.equal(group.progress.w1,2);assert.ok(Math.abs(group.averages.w1-8.65)<1e-9);
await api('a','review',{eventId:eid,wineId:'w1',review:{...emptyReview(),scores:[8,24,24,16,8]}});
group=(await api('a')).events.find(e=>e.id===eid);
assert.equal(group.progress.w1,2);assert.ok(Math.abs(group.averages.w1-8.15)<1e-9);
const finished=await api('b','finishParticipation',{id:eid,profileId:hostId});
assert.equal(finished.events.find(e=>e.id===eid).participationCompleted,true);
assert.equal(finished.events.find(e=>e.id===eid).status,'active');
assert.equal((await api('a')).events.find(e=>e.id===eid).participationCompleted,false);
assert.equal((await api('stranger')).events.find(e=>e.id===eid).participationCompleted,false);
await api('b','finishParticipation',{id:eid});
const rejoined=await api('b','join',{code});assert.equal(rejoined.events.find(e=>e.id===eid).participationCompleted,true);
await api('b','review',{eventId:eid,wineId:'w1',review:{...review,scores:[10,30,30,20,10],country:'Franța',notes:'Final personal note',favorite:false}});
const frozen=(await api('b')).reviews[eid+':w1'];assert.equal(score(frozen),8.3);assert.equal(frozen.country,'România');assert.equal(frozen.notes,'Final personal note');assert.equal(frozen.favorite,false);
const second=await api('a','saveEvent',{title:'Second',date:'2026-10-30',mode:'normal',wines:[wine]});await api('a','start',{id:second.eventId},400);
await api('a','reveal',{id:eid});guest=await api('b');assert.equal(guest.events.find(e=>e.id===eid).wines[0].name,'Cuvee');
await api('b','review',{eventId:eid,wineId:'w1',review:{...review,country:'Franța',grapes:['Syrah']}});guest=await api('b');assert.equal(guest.reviews[eid+':w1'].country,'România');assert.deepEqual(guest.reviews[eid+':w1'].grapes,review.grapes);
await api('a','end',{id:eid});await api('b','review',{eventId:eid,wineId:'w1',review:{...review,scores:[10,30,30,20,10],notes:'Edited later'}});guest=await api('b');assert.equal(score(guest.reviews[eid+':w1']),8.3);assert.equal(guest.reviews[eid+':w1'].notes,'Edited later');
await api('c','login',{username:'testhost',password:'wrong'},400);const login=await api('c','login',{username:'testhost',password:'test-secret-long'});assert.equal(login.profile.id,hostId);
await api('d','recover',{code:recovery},400);await api('a','recovery',{},400);
await api('a','activateHost',{username:'testhost',password:'another-password'},400);
await api('a','updateProfile',{name:'Host updated',dob:'1992-06-15',gender:'Prefer să nu spun'});assert.equal((await api('a')).profile.dob,'1992-06-15');
await api('a','changePassword',{current:'wrong',password:'updated-secret-long'},400);
await api('a','changePassword',{current:'test-secret-long',password:'updated-secret-long'});
await api('c','login',{username:'testhost',password:'test-secret-long'},400);
assert.equal((await api('c','login',{username:'testhost',password:'updated-secret-long'})).profile.name,'Host updated');
await api('a','start',{id:second.eventId});await api('b','deleteProfile');assert.equal((await api('b')).profile,null);
assert.equal((await POST(new Request('https://test.local/api/app',{method:'POST',headers:{'oai-authenticated-user-id':'a','origin':'https://evil.test','content-type':'application/json'},body:JSON.stringify({action:'deleteProfile'})}))).status,400);
// Read a real Excel workbook and verify the two independent import destinations.
compileTree('app/wine-import.ts',dir);
const {parseWineRows,parseDelimited,parsePastedWines}=await import('../'+dir+'/wine-import.mjs');
const israelRows=JSON.parse(fs.readFileSync('tests/fixtures/israel-import.json','utf8')).map(row=>row.map(v=>v&&typeof v==='object'?v.result??'':v));
const israelWines=parseWineRows(israelRows,60);
await api('israelImport','createProfile',{name:'Import regression',dob:'1990-01-01',gender:''});
await api('israelImport','activateHost',{username:'israel_import_test',password:'Test-password-123'});
const israelIdentified=await api('israelImport','identifyWines',{wines:israelWines});
assert.equal(israelIdentified.identifiedWines.length,9);
assert.equal(israelIdentified.identifiedWines[0].winery,'SPHERA');
assert.equal(israelIdentified.identifiedWines[0].alcohol,'13.5');
assert.equal(israelIdentified.identifiedWines[0].price,'38.85 EUR');
const israelSaved=await api('israelImport','saveEvent',{title:'Israel regression',date:'2026-10-29',mode:'normal',wines:israelIdentified.identifiedWines});
assert.equal(israelSaved.events.find(e=>e.id===israelSaved.eventId).wines.length,9);
assert.equal(israelSaved.profile.catalog.length,0);
const israelCollection=await api('israelImport','importCollection',{wines:israelIdentified.identifiedWines});
assert.equal(israelCollection.profile.catalog.length,9);
const Excel=(await import('exceljs')).default;const wb=new Excel.Workbook();const ws=wb.addWorksheet('Vinuri');
ws.addRow(['Crama','Vin','An','Țara','Soiuri','Tip','Alcool','Preț']);
ws.addRow(['Crama Excel','Alb',2023,'România','Chardonnay','Alb sec',13,55]);
ws.addRow(['Crama Excel','Cupaj',2022,'România','Merlot, Cabernet Sauvignon','Roșu sec',14,80]);
const loadedBook=new Excel.Workbook();await loadedBook.xlsx.load(await wb.xlsx.writeBuffer());
const rows=[];loadedBook.worksheets[0].eachRow(r=>rows.push(r.values.slice(1)));
const importedWines=parseWineRows(rows,300);assert.equal(importedWines.length,2);assert.deepEqual(importedWines[1].grapes,['Merlot','Cabernet Sauvignon']);
assert.throws(()=>parseWineRows(rows,1),/Mai poți/);assert.throws(()=>parseWineRows([['Vin','An'],['Invalid',1800]],60),/Rândul/);
const reordered=parseWineRows(parseDelimited('\ufeffPreț;Soiuri;Wine name;Vintage;Winery\r\n"89,50";"Merlot, Cabernet Sauvignon";"Cuvée; special";2022;Crama CSV'),60);
assert.equal(reordered[0].name,'Cuvée; special');assert.equal(reordered[0].price,'89,50');assert.equal(reordered[0].winery,'Crama CSV');assert.deepEqual(reordered[0].grapes,['Merlot','Cabernet Sauvignon']);
const commaRows=parseWineRows(parseDelimited('Price,Wine name,Year,Grapes\n"100,50","Vin \"\"A\"\"",2023,"Merlot, Syrah"'),60);assert.equal(commaRows[0].name,'Vin "A"');assert.equal(commaRows[0].grapes.length,2);
const minimal=parseWineRows([['Wine name','Price'],['Vin fără detalii',50]],60);assert.equal(minimal[0].year,null);assert.equal(minimal[0].winery,'');assert.deepEqual(minimal[0].grapes,[]);assert.equal(minimal[0].price,'50');
assert.throws(()=>parseWineRows([['Culoare','An'],['Alb',2022]],60),/antet/);
assert.throws(()=>parseWineRows([['Vin','Name'],['A','B']],60),/ambigue/);
const optional=await api('a','saveEvent',{title:'Date parțiale',date:'2026-10-29',mode:'normal',wines:minimal});assert.equal(optional.events.find(e=>e.id===optional.eventId).wines[0].year,null);
compile('app/api/grapes/route.ts','grapes-route.mjs',s=>s.replace("import {env} from 'cloudflare:workers';","const env=globalThis.testEnv;").replace("from '../../grape-names'","from './grape-names.mjs'"));
const grapeRoute=await import('../'+dir+'/grapes-route.mjs');
async function grapeSearch(query){return (await grapeRoute.GET(new Request('https://test.local/api/grapes?'+query))).json()}
assert.equal((await grapeSearch('')).total,492);assert.equal((await grapeSearch('color=white')).total,243);
assert.ok((await grapeSearch('q=feteasca')).items.some(g=>g.name==='Fetească Neagră'));
assert.ok((await grapeSearch('q=pinot+grigio')).items.some(g=>g.name==='Pinot Gris'));
assert.ok((await grapeSearch('q=shiraz')).items.some(g=>g.name==='Syrah'));
const excluded=JSON.parse(fs.readFileSync('scripts/data/excluded-grapes.json','utf8'));assert.equal(excluded.length,1621);for(const g of excluded)assert.equal(db.prepare('SELECT id FROM grape_varieties WHERE id=?').get(g.id),undefined);const activeGrapes=JSON.parse(fs.readFileSync('app/grape-data.json','utf8'));assert.ok(activeGrapes.every(g=>g.usage==='WINE GRAPE'&&!g.species.includes('SUBSP. SYLVESTRIS')));
const firstPage=await grapeSearch('');const nextPage=await grapeSearch('offset=60');assert.ok(!firstPage.items.some(g=>nextPage.items.some(n=>n.id===g.id)));
const {sameGrapes}=await import('../'+dir+'/grape-names.mjs');assert.ok(sameGrapes(['Shiraz','Feteasca Neagra'],['Syrah','Fetească Neagră']));assert.ok(!sameGrapes(['Merlot'],['Merlot','Syrah']));
const incompleteBlind=await api('a','saveEvent',{title:'Blind incomplete',date:'2026-10-29',mode:'blind',wines:minimal});await api('a','start',{id:incompleteBlind.eventId},400);
const originalCollection=(await api('a')).profile.catalog;
const importEvent=await api('a','saveEvent',{title:'Excel independent',date:'2026-10-29',mode:'normal',wines:importedWines});
assert.deepEqual(importEvent.profile.catalog,originalCollection);
assert.equal(importEvent.events.find(e=>e.id===importEvent.eventId).wines.length,2);
const savedCollection=await api('a','catalog',{wines:[...originalCollection,...importedWines]});
assert.equal(savedCollection.profile.catalog.length,originalCollection.length+2);
assert.equal(savedCollection.events.find(e=>e.id===importEvent.eventId).wines.length,2);
const {splitWineName,mergeWineCollection}=await import('../'+dir+'/wine-identity.mjs');
assert.deepEqual(splitWineName('Crama Exemplu - Rezerva'),{name:'Rezerva',winery:'Crama Exemplu'});
assert.deepEqual(splitWineName('Rezerva — Crama Exemplu'),{name:'Rezerva',winery:'Crama Exemplu'});
assert.deepEqual(splitWineName('Rezerva - Purcari','',['Purcari']),{name:'Rezerva',winery:'Purcari'});
assert.deepEqual(splitWineName('Saint-Émilion'),{name:'Saint-Émilion',winery:''});
assert.deepEqual(splitWineName('Grand - Reserve'),{name:'Grand - Reserve',winery:''});
assert.deepEqual(splitWineName('Rezerva - Purcari','Purcari'),{name:'Rezerva',winery:'Purcari'});
const splitRows=parseWineRows([['Vin','An'],['Crama Exemplu - Rezerva',2022]],60);assert.equal(splitRows[0].winery,'Crama Exemplu');
assert.equal(mergeWineCollection(importedWines,importedWines.map(w=>({...w,id:crypto.randomUUID()}))).length,2);
await api('importHost','createProfile',{name:'Import host',dob:'1990-01-01',gender:''});await api('importHost','activateHost',{username:'importhost',password:'long-import-password'});
const draftImported=await api('importHost','saveEvent',{title:'Fișier importat',date:'2026-10-29',mode:'normal',wines:importedWines,collectionWineIds:importedWines.map(w=>w.id)});
assert.equal(draftImported.profile.catalog.length,0);
await api('importHost','saveEvent',{id:draftImported.eventId,title:'Fișier importat',date:'2026-10-29',mode:'normal',wines:importedWines,collectionWineIds:importedWines.map(w=>w.id)});
const launched=await api('importHost','start',{id:draftImported.eventId});assert.equal(launched.events.find(e=>e.id===draftImported.eventId).status,'active');assert.equal(launched.profile.catalog.length,0);
const repeated=await api('importHost','importCollection',{wines:importedWines.map(w=>({...w,id:crypto.randomUUID()}))});assert.equal(repeated.profile.catalog.length,2);const explicitAgain=await api('importHost','importCollection',{wines:importedWines});assert.equal(explicitAgain.profile.catalog.length,2);
await api('otherDemo','importCollection',{wines:importedWines},400);
const combined={...wine,id:'combined',name:'Crama Exemplu — Rezerva — Cabernet Sauvignon',winery:'',grapes:[]};
const identified=await api('importHost','identifyWines',{wines:[combined]});const identifiedWine=identified.identifiedWines[0];
assert.equal(identifiedWine.winery,'Crama Exemplu');assert.equal(identifiedWine.name,'Rezerva');assert.deepEqual(identifiedWine.grapes,['Cabernet Sauvignon']);
const blend=await api('importHost','identifyWines',{wines:[{...combined,name:'Rezerva - Merlot & Syrah - Crama Exemplu'}]});assert.deepEqual(blend.identifiedWines[0].grapes,['Merlot','Syrah']);assert.equal(blend.identifiedWines[0].name,'Rezerva');
const varietal=await api('importHost','identifyWines',{wines:[{...combined,name:'Merlot - Crama Exemplu'}]});assert.equal(varietal.identifiedWines[0].name,'Merlot');assert.deepEqual(varietal.identifiedWines[0].grapes,['Merlot']);
const producer=await api('importHost','identifyWines',{wines:[{...combined,name:'Crama Merlot — Rezerva'}]});assert.deepEqual(producer.identifiedWines[0].grapes,[]);
const contextualImport=parseWineRows([['Degustare Africa de Sud'],['Vin','Cramă'],['Reserve CABERNET SAUVIGNON & merlot','Producător'],['Rezerva feteasca neagra','Producător'],['Chardonnay','Producător']],60);
const contextualIdentified=(await api('importHost','identifyWines',{wines:contextualImport})).identifiedWines;
assert.ok(contextualIdentified.every(w=>w.country==='Africa de Sud'));
assert.deepEqual(contextualIdentified[0].grapes,['Cabernet Sauvignon','Merlot']);
assert.deepEqual(contextualIdentified[1].grapes,['Fetească Neagră']);
assert.deepEqual(contextualIdentified[2].grapes,['Chardonnay']);
assert.equal(contextualIdentified[2].name,'Chardonnay');
const contextSaved=await api('importHost','saveEvent',{title:'Context import',date:'2026-10-29',mode:'normal',wines:contextualIdentified});
assert.deepEqual(contextSaved.events.find(e=>e.id===contextSaved.eventId).wines[0].grapes,['Cabernet Sauvignon','Merlot']);
assert.equal(contextSaved.events.find(e=>e.id===contextSaved.eventId).wines[0].country,'Africa de Sud');
await api('otherDemo','identifyWines',{wines:[combined]},400);await api('otherDemo','catalog',{wines:[wine]},400);assert.deepEqual((await api('otherDemo')).profile.catalog,[]);
assert.equal((await api('importHost')).profile.catalog.length,2); // identification does not save or auto-populate collections
console.log('PASS: profiles, host credentials, permanent guest recovery, authorization, invitation, blind redaction, partial grape scoring, score bounds, single active tasting, reveal freeze, history editing, deletion and CSRF.');
// Guest code remains identical across sessions and is encrypted at rest.
const personal=await api('persist','createProfile',{name:'Participant',dob:'1991-01-01',gender:''});
assert.equal((await api('persist')).profile.recoveryCode,personal.recoveryCode);
const storedGuest=db.prepare('SELECT recovery,recovery_cipher FROM profiles WHERE id=?').get(personal.profile.id);
assert(storedGuest.recovery_cipher.startsWith('v1:'));assert(!storedGuest.recovery_cipher.includes(personal.recoveryCode));
assert.equal((await api('persist','recovery')).recoveryCode,personal.recoveryCode);
assert.equal((await api('persist','recovery')).recoveryCode,personal.recoveryCode);
assert.deepEqual(db.prepare('SELECT recovery,recovery_cipher FROM profiles WHERE id=?').get(personal.profile.id),storedGuest);
assert.equal((await api('new-phone','recover',{code:personal.recoveryCode})).profile.recoveryCode,personal.recoveryCode);
const other=await api('separate','createProfile',{name:'Other',dob:'1992-01-01',gender:''});
assert.notEqual(other.profile.recoveryCode,personal.recoveryCode);assert.deepEqual(other.events,[]);assert.deepEqual(other.reviews,{});
// Upgrade old hash-only profiles without invalidating their saved recovery code.
db.prepare('UPDATE profiles SET recovery_code=NULL,recovery_cipher=NULL WHERE id=?').run(personal.profile.id);
const upgraded=await api('persist');assert.equal(upgraded.profile.recoveryCode,null);assert.equal(upgraded.profile.recoveryCodeUnavailable,true);await api('persist','recovery',{code:personal.recoveryCode});
assert.equal((await api('persist')).profile.recoveryCode,personal.recoveryCode);
assert.equal((await api('legacy-phone','recover',{code:personal.recoveryCode})).profile.id,personal.profile.id);
db.prepare('UPDATE profiles SET recovery_code=? WHERE id=?').run('LEGACYDISPLAYCODE',personal.profile.id);
await api('persist');assert.equal((await api('persist')).profile.recoveryCode,personal.recoveryCode);
assert.equal((await api('display-phone','recover',{code:'LEGACYDISPLAYCODE'})).profile.id,personal.profile.id);
// Decode actual generated QR pixels, using the same library as the camera.
const {default:QRCode}=await import('qrcode'),{default:jsQR}=await import('jsqr');
const invitation='https://test.local/?join=ORB2026';const matrix=QRCode.create(invitation).modules;const scale=5,size=(matrix.size+8)*scale,pixels=new Uint8ClampedArray(size*size*4).fill(255);
for(let y=0;y<matrix.size;y++)for(let x=0;x<matrix.size;x++)if(matrix.get(y,x))for(let dy=0;dy<scale;dy++)for(let dx=0;dx<scale;dx++){const i=(((y+4)*scale+dy)*size+(x+4)*scale+dx)*4;pixels[i]=pixels[i+1]=pixels[i+2]=0;}
assert.equal(jsQR(pixels,size,size)?.data,invitation);
console.log('PASS: permanent display of private recovery, legacy recovery, separate participant data and QR image decoding.');
const withoutFooters=parseWineRows([['Wine name','Year','Winery','Price'],['The Chocolate Block',2023,'Boekenhoutskloof',117.48],['Summary','','',''],['Total','','',1964.89],['Average','','',163.74],['Rezumat'],['Medie'],['Total',2022,'Crama exemplu',80]],60);
assert.equal(withoutFooters.length,2);assert.equal(withoutFooters[1].name,'Total');
await api('separate','saveEvent',{title:'Nu este gazdă',date:'2026-10-29',wines:[],mode:'normal'},400);
assert.equal((await api('separate')).profile.host,false);
console.log('PASS: spreadsheet footers excluded and participant cannot create tastings.');
assert.equal(activeGrapes.length,492);assert.equal(new Set(activeGrapes.map(g=>g.name)).size,492);assert.equal(activeGrapes.filter(g=>g.color==='NOIR').length,234);assert.equal(activeGrapes.filter(g=>g.color==='GRIS').length,13);
assert.ok((await grapeSearch('q=mer')).items.some(g=>g.name==='Merlot'));
assert.ok((await grapeSearch('q=pinot%20grigio')).items.some(g=>g.name==='Pinot Gris'));
console.log('PASS: 492 ranked varieties, colour categories and partial/alias search.');
// Public guests: independent secure cookie, no platform identity required.
const publicFirst=await GET(new Request('https://test.local/api/app'));
const guestCookie=publicFirst.headers.get('set-cookie');assert.match(guestCookie,/HttpOnly; Secure; SameSite=Lax/);
const cookie=guestCookie.split(';')[0];assert.equal((await publicFirst.json()).profile,null);
const publicCall=async(action,data={})=>{const r=await POST(new Request('https://test.local/api/app',{method:'POST',headers:{origin:'https://test.local',cookie,'content-type':'application/json'},body:JSON.stringify({action,...(action==='activateHost'?{confirm:data.password}:{}),...(['createProfile','activateHost'].includes(action)?{termsAccepted:'yes'}:{}),...(action==='activateHost'?{email:'host@example.com'}:{}),...data})}));return {status:r.status,...await r.json()}};
const publicProfile=await publicCall('createProfile',{name:'Invitat public',dob:'1990-01-01',gender:''});assert.equal(publicProfile.status,200);assert.equal(publicProfile.profile.host,false);
const publicReload=await(await GET(new Request('https://test.local/api/app',{headers:{cookie}}))).json();assert.equal(publicReload.profile.id,publicProfile.profile.id);
assert.equal((await publicCall('join',{code:'ORB2026'})).status,200);
assert.equal((await publicCall('end',{id:'mawine-blind-demo-2026'})).status,400);
assert.equal((await publicCall('saveEvent',{title:'Unauthorized',date:'2026-10-29',wines:[]})).status,400);
const stranger=await(await GET(new Request('https://test.local/api/app'))).json();assert.equal(stranger.profile,null);assert.deepEqual(stranger.events,[]);
console.log('PASS: anonymous guest isolation, invitation join and denied host actions.');
// History removal is per profile and never changes group scores or membership.
const beforeHistory=(await api('a')).events.find(e=>e.id===eid);
await api('history-outsider','createProfile',{name:'Outside',dob:'1990-01-01'});
await api('history-outsider','deleteHistory',{id:eid},400);
const hidden=await api('stranger','deleteHistory',{id:eid,profileId:hostId});
assert.equal(hidden.events.find(e=>e.id===eid).historyHidden,true);
assert.equal((await api('stranger')).events.find(e=>e.id===eid).historyHidden,true);
const afterHistory=(await api('a')).events.find(e=>e.id===eid);
assert.equal(afterHistory.historyHidden,false);
assert.deepEqual(afterHistory.averages,beforeHistory.averages);
assert.equal(afterHistory.count,beforeHistory.count);
assert.equal((await api('a','deleteHistory',{id:eid})).events.find(e=>e.id===eid).historyHidden,true);
await publicCall('deleteHistory',{id:'mawine-blind-demo-2026'}).then(r=>assert.equal(r.status,400));
// Logout disconnects this identity only; profile survives and can log in/recover.
assert.equal((await api('c','logout')).profile,null);
assert.equal((await api('c')).profile,null);
assert.equal((await api('a')).profile.id,hostId);
assert.equal((await api('c','login',{username:'testhost',password:'updated-secret-long'})).profile.id,hostId);
assert.equal((await publicCall('logout')).profile,null);
assert.equal((await(await GET(new Request('https://test.local/api/app',{headers:{cookie}}))).json()).profile,null);
assert.equal((await api('returning-guest','recover',{code:publicProfile.recoveryCode})).profile.id,publicProfile.profile.id);
console.log('PASS: scoped persistent history removal, preserved group results, host logout and public guest logout/recovery.');
// Tasting favorites are independent from wine favorites and other profiles.
await api('history-outsider','favoriteHistory',{id:eid,favorite:true},400);
await api('public-favorite','recover',{code:publicProfile.recoveryCode});
await api('public-favorite','favoriteHistory',{id:'mawine-blind-demo-2026',favorite:true},400);
const starred=await api('stranger','favoriteHistory',{id:eid,favorite:true});
assert.equal(starred.events.find(e=>e.id===eid).historyFavorite,true);
assert.equal((await api('stranger')).events.find(e=>e.id===eid).historyFavorite,true);
assert.equal((await api('a')).events.find(e=>e.id===eid).historyFavorite,false);
assert.equal((await api('stranger','favoriteHistory',{id:eid,favorite:false})).events.find(e=>e.id===eid).historyFavorite,false);
console.log('PASS: tasting favorites persist per profile and reject unrelated or unfinished tastings.');

const pastedText=parseWineRows(parsePastedWines('Crama Test – Rezerva Merlot 2022, 90 RON\nCrama Alta – Chardonnay 2023'),60);
assert.equal(pastedText.length,2);assert.equal(pastedText[0].year,2022);assert.equal(pastedText[0].price,'90 RON');assert.equal(pastedText[1].year,2023);
const pastedTable=parseWineRows(parsePastedWines('An;Vin;Preț\n2022;Rezerva;90'),60);assert.equal(pastedTable[0].name,'Rezerva');assert.equal(pastedTable[0].price,'90');
console.log('PASS: plain-text wine lines and Excel paste with reordered headers.');

await api('transferHost','createProfile',{name:'Collection host',dob:'1990-01-01',gender:''});
await api('transferHost','activateHost',{username:'transferhost',password:'transfer-test-secret'});
const transferWine={...wine,id:'transfer-wine'}, keepWine={...wine,id:'keep-wine'};
await api('transferHost','catalog',{wines:[transferWine,keepWine]});
await api('transferHost','saveEvent',{title:'',date:'2026-10-29',wines:[transferWine],collectionWineIds:[transferWine.id]},400);
assert.equal((await api('transferHost')).profile.catalog.length,2);
const transferEvent=await api('transferHost','saveEvent',{title:'Transfer test',date:'2026-10-29',mode:'normal',wines:[transferWine],collectionWineIds:[transferWine.id,keepWine.id]});
assert.deepEqual(transferEvent.profile.catalog.map(w=>w.id),[transferWine.id,keepWine.id]);
assert.equal(transferEvent.events.find(e=>e.id===transferEvent.eventId).wines[0].id,transferWine.id);
const launchTransfer=await api('transferHost','saveEvent',{title:'Start transfer',date:'2026-10-29',mode:'normal',wines:[transferWine],collectionWineIds:[transferWine.id]});
await api('transferHost','saveEvent',{id:launchTransfer.eventId,title:'Start transfer edited',date:'2026-10-29',mode:'normal',wines:[transferWine],collectionWineIds:[]});
assert.equal((await api('transferHost')).profile.catalog.length,2);
await api('transferHost','start',{id:launchTransfer.eventId});
const blockedTransfer=await api('transferHost','saveEvent',{title:'Blocked transfer',date:'2026-10-29',mode:'normal',wines:[keepWine],collectionWineIds:[keepWine.id]});
await api('transferHost','start',{id:blockedTransfer.eventId},400);
await api('transferHost','saveEvent',{title:'Imported copy',date:'2026-10-29',mode:'normal',wines:[keepWine]});
assert.deepEqual((await api('transferHost')).profile.catalog.map(w=>w.id),[keepWine.id]);
console.log('PASS: selected collection wines transfer only on successful start; unrelated and non-transfer wines remain.');

const detailPaste=parseWineRows(parsePastedWines('Davino, Flamboyant, 2022, 14%, 280 lei\nRecaș, Chardonnay, 2023, 12,5%, 72,48 RON'),60);
assert.equal(detailPaste.length,2);
assert.equal(detailPaste[0].winery,'Davino');assert.equal(detailPaste[0].name,'Flamboyant');
assert.equal(detailPaste[0].year,2022);assert.equal(detailPaste[0].alcohol,'14');assert.equal(detailPaste[0].price,'280 lei');
assert.equal(detailPaste[1].alcohol,'12,5');assert.equal(detailPaste[1].price,'72,48 RON');
const quotedPaste=parseWineRows(parsePastedWines('Davino, "Rezerva, specială", 2022, 14%, 280 lei'),60);
assert.equal(quotedPaste.length,1);assert.equal(quotedPaste[0].name,'Rezerva, specială');
console.log('PASS: one wine per line, comma-separated details, quoted names and decimal prices.');
await api('stranger','deleteDraft',{id:transferEvent.eventId},400);
await api('a','deleteDraft',{id:transferEvent.eventId},400);
assert((await api('transferHost')).events.some(e=>e.id===transferEvent.eventId));
const afterDraftDelete=await api('transferHost','deleteDraft',{id:transferEvent.eventId});
assert(!afterDraftDelete.events.some(e=>e.id===transferEvent.eventId));
await api('transferHost','deleteDraft',{id:transferEvent.eventId},400);
await api('a','deleteDraft',{id:eid},400);
console.log('PASS: only owned drafts can be deleted; other owners and completed events are protected.');

const {matchesWine,validTastingDate,tastingToday}=await import('../'+dir+'/lib.mjs');
const searchable={...wine,winery:'Crama Recaș',name:'Fetească Neagră',year:2022,grapes:['Cabernet Sauvignon']};
for(const query of ['2022','RECAS','feteasca neagra','2022 recas','sauvignon 2022','  cabernet   recas '])assert(matchesWine(searchable,query),query);
assert(!matchesWine(searchable,'2023 recas'));assert(matchesWine(searchable,''));
const now=new Date('2026-10-29T22:30:00Z');assert.equal(tastingToday(now),'2026-10-30');
assert(!validTastingDate('2026-10-29',now));assert(validTastingDate('2026-10-30',now));assert(validTastingDate('2026-11-01',now));assert(!validTastingDate('2026-02-30',now));
await api('transferHost','saveEvent',{title:'Past date',date:'2020-01-01',mode:'normal',wines:[wine]},400);
const pastedPipeline=parseWineRows(parsePastedWines('Davino,Flamboyant,2022,14%,280 lei\r\n\r\nRecaș,Rezerva Cabernet Sauvignon,2023,13,5%,72,48 lei'),60);
assert.equal(pastedPipeline.length,2);assert.equal(pastedPipeline[0].year,2022);assert.equal(pastedPipeline[0].alcohol,'14');
const identifiedPaste=await api('transferHost','identifyWines',{wines:pastedPipeline});
assert.equal(identifiedPaste.identifiedWines[0].name,'Flamboyant');assert(identifiedPaste.identifiedWines[1].grapes.includes('Cabernet Sauvignon'));
const savedPaste=await api('transferHost','saveEvent',{title:'Pasted lines test',date:tastingToday(),mode:'normal',wines:identifiedPaste.identifiedWines});
const roundTrip=(await api('transferHost')).events.find(e=>e.id===savedPaste.eventId).wines;
assert.equal(roundTrip.length,2);assert.equal(roundTrip[0].price,'280 lei');assert.equal(roundTrip[1].alcohol,'13,5');assert.equal(roundTrip[1].price,'72,48 lei');
assert.throws(()=>parseWineRows(parsePastedWines('   '),60));
assert.throws(()=>parsePastedWines('Davino, "unfinished'));
console.log('PASS: normalized multi-term collection search; Romanian date boundary and past-date rejection; paste identification, save and reload.');

const countryPaste=parseWineRows(parsePastedWines('Davino, Flamboyant, România, 2022, 15%'),60);
assert.equal(countryPaste.length,1);assert.equal(countryPaste[0].name,'Flamboyant');assert.equal(countryPaste[0].winery,'Davino');assert.equal(countryPaste[0].country,'România');assert.equal(countryPaste[0].year,2022);assert.equal(countryPaste[0].alcohol,'15');
assert.equal(parseWineRows(parsePastedWines('Davino, Flamboyant, romania, 2022, 15%'),60)[0].country,'România');
console.log('PASS: updated paste example recognizes country independently of wine name.');

// Blind grape scores count distinct correct varieties, including aliases.
const {grapeGuessScore}=await import('../'+dir+'/lib.mjs');
assert.equal(grapeGuessScore(['Merlot'],['Merlot']),1);
assert.equal(grapeGuessScore(['Merlot'],['Merlot','Syrah','Cabernet Sauvignon']),0.5);
assert.equal(grapeGuessScore(['Merlot','Shiraz'],['Merlot','Syrah','Cabernet Sauvignon']),1);
assert.equal(grapeGuessScore(['Syrah','Shiraz'],['Merlot','Syrah']),0.5);
assert.equal(grapeGuessScore(['Chardonnay'],['Merlot','Syrah']),0);
assert.equal(grapeGuessScore([],[]),0);

const {wineStatistics}=await import('../'+dir+'/lib.mjs');
const statsEvents=[{id:'stat',title:'Real tasting',status:'ended',wines:[wine,{...wine,id:'low',type:'Alb sec'},{...wine,id:'unrated'}]},{id:'draft-stat',status:'draft',wines:[wine]},{id:'demo-stat',status:'ended',isDemo:true,wines:[wine]}];
const statsReviews={'stat:w1':review,'stat:low':{...review,scores:[5,10,10,10,5]}};
const statistics=wineStatistics(statsEvents,statsReviews);
assert.equal(statistics.tastings,1);assert.equal(statistics.count,2);assert.equal(statistics.average,6.15);assert.equal(statistics.best.wine.id,'w1');assert.equal(statistics.worst.wine.id,'low');assert.deepEqual(statistics.colors,{'Alb':1,'Orange':0,'Roze':0,'Roșu':1});assert.equal(wineStatistics([],{}).average,null);
assert(activeGrapes.every(g=>g.name==='Muscat Bailey A'||! /\([A-Za-z]\)|\s[A-Za-z]$/.test(g.name)));
console.log('PASS: statistics exclude unrated wines, drafts and demos; extrema, average, colors and empty state.');

assert.deepEqual(wineStatistics([],{}).colors,{'Alb':0,'Orange':0,'Roze':0,'Roșu':0});

await api('revealHost','createProfile',{name:'Reveal host',dob:'1990-01-01'});
await api('revealHost','activateHost',{username:'revealhost',password:'test-password-long'});
const partial=await api('revealHost','saveEvent',{title:'Individual reveal',date:tastingToday(),mode:'blind',wines:[wine,{...wine,id:'w2'}]});
await api('revealHost','revealWine',{id:partial.eventId,wineId:'w1'},400);
const ps=await api('revealHost','start',{id:partial.eventId});const pe=ps.events.find(e=>e.id===partial.eventId);
await api('stranger','join',{code:pe.code});
await api('stranger','review',{eventId:pe.id,wineId:'w1',review});
await api('stranger','revealWine',{id:pe.id,wineId:'w1'},400);
await api('revealHost','revealWine',{id:pe.id,wineId:'missing'},400);
await api('revealHost','revealWine',{id:pe.id,wineId:'w1'});
await api('revealHost','revealWine',{id:pe.id,wineId:'w1'});
let partialGuest=(await api('stranger')).events.find(e=>e.id===pe.id);
assert.equal(partialGuest.revealed,false);assert.deepEqual(partialGuest.revealedWineIds,['w1']);assert.equal(partialGuest.wines[0].name,wine.name);assert.deepEqual(partialGuest.wines[1],{id:'w2'});
await api('stranger','review',{eventId:pe.id,wineId:'w1',review:{...review,country:'Italia'}});
await api('stranger','review',{eventId:pe.id,wineId:'w2',review:{...review,country:'Italia'}});
const pr=(await api('stranger')).reviews;assert.equal(pr[pe.id+':w1'].country,'România');assert.equal(pr[pe.id+':w2'].country,'Italia');
await api('revealHost','reveal',{id:pe.id});assert((await api('stranger')).events.find(e=>e.id===pe.id).wines.every(w=>w.name));
console.log('PASS: individual reveal authorization, idempotency, hidden other wine, per-wine guess lock and reveal-all.');

// The organizer can rate their own blind wines, but cannot submit guesses.
await api('revealHost','review',{eventId:pe.id,wineId:'w1',review});
const organizerReview=(await api('revealHost')).reviews[pe.id+':w1'];
assert.equal(score(organizerReview),8.3);assert.equal(organizerReview.country,'');assert.equal(organizerReview.year,'');assert.deepEqual(organizerReview.grapes,[]);assert.equal(organizerReview.notes,review.notes);
// Host status alone must not block guessing at somebody else's tasting.
await api('stranger','activateHost',{username:'visitinghost',password:'visiting-password-long'});
for(const active of (await api('a')).events.filter(e=>e.status==='active'&&e.owner===hostId))await api('a','end',{id:active.id});
const otherBlind=await api('a','saveEvent',{title:'Visiting host',date:tastingToday(),mode:'blind',wines:[wine]});
const otherStarted=await api('a','start',{id:otherBlind.eventId});
const otherEvent=otherStarted.events.find(e=>e.id===otherBlind.eventId);
await api('stranger','join',{code:otherEvent.code});
await api('stranger','review',{eventId:otherEvent.id,wineId:'w1',review});
assert.equal((await api('stranger')).reviews[otherEvent.id+':w1'].country,'România');
const {countries}=await import('../'+dir+'/lib.mjs');
assert.equal(countries.length,102);assert.equal(new Set(countries).size,102);
for(const c of ['România','Franța','Republica Moldova','SUA','Capul Verde','Bhutan','Kosovo','Zimbabwe'])assert(countries.includes(c));
console.log('PASS: organizer has tasting scores only; visiting hosts can guess; 102 distinct countries.');

const {tastingSection,newestTastings}=await import('../'+dir+'/lib.mjs');
const ownCompleted={id:'own-active',owner:'host',status:'active',participationCompleted:true,date:'2026-10-29',creationOrder:4};
assert.equal(tastingSection(ownCompleted,'host'),'active');
assert.equal(tastingSection(ownCompleted,'guest'),'ended');
assert.equal(tastingSection({...ownCompleted,participationCompleted:false},'guest'),'active');
assert.equal(tastingSection({...ownCompleted,status:'ended'},'host'),'ended');
assert.equal(tastingSection({...ownCompleted,status:'ended',historyHidden:true},'host'),null);
assert.equal(tastingSection({...ownCompleted,status:'draft'},'host'),'draft');
assert.equal(tastingSection({...ownCompleted,status:'draft'},'guest'),null);
const unsorted=[{...ownCompleted,id:'older',creationOrder:1},{...ownCompleted,id:'newer',creationOrder:9},{...ownCompleted,id:'tomorrow',date:'2026-10-30',creationOrder:2}];
assert.deepEqual(newestTastings(unsorted).map(e=>e.id),['tomorrow','newer','older']);assert.equal(unsorted[0].id,'older');
const serverEvents=(await api('a')).events;
assert(serverEvents.every(e=>typeof e.creationOrder==='number'));
assert.deepEqual(serverEvents.map(e=>e.id),newestTastings(serverEvents).map(e=>e.id));
console.log('PASS: completed host remains active, hidden history stays hidden, drafts are owner-only, newest-first sorting is deterministic.');

const {correctGuessSummary}=await import('../'+dir+'/lib.mjs');
const historyBlind={owner:'organizer',mode:'blind',status:'ended',revealed:true};
assert.deepEqual(correctGuessSummary(historyBlind,wine,review,'participant'),['Țara: România','Anul: 2022','Soiuri: Cabernet Sauvignon, Merlot']);
assert.deepEqual(correctGuessSummary(historyBlind,wine,{...review,country:'Franța',year:'2021',grapes:['Merlot','Syrah']},'participant'),['Soiuri: Merlot']);
assert.deepEqual(correctGuessSummary(historyBlind,wine,review,'organizer'),[]);
assert.deepEqual(correctGuessSummary({...historyBlind,status:'active',revealed:false},wine,review,'participant'),[]);
assert.deepEqual(correctGuessSummary({...historyBlind,status:'active',revealed:false,revealedWineIds:['w1']},wine,review,'participant'),['Țara: România','Anul: 2022','Soiuri: Cabernet Sauvignon, Merlot']);
console.log('PASS: compact history summaries include only correct answers, respect individual reveal and exclude the organizer.');

// Display names must remain compatible with previously stored blind answers.
for(const [id,name,alias] of [[100008,'Grenache','Garnacha Tinta'],[100017,'Malbec','Côt']]){
 assert.equal(db.prepare('SELECT name FROM grape_varieties WHERE id=?').get(id).name,name);
 assert.ok(activeGrapes.some(g=>g.id===id&&g.name===name&&g.aliases.includes(alias)));
 assert.equal(guessScore({...review,grapes:[name]},{...wine,grapes:[alias]}),3);
 assert.equal(guessScore({...review,grapes:[alias]},{...wine,grapes:[name]}),3);
}
console.log('PASS: Grenache and Malbec display names preserve legacy blind scoring.');
// Winery-only imports must survive identification, persistence and both destinations.
await api('wineryOnly','createProfile',{name:'Winery import',dob:'1990-01-01',gender:''});
await api('wineryOnly','activateHost',{username:'wineryonly',password:'test-secret-long'});
const unnamed=[{...wine,id:'unnamed1',name:'',winery:'Lagvinari',grapes:['Aladasturi'],year:2019},{...wine,id:'unnamed2',name:'',winery:'Lagvinari',grapes:['Otskhanuri Sapere'],year:2019}];
const identifiedUnnamed=await api('wineryOnly','identifyWines',{wines:unnamed});assert.ok(identifiedUnnamed.identifiedWines.every(w=>w.name===''));
const savedUnnamed=await api('wineryOnly','importCollection',{wines:identifiedUnnamed.identifiedWines});assert.equal(savedUnnamed.profile.catalog.length,2);assert.ok(savedUnnamed.profile.catalog.every(w=>w.name===''));
const unnamedEvent=await api('wineryOnly','saveEvent',{title:'Winery only',date:'2026-10-29',mode:'normal',wines:identifiedUnnamed.identifiedWines});
await api('wineryOnly','start',{id:unnamedEvent.eventId});
assert.ok((await api('wineryOnly')).events.find(e=>e.id===unnamedEvent.eventId).wines.every(w=>w.name===''));
await api('wineryOnly','importCollection',{wines:[{...wine,name:'',winery:''}]},400);
console.log('Winery-only API persistence OK for collection and started tasting.');

// Application profiles cannot access the separate administrator directory.
await api('a','adminUsers',{},403);
await api('b','adminUsers',{},403);

const tracked=await api('activity-test','createProfile',{name:'Activity test',dob:'1990-01-01',gender:''});
let timestamps=db.prepare('SELECT created_at,last_active_at FROM profiles WHERE id=?').get(tracked.profile.id);
assert.equal(timestamps.created_at,Date.now());assert.equal(timestamps.last_active_at,Date.now());
db.prepare('UPDATE profiles SET created_at=NULL,last_active_at=? WHERE id=?').run(Date.now()-31*86400000,tracked.profile.id);
await api('activity-test');
timestamps=db.prepare('SELECT created_at,last_active_at FROM profiles WHERE id=?').get(tracked.profile.id);
assert.equal(timestamps.created_at,null);assert.equal(timestamps.last_active_at,Date.now());
console.log('PASS: creation timestamps, activity refresh and unknown legacy creation date preserved.');

const blocked=await api('blocked-test','createProfile',{name:'Blocked',dob:'1990-01-01',gender:''});
await api('blocked-test','activateHost',{username:'blockedtest',password:'test-secret-long'});
db.prepare('UPDATE profiles SET blocked=1 WHERE id=?').run(blocked.profile.id);
assert.equal((await api('blocked-test',undefined,{},403)).blocked,true);
await api('blocked-test','createProfile',{name:'Bypass',dob:'1990-01-01'},403);
await api('blocked-test','saveEvent',{title:'Blocked mutation'},403);
await api('blocked-new','login',{username:'blockedtest',password:'test-secret-long'},403);
await api('blocked-new','recover',{code:blocked.recoveryCode},400);
assert.equal(db.prepare("SELECT COUNT(*) AS n FROM identities WHERE identity='blocked-new'").get().n,0);
await api('blocked-test','logout');
db.prepare('UPDATE profiles SET blocked=0 WHERE id=?').run(blocked.profile.id);
assert.equal((await api('blocked-new','login',{username:'blockedtest',password:'test-secret-long'})).profile.id,blocked.profile.id);
console.log('PASS: blocked existing sessions, mutations, login and recovery denied; logout and restored access after unblock.');
const separateLabels=await api('a','catalog',{wines:[{...wine,id:'shiraz-label',grapes:['Shiraz']},{...wine,id:'syrah-label',grapes:['Syrah']}]});
assert.deepEqual(separateLabels.profile.catalog.find(w=>w.id==='shiraz-label').grapes,['Shiraz']);
assert.deepEqual(separateLabels.profile.catalog.find(w=>w.id==='syrah-label').grapes,['Syrah']);
assert.ok(sameGrapes(['Shiraz'],['Syrah']));
console.log('PASS: Syrah and Shiraz labels survive save/reload separately while synonym scoring is preserved.');

assert.ok((await grapeSearch("q=tinta+roriz")).items.some(g=>g.name==="Tempranillo"));
assert.ok(sameGrapes(["Tinta Roriz"],["Tempranillo"]));

const {separateGrapeLabels,grapeChoices,displayGrape}=await import('../'+dir+'/grape-names.mjs');
assert.equal(grapeChoices.length,507);
assert.equal(new Set(grapeChoices.map(g=>g.id)).size,507);
for(const [primary,labels] of Object.entries(separateGrapeLabels)){
 for(const label of [primary,...labels]){
  assert.equal(grapeChoices.filter(g=>g.name===label).length,1);
  const id='regional-'+label;
  const result=await api('a','catalog',{wines:[{...wine,id,grapes:[label]}]});
  assert.deepEqual(result.profile.catalog.find(w=>w.id===id).grapes,[label]);
  assert.ok(sameGrapes([label],[primary]));
 }
}
assert.equal(displayGrape('Garnacha Tinta'),'Garnacha');
assert(!grapeChoices.some(g=>g.name==='Garnacha Tinta'));
for(const [oldName,newName] of [['Prosecco','Glera'],['Prosecco Lungo','Glera Lunga']]){
 assert.equal(grapeChoices.filter(g=>g.name===newName).length,1);
 assert(!grapeChoices.some(g=>g.name===oldName));
 assert.equal(displayGrape(oldName),newName);
 assert(sameGrapes([oldName],[newName]));
 const results=await grapeSearch('q='+encodeURIComponent(oldName));
 assert(results.items.some(g=>g.name===newName));
}
console.log('PASS: approved regional labels remain distinct after save, with cultivar-equivalent scoring.');

await api('emailHost','createProfile',{name:'Email host',dob:'1990-01-01'});
await api('emailHost','activateHost',{username:'emailhost',password:'password-long-enough'});
await api('emailHost','saveRecoveryEmail',{email:'emailhost@example.com'},403);
assert.equal((await api('emailHost')).profile.email,'emailhost@example.com');
await api('emailGuest','createProfile',{name:'Email guest',dob:'1990-01-01'});
await api('emailGuest','saveRecoveryEmail',{email:'guest@example.com'},403);
assert.equal((await api('emailGuest')).profile.recoveryEmail,undefined);
assert.equal((await api('emailGuest')).profile.password,undefined);
await api('emailHost','logout');
assert.equal((await api('emailHostAgain','login',{username:'emailhost',password:'password-long-enough'})).profile.email,'emailhost@example.com');
console.log('PASS: immutable primary email, removed alternate recovery email, persistence after login.');

compile('app/reset-email.ts','reset-email.mjs');
compileTree('app/email-language.ts',dir);
compile('app/api/password-reset/route.ts','password-reset.mjs',s=>s.replace("from '../../account-security'","from './account-security.mjs'").replace("from '../../security'","from './security.mjs'").replace("from '../../email-language'","from './email-language.mjs'").replace("from '../../reset-email'","from './reset-email.mjs'").replace("import {env} from 'cloudflare:workers';","const env=globalThis.testEnv;"));
const resetRoute=await import('../'+dir+'/password-reset.mjs');
async function resetCall(body,status=200,origin='https://test.local'){if(body.action==='request')body={...body,email:aliases.get(body.username)||body.username+'@example.com'};const r=await resetRoute.POST(new Request('https://test.local/api/password-reset',{method:'POST',headers:{origin,'content-type':'application/json','cf-connecting-ip':'reset-test'},body:JSON.stringify(body)}));const data=await r.json();assert.equal(r.status,status,JSON.stringify(data));return data}
delete globalThis.testEnv.CLOUDFLARE_EMAIL_API_TOKEN;await resetCall({action:'request',username:'emailhost'},503);
Object.assign(globalThis.testEnv,{CLOUDFLARE_EMAIL_API_TOKEN:'test',CLOUDFLARE_ACCOUNT_ID:'a'.repeat(32),MAWINE_EMAIL_FROM:'no-reply@mawine.app',MAWINE_PUBLIC_ORIGIN:'https://mawine.app'});
const originalFetch=globalThis.fetch;let sentMail;
globalThis.fetch=async(url,options)=>{assert.equal(url,'https://api.cloudflare.com/client/v4/accounts/'+ 'a'.repeat(32)+'/email/sending/send');assert.equal(options.headers.Authorization,'Bearer test');sentMail=JSON.parse(options.body);return Response.json({success:true,result:{queued:[sentMail.to]}})};
const requested=await resetCall({action:'request',username:'emailhost'});
assert.equal(sentMail.to,'emailhost@example.com');
assert.deepEqual(sentMail.from,{address:'no-reply@mawine.app',name:'Mawine'});
assert(sentMail.text.includes('https://mawine.app/#reset='));
const resetToken=sentMail.text.match(/#reset=([a-f0-9]{64})/)[1];
assert.deepEqual(await resetCall({action:'request',username:'missinghost'}),requested);
await resetCall({action:'validate',token:resetToken});
await resetCall({action:'reset',token:resetToken,password:'valid-new-password',confirm:'different'},400);
await resetCall({action:'reset',token:resetToken,password:'short',confirm:'short'},400);
await resetCall({action:'reset',token:resetToken,password:'valid-new-password',confirm:'valid-new-password'});
await resetCall({action:'validate',token:resetToken},400);
assert.equal((await api('emailHostAgain')).profile,null);
await api('resetLogin','login',{username:'emailhost',password:'password-long-enough'},400);
await api('resetLogin','login',{username:'emailhost',password:'valid-new-password'});
await resetCall({action:'request',username:'emailhost'});
const expiredToken=sentMail.text.match(/#reset=([a-f0-9]{64})/)[1];
db.prepare('UPDATE password_resets SET expires=?').run(Date.now());
await resetCall({action:'validate',token:expiredToken},400);
await resetCall({action:'request',username:'emailhost'},403,'https://evil.example');
for(const failure of [()=>Response.json({success:false}),()=>Response.json({success:true,result:{permanent_bounces:['emailhost@example.com']}}),()=>new Response('unavailable',{status:503}),()=>{throw new Error('network failure')}]){
 db.prepare('DELETE FROM password_reset_limits').run();
 const before=db.prepare('SELECT COUNT(*) AS n FROM password_resets WHERE expires>?').get(Date.now()).n;
 globalThis.fetch=async()=>failure();
 assert.deepEqual(await resetCall({action:'request',username:'emailhost'}),requested);
 assert.equal(db.prepare('SELECT COUNT(*) AS n FROM password_resets WHERE expires>?').get(Date.now()).n,before);
}
// Persist profile preference, including authentication/validation and legacy migration.
const emailProfile=(await api('resetLogin')).profile;
await api('resetLogin','saveLanguage',{language:'xx',profileId:emailProfile.id},400);
await api('resetLogin','saveLanguage',{language:'fr',profileId:'someone-else'},400);
await api('resetLogin','saveLanguage',{language:'fr',profileId:emailProfile.id});
assert.equal((await api('resetLogin')).profile.language,'fr');
await api('resetLogin','saveLanguage',{language:'ro',profileId:emailProfile.id,initializeOnly:true});
assert.equal((await api('resetLogin')).profile.language,'fr');
await api('languageOtherDevice','login',{username:'emailhost',password:'valid-new-password'});
assert.equal((await api('languageOtherDevice')).profile.language,'fr');
const newLanguageProfile=await api('languageNew','createProfile',{name:'Italian user',dob:'1990-01-01',language:'it'});
assert.equal(newLanguageProfile.profile.language,'it');
db.prepare('UPDATE profiles SET language=NULL WHERE id=?').run(newLanguageProfile.profile.id);
await api('languageNew','saveLanguage',{language:'en',profileId:newLanguageProfile.profile.id,initializeOnly:true});
assert.equal((await api('languageNew')).profile.language,'en');
const {translateForLanguage}=await import('../'+dir+'/i18n.mjs');
globalThis.fetch=async(_url,options)=>{sentMail=JSON.parse(options.body);return Response.json({success:true,result:{queued:[sentMail.to]}})};
for(const language of ['ro','en','it','fr']){
 await api('resetLogin','saveLanguage',{language,profileId:emailProfile.id});
 db.prepare('DELETE FROM password_reset_limits').run();
 await resetCall({action:'request',username:'emailhost',language:language==='fr'?'it':'fr'});
 assert.equal(sentMail.subject,translateForLanguage(language,'Mawine — Resetarea parolei'));
 assert(sentMail.text.startsWith(translateForLanguage(language,'Ai solicitat resetarea parolei. Deschide acest link pentru a alege o parolă nouă:')));
 assert(sentMail.text.endsWith(translateForLanguage(language,'Linkul este valabil o oră și poate fi folosit o singură dată. Dacă nu ai solicitat resetarea, ignoră acest mesaj.')));
}
for(const language of [null,'unsupported']){
 db.prepare('UPDATE profiles SET language=? WHERE id=?').run(language,emailProfile.id);
 db.prepare('DELETE FROM password_reset_limits').run();
 await resetCall({action:'request',username:'emailhost',language:'it'});
 assert.equal(sentMail.subject,'Mawine — Password reset');
}
console.log('PASS: stored language on new profiles, updates, cross-device login, legacy migration, ownership checks, all four email languages, caller-language ignored and English fallback.');
globalThis.fetch=originalFetch;
console.log('PASS: reset mail recipient, generic response, password confirmation, single use, one-hour expiry, session revocation and CSRF.');

// Upgrading and returning to participant keep the same identity and stored data.
const upgradeGuest=await api('upgradeGuest','createProfile',{name:'Upgrade guest',dob:'1990-01-01',gender:''});
await api('upgradeGuest','activateHost',{username:'upgradeguest',password:'upgrade-password-long',email:'invalid'},400);
assert.equal((await api('upgradeGuest')).profile.host,false);
const upgradeHost=await api('upgradeGuest','activateHost',{username:'upgradeguest',password:'upgrade-password-long',email:'recovery@example.com'});
assert.equal(upgradeHost.profile.id,upgradeGuest.profile.id);
assert.equal(upgradeHost.profile.recoveryCode,null);
assert.equal(upgradeHost.profile.email,'recovery@example.com');
await api('upgradeGuest','catalog',{wines:[wine]});
const beforeDowngrade=db.prepare('SELECT * FROM profiles WHERE id=?').get(upgradeGuest.profile.id);
const participantAgain=await api('upgradeGuest','deactivateHost');
assert.equal(participantAgain.profile.host,false);
const afterDowngrade=db.prepare('SELECT * FROM profiles WHERE id=?').get(upgradeGuest.profile.id);
for(const key of ['id','catalog','recovery_code','username','password','recovery_email'])assert.equal(afterDowngrade[key],beforeDowngrade[key]);
await api('upgradeLogin','login',{username:'upgradeguest',password:'upgrade-password-long'});
await api('upgradeGuest','catalog',{wines:[]},400);
const reactivated=await api('upgradeGuest','reactivateHost');
assert.equal(reactivated.profile.host,true);
assert.equal(reactivated.profile.catalog[0].id,wine.id);
assert.equal(reactivated.profile.email,'recovery@example.com');
await api('emailGuest','reactivateHost',{},400);

// Trial dates survive role changes and credential logins; legacy hosts share rollout day one.
const {trialStatus,trialStart,TRIAL_ROLLOUT_AT}=await import('../'+dir+'/subscription.mjs');
assert.equal(reactivated.profile.trialStartedAt,beforeDowngrade.trial_started_at);

assert.equal(trialStart({username:'legacy',trial_started_at:null}),TRIAL_ROLLOUT_AT);
assert.equal(trialStart({username:null,trial_started_at:null}),null);
assert.equal((await api('emailGuest')).profile.trialStartedAt,undefined);
const trialDay=86400000,start=Date.now();
assert.deepEqual([trialStatus(start,start).day,trialStatus(start,start).remainingDays],[1,30]);
assert.deepEqual([trialStatus(start,start+trialDay).day,trialStatus(start,start+trialDay).remainingDays],[2,29]);
assert.equal(trialStatus(start,start+30*trialDay-1).remainingDays,1);
assert.equal(trialStatus(start,start+30*trialDay).active,false);
assert.equal(trialStatus(start,start+31*trialDay).remainingDays,0);
assert.equal(trialStatus(start,start-trialDay).progress,0);
const legacy=await api('legacyTrial','createProfile',{name:'Legacy',dob:'1990-01-01',gender:''});
db.prepare("UPDATE profiles SET host=1,username='legacytrial',password='saved-hash' WHERE id=?").run(legacy.profile.id);
assert.equal((await api('legacyTrial')).profile.trialStartedAt,TRIAL_ROLLOUT_AT);
await api('legacyTrial','deactivateHost');
assert.equal((await api('legacyTrial','reactivateHost')).profile.trialStartedAt,TRIAL_ROLLOUT_AT);
console.log('PASS: new and existing host trials, expiry boundaries, participant restrictions and preserved trial on reactivation.');

// Audit regressions: credentials are exact strings; dates must exist in the calendar.
const auditFailures=[];
async function audit(name,run){try{await run();console.log('PASS: '+name)}catch(error){auditFailures.push(name+': '+error.message)}}
await audit('password with leading/trailing spaces survives host signup and login',async()=>{
 await api('spaceHost','createProfile',{name:'Spaced password',dob:'1990-01-01',gender:''});
 await api('spaceHost','activateHost',{username:'spacehost',password:'  valid password  '});
 await api('spaceLogin','login',{username:'spacehost',password:'  valid password  '});
 await api('spaceLogin','changePassword',{current:'  valid password  ',password:' new password value '});
 await api('spaceRelogin','login',{username:'spacehost',password:' new password value '});
});
await audit('impossible birth dates rejected on registration and edit',async()=>{
 await api('invalidBirth','createProfile',{name:'Bad date',dob:'1990-02-31',gender:''},400);
 await api('upgradeGuest','updateProfile',{name:'Test',dob:'2001-02-29',gender:''},400);
 await api('upgradeGuest','updateProfile',{name:'Test',dob:'2000-02-29',gender:''});
});
await audit('host signup rejects passwords longer than login supports',async()=>{
 await api('longPassword','createProfile',{name:'Long password',dob:'1990-01-01',gender:''});
 await api('longPassword','activateHost',{username:'longpassword',password:'a'.repeat(201)},400);
});
assert.deepEqual(auditFailures,[]);

// Hosting eligibility is enforced by the server, including reactivation.
const {isAdult}=await import('../'+dir+'/lib.mjs');
const ageNow=new Date('2026-10-29T12:00:00Z');
assert.equal(isAdult('2008-10-30',ageNow),false);
assert.equal(isAdult('2008-10-29',ageNow),true);
assert.equal(isAdult('2008-10-28',ageNow),true);
assert.equal(isAdult('2008-02-30',ageNow),false);
assert.equal(isAdult('2008-02-29',new Date('2026-02-28T12:00:00Z')),false);
assert.equal(isAdult('2008-02-29',new Date('2026-03-01T12:00:00Z')),true);
const denied=await api('minorHost','createProfile',{name:'Minor host',dob:'2008-10-30',gender:''},400);
assert.equal(denied.error,'Ne pare rău, nu ai încă 18 ani');
assert.equal((await api('minorHost')).profile,null);
await api('birthdayHost','createProfile',{name:'Birthday host',dob:'2008-10-29',gender:''});
await api('birthdayHost','activateHost',{username:'birthdayhost',password:'password123'});
await api('birthdayHost','updateProfile',{name:'Birthday host',dob:'2008-10-30'},400);
await api('birthdayHost','deactivateHost');
await api('birthdayHost','updateProfile',{name:'Birthday host',dob:'2008-10-30'},400);
assert.equal((await api('birthdayHost')).profile.dob,'2008-10-29');
await api('birthdayHost','updateProfile',{name:'Birthday host',dob:'2008-10-29'});
await api('birthdayHost','reactivateHost');
console.log('PASS: 18-year boundary, leap day, host activation/reactivation and host birth-date edits.');

for(const g of JSON.parse(fs.readFileSync('scripts/data/removed-table-grapes.json'))){assert.equal(db.prepare('SELECT id FROM grape_varieties WHERE id=?').get(g.id),undefined);assert(!(await grapeSearch('q='+encodeURIComponent(g.name))).items.some(x=>x.id===g.id));}

await api('largeImport','createProfile',{name:'Large import',dob:'1990-01-01',gender:''});
await api('largeImport','activateHost',{username:'largeimport',password:'long-import-password'});
const thousandWines=Array.from({length:1000},(_,i)=>({...wine,id:crypto.randomUUID(),name:'Import '+i,winery:'Test cellar'}));
const identifiedThousand=await api('largeImport','identifyWines',{wines:thousandWines});
assert.equal(identifiedThousand.identifiedWines.length,1000);
assert.equal((await api('largeImport','importCollection',{wines:thousandWines})).profile.catalog.length,1000);
assert.equal((await api('largeImport')).profile.catalog.length,1000);
assert.equal((await api('largeImport','catalog',{wines:thousandWines})).profile.catalog.length,1000);
const extraWine={...wine,id:crypto.randomUUID(),name:'Overflow wine'};
await api('largeImport','importCollection',{wines:[extraWine]},400);
await api('largeImport','catalog',{wines:[...thousandWines,extraWine]},400);
await api('largeImport','identifyWines',{wines:[...thousandWines,extraWine]},400);
assert.equal((await api('largeImport')).profile.catalog.length,1000);
console.log('PASS: 1,000 wines identify, import, save and reload; overflow is rejected without changing the collection.');

// Security regression suite: exercise the actual routes and persisted credentials.
const secured=await api('secured','createProfile',{name:'Security fixture',dob:'1990-01-01'});
await api('secured','activateHost',{username:'securityfixture',password:'original-secure-password'});
await api('secured2','login',{username:'securityfixture',password:'original-secure-password'});
await api('secured','saveRecoveryEmail',{email:'attacker@example.com',current:undefined},403);
await api('secured','deleteProfile',{current:undefined},400);
await api('secured','recovery',{current:undefined},400);
assert.equal(db.prepare('SELECT recovery_code FROM profiles WHERE id=?').get(secured.profile.id).recovery_code,null);
assert(!JSON.stringify(await api('secured')).includes(secured.recoveryCode));
await api('secured','changePassword',{current:'original-secure-password',password:'replacement-secure-password'});
assert.equal((await api('secured2')).profile,null);
await api('stolen-code','recover',{code:secured.recoveryCode},400);
assert.equal((await api('secured')).profile.id,secured.profile.id);
await api('secured','deactivateHost');
await api('secured','activateHost',{username:'hijacked',password:'attacker-password'},400);
await api('secured','reactivateHost');
// A fresh identity/cookie cannot reset the targeted account's attempt counter.
for(let i=0;i<8;i++)await api('brute-'+i,'login',{username:'securityfixture',password:'incorrect-password'},400);
await api('brute-new','login',{username:'securityfixture',password:'replacement-secure-password'},429);
const {rateLimit,readJson}=await import('../'+dir+'/security.mjs');
const concurrent=await Promise.allSettled(Array.from({length:20},()=>rateLimit(globalThis.testEnv.DB,'parallel-attempts',8)));
assert.equal(concurrent.filter(x=>x.status==='fulfilled').length,8);
// A cookie received before authentication stops working after successful login.
const beforeLogin=await GET(new Request('https://test.local/api/app',{headers:{'cf-connecting-ip':'rotation-fixture'}}));
const oldCookie=beforeLogin.headers.get('set-cookie').split(';')[0];
const logResponse=await POST(new Request('https://test.local/api/app',{method:'POST',headers:{origin:'https://test.local',cookie:oldCookie,'cf-connecting-ip':'rotation-fixture'},body:JSON.stringify({action:'login',email:'recovery@example.com',password:'upgrade-password-long'})}));
assert.equal(logResponse.status,200);
const newCookie=logResponse.headers.get('set-cookie').split(';')[0];assert.notEqual(oldCookie,newCookie);
assert.equal((await(await GET(new Request('https://test.local/api/app',{headers:{cookie:oldCookie}}))).json()).profile,null);
assert.equal((await(await GET(new Request('https://test.local/api/app',{headers:{cookie:newCookie}}))).json()).profile.id,upgradeGuest.profile.id);
// Limits apply to actual bytes, including chunked input without Content-Length.
await assert.rejects(()=>readJson(new Request('https://test.local',{method:'POST',body:'a'.repeat(4097)}),4096),e=>e.status===413);
for(const payload of ['null','[]','{invalid']){
 const response=await POST(new Request('https://test.local/api/app',{method:'POST',headers:{origin:'https://test.local','oai-authenticated-user-id':'malformed'},body:payload}));assert.equal(response.status,400);
}
const realPrepare=globalThis.testEnv.DB.prepare;
globalThis.testEnv.DB.prepare=()=>{throw Error('PRIVATE DATABASE DETAILS')};
const internalError=await POST(new Request('https://test.local/api/app',{method:'POST',headers:{origin:'https://test.local','oai-authenticated-user-id':'failure'},body:'{"action":"login"}'}));
assert.equal(internalError.status,500);assert(!(await internalError.text()).includes('PRIVATE DATABASE'));
globalThis.testEnv.DB.prepare=realPrepare;
console.log('PASS: password reauthentication, session revocation/rotation, recovery hash migration and revocation, role-change bypass blocked, account and atomic concurrent throttling, bounded bodies and safe errors.');

// Persistent login survives proxy identity appearing/disappearing and renews.
const durable=await api('durable','createProfile',{name:'Durable',dob:'1990-01-01',gender:''});
const durableCookie=browserCookies.get('durable');
const durableKey=(await cookieIdentity('durable')).slice(6);
db.prepare('UPDATE guest_sessions SET expires=? WHERE id=?').run(Date.now()+100000,durableKey);
const renewed=await GET(new Request('https://test.local/api/app',{headers:{cookie:durableCookie,'oai-authenticated-user-id':'different-proxy'}}));
assert.equal((await renewed.json()).profile.id,durable.profile.id);
assert.match(renewed.headers.get('set-cookie'),/Max-Age=31536000/);
assert.ok(db.prepare('SELECT expires FROM guest_sessions WHERE id=?').get(durableKey).expires>=Date.now()+31536000000);
const withoutProxy=await GET(new Request('https://test.local/api/app',{headers:{cookie:durableCookie}}));
assert.equal((await withoutProxy.json()).profile.id,durable.profile.id);
assert.equal(withoutProxy.headers.get('set-cookie'),null,'No cookie write on every poll');
// Legacy profile is transferred once; it cannot reappear after explicit logout.
db.prepare('UPDATE identities SET identity=? WHERE identity=?').run('legacy-proxy','guest:'+durableKey);
const spoofed=await GET(new Request('https://test.local/api/app',{headers:{cookie:durableCookie,'oai-authenticated-user-id':'legacy-proxy'}}));
assert.equal((await spoofed.json()).profile,null,'untrusted proxy identity must never authenticate');
globalThis.testEnv.MAWINE_TRUST_PROXY_IDENTITY='true';
const migrated=await GET(new Request('https://test.local/api/app',{headers:{cookie:durableCookie,'oai-authenticated-user-id':'legacy-proxy'}}));
assert.equal((await migrated.json()).profile.id,durable.profile.id);
assert.equal(db.prepare('SELECT * FROM identities WHERE identity=?').get('legacy-proxy'),undefined);
delete globalThis.testEnv.MAWINE_TRUST_PROXY_IDENTITY;
db.prepare('UPDATE guest_sessions SET expires=? WHERE id=?').run(Date.now()+100000,durableKey);
const loggedOut=await POST(new Request('https://test.local/api/app',{method:'POST',headers:{cookie:durableCookie,origin:'https://test.local'},body:JSON.stringify({action:'logout'})}));
assert.equal(loggedOut.status,200);assert.match(loggedOut.headers.get('set-cookie'),/Max-Age=0/);
const afterLogout=await GET(new Request('https://test.local/api/app',{headers:{cookie:durableCookie,'oai-authenticated-user-id':'legacy-proxy'}}));
assert.equal((await afterLogout.json()).profile,null);
assert.equal(db.prepare('SELECT * FROM guest_sessions WHERE id=?').get(durableKey),undefined);
console.log('PASS: persistent session priority, sliding expiry, legacy migration, explicit logout and revoked-cookie rejection.');

// Real authenticated reminder API: atomic daily claims, device identity and private-code preservation.
const reminderGuest=await api('reminderGuest','createProfile',{name:'Reminder guest',dob:'1990-01-01',gender:''});
const rid=reminderGuest.profile.id;
const beforeCode=db.prepare('SELECT recovery,recovery_code FROM profiles WHERE id=?').get(rid);
const claims=await Promise.all([api('reminderGuest','claimReminder',{profileId:rid}),api('reminderGuest','claimReminder',{profileId:rid})]);
assert.equal(claims.filter(x=>x.reminder?.kind==='recovery-code').length,1);
assert.deepEqual(db.prepare('SELECT recovery,recovery_code FROM profiles WHERE id=?').get(rid),beforeCode);
await api('reminderOtherDevice','recover',{code:reminderGuest.recoveryCode});
assert.equal((await api('reminderOtherDevice','claimReminder',{profileId:rid})).reminder,null);
await api('reminderGuest','claimReminder',{profileId:hostId},400);
const reminderStart=Date.now();
mock.timers.tick(86400000);
assert.equal((await api('reminderGuest','claimReminder',{profileId:rid})).reminder.kind,'recovery-code');
mock.timers.tick(86400000);
assert.equal((await api('reminderGuest','claimReminder',{profileId:rid})).reminder.kind,'recovery-code');
mock.timers.tick(86400000);
assert.equal((await api('reminderGuest','claimReminder',{profileId:rid})).reminder,null);
await api('reminderGuest','activateHost',{username:'reminderhost',password:'reminder-password-test'});
assert.equal((await api('reminderGuest','claimReminder',{profileId:rid})).reminder,null);
assert.equal((await api('reminderGuest','claimReminder',{profileId:rid})).reminder,null);
await api('reminderGuest','saveRecoveryEmail',{email:'recovery@example.com'},403);
mock.timers.tick(86400000);
assert.equal((await api('reminderGuest','claimReminder',{profileId:rid})).reminder,null);
mock.timers.tick(86400000);
db.prepare('UPDATE profiles SET trial_started_at=? WHERE id=?').run(Date.now()-27*86400000,rid);
for(const remaining of [3,2,1]){
 const result=await api('reminderGuest','claimReminder',{profileId:rid});
 assert.equal(result.reminder.remainingDays,remaining);
 assert.equal((await api('reminderGuest','claimReminder',{profileId:rid})).reminder,null);
 mock.timers.tick(86400000);
}
for(const graceDay of [1,2,3]){
 const result=await api('reminderGuest','claimReminder',{profileId:rid});assert.equal(result.reminder.kind,'payment-grace');assert.equal(result.reminder.graceDay,graceDay);
 assert.equal((await api('reminderGuest','claimReminder',{profileId:rid})).reminder,null);
 assert.equal((await api('reminderGuest')).profile.host,true);
 mock.timers.tick(86400000);
}
assert.equal((await api('reminderGuest','claimReminder',{profileId:rid})).reminder,null);
assert.equal((await api('reminderGuest')).profile.host,false);
console.log('PASS authenticated daily reminders across devices, no code rotation, removed email reminder and 3/2/1/expired trial.');
