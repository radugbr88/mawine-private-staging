import assert from 'node:assert/strict';
import fs from 'node:fs';
import ts from 'typescript';
const code=ts.transpileModule(fs.readFileSync('app/navigation-history.ts','utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
const exports={};new Function('exports',code)(exports);const {NavigationHistory}=exports;
const stack=[{}];let index=0;let controller;let restored;
const browser={get state(){return stack[index]},pushState(state,title,url){assert.equal(url,undefined);stack.splice(index+1);stack.push(state);index++},replaceState(state,title,url){assert.equal(url,undefined);stack[index]=state},back(){index--;controller.pop(stack[index])}};
controller=new NavigationHistory(browser,{page:'home'},entry=>restored=entry);
controller.scroll(215);assert(controller.update({page:'events',tab:'active'}));
controller.scroll(640);controller.update({page:'events',tab:'ended'});
controller.update({page:'results',event:'a',wine:2});
controller.back();assert.equal(restored.view.tab,'ended');
controller.back();assert.equal(restored.scroll,640);assert.equal(restored.view.page,'events');
index++;controller.pop(stack[index]);assert.equal(restored.view.tab,'ended');
controller.update({page:'wines'});assert.equal(stack.length,index+1);
assert.equal(controller.update({page:'wines'}),false);
controller.back();controller.back();controller.back();assert.equal(restored.view.page,'home');assert.equal(restored.scroll,215);
controller.back();assert.equal(restored.view.page,'home');assert.equal(index,1);
controller=new NavigationHistory(browser,{page:'welcome'},entry=>restored=entry);
controller.back();assert.equal(restored.view.page,'welcome');
console.log('PASS: submenu Back, Forward, scroll restoration, branching, duplicate suppression, same URL and account boundary.');
// Successful password reset removes the secret URL fragment without discarding navigation state.
const resetSource=fs.readFileSync('app/password-reset-form.tsx','utf8');
const resetCleanup=resetSource.match(/if\(token\)history\.replaceState\([^)]*\)/)[0];
let resetState;
new Function('token','history','location',resetCleanup)(true,{state:{mawineNavigation:{scope:'test',id:3}},replaceState:(state,title,url)=>{resetState=state;assert.equal(url,'/')}},{pathname:'/'});
assert.equal(resetState.mawineNavigation.id,3);
console.log('PASS: password-reset completion preserves Back navigation while removing the reset token from the URL.');

// Cancelled hardware Back restores the current history marker, so a second Back can retry.
let allowLeave=false;restored=null;
controller=new NavigationHistory(browser,{page:'home'},entry=>{if(!allowLeave)return false;restored=entry;});
controller.update({page:'hostSignup'});
const signupMarker=browser.state.mawineNavigation.id;
controller.back();assert.equal(restored,null);assert.equal(browser.state.mawineNavigation.id,signupMarker);
assert.equal(controller.update({page:'hostSignup'}),false);
allowLeave=true;controller.back();assert.equal(restored.view.page,'home');
console.log('PASS: cancelled signup Back preserves history position and accepted retry restores prior screen.');
