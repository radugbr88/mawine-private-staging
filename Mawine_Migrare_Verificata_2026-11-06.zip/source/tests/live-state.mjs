import assert from 'node:assert/strict';
import fs from 'node:fs';
import {compileTree} from './helpers/compile.mjs';
const {mergeLiveState}=await import(compileTree('app/live-state.ts','.sites-runtime/live-state-tests'));
const current={profile:{id:'host',catalog:[{id:'wine'}],name:'Edited name',billing:{subscription:null}},events:[],reviews:{local:{notes:'Unsaved note',favorite:true}}};
for(const subscription of [{paid:true,status:'active'},{paid:true,cancelAtPeriodEnd:true},{paid:false,status:'canceled'}]){
 const incoming={profile:{id:'host',name:'Old name',host:false,catalog:[],billing:{subscription}},events:[{id:'tasting'}],reviews:{}};
 const result=mergeLiveState(current,incoming);
 assert.equal(result.profile.host,false);assert.equal(result.profile.billing,incoming.profile.billing);assert.equal(result.profile.catalog,current.profile.catalog);assert.equal(result.reviews,current.reviews);assert.equal(result.profile.name,current.profile.name);assert.equal(result.events,incoming.events);
}
assert.equal(mergeLiveState(current,{profile:{id:'other'},events:[],reviews:{}}),current);
for(const lang of ['ro','en','it','fr'])for(const page of ['terms','privacy']){
 const file=`public/${page}-${lang}.html`;assert(fs.existsSync(file),file);
 const html=fs.readFileSync(file,'utf8');assert(html.includes('<html'));assert(!html.includes('mawine-private-tastings.bdnsrl.chatgpt.site'));
}
console.log('PASS: webhook billing refresh, cancellation, account isolation, local edits and all eight legal links');
