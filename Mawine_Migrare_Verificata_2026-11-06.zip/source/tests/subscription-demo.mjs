import assert from 'node:assert/strict';
import fs from 'node:fs';
import ts from 'typescript';
import React from 'react';
import * as jsx from 'react/jsx-runtime';
import {compileTree} from './helpers/compile.mjs';
const policy=await import(compileTree('app/subscription.ts','.sites-runtime/demo-policy'));
const source=fs.readFileSync('app/billing-demo/page.tsx','utf8');
assert(!/fetch\(|localStorage|stripeCheckout|stripePortal/.test(source));
const slots=[];let index=0;
const hooks={...React,useState:init=>{const i=index++;if(!(i in slots))slots[i]=init;return [slots[i],v=>{slots[i]=typeof v==='function'?v(slots[i]):v}]},useEffect(){},useSyncExternalStore:()=> 'ro'};
const panel=()=>null;const exports={};
const code=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,jsx:ts.JsxEmit.ReactJSX}}).outputText;
new Function('require','exports',code)(name=>name==='react'?hooks:name==='react/jsx-runtime'?jsx:name.includes('subscription-panel')?{SubscriptionPanel:panel}:name==='../subscription'?policy:{t:x=>x,locale:()=> 'ro-RO'},exports);
function render(){index=0;return exports.default()}
function walk(el,predicate){if(!el||typeof el!=='object')return null;if(predicate(el))return el;for(const child of React.Children.toArray(el.props?.children)){const found=walk(child,predicate);if(found)return found}return null}
function current(){return walk(render(),e=>e.type===panel).props}
function confirm(){const tree=render();const btn=walk(tree,e=>e.type==='button'&&e.props.children==='Confirmă');assert(btn);btn.props.onClick()}

function click(label){const button=walk(render(),e=>e.type==='button'&&e.props.children===label);assert(button,label);button.props.onClick()}
for(const plan of ['monthly','annual']){
 click('Reia simularea');current().onCheckout(plan);confirm();const end=current().billing.subscription.periodEnd;
 current().onManage('cancel');click('Renunță');assert(!current().billing.subscription.cancelAtPeriodEnd);
 current().onManage('cancel');confirm();assert(current().billing.hostAccess);assert.equal(current().billing.subscription.periodEnd,end);assert(current().billing.subscription.cancelAtPeriodEnd);
 click('Simulează expirarea');assert(current().billing.grace.inGrace);click('După cele 3 zile');assert(!walk(render(),e=>e.type===panel));
}
click('Reia simularea');click('Simulează expirarea');assert(current().billing.grace.inGrace);click('După cele 3 zile');assert(!walk(render(),e=>e.type===panel));
click('Reia simularea');current().onCheckout('annual');confirm();const end=current().billing.subscription.periodEnd;
current().onManage('change','monthly');confirm();assert.equal(current().billing.subscription.plan,'annual');assert.equal(current().billing.subscription.periodEnd,end);
const scheduledText=React.Children.toArray(render().props.children).filter(e=>e?.props?.role==='status'&&JSON.stringify(e.props.children).includes('Abonamentul lunar începe'));assert.equal(scheduledText.length,1);
click('Simulează expirarea');assert.equal(current().billing.subscription.plan,'monthly');assert.equal(current().billing.subscription.periodEnd,policy.nextBillingDate(end,'monthly'));assert(current().billing.subscription.paid);
console.log('PASS simulation: both cancellations preserve paid access until expiry, paid and trial grace, participant transition, scheduled annual-to-monthly billing');

click('Reia simularea');current().onCheckout('monthly');confirm();const monthEnd=current().billing.subscription.periodEnd;
const before=walk(render(),e=>e.type==='button'&&Array.isArray(e.props.children)&&e.props.children[0]===3);assert(before);before.props.onClick();
const changeAt=monthEnd-3*86400000;
current().onManage('change','annual');assert(JSON.stringify(render()).includes('timpul nefolosit'));click('Renunță');assert.equal(current().billing.subscription.plan,'monthly');
current().onManage('change','annual');confirm();assert.equal(current().billing.subscription.plan,'annual');assert.equal(current().billing.subscription.periodEnd,policy.nextBillingDate(changeAt,'annual'));assert(current().billing.subscription.paid);
assert(!JSON.stringify(render()).includes('Abonamentul lunar începe'));
console.log('PASS: monthly-to-annual confirmation explains unused-time adjustment, can be dismissed, starts annual period immediately');

for(const [plan,amount] of [['monthly','7,99'],['annual','79,20']]){
 click('Reia simularea');
 assert.equal(await current().onApplyCode('INVALID'),false);
 assert(JSON.stringify(render()).includes('Cod demonstrativ invalid'));
 assert.equal(await current().onApplyCode(' mawine20 '),true);
 const originalKey=walk(render(),e=>e.type===panel).key;
 current().onChoose();assert.equal(walk(render(),e=>e.type===panel).key,originalKey,'Choosing a plan retains the coupon component state');
 current().onCheckout(plan,'MAWINE20');
 assert(JSON.stringify(render()).includes(amount));
 assert(JSON.stringify(render()).includes('Reînnoirile sunt la prețul standard'));
 click('Renunță');assert.equal(current().billing.subscription,null);
 current().onCheckout(plan,'MAWINE20');confirm();assert(JSON.stringify(render()).includes('Codul MAWINE20 a fost aplicat'));
 click('Reia simularea');assert.notEqual(walk(render(),e=>e.type===panel).key,originalKey,'Reset clears the coupon state');
}
console.log('PASS: demo coupon validation, persistence between menus, both discounted totals, dismiss/confirm and reset');
