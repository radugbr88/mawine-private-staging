import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import ts from 'typescript';
const source=ts.transpile(fs.readFileSync('app/save-download.ts','utf8').replace('export ',''));
async function scenario(navigator){
 const events=[],link={click(){events.push('click')},remove(){events.push('remove')}};
 const context={navigator,File,DOMException,URL:{createObjectURL(){return 'blob:test'},revokeObjectURL(){events.push('revoke')}},document:{createElement(){return link},body:{appendChild(){events.push('append')}}},setTimeout(fn,delay){assert.equal(delay,60000);events.push('cleanup scheduled')}};
 vm.createContext(context);vm.runInContext(source,context);await context.saveDownload(new Blob(['test'],{type:'text/plain'}),'test.txt');return{events,link};
}
let shared;
assert.deepEqual((await scenario({canShare:()=>true,share:async data=>{shared=data.files[0]}})).events,[]);assert.equal(shared.name,'test.txt');
assert.deepEqual((await scenario({canShare:()=>true,share:async()=>{throw new DOMException('Cancelled','AbortError')}})).events,[]);
for(const nav of [{},{canShare:()=>false},{canShare:()=>true,share:async()=>{throw new DOMException('No activation','NotAllowedError')}}]){
 const {events,link}=await scenario(nav);assert.deepEqual(events,['append','click','remove','cleanup scheduled']);assert.equal(link.target,'_blank');assert.equal(link.rel,'noopener');assert.equal(link.download,'test.txt');
}
console.log('PASS: native file save, cancellation and unsupported/denied share fallback preserve the app browsing context.');
