import assert from 'node:assert/strict';
import fs from 'node:fs';
import React from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {compileTree} from './helpers/compile.mjs';
const dir='.sites-runtime/terms-tests';
const {SubscriptionPanel}=await import(compileTree('app/subscription-panel.tsx',dir));
const {TermsConsent}=await import(compileTree('app/terms-consent.tsx',dir));
const {setLanguage}=await import(compileTree('app/i18n.ts',dir));
const props={choosing:true,startedAt:Date.now(),onChoose(){},onUnavailable(){},onDowngrade(){},busy:false};
for(const language of ['ro','en','it','fr']){
 setLanguage(language);
 const consent=renderToStaticMarkup(React.createElement(TermsConsent));
 assert(consent.includes('/terms-'+language+'.html'));assert(consent.includes('required=""'));assert(!consent.includes('checked=""'));
 const doc=JSON.parse(fs.readFileSync('app/terms-'+language+'.json'));assert.equal(doc.length,28);
 const html=fs.readFileSync('public/terms-'+language+'.html','utf8');assert(html.includes(doc[0]));assert.equal((html.match(/<h2>/g)||[]).length,10);
 const markup=renderToStaticMarkup(React.createElement(SubscriptionPanel,props));
 assert(markup.includes('$99 USD'));assert(/\$9[,.]99 USD/.test(markup));
}
setLanguage('ro');
const billing={enabled:true,mode:'live',hasCustomer:true,subscription:{paid:true,status:'active',plan:'annual',cancelAtPeriodEnd:false}};
let html=renderToStaticMarkup(React.createElement(SubscriptionPanel,{...props,billing}));assert(html.includes('Anulare abonament'));
html=renderToStaticMarkup(React.createElement(SubscriptionPanel,{...props,billing,choosing:false}));assert(html.includes('Gestionează abonamentul'));assert(!html.includes('Schimbă perioada de abonare'));
billing.subscription.cancelAtPeriodEnd=true;html=renderToStaticMarkup(React.createElement(SubscriptionPanel,{...props,billing}));assert(html.includes('Reînnoire anulată'));
console.log('PASS: four-language terms, unchecked required consent, USD prefixes and paid/cancelled subscription labels');
