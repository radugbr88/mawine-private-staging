import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import ts from 'typescript';
import React from 'react';
import {jsx,jsxs} from 'react/jsx-runtime';
import {renderToStaticMarkup} from 'react-dom/server';
import * as icons from 'lucide-react';
import {compileTree} from './helpers/compile.mjs';
compileTree('app/language-settings.tsx','.sites-runtime/entry-language');
const i=await import('../.sites-runtime/entry-language/i18n.mjs');
const {LanguageSettings}=await import('../.sites-runtime/entry-language/language-settings.mjs');
const storage=new Map();globalThis.localStorage={getItem:key=>storage.get(key)||null,setItem:(key,value)=>storage.set(key,value)};
storage.set('mawine.language','fr');assert.equal(i.getEntryLanguage(),'en');
const source=fs.readFileSync('app/page.tsx','utf8');
const ast=ts.createSourceFile('page.tsx',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);
let welcome,selector;
function walk(node){if(ts.isBinaryExpression(node)&&node.operatorToken.kind===ts.SyntaxKind.AmpersandAmpersandToken){if(node.left.getText(ast)==="page==='welcome'")welcome=node.right.getText(ast);if(node.left.getText(ast)==="page==='entryLanguage'")selector=node.right.getText(ast);}ts.forEachChild(node,walk)}walk(ast);assert(welcome&&selector);
function evaluate(expression,context){const code=ts.transpileModule('result=('+expression+');',{compilerOptions:{jsx:ts.JsxEmit.React,module:ts.ModuleKind.CommonJS}}).outputText;const ctx=vm.createContext({React,...icons,...context});vm.runInContext(code,ctx);return ctx.result;}
const words={en:['Join a tasting','Change language'],ro:['Vreau să particip','Schimbă limba'],it:['Voglio partecipare','Cambia lingua'],fr:['Participer','Changer de langue']};
for(const lang of ['en','ro','it','fr']){
 let destination;const element=evaluate(selector,{LanguageSettings,language:i.getLanguage(),setEntryLanguage:i.setEntryLanguage,go:value=>destination=value});element.props.onChange(lang);assert.equal(destination,'welcome');assert.equal(i.getLanguage(),lang);assert.equal(i.getEntryLanguage(),lang);
 for(const pendingCode of ['', 'INVITATION']){
  const html=renderToStaticMarkup(evaluate(welcome,{translate:i.t,pendingCode,p:null,state:{},chooseRole(){},go(){}}));
  for(const word of words[lang])assert(html.includes(word),lang+': '+word);
  if(lang!=='ro')assert(!html.includes('Vreau să particip'));
 }
 // Authenticated profile changes do not overwrite the chosen entry language.
 i.setLanguage(lang==='fr'?'it':'fr');assert.equal(i.getEntryLanguage(),lang);i.setLanguage(i.getEntryLanguage());assert.equal(i.getLanguage(),lang);
}
const css=fs.readFileSync('app/globals.css','utf8');const rule=css.match(/\.welcomeForm \.entryLanguageButton\{([^}]+)\}/)[1];assert(rule.includes('text-decoration:none'));assert(rule.includes('font-size:12px'));assert(rule.includes('color:#97909b'));
console.log('PASS: actual welcome JSX translated in all 4 languages, invitation/non-invitation entry, selector auto-return, separate persisted entry choice and neutral button styling.');
