import fs from 'node:fs';
import path from 'node:path';
import ts from 'typescript';
// Compile real application dependencies, including translations, without a browser or production database.
export function compileTree(entry,dir){
 const root=path.resolve('app'),seen=new Set();
 function compile(file){
  file=path.resolve(file);const rel=path.relative(root,file),out=path.resolve(dir,rel.replace(/\.(tsx?|json)$/ ,'.mjs'));
  if(seen.has(file))return out;seen.add(file);fs.mkdirSync(path.dirname(out),{recursive:true});
  if(file.endsWith('.json')){fs.writeFileSync(out,'export default '+fs.readFileSync(file,'utf8')+';');return out}
  const source=fs.readFileSync(file,'utf8').replace(/from (['"])(\.[^'"]+)\1/g,(_,quote,name)=>{
   const base=path.resolve(path.dirname(file),name),target=[base,base+'.ts',base+'.tsx'].find(f=>fs.existsSync(f)&&fs.statSync(f).isFile());
   if(!target)throw Error('Missing test dependency: '+base);
   const result=compile(target);let relative=path.relative(path.dirname(out),result);if(!relative.startsWith('.'))relative='./'+relative;
   return 'from '+quote+relative+quote;
  });
  fs.writeFileSync(out,ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.ES2022,target:ts.ScriptTarget.ES2022,jsx:ts.JsxEmit.ReactJSX,esModuleInterop:true}}).outputText);return out;
 }
 return compile(entry);
}
