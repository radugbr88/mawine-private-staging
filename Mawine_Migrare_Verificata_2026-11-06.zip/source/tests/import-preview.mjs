import assert from 'node:assert/strict';
import React from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {compileTree} from './helpers/compile.mjs';
const dir='.sites-runtime/import-preview-tests';
const {countryCode}=await import(compileTree('app/country-code.ts',dir));
const {ImportWineRow}=await import(compileTree('app/import-wine-row.tsx',dir));
const {setLanguage}=await import(compileTree('app/i18n.ts',dir));
for(const [name,code] of Object.entries({'România':'RO','Romania':'RO','Roumanie':'RO','España':'ES','Spain':'ES','Spagna':'ES','Spania':'ES','Slovenia':'SLO','SLO':'SLO','SI':'SLO','Georgia':'GE','Afrique du Sud':'ZA','SUA':'US','unknown':'','':''}))assert.equal(countryCode(name),code,name);
for(const lang of ['ro','en','it','fr']){
 setLanguage(lang);let edited=0,removed=0;
 const element=ImportWineRow({wine:{id:'1',name:'Wine',winery:'Winery',year:2024,grapes:[],type:'',country:'România',price:'20 EUR'},onEdit(){edited++},onRemove(){removed++}});
 const html=renderToStaticMarkup(element);assert(html.includes('importWineCountry'));assert(html.includes('>RO</small>'));assert(html.includes('lucide-x'));
 const actions=element.props.children.find(c=>c?.props?.className==='importWineActions');
 actions.props.children[0].props.onClick();actions.props.children[1].props.onClick();assert.equal(edited,1);assert.equal(removed,1);
}
console.log('PASS country names/codes, shared import preview, edit/remove callbacks in four languages');
