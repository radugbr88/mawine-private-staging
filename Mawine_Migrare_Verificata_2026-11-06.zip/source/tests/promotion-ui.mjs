import assert from 'node:assert/strict';
import React from 'react';
import {renderToStaticMarkup as render} from 'react-dom/server';
import {compileTree} from './helpers/compile.mjs';
const dir='.sites-runtime/promotion-ui';
const {PromotionField}=await import(compileTree('app/promotion-field.tsx',dir));
const {SubscriptionPanel}=await import(compileTree('app/subscription-panel.tsx',dir));
const {setLanguage,t}=await import(compileTree('app/i18n.ts',dir));
for(const lang of ['ro','en','it','fr']){
 setLanguage(lang);
 for(const applied of [true,false]){
  const html=render(React.createElement(PromotionField,{code:applied?'MAWINE20':'',applied,busy:false,onChange(){},onApply(){}}));
  assert(html.includes(t('Cod de reducere')));assert(html.includes(t(applied?'Aplicat':'Aplică')));assert(html.includes('disabled=""'));assert(!html.includes('lucide-check'));
 }
 for(const choosing of [false,true]){
  const view=render(React.createElement(SubscriptionPanel,{choosing,startedAt:Date.now(),busy:false,onChoose(){},onUnavailable(){},onDowngrade(){},onApplyCode:async()=>true}));
  assert.equal(view.includes('promotionField'),choosing,'coupon belongs only on period selection');
 }
 const html=render(React.createElement(SubscriptionPanel,{choosing:false,startedAt:Date.now(),billing:{enabled:false,hasCustomer:false,mode:'off',hostAccess:true,complimentaryUntil:Date.now()+86400000,subscription:null},busy:false,onChoose(){},onUnavailable(){},onDowngrade(){}}));
 assert(html.includes(t('Abonament gratuit')));assert(!html.includes('promotionField'));assert(!html.includes('subscriptionAfter'));assert.equal((html.match(/class="trialCard"/g)||[]).length,1);
}
console.log('PASS: coupon idle/applied/no-checkmark states, complimentary card in all four locales');
