import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import ts from 'typescript';
const source=fs.readFileSync('app/page.tsx','utf8');
const fn=source.split('\n').find(line=>line.includes('async function createProfile('));
for(const intent of ['host','participant'])for(const pendingCode of ['', 'INVITE']){
 const calls=[];
 const context={setSuppressRecovery(){},isAdult:()=>true,getLanguage:()=> 'en',document:{activeElement:{blur(){}}},setShowRecoveryPrompt:value=>calls.push('recovery:'+value),intent,pendingCode,FormData:class{*[Symbol.iterator](){yield ['name','Test']}},fetch:async()=>({ok:true,json:async()=>({profile:{id:'test'},recoveryCode:'test-code'})}),stateRef:{current:{}},setBusy:()=>{},setState:()=>{},setRecoveryCode:()=>{},setNotice:()=>{},setError:message=>{throw Error(message)},go:page=>calls.push(page),enterInvitation:async code=>calls.push('join:'+code)};
 vm.createContext(context);vm.runInContext(ts.transpileModule(fn,{compilerOptions:{target:ts.ScriptTarget.ES2022}}).outputText,context);
 await context.createProfile({preventDefault(){},currentTarget:{}});
 assert.deepEqual(calls,[intent==='host'?'hostSignup':'recovery:true']);
}
console.log('PASS: participant and host registration, including preserved invitation and required credential step.');

// Leaving signup only prompts if fields were edited, and suppresses guest reminders after abandonment.
const leave=source.split(' function leaveSignup(){')[1].split('\n')[0];
for(const dirty of [false,true])for(const accepted of [false,true]){
 const calls=[];const context={page:'hostSignup',signupDirty:{current:dirty},window:{confirm:()=>{calls.push('confirm');return accepted}},translate:s=>s,setSuppressRecovery:v=>calls.push('suppress:'+v),setShowRecoveryPrompt:v=>calls.push('prompt:'+v)};
 vm.createContext(context);vm.runInContext('function leaveSignup(){'+leave,context);
 assert.equal(context.leaveSignup(),!dirty||accepted);
 if(dirty&&!accepted){assert.deepEqual(calls,['confirm']);assert.equal(context.signupDirty.current,true)}
 else{assert.equal(context.signupDirty.current,false);assert(calls.includes('suppress:true'));assert(calls.includes('prompt:false'))}
}
console.log('PASS: signup cancellation stays on form; confirmed abandonment suppresses guest popup without creating credentials.');

// Existing legacy account names remain usable at login; new registrations must use an email.
assert(source.includes('<input type="text" inputMode="email" required name="email" maxLength={254} autoComplete="username"/>'));
assert(source.includes('<input type="email" name="email" required maxLength={254} autoComplete="email"'));
console.log('PASS: login allows legacy identifiers while new registration requires email.');
