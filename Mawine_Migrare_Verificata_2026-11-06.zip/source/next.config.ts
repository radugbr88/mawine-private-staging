import type { NextConfig } from 'next';
const nextConfig:NextConfig={
 async headers(){return[{source:'/:path*',headers:[
  {key:'Content-Security-Policy',value:"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: blob: https:; media-src 'self' blob:; connect-src 'self' https://*.stripe.com; frame-src https://*.stripe.com; object-src 'none'; base-uri 'self'; form-action 'self' https://*.stripe.com"},
  {key:'Referrer-Policy',value:'strict-origin-when-cross-origin'},
  {key:'X-Content-Type-Options',value:'nosniff'}
 ]}]}
};
export default nextConfig;
