/* Push only: deliberately no fetch interception or offline cache of account data. */
self.addEventListener('install',event=>event.waitUntil(self.skipWaiting()));
self.addEventListener('activate',event=>event.waitUntil(self.clients.claim()));
self.addEventListener('push',event=>{
 let message={};try{message=event.data?.json()||{}}catch{}
 const target=new URL(message.url||'/',self.location.origin);
 event.waitUntil(self.registration.showNotification('Mawine',{body:typeof message.body==='string'?message.body:'Mawine',icon:'/icons/mawine-192.png',tag:message.tag||'mawine',data:{url:target.origin===self.location.origin?target.href:self.location.origin}}));
});
self.addEventListener('notificationclick',event=>{
 event.notification.close();const target=new URL(event.notification.data?.url||'/',self.location.origin);if(target.origin!==self.location.origin)return;
 event.waitUntil((async()=>{const windows=await self.clients.matchAll({type:'window',includeUncontrolled:true});const existing=windows.find(w=>new URL(w.url).origin===target.origin);if(existing){await existing.navigate(target.href);await existing.focus()}else await self.clients.openWindow(target.href)})());
});
