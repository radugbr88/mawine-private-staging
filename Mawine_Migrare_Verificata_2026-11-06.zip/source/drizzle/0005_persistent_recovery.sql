ALTER TABLE profiles ADD COLUMN recovery_code text;
