ALTER TABLE profiles ADD COLUMN trial_started_at integer;
