CREATE TABLE `billing_checkouts` (
	`profile_id` text NOT NULL,
	`environment` text NOT NULL,
	`provider_account_id` text NOT NULL,
	`id` text NOT NULL,
	`plan` text NOT NULL,
	`params` text NOT NULL,
	`created_at` integer NOT NULL,
	`session_id` text,
	PRIMARY KEY(`profile_id`, `environment`, `provider_account_id`),
	FOREIGN KEY (`profile_id`) REFERENCES `profiles`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `billing_checkouts_id_unique` ON `billing_checkouts` (`id`);--> statement-breakpoint
CREATE TABLE `billing_locks` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`expires_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `billing_operations` (
	`id` text PRIMARY KEY NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
ALTER TABLE `billing_subscriptions` ADD `risk_blocked` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `billing_subscriptions` ADD `risk_reason` text;