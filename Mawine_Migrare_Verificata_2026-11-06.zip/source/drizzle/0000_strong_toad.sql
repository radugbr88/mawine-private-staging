CREATE TABLE `attempts` (
	`id` text PRIMARY KEY NOT NULL,
	`count` integer NOT NULL,
	`since` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `events` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`title` text NOT NULL,
	`date` text NOT NULL,
	`mode` text NOT NULL,
	`status` text NOT NULL,
	`code` text NOT NULL,
	`wines` text NOT NULL,
	`revealed` integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `events_code_unique` ON `events` (`code`);--> statement-breakpoint
CREATE TABLE `identities` (
	`identity` text PRIMARY KEY NOT NULL,
	`profile_id` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `members` (
	`event_id` text NOT NULL,
	`profile_id` text NOT NULL,
	PRIMARY KEY(`event_id`, `profile_id`)
);
--> statement-breakpoint
CREATE TABLE `profiles` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`dob` text NOT NULL,
	`gender` text NOT NULL,
	`host` integer DEFAULT 0 NOT NULL,
	`username` text,
	`password` text,
	`recovery` text NOT NULL,
	`catalog` text DEFAULT '[]' NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `profiles_username_unique` ON `profiles` (`username`);--> statement-breakpoint
CREATE TABLE `reviews` (
	`event_id` text NOT NULL,
	`profile_id` text NOT NULL,
	`wine_id` text NOT NULL,
	`data` text NOT NULL,
	PRIMARY KEY(`event_id`, `profile_id`, `wine_id`)
);
