ALTER TABLE events ADD COLUMN revealed_wine_ids TEXT NOT NULL DEFAULT '[]';
