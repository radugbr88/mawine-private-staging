CREATE TABLE `wine_catalog` (
	`id` text PRIMARY KEY NOT NULL,
	`data` text NOT NULL,
	`source_url` text NOT NULL,
	`checked_at` text NOT NULL
);
