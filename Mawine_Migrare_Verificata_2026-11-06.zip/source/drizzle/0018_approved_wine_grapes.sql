INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100424,'Shesh i Zi','NOIR','sheshizi') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100425,'Serina e Zezë','NOIR','serinaezeze') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100426,'Vlosh','NOIR','vlosh') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100427,'Haghtanak','NOIR','haghtanak akhtanak') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100428,'Karmrahyut','NOIR','karmrahyut') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100429,'Khndoghni','NOIR','khndoghni khindogni sireni') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100430,'Kakhet','NOIR','kakhet milagh') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100431,'Rösler','NOIR','rosler') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100432,'Cabernet Cortis','NOIR','cabernetcortis') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100433,'Cabernet Dorsa','NOIR','cabernetdorsa') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100434,'Cabaret Noir','NOIR','cabaretnoir') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100435,'Pinotin','NOIR','pinotin') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100436,'Bordô','NOIR','bordo ives ivesseedling') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100437,'Babić','NOIR','babic') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100438,'Maratheftiko','NOIR','maratheftiko') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100439,'Lefkada','NOIR','lefkada') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100440,'Ofthalmo','NOIR','ofthalmo') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100441,'Cabernet Moravia','NOIR','cabernetmoravia') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100442,'Rondo','NOIR','rondo') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100443,'Léon Millot','NOIR','leonmillot') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100444,'Pinot Noir Précoce','NOIR','pinotnoirprecoce fruhburgunder') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100445,'Argaman','NOIR','argaman') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100446,'Muscat Bailey A','NOIR','muscatbaileya') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100447,'Campbell Early','NOIR','campbellearly') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100448,'Yama Sauvignon','NOIR','yamasauvignon') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100449,'Marquette','NOIR','marquette') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100450,'Maréchal Foch','NOIR','marechalfoch') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100451,'Cabernet Cantor','NOIR','cabernetcantor') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100452,'Zilga','NOIR','zilga') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100453,'Saint Croix','NOIR','saintcroix stcroix') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100454,'Garanoir','NOIR','garanoir') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100455,'Diolinoir','NOIR','diolinoir') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100456,'Cornalin du Valais','NOIR','cornalinduvalais rougedupays landroter') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100457,'Humagne Rouge','NOIR','humagnerouge cornalindaoste') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100458,'Blatina','NOIR','blatina') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100459,'Trnjak','NOIR','trnjak') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100460,'Ġellewża','NOIR','gellewza') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100461,'Madrasa','NOIR','madrasa matrasa') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100462,'Vischoqueña','NOIR','vischoquena') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100463,'Limnio','NOIR','limnio') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100464,'Mavrodaphne','NOIR','mavrodaphne') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100465,'Mavrotragano','NOIR','mavrotragano') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100466,'Shesh i Bardhë','BLANC','sheshibardhe') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100467,'Pulës','BLANC','pules') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100468,'Debinë e Bardhë','BLANC','debineebardhe') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100469,'Kangun','BLANC','kangun') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100470,'Voskehat','BLANC','voskehat voskeat') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100471,'Lalvari','BLANC','lalvari') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100472,'Chilar','BLANC','chilar') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100473,'Garan Dmak','BLANC','garandmak garandmak') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100474,'Johanniter','BLANC','johanniter') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100475,'Solaris','BLANC','solaris') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100476,'Muscaris','BLANC','muscaris') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100477,'Sauvignac','BLANC','sauvignac') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100478,'Bronner','BLANC','bronner') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100479,'Pošip','BLANC','posip posipbijeli') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100480,'Debit','BLANC','debit') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100481,'Kujundžuša','BLANC','kujundzusa') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100482,'Promara','BLANC','promara') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100483,'Morokanela','BLANC','morokanela') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100484,'Pálava','ROSE','palava') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100485,'Muškát moravský','BLANC','muskatmoravsky muskatmoravsky') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100486,'Orion','BLANC','orion') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100487,'Phoenix','BLANC','phoenix') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100488,'Malagousia','BLANC','malagousia') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100489,'Emerald Riesling','BLANC','emeraldriesling') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100490,'Frontenac Blanc','BLANC','frontenacblanc') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100491,'Saint Pepin','BLANC','saintpepin stpepin') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100492,'La Crescent','BLANC','lacrescent') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100493,'Villaris','BLANC','villaris') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100494,'Hibernal','BLANC','hibernal') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100495,'Petite Arvine','BLANC','petitearvine arvine') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100496,'Emir','BLANC','emir') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100497,'Vasilaki','BLANC','vasilaki') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100498,'Reichensteiner','BLANC','reichensteiner') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100499,'Șarba','BLANC','sarba') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100500,'Plăvaie','BLANC','plavaie') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100501,'Mustoasă de Măderat','BLANC','mustoasademaderat') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100502,'Băbească Gri','GRIS','babeascagri') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100503,'Žilavka','BLANC','zilavka') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100504,'Krstač','BLANC','krstac') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100505,'Žižak','BLANC','zizak') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100506,'Girgentina','BLANC','girgentina ghirgentina') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100507,'Robola','BLANC','robola') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100508,'Vidiano','BLANC','vidiano') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100003,'Tempranillo','NOIR','tempranillo tintaroriz aragonez aragones') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
