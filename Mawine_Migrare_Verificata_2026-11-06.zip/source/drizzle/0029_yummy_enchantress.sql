CREATE TABLE `admin_access_audit` (
	`id` text PRIMARY KEY NOT NULL,
	`profile_id` text NOT NULL,
	`admin` text NOT NULL,
	`expires_at` integer NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `complimentary_access` (
	`profile_id` text PRIMARY KEY NOT NULL,
	`expires_at` integer NOT NULL,
	`granted_by` text NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`profile_id`) REFERENCES `profiles`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE TABLE `event_entry` (
	`id` integer PRIMARY KEY NOT NULL,
	`enabled` integer DEFAULT 0 NOT NULL,
	`title` text NOT NULL,
	`event_id` text NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `event_guests` (
	`number` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`profile_id` text NOT NULL,
	`event_id` text NOT NULL,
	`age_confirmed_at` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `event_guests_profile_id_unique` ON `event_guests` (`profile_id`);