UPDATE grape_varieties SET name = 'Glera', search_key = search_key || ' glera prosecco' WHERE name = 'Prosecco';
--> statement-breakpoint
UPDATE grape_varieties SET name = 'Glera Lunga', search_key = search_key || ' gleralunga proseccolungo' WHERE name = 'Prosecco Lungo';
