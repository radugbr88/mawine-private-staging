CREATE TABLE `admin_challenges` (
	`device_hash` text PRIMARY KEY NOT NULL,
	`username` text NOT NULL,
	`token_hash` text NOT NULL,
	`expires` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `admin_challenges_token_hash_unique` ON `admin_challenges` (`token_hash`);--> statement-breakpoint
CREATE TABLE `managed_prices` (
	`id` text PRIMARY KEY NOT NULL,
	`environment` text NOT NULL,
	`account` text NOT NULL,
	`plan` text NOT NULL,
	`amount` integer NOT NULL,
	`active` integer NOT NULL,
	`created_at` integer NOT NULL
);

--> statement-breakpoint
DELETE FROM admin_sessions;
--> statement-breakpoint
UPDATE admin_accounts SET username='radugbr88@gmail.com' WHERE username='radugbr88';
