UPDATE grape_varieties SET search_key=search_key || ' garnacha' WHERE name='Grenache';
