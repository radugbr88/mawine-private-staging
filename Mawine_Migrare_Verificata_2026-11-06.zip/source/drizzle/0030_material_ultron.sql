DROP TABLE `event_entry`;--> statement-breakpoint
DROP TABLE `event_guests`;