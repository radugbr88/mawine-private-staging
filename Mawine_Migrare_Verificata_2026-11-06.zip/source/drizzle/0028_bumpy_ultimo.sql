CREATE TABLE `profile_reminders` (
	`profile_id` text NOT NULL,
	`kind` text NOT NULL,
	`shown_day` text NOT NULL,
	`shown_at` integer NOT NULL,
	PRIMARY KEY(`profile_id`, `kind`),
	FOREIGN KEY (`profile_id`) REFERENCES `profiles`(`id`) ON UPDATE no action ON DELETE cascade
);
