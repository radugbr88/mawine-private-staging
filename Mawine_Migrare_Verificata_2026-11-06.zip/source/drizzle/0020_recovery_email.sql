ALTER TABLE profiles ADD COLUMN recovery_email text;
