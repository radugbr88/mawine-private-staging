INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100001,'Cabernet Sauvignon','NOIR','cabernetsauvignon') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100002,'Merlot','NOIR','merlot') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100003,'Tempranillo','NOIR','tempranillo') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100004,'Airén','BLANC','airen') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100005,'Chardonnay','BLANC','chardonnay') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100007,'Syrah','NOIR','syrah shiraz') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100008,'Grenache','NOIR','grenache garnachatinta grenachenoir') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100010,'Sauvignon Blanc','BLANC','sauvignonblanc') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100011,'Trebbiano Toscano','BLANC','trebbianotoscano ugniblanc trebbiano') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100012,'Pinot Noir','NOIR','pinotnoir') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100013,'Sangiovese','NOIR','sangiovese') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100014,'Riesling','BLANC','riesling') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100015,'Bobal','NOIR','bobal') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100016,'Cabernet Franc','NOIR','cabernetfranc') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100017,'Malbec','NOIR','malbec cot') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100018,'Monastrell','NOIR','monastrell mourvedre monastrellmourvedre') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100019,'Rkatsiteli','BLANC','rkatsiteli') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100020,'Pinot Gris','GRIS','pinotgris pinotgrigio') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100021,'Mazuelo','NOIR','mazuelo carignan') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100022,'Macabeo','BLANC','macabeo viura') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100023,'Cayetana Blanca','BLANC','cayetanablanca') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100024,'Alicante Henri Bouschet','NOIR','alicantehenribouschet alicantebouschet') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100025,'Muscat of Alexandria','BLANC','muscatofalexandria') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100026,'Muscat Blanc à Petits Grains','BLANC','muscatblancapetitsgrains muscatblanc') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100027,'Tribidrag','NOIR','tribidrag zinfandel primitivo zinfandelprimitivo') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100028,'Montepulciano','NOIR','montepulciano') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100029,'Chenin Blanc','BLANC','cheninblanc') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100030,'Colombard','BLANC','colombard') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100031,'Cereza','GRIS','cereza') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100032,'Catarratto Bianco','BLANC','catarrattobianco catarratto') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100033,'Aligoté','BLANC','aligote') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100034,'Gamay Noir','NOIR','gamaynoir gamay') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100035,'Graševina','BLANC','grasevina welschriesling') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100036,'Palomino Fino','BLANC','palominofino') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100037,'Cinsaut','NOIR','cinsaut cinsault') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100038,'Carmenère','NOIR','carmenere') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100039,'Prosecco','BLANC','prosecco glera') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100040,'Douce Noire','NOIR','doucenoire bonarda charbono') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100041,'Müller-Thurgau','BLANC','mullerthurgau') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100042,'Grüner Veltliner','BLANC','grunerveltliner') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100043,'Trebbiano Romagnolo','BLANC','trebbianoromagnolo') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100044,'Sémillon','BLANC','semillon') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100045,'Verdejo','BLANC','verdejo') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100046,'Barbera','NOIR','barbera') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100047,'Isabella','NOIR','isabella') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100048,'Blaufränkisch','NOIR','blaufrankisch') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100049,'Viognier','BLANC','viognier') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100050,'Criolla Grande','NOIR','criollagrande') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100051,'Pedro Giménez','BLANC','pedrogimenez') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100052,'Pinot Meunier','NOIR','pinotmeunier') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100053,'Nero d''Avola','NOIR','nerodavola') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100054,'Touriga Franca','NOIR','tourigafranca') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100055,'Pinot Blanc','BLANC','pinotblanc') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100056,'Fetească Albă','BLANC','feteascaalba') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100057,'Fetească Regală','BLANC','feteascaregala') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100058,'Gewürztraminer','BLANC','gewurztraminer') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100059,'Castelão','NOIR','castelao') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100060,'Muscat Ottonel','BLANC','muscatottonel') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100061,'Moldova','NOIR','moldova') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100062,'Fernão Pires','BLANC','fernaopires') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100063,'Touriga Nacional','NOIR','touriganacional') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100064,'Vermentino','BLANC','vermentino') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100065,'Negroamaro','NOIR','negroamaro') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100066,'Mencía','NOIR','mencia') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100067,'Concord','NOIR','concord') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100068,'Trincadeira','NOIR','trincadeira') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100069,'Savatiano','BLANC','savatiano') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100070,'Listán Prieto','NOIR','listanprieto pais') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100071,'Pamid','NOIR','pamid') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100072,'Bianca','BLANC','bianca') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100073,'Aglianico','NOIR','aglianico') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100074,'Dimyat','BLANC','dimyat') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100075,'Malvasia Bianca di Candia','BLANC','malvasiabiancadicandia') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100076,'Melon','BLANC','melon melondebourgogne') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100077,'Vranac','NOIR','vranac') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100078,'Zweigelt','NOIR','zweigelt') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100079,'Torrontés Riojano','BLANC','torrontesriojano torrontes') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100080,'Pedro Ximénez','BLANC','pedroximenez') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100082,'Garganega','BLANC','garganega') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100083,'Xarello','BLANC','xarello') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100084,'Roditis','GRIS','roditis') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100086,'Petit Verdot','NOIR','petitverdot') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100087,'Nebbiolo','NOIR','nebbiolo') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100088,'Tsolikouri','BLANC','tsolikouri') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100089,'Dornfelder','NOIR','dornfelder') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100090,'Muscat of Hamburg','NOIR','muscatofhamburg') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100091,'Garnacha Blanca','BLANC','garnachablanca grenacheblanc') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100092,'Grillo','BLANC','grillo') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100093,'Chasselas','BLANC','chasselas') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100094,'Parellada','BLANC','parellada') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100095,'Pinotage','NOIR','pinotage') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100096,'Síria','BLANC','siria') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100097,'Baga','NOIR','baga') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100098,'Blauer Portugieser','NOIR','blauerportugieser portugieser') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100099,'Saperavi','NOIR','saperavi') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100100,'Corvina Veronese','NOIR','corvinaveronese corvina') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100101,'Lambrusco Salamino','NOIR','lambruscosalamino') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100102,'Silvaner','BLANC','silvaner silvanersylvaner sylvaner') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100103,'Bonarda Piemontese','NOIR','bonardapiemontese') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100104,'Lambrusco Maestri','NOIR','lambruscomaestri') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100105,'Tannat','NOIR','tannat') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100106,'Alvarinho','BLANC','alvarinho albarino albarinoalvarinho') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100107,'Arinto de Bucelas','BLANC','arintodebucelas arinto') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100108,'Tinto Velasco','NOIR','tintovelasco') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100109,'Sultaniye','BLANC','sultaniye') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100110,'Ruby Cabernet','NOIR','rubycabernet') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100111,'Caladoc','NOIR','caladoc') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100112,'Italia','BLANC','italia') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100113,'Chelva','BLANC','chelva') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100114,'Tinta Barroca','NOIR','tintabarroca') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100115,'Rubired','NOIR','rubired') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100116,'Durif','NOIR','durif petitesirah') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100117,'Yan 73','NOIR','yan73') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100118,'Inzolia','BLANC','inzolia') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100119,'Loureiro','BLANC','loureiro') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100120,'Marufo','NOIR','marufo') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100121,'Verdicchio Bianco','BLANC','verdicchiobianco verdicchio') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100122,'Gaglioppo','NOIR','gaglioppo') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100123,'Dolcetto','NOIR','dolcetto') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100124,'Vinhao','NOIR','vinhao') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100125,'Furmint','BLANC','furmint') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100126,'Alarije','BLANC','alarije') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100127,'Misket Cherven','GRIS','misketcherven') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100128,'Cserszegi Fűszeres','GRIS','cserszegifuszeres') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100129,'Prieto Picudo','NOIR','prietopicudo') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100130,'Aspiran Bouschet','NOIR','aspiranbouschet') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100131,'Zalema','BLANC','zalema') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100132,'Marselan','NOIR','marselan') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100133,'Sauvignonasse','BLANC','sauvignonasse friulano fruilano') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100134,'Torrontés Sanjuanino','BLANC','torrontessanjuanino') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100135,'Tsitska','BLANC','tsitska') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100136,'Falanghina Flegrea','BLANC','falanghinaflegrea falanghina') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100137,'Pardillo','BLANC','pardillo') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100138,'Malvasia Fina','BLANC','malvasiafina') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100139,'Agiorgitiko','NOIR','agiorgitiko') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100140,'Sankt Laurent','NOIR','sanktlaurent stlaurent') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100141,'Niagara','BLANC','niagara') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100142,'Fetească Neagră','NOIR','feteascaneagra') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100143,'Mavro','NOIR','mavro') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100144,'Gros Manseng','BLANC','grosmanseng') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100145,'Negramoll','NOIR','negramoll') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100146,'Graciano','NOIR','graciano') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100147,'Alvarelhão','NOIR','alvarelhao') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100148,'Kerner','BLANC','kerner') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100149,'Auxerrois','BLANC','auxerrois') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100150,'Listan Negro','NOIR','listannegro') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100151,'Malvazija Istarska','BLANC','malvazijaistarska') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100152,'Kyoho (4N)','NOIR','kyoho4n') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100153,'Pervenets Magaracha','BLANC','pervenetsmagaracha') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100154,'Ancellotta','NOIR','ancellotta') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100155,'Seyval Blanc','BLANC','seyvalblanc') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100156,'Băbească Neagră','NOIR','babeascaneagra') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100157,'Croatina','NOIR','croatina') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100158,'Rondinella','NOIR','rondinella') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100159,'Liatiko','NOIR','liatiko') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100160,'Trebbiano d''Abruzzo','BLANC','trebbianodabruzzo') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100161,'Beba','BLANC','beba') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100162,'Nero di Troia','NOIR','neroditroia') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100163,'Odessky Cherny','NOIR','odesskycherny') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100164,'Trajadura','BLANC','trajadura') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100165,'Clairette','BLANC','clairette') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100166,'Cortese','BLANC','cortese') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100167,'Merseguera','BLANC','merseguera') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100168,'Trebbiano Giallo','BLANC','trebbianogiallo') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100169,'Savagnin Blanc','BLANC','savagninblanc') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100170,'Schiava Grossa','NOIR','schiavagrossa schiava') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100171,'Fiano','BLANC','fiano') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100172,'Malvasia','BLANC','malvasia') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100173,'Roussanne','BLANC','roussanne') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100174,'Couderc Noir','NOIR','coudercnoir') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100175,'Xinomavro','NOIR','xinomavro') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100176,'Greco Bianco','BLANC','grecobianco') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100177,'Regent','NOIR','regent') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100178,'Rabigato','BLANC','rabigato') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100179,'Grolleau Noir','NOIR','grolleaunoir') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100180,'Xynisteri','BLANC','xynisteri') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100181,'Vidal','BLANC','vidal') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100182,'Malvasia Preta','NOIR','malvasiapreta') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100183,'Rufete','NOIR','rufete') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100184,'Marsanne','BLANC','marsanne') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100185,'Grechetto di Orvieto','BLANC','grechettodiorvieto grechetto') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100187,'Nerello Mascalese','NOIR','nerellomascalese') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100188,'Irsai Olivér','BLANC','irsaioliver') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100189,'Assyrtiko','BLANC','assyrtiko') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100190,'Antao Vaz','BLANC','antaovaz') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100191,'Bacchus','BLANC','bacchus') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100192,'Pecorino','BLANC','pecorino') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100193,'Plavac Mali','NOIR','plavacmali') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100194,'Brachetto del Piemonte','NOIR','brachettodelpiemonte brachetto') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100195,'Fer','NOIR','fer') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100196,'Aletta','BLANC','aletta') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100197,'Cococciola','BLANC','cococciola') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100198,'Cardinal','NOIR','cardinal') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100199,'Mavrouda','NOIR','mavrouda') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100200,'Moscato Giallo','BLANC','moscatogiallo') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100201,'Scheurebe','BLANC','scheurebe') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100202,'Kadarka','NOIR','kadarka') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100203,'Damaschino','BLANC','damaschino') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100204,'Hárslevelű','BLANC','harslevelu') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100205,'Öküzgözü','NOIR','okuzgozu') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100206,'Beibinghong','NOIR','beibinghong') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100207,'Folle Blanche','BLANC','folleblanche') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100208,'Piquepoul Blanc','BLANC','piquepoulblanc picpoul picpoulblanc') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100209,'Juan García','NOIR','juangarcia') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100210,'Mauzac Blanc','BLANC','mauzacblanc') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100211,'Verdelho','BLANC','verdelho') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100212,'Muscadelle','BLANC','muscadelle') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100213,'Garnacha Roja (Gris)','GRIS','garnacharojagris') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100214,'Prosecco Lungo','BLANC','proseccolungo') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100215,'Azal','BLANC','azal') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100216,'Jacquez','NOIR','jacquez') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100218,'Boğazkere','NOIR','bogazkere') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100219,'Godello','BLANC','godello') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100220,'Prokupac','NOIR','prokupac') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100221,'Refosco','NOIR','refosco') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100222,'Kotsifali','NOIR','kotsifali') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100223,'Biancame','BLANC','biancame') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100224,'Petit Manseng','BLANC','petitmanseng') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100225,'Refosco dal Peduncolo Rosso','NOIR','refoscodalpeduncolorosso') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100226,'Malvasia Nera di Brindisi','NOIR','malvasianeradibrindisi') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100227,'Trousseau','NOIR','trousseau') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100228,'Zalagyöngye','BLANC','zalagyongye') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100229,'Malvasia Bianca Lunga','BLANC','malvasiabiancalunga') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100230,'Chinuri','BLANC','chinuri') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100231,'Blauburger','NOIR','blauburger') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100232,'Alfrocheiro','NOIR','alfrocheiro') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100233,'Malvasia di Candia Aromatica','BLANC','malvasiadicandiaaromatica') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100234,'Shiroka Melnishka','NOIR','shirokamelnishka') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100235,'Monica Nera','NOIR','monicanera') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100236,'Trepat','NOIR','trepat') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100237,'Mavrud','NOIR','mavrud') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100238,'Aramon Noir','NOIR','aramonnoir') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100239,'Arneis','BLANC','arneis') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100240,'Pignoletto','BLANC','pignoletto') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100241,'Albillo Mayor','BLANC','albillomayor') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100242,'Bombino Bianco','BLANC','bombinobianco') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100243,'Kodryanka','NOIR','kodryanka') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100244,'Corvinone','NOIR','corvinone') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100245,'Romeiko','NOIR','romeiko') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100246,'Tinta Carvalha','NOIR','tintacarvalha') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100247,'Négrette','NOIR','negrette') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100248,'Diagalves','BLANC','diagalves') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100249,'Moschofilero','GRIS','moschofilero') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100251,'Bical','BLANC','bical') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100252,'Lambrusco Marani','NOIR','lambruscomarani') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100253,'Canaiolo Nero','NOIR','canaiolonero') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100254,'Sagrantino','NOIR','sagrantino') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100255,'Nuragus','BLANC','nuragus') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100256,'Longyan','NOIR','longyan') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100257,'Kunleány','BLANC','kunleany') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100258,'Elbling','BLANC','elbling') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100259,'Chambourcin','NOIR','chambourcin') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100260,'Ribolla Gialla','BLANC','ribollagialla') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100261,'Lambrusco Grasparossa','NOIR','lambruscograsparossa') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100262,'Passerina','BLANC','passerina') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100263,'Mandilaria','NOIR','mandilaria') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100264,'Viosinho','BLANC','viosinho') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100265,'Verdeca','BLANC','verdeca') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100266,'Mammolo','NOIR','mammolo') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100267,'Grignolino','NOIR','grignolino') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100268,'Garnacha Peluda','NOIR','garnachapeluda') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100269,'Ciliegiolo','NOIR','ciliegiolo') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100270,'Levokumskij','NOIR','levokumskij') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100271,'Planta Nova','BLANC','plantanova') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100272,'Magaracha Rannii','NOIR','magaracharannii') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100273,'Vernaccia di San Gimignano','BLANC','vernacciadisangimignano') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100274,'Terret','BLANC','terret') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100275,'Bombino Nero','NOIR','bombinonero') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100276,'Lambrusco di Sorbara','NOIR','lambruscodisorbara') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100278,'Žametovka','NOIR','zametovka') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100279,'Çalkarası','NOIR','calkaras') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100280,'Narince','BLANC','narince') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100281,'Marzemino','NOIR','marzemino') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100282,'Duras','NOIR','duras') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100283,'Gibi','BLANC','gibi') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100284,'Királyleányka','BLANC','kiralyleanyka') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100285,'Albana','BLANC','albana') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100286,'Alb de Suruceni','BLANC','albdesuruceni') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100287,'Villard Noir','NOIR','villardnoir') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100288,'Teroldego','NOIR','teroldego') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100289,'Perruno','BLANC','perruno') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100290,'Muscat','BLANC','muscat') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100291,'Villard Blanc','BLANC','villardblanc') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100292,'Rojal Tinta','NOIR','rojaltinta') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100293,'Baco Noir','NOIR','baconoir') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100294,'Santarena','NOIR','santarena') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100295,'Leányka','BLANC','leanyka') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100296,'Ortrugo','BLANC','ortrugo') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100297,'Grand Noir','NOIR','grandnoir') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100298,'Kalecik Karası','NOIR','kalecikkaras') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100299,'Dimrit','NOIR','dimrit') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100300,'Schiava Lombarda','NOIR','schiavalombarda') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100301,'Avesso','BLANC','avesso') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100302,'Koshu','GRIS','koshu') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100303,'Verduzzo Friulano','BLANC','verduzzofriulano') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100304,'Muscat Yantarnyi','BLANC','muscatyantarnyi') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100305,'Plavina','NOIR','plavina') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100306,'Moscato Embrapa','BLANC','moscatoembrapa') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100307,'Malvasia del Lazio','BLANC','malvasiadellazio') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100308,'Magliocco Canino','NOIR','maglioccocanino') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100309,'Raboso Piave','NOIR','rabosopiave') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100310,'Zenit','BLANC','zenit') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100311,'Vital','BLANC','vital') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100312,'Kövidinka','GRIS','kovidinka') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100313,'Torrontes Mendocino','BLANC','torrontesmendocino') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100314,'Vilana','BLANC','vilana') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100315,'Symphony','BLANC','symphony') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100316,'Bayanshira','BLANC','bayanshira') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100317,'Violeta','NOIR','violeta') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100318,'Ezerjó','BLANC','ezerjo') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100319,'Alphonse Lavallée','NOIR','alphonselavallee') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100320,'Grasă de Cotnari','BLANC','grasadecotnari') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100321,'Catawba','NOIR','catawba') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100322,'Hondarribi Zuri','BLANC','hondarribizuri') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100323,'Jacquere','BLANC','jacquere') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100324,'Victoria','BLANC','victoria') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100325,'Béquignol Noir','NOIR','bequignolnoir') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100326,'Molinara','NOIR','molinara') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100327,'Jurançon Noir','NOIR','juranconnoir') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100328,'Len de l''El','BLANC','lendelel') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100329,'Albillo Real','BLANC','albilloreal') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100330,'Piedirosso','NOIR','piedirosso') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100331,'Arany Sárfehér','BLANC','aranysarfeher') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100332,'Gouveio Real','BLANC','gouveioreal') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100333,'Frappato','NOIR','frappato') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100334,'Neuburger','BLANC','neuburger') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100335,'Athiri','BLANC','athiri') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100336,'Cora','NOIR','cora') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100337,'Riton','BLANC','riton') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100338,'Montonico Bianco','BLANC','montonicobianco') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100339,'Rabo de Ovelha','BLANC','rabodeovelha') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100340,'Krasnostop Zolotovsky','NOIR','krasnostopzolotovsky') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100341,'Viorika','BLANC','viorika') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100342,'Chasan','BLANC','chasan') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100343,'Uva Longanesi','NOIR','uvalonganesi') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100344,'Aubun','NOIR','aubun') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100345,'Forcallat Tinta','NOIR','forcallattinta') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100346,'Ortega','BLANC','ortega') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100347,'Verduzzo Trevigiano','BLANC','verduzzotrevigiano') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100348,'Baco Blanc','BLANC','bacoblanc') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100349,'Freisa','NOIR','freisa') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100350,'Borraçal','NOIR','borracal') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100351,'Carrega Branco','BLANC','carregabranco') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100352,'Cornifesto','NOIR','cornifesto') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100353,'Župljanka','BLANC','zupljanka') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100354,'Bourboulenc','BLANC','bourboulenc') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100355,'Sheridan','NOIR','sheridan') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100356,'Lorena','BLANC','lorena') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100357,'Onitskanskii Belyi','BLANC','onitskanskiibelyi') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100358,'Arinarnoa','NOIR','arinarnoa') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100359,'Dunavski Lazur','BLANC','dunavskilazur') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100360,'Seibel','NOIR','seibel') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100361,'Durella','BLANC','durella') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100362,'Acolon','NOIR','acolon') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100363,'Couderc 13','BLANC','couderc13') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100364,'Seara Nova','BLANC','searanova') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100365,'Fortana','NOIR','fortana') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100366,'Niagara Red','NOIR','niagarared') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100367,'Listain de Huelva','BLANC','listaindehuelva') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100368,'Huxelrebe','BLANC','huxelrebe') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100369,'Codega de Larinho','BLANC','codegadelarinho') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100370,'Chenanson','NOIR','chenanson') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100371,'Tsimlyansky Cherny','NOIR','tsimlyanskycherny') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100372,'Crimposie','BLANC','crimposie') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100373,'Cesanese','NOIR','cesanese') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100374,'Gamaret','NOIR','gamaret') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100375,'Morio-Muskat','BLANC','moriomuskat') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100376,'Greco Nero','NOIR','greconero') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100377,'Blauer Wildbacher','NOIR','blauerwildbacher') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100378,'Tibouren','NOIR','tibouren') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100379,'Nouvelle','BLANC','nouvelle') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100380,'Delaware','GRIS','delaware') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100381,'Plantet','NOIR','plantet') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100382,'Counoise','NOIR','counoise') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100383,'Galbenă de Odobești','BLANC','galbenadeodobesti') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100384,'Pineau d''Aunis','NOIR','pineaudaunis') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100385,'Triplett Blanc','BLANC','triplettblanc') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100386,'Sukholimansky Bely','BLANC','sukholimanskybely') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100387,'Stanušina Crna','NOIR','stanusinacrna') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100388,'Frühroter Veltliner','NOIR','fruhroterveltliner') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100389,'Kuldzhinskii','GRIS','kuldzhinskii') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100390,'Domina','NOIR','domina') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100391,'Tinto Cão','NOIR','tintocao') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100392,'Vijariego','BLANC','vijariego') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100393,'Frâncușă','BLANC','francusa') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100394,'Espadeiro','NOIR','espadeiro') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100395,'Cabinda','NOIR','cabinda') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100397,'Tinta da Barca','NOIR','tintadabarca') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100398,'Lairen','BLANC','lairen') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100399,'Salvador','NOIR','salvador') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100400,'Busuioacă de Bohotin','GRIS','busuioacadebohotin') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100401,'Manzoni Bianco','BLANC','manzonibianco') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100402,'Faberrebe','BLANC','faberrebe') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100403,'Quebranta','NOIR','quebranta') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100404,'Traminer','BLANC','traminer') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100405,'Areni noir','NOIR','areninoir') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100406,'Encruzado','BLANC','encruzado') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100407,'Erbaluce','BLANC','erbaluce') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100408,'Norton','NOIR','norton') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100409,'Picolit','BLANC','picolit') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100410,'Picapoll Blanc','BLANC','picapollblanc picapoll') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100411,'Goruli Mtsvane','BLANC','gorulimtsvane') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100412,'Mtsvane Kakhuri','BLANC','mtsvanekakhuri kakhurimtsvane') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100413,'Khikhvi','BLANC','khikhvi') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100414,'Kisi','BLANC','kisi') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100415,'Krakhuna','BLANC','krakhuna') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100416,'Rachuli Tetra','BLANC','rachulitetra rachulitsulukidzistetra tsulukidzistetra') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100417,'Sakmiela','BLANC','sakmiela') ON CONFLICT(id) DO UPDATE SET name=excluded.name,color=excluded.color,search_key=excluded.search_key;
--> statement-breakpoint
DELETE FROM grape_varieties WHERE id NOT IN (100001,100002,100003,100004,100005,100007,100008,100010,100011,100012,100013,100014,100015,100016,100017,100018,100019,100020,100021,100022,100023,100024,100025,100026,100027,100028,100029,100030,100031,100032,100033,100034,100035,100036,100037,100038,100039,100040,100041,100042,100043,100044,100045,100046,100047,100048,100049,100050,100051,100052,100053,100054,100055,100056,100057,100058,100059,100060,100061,100062,100063,100064,100065,100066,100067,100068,100069,100070,100071,100072,100073,100074,100075,100076,100077,100078,100079,100080,100082,100083,100084,100086,100087,100088,100089,100090,100091,100092,100093,100094,100095,100096,100097,100098,100099,100100,100101,100102,100103,100104,100105,100106,100107,100108,100109,100110,100111,100112,100113,100114,100115,100116,100117,100118,100119,100120,100121,100122,100123,100124,100125,100126,100127,100128,100129,100130,100131,100132,100133,100134,100135,100136,100137,100138,100139,100140,100141,100142,100143,100144,100145,100146,100147,100148,100149,100150,100151,100152,100153,100154,100155,100156,100157,100158,100159,100160,100161,100162,100163,100164,100165,100166,100167,100168,100169,100170,100171,100172,100173,100174,100175,100176,100177,100178,100179,100180,100181,100182,100183,100184,100185,100187,100188,100189,100190,100191,100192,100193,100194,100195,100196,100197,100198,100199,100200,100201,100202,100203,100204,100205,100206,100207,100208,100209,100210,100211,100212,100213,100214,100215,100216,100218,100219,100220,100221,100222,100223,100224,100225,100226,100227,100228,100229,100230,100231,100232,100233,100234,100235,100236,100237,100238,100239,100240,100241,100242,100243,100244,100245,100246,100247,100248,100249,100251,100252,100253,100254,100255,100256,100257,100258,100259,100260,100261,100262,100263,100264,100265,100266,100267,100268,100269,100270,100271,100272,100273,100274,100275,100276,100278,100279,100280,100281,100282,100283,100284,100285,100286,100287,100288,100289,100290,100291,100292,100293,100294,100295,100296,100297,100298,100299,100300,100301,100302,100303,100304,100305,100306,100307,100308,100309,100310,100311,100312,100313,100314,100315,100316,100317,100318,100319,100320,100321,100322,100323,100324,100325,100326,100327,100328,100329,100330,100331,100332,100333,100334,100335,100336,100337,100338,100339,100340,100341,100342,100343,100344,100345,100346,100347,100348,100349,100350,100351,100352,100353,100354,100355,100356,100357,100358,100359,100360,100361,100362,100363,100364,100365,100366,100367,100368,100369,100370,100371,100372,100373,100374,100375,100376,100377,100378,100379,100380,100381,100382,100383,100384,100385,100386,100387,100388,100389,100390,100391,100392,100393,100394,100395,100397,100398,100399,100400,100401,100402,100403,100404,100405,100406,100407,100408,100409,100410,100411,100412,100413,100414,100415,100416,100417);
