CREATE TABLE password_resets(token_hash text PRIMARY KEY NOT NULL,profile_id text NOT NULL,password_snapshot text NOT NULL,email_snapshot text NOT NULL,expires integer NOT NULL);
CREATE INDEX password_resets_profile ON password_resets(profile_id);
CREATE TABLE password_reset_limits(id text PRIMARY KEY NOT NULL,count integer NOT NULL,since integer NOT NULL);
