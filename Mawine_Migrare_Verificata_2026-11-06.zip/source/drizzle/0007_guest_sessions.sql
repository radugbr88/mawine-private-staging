CREATE TABLE guest_sessions (id text PRIMARY KEY NOT NULL, expires integer NOT NULL);
