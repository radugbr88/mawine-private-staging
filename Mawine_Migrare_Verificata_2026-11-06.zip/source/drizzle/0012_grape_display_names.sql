UPDATE grape_varieties SET name='Grenache', search_key='grenache grenachenoir garnachatinta' WHERE id=100008;
--> statement-breakpoint
UPDATE grape_varieties SET name='Malbec', search_key='malbec cot' WHERE id=100017;
