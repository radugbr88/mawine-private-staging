-- Billing foundation only. Earlier manual migrations 0003–0024 already provide the other schema objects.
CREATE TABLE `billing_customers` (
	`id` text PRIMARY KEY NOT NULL,
	`profile_id` text,
	`provider` text NOT NULL,
	`environment` text NOT NULL,
	`provider_account_id` text NOT NULL,
	`provider_customer_id` text NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`profile_id`) REFERENCES `profiles`(`id`) ON UPDATE no action ON DELETE set null,
	CONSTRAINT "billing_customer_provider" CHECK("billing_customers"."provider" IN ('stripe','apple','google')),
	CONSTRAINT "billing_customer_environment" CHECK("billing_customers"."environment" IN ('test','live'))
);
--> statement-breakpoint
CREATE UNIQUE INDEX `billing_customer_remote_unique` ON `billing_customers` (`provider`,`environment`,`provider_account_id`,`provider_customer_id`);
--> statement-breakpoint
CREATE UNIQUE INDEX `billing_customer_profile_unique` ON `billing_customers` (`profile_id`,`provider`,`environment`,`provider_account_id`);
--> statement-breakpoint
CREATE TABLE `billing_events` (
	`provider` text NOT NULL,
	`environment` text NOT NULL,
	`provider_account_id` text NOT NULL,
	`provider_event_id` text NOT NULL,
	`event_type` text NOT NULL,
	`provider_object_id` text,
	`provider_created_at` integer NOT NULL,
	`received_at` integer NOT NULL,
	`processed_at` integer,
	`processing_status` text DEFAULT 'pending' NOT NULL,
	`attempts` integer DEFAULT 0 NOT NULL,
	`last_error_code` text,
	PRIMARY KEY(`provider`, `environment`, `provider_account_id`, `provider_event_id`),
	CONSTRAINT "billing_event_provider" CHECK("billing_events"."provider" IN ('stripe','apple','google')),
	CONSTRAINT "billing_event_environment" CHECK("billing_events"."environment" IN ('test','live')),
	CONSTRAINT "billing_event_status" CHECK("billing_events"."processing_status" IN ('pending','processed','failed','ignored')),
	CONSTRAINT "billing_event_attempts" CHECK("billing_events"."attempts" >= 0)
);
--> statement-breakpoint
CREATE INDEX `billing_event_retry_idx` ON `billing_events` (`processing_status`,`received_at`);
--> statement-breakpoint
CREATE TABLE `billing_subscriptions` (
	`id` text PRIMARY KEY NOT NULL,
	`profile_id` text,
	`provider` text NOT NULL,
	`environment` text NOT NULL,
	`provider_account_id` text NOT NULL,
	`provider_subscription_id` text NOT NULL,
	`provider_customer_id` text,
	`provider_price_id` text,
	`plan_key` text NOT NULL,
	`billing_interval` text NOT NULL,
	`provider_status` text NOT NULL,
	`current_period_start` integer,
	`current_period_end` integer,
	`access_expires_at` integer,
	`cancel_at_period_end` integer DEFAULT 0 NOT NULL,
	`canceled_at` integer,
	`ended_at` integer,
	`last_synced_at` integer,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`profile_id`) REFERENCES `profiles`(`id`) ON UPDATE no action ON DELETE set null,
	CONSTRAINT "billing_subscription_provider" CHECK("billing_subscriptions"."provider" IN ('stripe','apple','google')),
	CONSTRAINT "billing_subscription_environment" CHECK("billing_subscriptions"."environment" IN ('test','live')),
	CONSTRAINT "billing_subscription_interval" CHECK("billing_subscriptions"."billing_interval" IN ('monthly','annual')),
	CONSTRAINT "billing_subscription_cancel_flag" CHECK("billing_subscriptions"."cancel_at_period_end" IN (0,1))
);
--> statement-breakpoint
CREATE UNIQUE INDEX `billing_subscription_remote_unique` ON `billing_subscriptions` (`provider`,`environment`,`provider_account_id`,`provider_subscription_id`);
--> statement-breakpoint
CREATE INDEX `billing_subscription_profile_idx` ON `billing_subscriptions` (`profile_id`,`environment`,`access_expires_at`);
--> statement-breakpoint
CREATE INDEX `billing_subscription_customer_idx` ON `billing_subscriptions` (`provider`,`environment`,`provider_account_id`,`provider_customer_id`);
