INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100418,'Tavkveri','NOIR','tavkveri');
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100419,'Shavkapito','NOIR','shavkapito');
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100420,'Ojaleshi','NOIR','ojaleshi');
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100421,'Aleksandrouli','NOIR','aleksandrouli alexandrouli');
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100422,'Mujuretuli','NOIR','mujuretuli mudjuretuli');
--> statement-breakpoint
INSERT INTO grape_varieties(id,name,color,search_key) VALUES(100423,'Chkhaveri','ROSE','chkhaveri');
