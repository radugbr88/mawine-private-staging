CREATE TABLE admin_accounts (
 username TEXT PRIMARY KEY NOT NULL,
 password TEXT,
 created_at INTEGER NOT NULL
);
--> statement-breakpoint
CREATE TABLE admin_sessions (
 id TEXT PRIMARY KEY NOT NULL,
 username TEXT NOT NULL REFERENCES admin_accounts(username),
 expires INTEGER NOT NULL
);
--> statement-breakpoint
INSERT INTO admin_accounts(username,password,created_at) VALUES('radugbr88',NULL,unixepoch()*1000);
