CREATE TABLE `collection_retention_policy` (
	`id` integer PRIMARY KEY NOT NULL,
	`started_at` integer NOT NULL
);

--> statement-breakpoint
INSERT INTO collection_retention_policy(id,started_at) VALUES(1,CAST(strftime('%s','now') AS INTEGER)*1000);
