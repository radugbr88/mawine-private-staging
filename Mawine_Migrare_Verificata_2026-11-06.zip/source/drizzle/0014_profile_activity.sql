ALTER TABLE profiles ADD COLUMN created_at INTEGER;
--> statement-breakpoint
ALTER TABLE profiles ADD COLUMN last_active_at INTEGER;
