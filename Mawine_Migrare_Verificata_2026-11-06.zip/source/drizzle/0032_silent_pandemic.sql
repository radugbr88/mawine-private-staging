CREATE TABLE `email_verifications` (
	`profile_id` text PRIMARY KEY NOT NULL,
	`email` text NOT NULL,
	`password_hash` text NOT NULL,
	`token_hash` text NOT NULL,
	`identity` text NOT NULL,
	`expires` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `email_verifications_email_unique` ON `email_verifications` (`email`);--> statement-breakpoint
CREATE UNIQUE INDEX `email_verifications_token_hash_unique` ON `email_verifications` (`token_hash`);--> statement-breakpoint
CREATE TABLE `trial_email_ledger` (
	`fingerprint` text PRIMARY KEY NOT NULL,
	`used_at` integer NOT NULL
);
--> statement-breakpoint
ALTER TABLE `profiles` ADD `primary_email` text;--> statement-breakpoint
ALTER TABLE `profiles` ADD `email_verified_at` integer;--> statement-breakpoint
ALTER TABLE `profiles` ADD `recovery_cipher` text;--> statement-breakpoint
CREATE UNIQUE INDEX `profiles_primary_email_unique` ON `profiles` (`primary_email`) WHERE "profiles"."primary_email" IS NOT NULL;
--> statement-breakpoint
-- Preserve legacy logins; only unambiguous addresses become primary addresses.
UPDATE profiles SET primary_email=lower(trim(recovery_email)) WHERE username IS NOT NULL AND recovery_email LIKE '%@%.%' AND (SELECT count(*) FROM profiles p2 WHERE lower(trim(p2.recovery_email))=lower(trim(profiles.recovery_email)) AND p2.username IS NOT NULL)=1;
