# Ma’wine — degustări private

Aplicație web responsive în limba română. Interfață albă, accente #AC1736, controale rotunjite, fără logotip în pagini.

## Funcții

- Deschidere pe „Cum vrei să începi?”; participant/gazdă, creare profil, recuperare sau acces la profilul salvat. Fără date demonstrative în interfață.
- Invitațiile QR sar peste alegerea rolului; după profil ajungi la „Bine ai venit” cu degustarea și gazda reale.
- Profil editabil (nume, dată de naștere, gen opțional) și schimbarea parolei pentru gazdă.
- Profil personal, gazdă cu toate funcțiile participantului, username/parolă și recuperare prin cod criptografic.
- Degustări în pregătire, active și încheiate; maximum o degustare activă per gazdă.
- Adăugare manuală, copy-paste, import Excel .xlsx / CSV cu separator punct și virgulă / TSV; model Excel descărcabil și verificarea datelor înainte de import.
- Catalog, ordonarea vinurilor, invitații QR reale și coduri.
- Evaluări senzoriale (10/30/30/20/10), notă finală din 10, favorite și notițe personale.
- Degustare în orb: identitatea este eliminată server-side pentru participanți până la dezvăluire. Țară, an și combinație exactă de soiuri: câte un punct. Gazda cunoaște vinurile introduse.
- Istoric extensibil și rezultate; punctajele se blochează la încheiere, notițele/favoritele rămân editabile.

## Persistență și acces

Cloudflare D1 (SQLite), nu MySQL. Migrations Drizzle, API server-side și autorizare pe profil/degustare. Datele persistente nu se află în localStorage. Parolele folosesc PBKDF2, codurile de recuperare sunt stocate ca SHA-256. Codul poate fi vizualizat doar la generare; regenerarea invalidează codul anterior. Codul nu este transmis altor participanți. Încercările de recuperare/login sunt limitate pentru identitatea de platformă.

Această publicație Sites este privată. Accesul inițial este protejat de autentificarea ChatGPT a platformei. Datele username/parolă identifică profilul în interiorul acestui acces; nu înlocuiesc autentificarea de platformă. Invitații externi anonimi și distribuția publică/native nu sunt activate. Pentru lansare fără ChatGPT sunt necesare configurarea accesului public și un mecanism de sesiune pentru vizitatorii anonimi pe infrastructura aleasă. Nu schimba accesul site-ului înainte de această implementare.

Scanarea QR în pagină folosește BarcodeDetector dacă browserul îl oferă. În celelalte browsere, camera telefonului poate deschide URL-ul invitației; introducerea manuală a codului rămâne disponibilă.

Notițele sunt salvate la părăsirea câmpului; evaluările și favoritele la fiecare modificare. Eșecurile de salvare sunt afișate. Datele evenimentului sunt reîncărcate la 15 secunde.

## Verificare

- `node node_modules/typescript/bin/tsc --noEmit`
- `node tests/flows.mjs`: teste de flux cu schema SQL reală și o bază SQLite în memorie, fără date de producție.
- Build prin helperul Sites.
- Previzualizarea browserului nu a putut porni: daemonul sites-previewd lipsește din mediul curent. Verificarea vizuală pe dispozitive rămâne de făcut.

## Organizare

- `app/page.tsx`: interfața și fluxurile.
- `app/globals.css`: design responsive.
- `app/lib.ts`: tipuri, punctaje și date demonstrative.
- `app/api/app/route.ts`: API, autentificare de profil, autorizare și persistență.
- `db/schema.ts`, `drizzle/`: schema bazei de date.

## Catalog de referință

12 vinuri din România și Republica Moldova, verificate pe paginile Vivino legate în fiecare fișă (2026-10-29). Datele sunt în tabela `wine_catalog`, separat de colecțiile personale. POST `/api/catalog` importă idempotent numai setul fix din `app/catalog-seed.ts`; nu acceptă înregistrări de la apelant și nu modifică rânduri existente. GET servește numai fișele publice de referință. Fără recenzii, fotografii, prețuri sau note Vivino copiate. Anul rămâne necompletat pentru paginile generale; anul 2022 pentru SERVE Terra Romana este verificat în pagina acelui an. Gazda confirmă detaliile de pe sticlă înainte de utilizare. Sigla originală furnizată de utilizator este afișată pe prima pagină.

## Finalizarea participării

Butonul de la sfârșitul rezumatului salvează `members.completed=1` pentru profilul curent, fără să schimbe starea evenimentului. Degustarea trece în istoricul personal și dispare din lista personală de degustări active. Pentru gazda care și-a încheiat propriile evaluări, administrarea evenimentului rămâne activă. Punctajele și presupunerile sunt blocate după finalizare; notițele/favoritele pot fi editate. Vinurile în orb rămân ascunse până la dezvăluirea gazdei. Reintroducerea invitației nu anulează finalizarea. Evaluările incomplete sunt permise cu informare la confirmare.
