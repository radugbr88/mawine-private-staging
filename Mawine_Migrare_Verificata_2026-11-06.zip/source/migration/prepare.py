"""Build a clean, verified deployment kit. Never reads the running application's DB."""
import hashlib, json, pathlib, re, shutil, sqlite3, subprocess, sys, zipfile
root=pathlib.Path(__file__).resolve().parents[1]
out=pathlib.Path(sys.argv[1]).resolve()
if out.exists(): raise SystemExit('Choose a new output directory; existing files are never overwritten.')
out.mkdir(parents=True)
source=out/'source';source.mkdir()
for rel in subprocess.check_output(['git','ls-files'],cwd=root,text=True).splitlines():
    if rel.startswith(('.git/','.env','.dev.vars','tests/fixtures/')): continue
    p=root/rel
    if p.is_file():
        target=source/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
# Database is built solely from versioned schema/reference data, not production.
db=sqlite3.connect(':memory:')
for p in sorted((root/'drizzle').glob('*.sql')): db.executescript(p.read_text())
assert db.execute('select count(*) from profiles').fetchone()[0]==0
assert db.execute('select count(*) from admin_sessions').fetchone()[0]==0
db.commit()
assert db.execute('select username,password from admin_accounts').fetchall()==[('radugbr88@gmail.com',None)]
counts={name:db.execute('SELECT count(*) FROM "'+name+'"').fetchone()[0] for name, in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")}
assert all(count==0 for name,count in counts.items() if name not in ('admin_accounts','grape_varieties','collection_retention_policy'))
assert db.execute('pragma integrity_check').fetchone()[0]=='ok'
assert db.execute('pragma foreign_key_check').fetchall()==[]
sql='\n'.join(line for line in db.iterdump() if line not in ('BEGIN TRANSACTION;','COMMIT;','DELETE FROM "sqlite_sequence";'))+'\n'
# Fresh installations start retention at import, not kit generation time.
sql=re.sub(r'INSERT INTO "collection_retention_policy" VALUES\(1,\d+\);', "INSERT INTO collection_retention_policy(id,started_at) VALUES(1,CAST(strftime('%s','now') AS INTEGER)*1000);", sql)
(out/'database-clean.sql').write_text(sql)
restored=sqlite3.connect(':memory:');restored.executescript(sql)
assert restored.execute('select username,password from admin_accounts').fetchall()==[('radugbr88@gmail.com',None)]
assert restored.execute('pragma integrity_check').fetchone()[0]=='ok'
assert restored.execute('pragma foreign_key_check').fetchall()==[]
shutil.copytree(root/'dist',source/'dist',ignore=shutil.ignore_patterns('.openai'))
shutil.copy2(root/'migration/README.md',out/'README.md')
config=json.loads((root/'dist/server/wrangler.json').read_text())
config.update(triggers={'crons':['*/10 * * * *']},name='mawine',main='dist/server/index.js',assets={'directory':'dist/client'},workers_dev=False,
 routes=[{'pattern':'mawine.app','custom_domain':True}],
 d1_databases=[{'binding':'DB','database_name':'mawine-production','database_id':'REPLACE_WITH_NEW_D1_UUID'}],
 vars={'MAWINE_DEPLOYMENT':'standalone','MAWINE_ADMIN_TEMPORARY_PASSWORD_LOGIN':'false','MAWINE_TRUST_PROXY_IDENTITY':'false','MAWINE_PUBLIC_ORIGIN':'https://mawine.app','MAWINE_EMAIL_FROM':'no-reply@mawine.app','STRIPE_MODE':'test','STRIPE_LIVE_ENABLED':'false','STRIPE_ENFORCE_ACCESS':'true','STRIPE_ACCOUNT_ID':'REPLACE_WITH_VERIFIED_STRIPE_ACCOUNT','STRIPE_PRICE_MONTHLY':'REPLACE_WITH_VERIFIED_MONTHLY_PRICE','STRIPE_PRICE_ANNUAL':'REPLACE_WITH_VERIFIED_ANNUAL_PRICE','STRIPE_PORTAL_CONFIGURATION_ID':'REPLACE_WITH_VERIFIED_PORTAL','STRIPE_TEST_USERNAMES':'','CLOUDFLARE_ACCOUNT_ID':'REPLACE_WITH_EMAIL_ACCOUNT_ID'})
(source/'wrangler.migration.json').write_text(json.dumps(config,indent=2)+'\n')
report={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'database_integrity':'ok','restored_database_integrity':'ok','table_counts':counts,'admin':'radugbr88@gmail.com','admin_password':'not set; account locked','runtime':'Cloudflare Workers + D1','production_data_exported':False,'secrets_exported':False,'external_launch_status':'pending target hosting, correct Stripe account and DNS/provider verification'}
(out/'VERIFICATION.json').write_text(json.dumps(report,indent=2)+'\n')
# Detect real secret material, while allowing placeholders and synthetic test values.
for p in source.rglob('*'):
    if p.is_file() and p.suffix in ('.ts','.tsx','.js','.mjs','.json','.md','.sql'):
        text=p.read_text(errors='ignore')
        if re.search(r'(?:sk|rk)_(?:live|test)_[A-Za-z0-9]{24,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',text):
            raise SystemExit('Potential secret material detected: '+str(p.relative_to(out)))
files=sorted(p for p in out.rglob('*') if p.is_file())
(out/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(out).as_posix()+'\n' for p in files))
archive=out.with_suffix('.zip')
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(out.rglob('*')):
        if p.is_file(): z.write(p,p.relative_to(out))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for line in z.read('SHA256SUMS').decode().splitlines():
        digest,rel=line.split('  ',1);assert hashlib.sha256(z.read(rel)).hexdigest()==digest
print(json.dumps({'archive':str(archive),'size':archive.stat().st_size,'tables':counts,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}))
