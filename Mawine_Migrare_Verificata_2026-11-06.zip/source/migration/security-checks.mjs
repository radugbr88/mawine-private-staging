// Offline checks; never prints secret material or contacts providers.
import assert from 'node:assert/strict';
import {webcrypto} from 'node:crypto';
export async function validateSecurity(env,config){
 const checks=[];
 const check=async(name,fn)=>{try{await fn();checks.push({name,ok:true})}catch{checks.push({name,ok:false})}};
 await check('Admin confirmation required; proxy identity disabled',()=>{
  assert.equal(env.MAWINE_DEPLOYMENT,'standalone');
  assert.notEqual(env.MAWINE_ADMIN_TEMPORARY_PASSWORD_LOGIN,'true');
  assert.notEqual(env.MAWINE_TRUST_PROXY_IDENTITY,'true');
 });
 await check('Recovery encryption key has 32 bytes',()=>{
  assert.match(env.MAWINE_RECOVERY_ENCRYPTION_KEY||'',/^[A-Za-z0-9+/]{43}=$/);
  assert.equal(Buffer.from(env.MAWINE_RECOVERY_ENCRYPTION_KEY,'base64').length,32);
 });
 await check('VAPID private/public keys match cryptographically',async()=>{
  const raw=Buffer.from(env.MAWINE_PUSH_PUBLIC_KEY||'','base64url');
  assert.equal(raw.length,65);assert.equal(raw[0],4);
  const jwk=JSON.parse(env.MAWINE_PUSH_PRIVATE_JWK||'{}');
  assert.equal(jwk.kty,'EC');assert.equal(jwk.crv,'P-256');assert(jwk.d);
  const priv=await webcrypto.subtle.importKey('jwk',jwk,{name:'ECDSA',namedCurve:'P-256'},false,['sign']);
  const pub=await webcrypto.subtle.importKey('raw',raw,{name:'ECDSA',namedCurve:'P-256'},false,['verify']);
  const sample=Buffer.from('Mawine migration VAPID validation');
  const sig=await webcrypto.subtle.sign({name:'ECDSA',hash:'SHA-256'},priv,sample);
  assert(await webcrypto.subtle.verify({name:'ECDSA',hash:'SHA-256'},pub,sig,sample));
 });
 await check('Scheduled cleanup and push every ten minutes',()=>assert(config.triggers?.crons?.includes('*/10 * * * *')));
 await check('Stripe pricing IDs are distinct',()=>assert(env.STRIPE_PRICE_MONTHLY&&env.STRIPE_PRICE_ANNUAL&&env.STRIPE_PRICE_MONTHLY!==env.STRIPE_PRICE_ANNUAL));
 return checks;
}
