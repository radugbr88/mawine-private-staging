// Read-only checks. Never creates charges, accounts, products or webhook endpoints.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import Stripe from 'stripe';
import {validateSecurity} from './security-checks.mjs';
const config=JSON.parse(fs.readFileSync(process.argv[2]||'wrangler.migration.json','utf8'));
const env={...config.vars,...process.env};
const local=process.argv.includes('--local-only');
let failures=0;
async function check(name,fn){try{await fn();console.log('OK   '+name)}catch{failures++;console.log('FAIL '+name)}}
await check('Runtime standalone, origin and email',()=>{
 assert.equal(env.MAWINE_DEPLOYMENT,'standalone');assert.equal(env.MAWINE_PUBLIC_ORIGIN,'https://mawine.app');
 assert.equal(env.MAWINE_EMAIL_FROM,'no-reply@mawine.app');assert.equal(env.STRIPE_ENFORCE_ACCESS,'true');
 assert(fs.existsSync(config.main));assert(fs.existsSync(config.assets.directory));
});
await check('Dedicated D1 and custom domain',()=>{
 assert.equal(config.workers_dev,false);assert(config.routes.some(x=>x.pattern==='mawine.app'&&x.custom_domain));
 assert(config.d1_databases.some(x=>x.binding==='DB'&&/^[a-f0-9-]{36}$/i.test(x.database_id)));
});
await check('Required non-secret identifiers',()=>{
 for(const [key,re] of Object.entries({STRIPE_ACCOUNT_ID:/^acct_[a-zA-Z0-9]+$/,STRIPE_PRICE_MONTHLY:/^price_[a-zA-Z0-9]+$/,STRIPE_PRICE_ANNUAL:/^price_[a-zA-Z0-9]+$/,STRIPE_PORTAL_CONFIGURATION_ID:/^bpc_[a-zA-Z0-9]+$/,CLOUDFLARE_ACCOUNT_ID:/^[a-f0-9]{32}$/i}))assert(re.test(env[key]||''));
});
for(const result of await validateSecurity(env,config)){console.log((result.ok?'OK   ':'FAIL ')+result.name);if(!result.ok)failures++;}
if(local){console.log('External checks NOT RUN (--local-only). This is not launch approval.');process.exitCode=failures?1:0;}
else{
 const mode=env.STRIPE_MODE;
 await check('Secret presence and mode (values never printed)',()=>{
  assert(['test','live'].includes(mode));assert(new RegExp('^(sk|rk)_'+mode+'_').test(env.STRIPE_SECRET_KEY||''));
  assert((env.STRIPE_WEBHOOK_SECRET||'').startsWith('whsec_'));assert(env.CLOUDFLARE_EMAIL_API_TOKEN);
  if(mode==='live')assert.equal(env.STRIPE_LIVE_ENABLED,'true');else assert(env.STRIPE_TEST_USERNAMES?.trim());
 });
 if(env.STRIPE_SECRET_KEY){
  const stripe=new Stripe(env.STRIPE_SECRET_KEY,{apiVersion:'2026-09-30.endive',timeout:10000,maxNetworkRetries:1});
  let accountOK=false,prices;
  await check('Stripe key belongs to expected account',async()=>{const a=await stripe.accounts.retrieve();assert.equal(a.id,env.STRIPE_ACCOUNT_ID);accountOK=true;if(mode==='live'){assert(a.charges_enabled);assert(a.details_submitted)}});
  if(accountOK){
   await check('Two active USD prices, shared active product, inclusive tax behavior',async()=>{
    prices=await Promise.all([env.STRIPE_PRICE_MONTHLY,env.STRIPE_PRICE_ANNUAL].map(id=>stripe.prices.retrieve(id,{expand:['product']})));
    for(const [i,p] of prices.entries()){
     assert(p.active);assert.equal(p.livemode,mode==='live');assert.equal(p.currency,'usd');assert(Number.isSafeInteger(p.unit_amount)&&p.unit_amount>0);
     const expected=env[i?'MAWINE_EXPECTED_ANNUAL_CENTS':'MAWINE_EXPECTED_MONTHLY_CENTS'];if(expected)assert.equal(p.unit_amount,Number(expected));
     assert.equal(p.recurring?.interval,i?'year':'month');assert.equal(p.recurring.interval_count,1);assert.equal(p.tax_behavior,'inclusive');
     assert(p.product.active);assert(!p.product.deleted);
    }
    assert.equal(prices[0].product.id,prices[1].product.id);
   });
   await check('Promotion codes readable in the selected Stripe environment',async()=>{
    const page=await stripe.promotionCodes.list({limit:100,active:true,expand:['data.promotion.coupon']});
    for(const p of page.data){assert.equal(p.livemode,mode==='live');assert(p.active);}
    console.log('INFO Active promotion codes on first page: '+page.data.length+(page.has_more?' (additional pages exist)':''));
   });
   await check('Portal cancellation, scheduled annual downgrade, products and legal links',async()=>{
    const p=await stripe.billingPortal.configurations.retrieve(env.STRIPE_PORTAL_CONFIGURATION_ID);
    assert(p.active);assert.equal(p.livemode,mode==='live');assert.equal(p.default_return_url,'https://mawine.app/?billing=portal');
    const f=p.features;assert(f.subscription_cancel.enabled);assert.equal(f.subscription_cancel.mode,'at_period_end');
    assert(f.subscription_update.enabled);assert(f.subscription_update.default_allowed_updates.includes('price'));
    assert.equal(f.subscription_update.proration_behavior,'always_invoice');assert.equal(f.subscription_update.billing_cycle_anchor,'now');
    assert.deepEqual(f.subscription_update.schedule_at_period_end.conditions,[{type:'shortening_interval'}]);
    assert(f.subscription_update.products?.some(p=>p.prices.includes(env.STRIPE_PRICE_MONTHLY)&&p.prices.includes(env.STRIPE_PRICE_ANNUAL)));
    for(const key of ['privacy_policy_url','terms_of_service_url'])assert(p.business_profile[key]?.startsWith('https://mawine.app/'));
   });
   await check('Enabled webhook, expected API version and every application event',async()=>{
    const source=fs.readFileSync('app/billing.ts','utf8');const events=[...source.match(/STRIPE_EVENTS=\[([^\]]+)\]/)[1].matchAll(/'([^']+)'/g)].map(x=>x[1]);
    let found=false;
    for await(const w of stripe.webhookEndpoints.list({limit:100})){
     if(w.url!=='https://mawine.app/api/stripe/webhook')continue;
     assert.equal(w.status,'enabled');assert.equal(w.livemode,mode==='live');assert.equal(w.api_version,'2026-09-30.endive');
     assert(w.enabled_events.includes('*')||events.every(x=>w.enabled_events.includes(x)));found=true;
    }
    assert(found);
   });
  }
 }
 await check('HTTPS and four-language public legal pages',async()=>{
  for(const path of ['/','/terms-ro.html','/terms-en.html','/terms-it.html','/terms-fr.html','/privacy-ro.html','/privacy-en.html','/privacy-it.html','/privacy-fr.html']){
   const r=await fetch('https://mawine.app'+path,{signal:AbortSignal.timeout(10000)});assert(r.ok);assert(new URL(r.url).origin==='https://mawine.app');
   assert((r.headers.get('content-type')||'').includes('text/html'));if(path==='/'){assert((r.headers.get('content-security-policy')||'').includes("frame-ancestors 'none'"));assert(r.headers.has('strict-transport-security'));}const body=await r.text();assert(/Mawine/i.test(body));
  }
 });
 console.log('Manual proof still required: controlled inbox delivery/SPF/DKIM/DMARC, signed webhook delivery, Sandbox payment and restore drill. No emails or payments were sent.');
 process.exitCode=failures?1:0;
}
