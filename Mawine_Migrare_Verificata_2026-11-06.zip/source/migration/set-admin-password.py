"""Run privately on the target machine. Produces a one-time SQL file, no plaintext password."""
import getpass, hashlib, os, pathlib, uuid
password=getpass.getpass('Password for radugbr88@gmail.com (12–200 characters): ')
if not 12<=len(password)<=200: raise SystemExit('Password must be 12–200 characters.')
if password!=getpass.getpass('Repeat password: '): raise SystemExit('Passwords differ.')
salt=str(uuid.uuid4());hashed=salt+':'+hashlib.pbkdf2_hmac('sha256',password.encode(),salt.encode(),100000,32).hex()
p=pathlib.Path('admin-password-once.sql')
fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
with os.fdopen(fd,'w') as f: f.write("UPDATE admin_accounts SET password='"+hashed+"' WHERE username='radugbr88@gmail.com' AND password IS NULL;\n")
print('Created admin-password-once.sql. Apply only to the new database, then remove this file.')
