'use client';
import {useEffect,useRef,type ReactNode} from 'react';
// Measure complete rows instead of clipping the fourth wine at a fixed height.
export function FourWineList({children}:{children:ReactNode}){
 const ref=useRef<HTMLDivElement>(null);
 useEffect(()=>{
  const el=ref.current;if(!el)return;
  const rows=Array.from(el.children) as HTMLElement[];
  const measure=()=>{const first=rows[0],last=rows[Math.min(3,rows.length-1)];if(!first||!last){el.style.removeProperty('height');return}const height=last.getBoundingClientRect().bottom-first.getBoundingClientRect().top;el.style.height=`${Math.ceil(height)}px`};
  measure();const observer=new ResizeObserver(measure);observer.observe(el);rows.slice(0,4).forEach(row=>observer.observe(row));
  return()=>observer.disconnect();
 },[children]);
 return <div ref={ref} className="fourWineList">{children}</div>;
}
