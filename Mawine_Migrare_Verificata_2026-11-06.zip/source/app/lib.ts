import {locale,t} from './i18n';
import {canonicalGrape,grapeKey} from './grape-names';
export type Wine={sourceUrl?:string;checkedAt?:string;id:string;winery:string;name:string;year:number|null;grapes:string[];country:string;type:string;alcohol:string;price:string};
export type Review={scores:(number|null)[];notes:string;favorite:boolean;favoriteAt?:number|null;country:string;year:string;grapes:string[]};
export type Tasting={creationOrder?:number;revealedWineIds?:string[];historyHidden?:boolean;historyFavorite?:boolean;isDemo?:boolean;participationCompleted?:boolean;hostName?:string;id:string;owner:string;title:string;date:string;mode:string;status:string;code:string;wines:Wine[];revealed:boolean;count:number;progress?:Record<string,number>;participants?:string[];averages?:Record<string,number>};
export type Profile={termsAccepted?:boolean;billing?:import('./billing-types').BillingSummary;language?:import('./i18n').Language|null;trialStartedAt?:number;recoveryCode?:string;email?:string;emailVerified?:boolean;pendingEmail?:string;recoveryCodeUnavailable?:boolean;id:string;name:string;dob:string;gender:string;host:boolean;username?:string;catalog:Wine[]};
export type State={pendingVerification?:{email:string};profile:Profile|null;events:Tasting[];reviews:Record<string,Review>};
export const criteria=[['Culoare','Limpiditate și intensitate',10],['Miros','Arome, intensitate și complexitate',30],['Gust','Echilibru, structură și arome',30],['Post-gust','Persistență și senzații finale',20],['Impresii generale','Armonie și impresie de ansamblu',10]] as const;
export const countries=["Albania", "Algeria", "Andorra", "Argentina", "Armenia", "Australia", "Austria", "Azerbaidjan", "Belarus", "Belgia", "Bhutan", "Bolivia", "Bosnia și Herțegovina", "Brazilia", "Bulgaria", "Capul Verde", "Canada", "Chile", "China", "Columbia", "Costa Rica", "Croația", "Cuba", "Cipru", "Cehia", "Danemarca", "Republica Dominicană", "Ecuador", "Egipt", "Estonia", "Etiopia", "Finlanda", "Franța", "Georgia", "Germania", "Grecia", "Ungaria", "India", "Indonezia", "Irlanda", "Israel", "Italia", "Japonia", "Iordania", "Kazahstan", "Kenya", "Kosovo", "Kârgâzstan", "Letonia", "Liban", "Liechtenstein", "Lituania", "Luxemburg", "Madagascar", "Malta", "Mauritius", "Mexic", "Republica Moldova", "Mongolia", "Muntenegru", "Maroc", "Myanmar", "Namibia", "Nepal", "Țările de Jos", "Noua Zeelandă", "Macedonia de Nord", "Norvegia", "Palestina", "Panama", "Paraguay", "Peru", "Polonia", "Portugalia", "România", "Rusia", "Sfânta Lucia", "San Marino", "Serbia", "Slovacia", "Slovenia", "Africa de Sud", "Coreea de Sud", "Spania", "Suedia", "Elveția", "Siria", "Taiwan", "Tadjikistan", "Tanzania", "Thailanda", "Tunisia", "Turcia", "Turkmenistan", "Ucraina", "Regatul Unit", "SUA", "Uruguay", "Uzbekistan", "Venezuela", "Vietnam", "Zimbabwe"].sort((a,b)=>a.localeCompare(b,'ro'));
export const emptyReview=():Review=>({scores:[null,null,null,null,null],notes:'',favorite:false,country:'',year:'',grapes:[]});
export const score=(r?:Review)=>r&&r.scores.every(v=>v!==null)?r.scores.reduce<number>((s,v)=>s+(v||0),0)/10:null;
export function grapeGuessScore(guessed:string[],actual:string[]){
 const truth=new Set(actual.map(g=>grapeKey(canonicalGrape(g))));
 const hits=[...new Set(guessed.map(g=>grapeKey(canonicalGrape(g))))].filter(g=>truth.has(g)).length;
 return !hits?0:truth.size===1||hits>=2?1:0.5;
}
export const guessScore=(r:Review,w:Wine)=>Number(!!w.country&&r.country===w.country)+Number(!!w.year&&r.year===String(w.year))+grapeGuessScore(r.grapes,w.grapes);
export const fmt=(n:number|null)=>n===null?'—':n.toLocaleString(locale(),{minimumFractionDigits:1,maximumFractionDigits:1});
export const sampleWines:Wine[]=[
{id:'w1',winery:'Crama Dealu Vechi',name:'Chardonnay',year:2019,grapes:['Chardonnay'],country:'România',type:'Alb sec',alcohol:'13,6',price:'40'},
{id:'w2',winery:'Crama Colinele Albe',name:'Éclat Blanc',year:2023,grapes:['Sauvignon Blanc'],country:'România',type:'Alb sec',alcohol:'13',price:'65'},
{id:'w3',winery:'Crama Valea Soarelui',name:'Rosé de vară',year:2022,grapes:['Pinot Noir'],country:'România',type:'Rosé sec',alcohol:'12,5',price:'55'},
{id:'w4',winery:'Crama Dealu Vechi',name:'Rezerva No. 7',year:2021,grapes:['Fetească Neagră'],country:'România',type:'Roșu sec',alcohol:'14',price:'90'},
{id:'w5',winery:'Crama Valea Soarelui',name:'Cuvée de Toamnă',year:2022,grapes:['Merlot','Cabernet Sauvignon'],country:'România',type:'Roșu sec',alcohol:'14,5',price:'110'},
{id:'w6',winery:'Crama Colinele Albe',name:'Merlot',year:2021,grapes:['Merlot'],country:'România',type:'Roșu sec',alcohol:'14',price:'75'}];
export function demoState():State {const events:Tasting[]=['O seară în Dealu Mare','Descoperă Feteasca Neagră','Sauvignon Blanc: Lumea Nouă','Bule de sărbătoare','Rosé de vară','Merlot vs. Cabernet Sauvignon'].map((title,i)=>({id:'e'+i,owner:'demo',title,date:'2026-10-'+(29-i*3).toString().padStart(2,'0'),mode:'normal',status:i===0?'active':'ended',code:'VIN742',wines:structuredClone(sampleWines.slice(0,i===3?4:6)),revealed:true,count:i===0?8:6,participants:['Horia','Andrei','Maria','Ioana','Alex','Diana','Vlad','Elena'],progress:{w1:8,w2:8,w3:6,w4:3,w5:0,w6:0}}));const reviews:Record<string,Review>={};events.slice(1).forEach(e=>e.wines.forEach((w,i)=>reviews[e.id+':'+w.id]={...emptyReview(),scores:[8,25,25,17,8],favorite:e.id==='e1'&&i<3,notes:i===0?'Arome de măr verde și citrice, cu note fine de vanilie. Gust proaspăt, echilibrat, cu o aciditate plăcută.':''}));return{profile:{id:'demo',name:'Horia',dob:'1990-05-14',gender:'',host:true,catalog:structuredClone(sampleWines)},events,reviews};}

export type CatalogWine=Omit<Wine,'year'> & {year:number|null;sourceUrl:string;checkedAt:string;region:string};

export function tastingToday(now=new Date()){return new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/Bucharest',year:'numeric',month:'2-digit',day:'2-digit'}).format(now)}
export function validBirthDate(value:unknown,now=new Date()){if(typeof value!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(value))return false;const d=new Date(value+'T12:00:00Z');return !Number.isNaN(d.getTime())&&d.toISOString().slice(0,10)===value&&value<=tastingToday(now)}
export function isAdult(value:unknown,now=new Date()){
 if(!validBirthDate(value,now))return false;
 const today=tastingToday(now),dob=value as string;
 const age=Number(today.slice(0,4))-Number(dob.slice(0,4))-(today.slice(5)<dob.slice(5)?1:0);
 return age>=18;
}
export function validTastingDate(value:string,now=new Date()){if(!/^\d{4}-\d{2}-\d{2}$/.test(value))return false;const d=new Date(value+'T12:00:00Z');return !Number.isNaN(d.getTime())&&d.toISOString().slice(0,10)===value&&value>=tastingToday(now)}
export function matchesWine(w:Wine,query:string){const norm=(s:string)=>s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();const hay=norm([w.winery,w.name,w.year,...(w.grapes||[]),w.type,w.country,t(w.type),t(w.country)].filter(Boolean).join(' '));return norm(query).split(/\s+/).every(term=>hay.includes(term))}

export function wineStatistics(events:Tasting[],reviews:Record<string,Review>){
 const entries=events.filter(e=>e.status!=='draft'&&!e.isDemo&&!e.historyHidden).flatMap(event=>event.wines.flatMap(wine=>{
  const rating=score(reviews[event.id+':'+wine.id]);return typeof rating!=='number'?[]:[{event,wine,rating}];
 }));
 const ordered=[...entries].sort((a,b)=>b.rating-a.rating);
 const colors:Record<string,number>={'Alb':0,'Orange':0,'Roze':0,'Roșu':0};
 for(const {wine} of entries){const type=(wine.type||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();const color=type.startsWith('rosu')?'Roșu':(type.startsWith('rose')||type.startsWith('roze'))?'Roze':type.startsWith('alb')?'Alb':type.startsWith('orange')?'Orange':type.startsWith('spumant')?'Spumant':'Nespecificat';colors[color]=(colors[color]||0)+1;}
 return {tastings:events.filter(e=>e.status!=='draft'&&!e.isDemo&&!e.historyHidden).length,count:entries.length,average:entries.length?entries.reduce((s,e)=>s+e.rating,0)/entries.length:null,best:ordered[0]||null,worst:ordered.at(-1)||null,colors};
}

export function isWineRevealed(event:Tasting,wine:Wine){return event.revealed||event.status==='ended'||!!event.revealedWineIds?.includes(wine.id)}

export function tastingSection(e:Tasting,profileId?:string){
 if(e.status==='draft')return e.owner===profileId?'draft':null;
 if(e.status==='active'&&(e.owner===profileId||!e.participationCompleted))return 'active';
 return e.historyHidden?null:'ended';
}
export function newestTastings(events:Tasting[]){return [...events].sort((a,b)=>b.date.localeCompare(a.date)||(b.creationOrder||0)-(a.creationOrder||0))}

export function correctGuessSummary(event:Tasting,wine:Wine,review:Review,profileId?:string){
 if(event.mode!=='blind'||event.owner===profileId||!isWineRevealed(event,wine))return [];
 const correct:string[]=[];
 if(wine.country&&review.country===wine.country)correct.push('Țara: '+wine.country);
 if(wine.year&&review.year===String(wine.year))correct.push('Anul: '+wine.year);
 const truth=new Set((wine.grapes||[]).map(g=>grapeKey(canonicalGrape(g))));
 const grapes=[...new Set(review.grapes.map(canonicalGrape))].filter(g=>truth.has(grapeKey(g)));
 if(grapes.length)correct.push('Soiuri: '+grapes.join(', '));
 return correct;
}
