import {Menu} from 'lucide-react';
import {t,locale} from './i18n';
import {displayGrape} from './grape-names';
import type {Wine} from './lib';
export type CollectionSort={key:'winery'|'name'|'year'|'grapes';direction:1|-1}|null;
export function sortCollection(wines:Wine[],sort:CollectionSort){
 const recent=[...wines].reverse();
 if(!sort)return recent;
 const collator=new Intl.Collator(locale(),{sensitivity:'base',numeric:true});
 return recent.sort((a,b)=>{
  const value=(w:Wine)=>sort.key==='grapes'?w.grapes.map(displayGrape).join(', '):w[sort.key];
  const av=value(a),bv=value(b);
  if(av===null||av==='')return bv===null||bv===''?0:1;
  if(bv===null||bv==='')return -1;
  return collator.compare(String(av),String(bv))*sort.direction;
 });
}
export function CollectionSortBar({open,onToggle,value,onChange}:{open:boolean;onToggle:()=>void;value:CollectionSort;onChange:(s:CollectionSort)=>void}){
 return <div className="collectionSortBar"><div className="collectionSortOptions" hidden={!open}>{(['winery','name','year','grapes'] as const).map((key,i)=>{const active=value?.key===key;const direction=active?value.direction:1;return <button type="button" key={key} className={active?'active':''} aria-pressed={active} onClick={()=>onChange({key,direction:active&&direction===1?-1:1})}>{t(['Cramă','Vin','An','Soi'][i])}</button>})}</div><button type="button" className="collectionSortToggle" aria-label={t('Sortare')} aria-expanded={open} onClick={onToggle}><Menu size={21}/></button></div>
}
