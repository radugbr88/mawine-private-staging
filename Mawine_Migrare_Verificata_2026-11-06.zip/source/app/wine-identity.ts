import type {Wine} from './lib';
const key=(s:string)=>s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]/g,'');
export function splitWineName(name:string,winery='',knownWineries:string[]=[]){
 const parts=name.split(/\s+-\s+|\s*[–—]\s*/).map(s=>s.trim()).filter(Boolean);
 if(parts.length<2)return{name,winery};
 if(winery){const remaining=parts.filter(p=>key(p)!==key(winery));return{name:remaining.length&&remaining.length<parts.length?remaining.join(' — '):name,winery}}
 const known=new Set(knownWineries.filter(Boolean).map(key));
 const candidates=parts.map((p,i)=>known.has(key(p))||/^(crama|cramele|domeniul|domeniile|ch[aâ]teau|domaine|bodega|bodegas|tenuta|cantina|winery)\s+/i.test(p)||/\s+(winery|vineyards)$/i.test(p)?i:-1).filter(i=>i>=0);
 if(candidates.length===1){const i=candidates[0];return{name:parts.filter((_,j)=>i!==j).join(' — '),winery:parts[i]}}
 return{name,winery}; // Ambiguous: preserve original, ask the user to choose the order in preview.
}
export function mergeWineCollection(existing:Wine[],incoming:Wine[]){
 const all=existing.map(w=>({...w}));const identity=(w:Wine)=>[key(w.winery),key(w.name),w.year??'',...(!w.name.trim()?[key(w.country),key(w.type),[...new Set(w.grapes.map(key))].sort().join(',')]:[])].join('|');
 for(const w of incoming){const index=all.findIndex(old=>old.id===w.id||identity(old)===identity(w));if(index<0)all.push(w);else{const old=all[index];all[index]={...old,...w,id:old.id,winery:w.winery||old.winery,year:w.year??old.year,country:w.country||old.country,type:w.type||old.type,price:w.price||old.price,alcohol:w.alcohol||old.alcohol,grapes:w.grapes.length?w.grapes:old.grapes}}}
 return all;
}
