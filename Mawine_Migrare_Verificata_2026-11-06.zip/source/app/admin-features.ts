import {trialStart,trialStatus} from './subscription';
import {RequestError} from './security';
import {billingLock,billingConfig,assertBillingCanClose,type BillingEnv} from './billing';
const q=(db:D1Database,sql:string,...args:unknown[])=>db.prepare(sql).bind(...args);
export async function adminFeatures(db:D1Database,env:BillingEnv,admin:string,body:any){
 if(body.action==='grantComplimentary'||body.action==='revokeComplimentary'){
  const id=typeof body.userId==='string'?body.userId:'';
  const lock=await billingLock(db,id);
  try{
   const p:any=await q(db,'SELECT * FROM profiles WHERE id=?',id).first();
   if(!p||!p.username||!trialStart(p)||p.blocked)throw new RequestError('Selectează un cont care a început perioada gratuită.');
   if(body.confirmed!==true)throw new RequestError('Confirmă modificarea accesului gratuit.');
   const expires=body.action==='revokeComplimentary'?0:Number(body.expiresAt);
   if(!Number.isSafeInteger(expires)||(body.action==='grantComplimentary'&&(expires<=Date.now()||expires>Date.now()+10*366*86400000)))throw new RequestError('Alege o dată de expirare în viitor, în următorii 10 ani.');
   // A local grant must never hide ongoing Stripe charges or a pending Checkout session.
   if(expires){if(!await complimentaryEligible(db,env,p))throw new RequestError('Gratuitatea se poate activa doar în cele 30 de zile de probă sau după încheierea perioadei plătite.');await assertBillingCanClose(db,env,p);}
   await lock.assert();
   await db.batch([
    q(db,'INSERT INTO complimentary_access(profile_id,expires_at,granted_by,updated_at) VALUES(?,?,?,?) ON CONFLICT(profile_id) DO UPDATE SET expires_at=excluded.expires_at,granted_by=excluded.granted_by,updated_at=excluded.updated_at',id,expires,admin,Date.now()),
    q(db,'INSERT INTO admin_access_audit(id,profile_id,admin,expires_at,created_at) VALUES(?,?,?,?,?)',crypto.randomUUID(),id,admin,expires,Date.now()),
    q(db,'UPDATE profiles SET host=CASE WHEN ?>0 THEN 1 ELSE host END WHERE id=?',expires,id)
   ]);return{ok:true};
  }finally{await lock.release()}
 }
 return null;
}

export async function complimentaryEligible(db:D1Database,env:BillingEnv,p:any,now=Date.now()){
 if(!p?.username||p.blocked)return false;
 const c=billingConfig(env);
 const rows:any[]=(await q(db,"SELECT environment,provider_account_id,access_expires_at,risk_blocked FROM billing_subscriptions WHERE profile_id=? AND provider='stripe'",p.id).all()).results as any[];
 // Fail closed if existing billing cannot be scoped to the configured Stripe account.
 if(rows.length&&!c)return false;
 const scoped=rows.filter(r=>r.environment===c?.mode&&r.provider_account_id===c?.account);
 if(scoped.some(r=>r.risk_blocked||r.access_expires_at>now))return false;
 if(scoped.some(r=>r.access_expires_at>0&&r.access_expires_at<=now))return true;
 const start=trialStart(p);return start!==null&&start<=now&&trialStatus(start,now).active;
}
