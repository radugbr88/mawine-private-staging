'use client';
import {t} from './i18n';
export function PromotionField({code,applied,busy,onChange,onApply,simulation=false}:{simulation?:boolean;code:string;applied:boolean;busy:boolean;onChange:(code:string)=>void;onApply:()=>void}){
 return <section className="promotionField"><label htmlFor="promotion-code">{t('Cod de reducere')}</label><div className="promotionControls"><input id="promotion-code" value={code} maxLength={64} autoComplete="off" autoCapitalize="characters" spellCheck={false} placeholder={t('Introdu codul')} onChange={e=>onChange(e.target.value)} disabled={busy}/><button type="button" disabled={busy||!code.trim()||applied} className={applied?'applied':code.trim()?'ready':'empty'} onClick={onApply}>{t(busy?'Se verifică…':applied?'Aplicat':'Aplică')}</button></div>{applied&&<small role="status">{t(simulation?'Cod aplicat în simulare. Nu a fost validat în Stripe.':'Cod validat în Stripe. Reducerea se confirmă la finalizarea plății.')}</small>}</section>;
}
