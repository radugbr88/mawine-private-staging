// Only the personal catalogue is purged. Event snapshots/reviews and credentials survive.
// The rollout floor gives existing expired accounts a full year (no retroactive deletion).
export const COLLECTION_RETENTION_MS=365*86400000;
export const PURGE_COLLECTIONS_SQL=`UPDATE profiles SET catalog='[]' WHERE id IN (
 SELECT p.id FROM profiles p
 WHERE p.catalog<>'[]' AND p.username IS NOT NULL
 AND ? >= MAX(
   (SELECT started_at FROM collection_retention_policy WHERE id=1),
   COALESCE(p.trial_started_at,1793456501369)+33*86400000,
   COALESCE((SELECT MAX(access_expires_at)+3*86400000 FROM billing_subscriptions WHERE profile_id=p.id),0),
   COALESCE((SELECT MAX(expires_at) FROM complimentary_access WHERE profile_id=p.id),0)
 )+365*86400000
 AND NOT EXISTS(SELECT 1 FROM billing_locks WHERE id='billing:'||p.id AND expires_at>?)
 AND NOT EXISTS(SELECT 1 FROM billing_events WHERE processing_status IN ('pending','failed'))
 ORDER BY p.id LIMIT 100
)`;
export async function purgeExpiredCollections(db:D1Database,now=Date.now()){
 // One atomic statement rechecks grants and paid entitlements at deletion time.
 return db.prepare(PURGE_COLLECTIONS_SQL).bind(now,now).run();
}
