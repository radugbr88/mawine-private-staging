import {t} from './i18n';
export async function copyRecoveryCode(code:string){
 if(!navigator.clipboard?.writeText)throw Error('clipboard-unavailable');
 let timer:ReturnType<typeof setTimeout>|undefined;
 try{await Promise.race([navigator.clipboard.writeText(code),new Promise<never>((_,reject)=>{timer=setTimeout(()=>reject(Error('clipboard-timeout')),5000)})])}
 finally{clearTimeout(timer)}
}
export async function saveRecoveryCode(code:string,container:HTMLElement){
 const file=new File([t('Mawine — Cod personal de recuperare')+'\n'+code+'\n'+t('Păstrează-l privat. Oricine are codul poate accesa profilul.')],'cod-recuperare-mawine.txt',{type:'text/plain;charset=utf-8'});
 if(navigator.canShare?.({files:[file]})&&navigator.share){
  try{await navigator.share({files:[file],title:t('Cod de recuperare Mawine')});return 'shared'}
  catch(error){if((error as Error).name==='AbortError')return 'cancelled';/* Fall back to a local download if sharing is unavailable. */}
 }
 const url=URL.createObjectURL(file);const link=document.createElement('a');
 link.href=url;link.download=file.name;link.hidden=true;container.appendChild(link);
 try{link.click();return 'downloaded'}finally{link.remove();setTimeout(()=>URL.revokeObjectURL(url),60000)}
}
