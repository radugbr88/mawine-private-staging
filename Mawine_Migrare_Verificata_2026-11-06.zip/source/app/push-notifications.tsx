'use client';
import {useEffect,useRef,useState} from 'react';
import {t} from './i18n';
async function api(action:string,extra:object={}){const r=await fetch('/api/app',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action,...extra})});const data:any=await r.json();if(!r.ok)throw Error(data.error||'Operația nu a putut fi finalizată. Încearcă din nou.');return data}
export function PushNotifications({profileId,settings=false}:{profileId:string;settings?:boolean}){
 const activating=useRef(false);
 const [needsInstall,setNeedsInstall]=useState(false);
 const [config,setConfig]=useState<{enabled:boolean;publicKey:string}|null>(null),[supported,setSupported]=useState(false),[active,setActive]=useState(false),[busy,setBusy]=useState(false),[hidden,setHidden]=useState(true),[message,setMessage]=useState('');
 useEffect(()=>{let live=true;const ios=/iPad|iPhone|iPod/.test(navigator.userAgent)||(navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1);const installed=window.matchMedia('(display-mode: standalone)').matches||(navigator as Navigator&{standalone?:boolean}).standalone===true;setNeedsInstall(ios&&!installed);const ok=!(ios&&!installed)&&'serviceWorker' in navigator&&'PushManager' in window&&'Notification' in window&&isSecureContext;setSupported(ok);try{setHidden(localStorage.getItem('mawine.push.prompt.'+profileId)==='seen')}catch{setHidden(false)}
  if(ok){api('pushConfig').then(async c=>{if(!live)return;setConfig(c);if(c.enabled){const registration=await navigator.serviceWorker.register('/sw.js');const sub=await registration.pushManager.getSubscription();if(live)setActive(c.subscribed&&!!sub&&Notification.permission==='granted')}}).catch(()=>{if(live)setMessage('Notificările push nu sunt configurate.')})}return()=>{live=false};
 },[profileId]);
 function dismiss(){try{localStorage.setItem('mawine.push.prompt.'+profileId,'seen')}catch{}setHidden(true)}
 async function enable(){if(!config?.enabled||activating.current)return;activating.current=true;setBusy(true);setMessage('');try{
  // Invoke permission directly from the user's tap, before unrelated asynchronous work.
  const permission=await Notification.requestPermission();if(permission!=='granted'){setMessage('Permite notificările din setările browserului.');dismiss();return}
  const registration=await navigator.serviceWorker.ready;let sub=await registration.pushManager.getSubscription();
  if(!sub){const raw=atob(config.publicKey.replace(/-/g,'+').replace(/_/g,'/'));sub=await registration.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:Uint8Array.from(raw,c=>c.charCodeAt(0))})}
  await api('pushSubscribe',{subscription:sub.toJSON()});setActive(true);dismiss();
  try{await api('pushTest');setMessage('Notificările sunt acum active.')}
  catch{setMessage('Notificările sunt activate, dar mesajul de confirmare nu a putut fi trimis.');}
 }catch(e){setMessage(e instanceof Error?e.message:'Notificarea nu a putut fi trimisă. Încearcă din nou.')}finally{activating.current=false;setBusy(false)}}
 async function disable(){setBusy(true);try{await api('pushDisable');const reg=await navigator.serviceWorker.getRegistration('/');await(await reg?.pushManager.getSubscription())?.unsubscribe();setActive(false);setMessage('Notificările sunt dezactivate pe acest dispozitiv.');dismiss()}catch(e){setMessage((e as Error).message)}finally{setBusy(false)}}
 if(!settings&&(hidden||active||!supported||!config?.enabled))return null;
 return <section className={settings ? "pushPreferences pushSettings" : "pushPreferences"}>
  <h3>{t('Notificări push')}</h3>
  <p>{t('Primește reamintiri despre abonament pe acest dispozitiv, chiar și când aplicația este închisă.')}</p>
  {needsInstall?<p>{t('Pentru a primi notificări, adaugă Mawine pe ecranul principal: apasă Distribuie → Adaugă pe ecranul principal. Apoi deschide aplicația din iconiță și activează notificările.')}</p>:!supported?<p>{t('Folosește un browser compatibil cu notificările push.')}</p>:!config?.enabled?<p>{t('Notificările push nu sunt configurate.')}</p>:null}
  {message&&<p role="status">{t(message)}</p>}
  <p>{t('Pe iPhone și iPad, notificările push apar doar dacă Mawine este adăugată pe ecranul principal (Home Screen) și ai permis notificările.')}</p>
  {supported&&config?.enabled&&<div className="pushActions">
   <button type="button" disabled={busy} onClick={active?disable:enable}>{t(active?'Dezactivează notificările':'Activează notificările')}</button>
   {!settings&&<button type="button" disabled={busy} onClick={dismiss}>{t('Mai târziu')}</button>}
  </div>}
 </section>;
}
