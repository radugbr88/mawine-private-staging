// RFC 8291 (aes128gcm) and RFC 8292 (VAPID), using the runtime Web Crypto API.
const te=new TextEncoder();
export const base64url=(bytes:Uint8Array)=>btoa(String.fromCharCode(...bytes)).replace(/=/g,'').replace(/\+/g,'-').replace(/\//g,'_');
export function decode64(value:string){if(!/^[A-Za-z0-9_-]+$/.test(value))throw Error('Invalid key');return Uint8Array.from(atob(value.replace(/-/g,'+').replace(/_/g,'/')),c=>c.charCodeAt(0))}
const concat=(...parts:Uint8Array[])=>{const out=new Uint8Array(parts.reduce((n,p)=>n+p.length,0));let at=0;for(const p of parts){out.set(p,at);at+=p.length}return out};
export function pushEndpoint(value:unknown){
 if(typeof value!=='string'||value.length>2048)throw Error('Invalid endpoint');const u=new URL(value);
 const allowed=u.hostname==='fcm.googleapis.com'||u.hostname==='updates.push.services.mozilla.com'||u.hostname.endsWith('.push.services.mozilla.com')||u.hostname==='web.push.apple.com'||u.hostname.endsWith('.notify.windows.com');
 if(!allowed||u.protocol!=='https:'||u.port||u.username||u.password||u.hash||u.pathname==='/')throw Error('Invalid endpoint');return u;
}
async function hkdf(secret:Uint8Array,salt:Uint8Array,info:Uint8Array,length:number){const key=await crypto.subtle.importKey('raw',new Uint8Array(secret),'HKDF',false,['deriveBits']);return new Uint8Array(await crypto.subtle.deriveBits({name:'HKDF',hash:'SHA-256',salt:new Uint8Array(salt),info:new Uint8Array(info)},key,length*8))}
export async function encryptPush(p256dh:string,auth:string,text:string){
 const ua=decode64(p256dh),secret=decode64(auth);if(ua.length!==65||ua[0]!==4||secret.length!==16)throw Error('Invalid subscription');
 const remote=await crypto.subtle.importKey('raw',ua,{name:'ECDH',namedCurve:'P-256'},false,[]);
 const pair=await crypto.subtle.generateKey({name:'ECDH',namedCurve:'P-256'},true,['deriveBits']);
 const publicKey=new Uint8Array(await crypto.subtle.exportKey('raw',pair.publicKey));
 const shared=new Uint8Array(await crypto.subtle.deriveBits({name:'ECDH',public:remote},pair.privateKey,256));
 const ikm=await hkdf(shared,secret,concat(te.encode('WebPush: info\0'),ua,publicKey),32);
 const salt=crypto.getRandomValues(new Uint8Array(16));
 const key=await crypto.subtle.importKey('raw',await hkdf(ikm,salt,te.encode('Content-Encoding: aes128gcm\0'),16),'AES-GCM',false,['encrypt']);
 const nonce=await hkdf(ikm,salt,te.encode('Content-Encoding: nonce\0'),12);
 const plain=te.encode(text);if(plain.length>3000)throw Error('Payload too large');
 const encrypted=new Uint8Array(await crypto.subtle.encrypt({name:'AES-GCM',iv:nonce},key,concat(plain,new Uint8Array([2]))));
 const header=new Uint8Array(21);header.set(salt);new DataView(header.buffer).setUint32(16,4096);header[20]=65;
 return concat(header,publicKey,encrypted);
}
export type PushEnv=Record<string,unknown>;
export function pushConfigured(env:PushEnv){return typeof env.MAWINE_PUSH_PUBLIC_KEY==='string'&&typeof env.MAWINE_PUSH_PRIVATE_JWK==='string'}
export async function vapidAuthorization(endpoint:string,env:PushEnv,now=Date.now()){
 const origin=pushEndpoint(endpoint).origin;
 const key=await crypto.subtle.importKey('jwk',JSON.parse(String(env.MAWINE_PUSH_PRIVATE_JWK)),{name:'ECDSA',namedCurve:'P-256'},false,['sign']);
 const token=[{typ:'JWT',alg:'ES256'},{aud:origin,exp:Math.floor(now/1000)+3600,sub:'mailto:no-reply@mawine.app'}].map(x=>base64url(te.encode(JSON.stringify(x)))).join('.');
 const signature=new Uint8Array(await crypto.subtle.sign({name:'ECDSA',hash:'SHA-256'},key,te.encode(token)));
 return `vapid t=${token}.${base64url(signature)}, k=${env.MAWINE_PUSH_PUBLIC_KEY}`;
}
export async function sendPush(env:PushEnv,subscription:{endpoint:string;p256dh:string;auth:string},payload:unknown){
 pushEndpoint(subscription.endpoint);
 // Workerd supports only follow/manual. Never follow a provider redirect with VAPID credentials.
 return fetch(subscription.endpoint,{method:'POST',redirect:'manual',signal:AbortSignal.timeout(10000),headers:{Authorization:await vapidAuthorization(subscription.endpoint,env),'Content-Encoding':'aes128gcm','Content-Type':'application/octet-stream',TTL:'3600',Urgency:'normal'},body:await encryptPush(subscription.p256dh,subscription.auth,JSON.stringify(payload))});
}
