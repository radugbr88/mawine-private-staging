import english from './i18n-en.json';
import italian from './i18n-it.json';
import french from './i18n-fr.json';
export type Language='ro'|'en'|'it'|'fr';
export const languages:readonly Language[]=['ro','en','it','fr'];
export const parseLanguage=(value:unknown):Language=>languages.includes(value as Language)?value as Language:'ro';
const dictionaries:Record<Exclude<Language,'ro'>,Record<string,string>>={en:english,it:italian,fr:french};
let language:Language='en';
const listeners=new Set<()=>void>();
export const getLanguage=()=>language;
export const getServerLanguage=():Language=>'en';
export const subscribeLanguage=(listener:()=>void)=>{listeners.add(listener);return()=>{listeners.delete(listener)}};
export const locale=()=>({ro:'ro-RO',en:'en-GB',it:'it-IT',fr:'fr-FR'})[language];
export function setLanguage(value:Language){language=value;try{localStorage.setItem('mawine.language',value)}catch{};if(typeof document!=='undefined'){document.documentElement.lang=value;document.title='Mawine'}listeners.forEach(fn=>fn())}
// Entry-page choice is separate from an authenticated profile's preference.
export function getEntryLanguage():Language{try{const value=localStorage.getItem('mawine.entryLanguage');if(languages.includes(value as Language))return value as Language;}catch{}return 'en';}
export function setEntryLanguage(value:Language){try{localStorage.setItem('mawine.entryLanguage',value)}catch{}setLanguage(value);}
export function loadLanguage(){try{setLanguage(parseLanguage(localStorage.getItem('mawine.language')))}catch{}}
const patterns=Object.entries(dictionaries).map(([lang,dictionary])=>({lang,items:Object.entries(dictionary).filter(([key])=>/\{\d+\}/.test(key)).map(([key,value])=>{
 const slots:number[]=[];
 const source=key.split(/(\{\d+\})/).map(part=>{if(/^\{\d+\}$/.test(part)){slots.push(Number(part.slice(1,-1)));return '(.*?)'}return part.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}).join('');
 return {regex:new RegExp('^'+source+'$'),value,slots};
})}));
export function t<T>(value:T,context?:string):T{return translateForLanguage(language,value,context)}
// Explicit locale keeps server requests independent of browser language state.
export function translateForLanguage<T>(selectedLanguage:Language,value:T,context?:string):T{
 if(typeof value!=='string')return value;
 if(selectedLanguage==='ro')return (value==='Vin desert'?'Desert':value) as T;
 const key=value.trim().replace(/\s+/g,' ');
 const dictionary=dictionaries[selectedLanguage];
 const translated=(context?dictionary[context+':'+key]:undefined)??dictionary[key];
 if(translated!==undefined)return value.replace(value.trim(),translated) as T;
 for(const pattern of patterns.find(p=>p.lang===selectedLanguage)!.items){const match=pattern.regex.exec(key);if(match)return pattern.value.replace(/\{(\d+)\}/g,(_,slot)=>match[pattern.slots.indexOf(Number(slot))+1]||'') as T}
 if(key.includes(' · '))return key.split(' · ').map(part=>translateForLanguage(selectedLanguage,part)).join(' · ') as T;
 return value as T;
}

export function pluralLabel(count:number,noun:string,suffix=''){
 const single:Record<string,string>={vinuri:'vin',participanți:'participant',evaluări:'evaluare'};
 return ' '+t(count===1?(single[noun]||noun):noun)+t(suffix);
}
