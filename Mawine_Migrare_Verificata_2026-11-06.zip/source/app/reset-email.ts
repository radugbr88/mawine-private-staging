// Server-only email transport. Imported only by the password-reset API route.
export type ResetEmailEnv = {
 CLOUDFLARE_EMAIL_API_TOKEN?: string;
 CLOUDFLARE_ACCOUNT_ID?: string;
 MAWINE_EMAIL_FROM?: string;
 MAWINE_PUBLIC_ORIGIN?: string;
};
export function resetEmailConfig(env: ResetEmailEnv) {
 const token=env.CLOUDFLARE_EMAIL_API_TOKEN?.trim();
 const accountId=env.CLOUDFLARE_ACCOUNT_ID?.trim();
 const from=env.MAWINE_EMAIL_FROM?.trim();
 if(!token || !accountId || !/^[a-f0-9]{32}$/.test(accountId) || !from || !/^[^\s<>@]+@[^\s<>@]+\.[^\s<>@]+$/.test(from)) return null;
 try {
  const url=new URL(env.MAWINE_PUBLIC_ORIGIN || '');
  if(url.protocol!=='https:' || url.username || url.password || url.pathname!=='/' || url.search || url.hash) return null;
  return {token,accountId,from,origin:url.origin};
 } catch {return null;}
}
export async function sendResetEmail(config: NonNullable<ReturnType<typeof resetEmailConfig>>, to: string, subject: string, text: string) {
 const response=await fetch(`https://api.cloudflare.com/client/v4/accounts/${config.accountId}/email/sending/send`,{
  method:'POST',redirect:'error',
  headers:{Authorization:`Bearer ${config.token}`,'Content-Type':'application/json'},
  body:JSON.stringify({from:{address:config.from,name:'Mawine'},to,subject,text}),
  signal:AbortSignal.timeout(10000)
 });
 // Never log provider payloads: they may contain email addresses or credentials.
 if(!response.ok)throw new Error('Email delivery failed');
 const data=await response.json() as {success?:boolean;result?:{delivered?:string[];queued?:string[];permanent_bounces?:string[]}};
 const contains=(items:unknown)=>Array.isArray(items)&&items.some(item=>typeof item==='string'&&item.toLowerCase()===to.toLowerCase());
 if(data.success!==true || contains(data.result?.permanent_bounces) || !(contains(data.result?.delivered)||contains(data.result?.queued)))throw new Error('Email delivery failed');
}
