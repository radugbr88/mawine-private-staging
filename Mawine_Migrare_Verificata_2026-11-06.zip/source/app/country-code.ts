// Resolve imported names in every app language as well as two/three-letter codes.
const codes='AL DZ AD AR AM AU AT AZ BY BE BT BO BA BR BG CV CA CL CN CO CR HR CU CY CZ DK DO EC EG EE ET FI FR GE DE GR HU IN ID IE IL IT JP JO KZ KE XK KG LV LB LI LT LU MG MT MU MX MD MN ME MA MM NA NP NL NZ MK NO PS PA PY PE PL PT RO RU LC SM RS SK SI ZA KR ES SE CH SY TW TJ TZ TH TN TR TM UA GB US UY UZ VE VN ZW'.split(' ');
const normalize=(v:string)=>v.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z]/g,'');
const aliases:Record<string,string>={sua:'US',usa:'US',uk:'GB',slo:'SI',svn:'SI',rou:'RO',esp:'ES',republicamoldova:'MD',moldova:'MD',africades:'ZA',nzeelanda:'NZ',mbritanie:'GB'};
for(const code of codes){aliases[normalize(code)]=code;for(const lang of ['ro','en','it','fr','es']){const name=new Intl.DisplayNames([lang],{type:'region'}).of(code);if(name)aliases[normalize(name)]=code;}}
export function countryCode(country:string|undefined){const code=aliases[normalize(country||'')];return code==='SI'?'SLO':code||'';}
