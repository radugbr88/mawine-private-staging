// Shared request boundaries. Never expose database/provider exceptions to visitors.
export class RequestError extends Error {constructor(message:string,public status=400){super(message)}}
export async function readJson(req:Pick<Request,'headers'|'body'>,maxBytes:number):Promise<Record<string,any>>{
 if(Number(req.headers.get('content-length')||0)>maxBytes)throw new RequestError('Cerere prea mare.',413);
 const reader=req.body?.getReader();if(!reader)throw new RequestError('Cerere invalidă.');
 const chunks:Uint8Array[]=[];let size=0;
 try{while(true){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>maxBytes){void reader.cancel();throw new RequestError('Cerere prea mare.',413)}chunks.push(value)}}finally{reader.releaseLock()}
 const bytes=new Uint8Array(size);let offset=0;for(const c of chunks){bytes.set(c,offset);offset+=c.byteLength}
 let body;try{body=JSON.parse(new TextDecoder().decode(bytes))}catch{throw new RequestError('Cerere invalidă.')}
 if(!body||typeof body!=='object'||Array.isArray(body))throw new RequestError('Cerere invalidă.');return body;
}
export async function digest(value:string){return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value)))).map(x=>x.toString(16).padStart(2,'0')).join('')}
export function equalSecret(a:string,b:string){let diff=a.length^b.length;for(let i=0;i<Math.max(a.length,b.length);i++)diff|=(a.charCodeAt(i)||0)^(b.charCodeAt(i)||0);return diff===0}
// Atomic increment prevents parallel requests from sharing the same remaining attempt.
export async function rateLimit(db:any,key:string,max:number,window=900000){
 const now=Date.now();const row=await db.prepare('INSERT INTO attempts(id,count,since) VALUES(?,1,?) ON CONFLICT(id) DO UPDATE SET count=CASE WHEN ?-since>=? THEN 1 ELSE count+1 END,since=CASE WHEN ?-since>=? THEN ? ELSE since END RETURNING count').bind(key,now,now,window,now,window,now).first();
 if(row.count>max)throw new RequestError('Prea multe încercări. Reîncearcă în 15 minute.',429);
}
export async function requestSource(req:Request){return digest(req.headers.get('cf-connecting-ip')||req.headers.get('oai-authenticated-user-id')||'unknown')}
