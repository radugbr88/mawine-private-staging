import {pushConfigured,pushEndpoint,decode64,sendPush,type PushEnv} from './web-push';
import {RequestError,rateLimit} from './security';
import {billingSummary} from './billing';
import {dueReminders} from './subscription';
import {parseLanguage,translateForLanguage} from './i18n';
const response=(body:unknown)=>Response.json(body,{headers:{'Cache-Control':'no-store'}});
export async function pushAction(db:D1Database,env:PushEnv,p:any,identity:string,action:string,body:any){
 const q=(sql:string,...args:any[])=>db.prepare(sql).bind(...args);
 if(action==='pushConfig')return response({enabled:pushConfigured(env),publicKey:pushConfigured(env)?env.MAWINE_PUSH_PUBLIC_KEY:null,subscribed:!!await q('SELECT id FROM push_subscriptions WHERE identity=? AND profile_id=?',identity,p.id).first()});
 if(action==='pushDisable'){await q('DELETE FROM push_subscriptions WHERE identity=? AND profile_id=?',identity,p.id).run();return response({ok:true})}
 if(!pushConfigured(env))throw new RequestError('Notificările push nu sunt configurate.',503);
 await rateLimit(db,'push:'+p.id,20);
 if(action==='pushSubscribe'){
  const sub=body.subscription;try{pushEndpoint(sub?.endpoint);if(decode64(sub.keys.p256dh).length!==65||decode64(sub.keys.auth).length!==16)throw Error();await crypto.subtle.importKey('raw',decode64(sub.keys.p256dh),{name:'ECDH',namedCurve:'P-256'},false,[])}catch{throw new RequestError('Abonarea la notificări nu este validă.')}
  const existing:any=await q('SELECT id,profile_id,identity FROM push_subscriptions WHERE endpoint=?',sub.endpoint).first();
  if(existing?.profile_id===p.id&&existing?.identity===identity){await q('UPDATE push_subscriptions SET p256dh=?,auth=? WHERE id=?',sub.keys.p256dh,sub.keys.auth,existing.id).run();return response({ok:true})}
  const count:any=await q('SELECT COUNT(*) AS n FROM push_subscriptions WHERE profile_id=?',p.id).first();if(count.n>=10)throw new RequestError('Maximum 10 dispozitive pentru notificări.');
  // One browser endpoint belongs to the currently signed-in profile only.
  await db.batch([q('DELETE FROM push_subscriptions WHERE identity=?',identity),q('DELETE FROM push_subscriptions WHERE endpoint=?',sub.endpoint),q('INSERT INTO push_subscriptions(id,profile_id,identity,endpoint,p256dh,auth,next_check,created_at) VALUES(?,?,?,?,?,?,?,?)',crypto.randomUUID(),p.id,identity,sub.endpoint,sub.keys.p256dh,sub.keys.auth,Date.now(),Date.now())]);
  return response({ok:true});
 }
 if(action==='pushTest'){
  // Fresh bucket: failed attempts from the unsupported v1 transport must not block this fix.
  await rateLimit(db,'push-test-delivery:'+p.id,3);
  const sub:any=await q('SELECT * FROM push_subscriptions WHERE profile_id=? AND identity=?',p.id,identity).first();if(!sub)throw new RequestError('Activează notificările pe acest dispozitiv.');
  let result:Response;
  try{result=await sendPush(env,sub,{title:'Mawine',body:translateForLanguage(parseLanguage(p.language),'Notificările sunt acum active.'),url:'/',tag:'mawine-activation'})}
  catch(e){console.error('push_test_transport_failed',e instanceof Error&&['TypeError','SyntaxError','AbortError','TimeoutError','DataError','OperationError'].includes(e.name)?e.name:'Error');throw new RequestError('Notificarea nu a putut fi trimisă. Încearcă din nou.',503)}
  if(!result.ok)console.error('push_test_provider_rejected',result.status);
  if(result.status===404||result.status===410)await q('DELETE FROM push_subscriptions WHERE id=?',sub.id).run();
  if(!result.ok)throw new RequestError('Notificarea nu a putut fi trimisă. Încearcă din nou.',503);
  return response({ok:true});
 }
 throw new RequestError('Cerere nepermisă.');
}
// Bounded batches; next_check also acts as a lease against concurrent cron/request runs.
export async function dispatchPush(db:D1Database,env:PushEnv,limit=25){
 if(!pushConfigured(env))return {configured:false,sent:0};
 const q=(sql:string,...args:any[])=>db.prepare(sql).bind(...args),now=Date.now();let sent=0;
 await q('DELETE FROM push_deliveries WHERE sent_at<?',now-7*86400000).run();
 await q('DELETE FROM push_subscriptions WHERE NOT EXISTS(SELECT 1 FROM identities i JOIN guest_sessions s ON i.identity=\'guest:\'||s.id WHERE i.identity=push_subscriptions.identity AND i.profile_id=push_subscriptions.profile_id AND s.expires>?)',now).run();
 const rows=(await q('SELECT s.* FROM push_subscriptions s JOIN profiles p ON p.id=s.profile_id WHERE s.next_check<=? AND p.blocked=0 ORDER BY s.next_check LIMIT ?',now,limit).all()).results as any[];
 for(const sub of rows){
  const claimed=await q('UPDATE push_subscriptions SET next_check=? WHERE id=? AND next_check<=?',now+3600000,sub.id,now).run();if(!claimed.meta.changes)continue;
  try{
   const p:any=await q('SELECT * FROM profiles WHERE id=? AND blocked=0',sub.profile_id).first();if(!p)continue;
   const billing=await billingSummary(db,env,p);if(billing.complimentaryUntil)continue;
   const reminder=dueReminders(p,billing.subscription,now).find(r=>['trial-ending','paid-ending','payment-grace'].includes(r.kind));if(!reminder)continue;
   const t=(s:string)=>translateForLanguage(parseLanguage(p.language),s);
   const message=reminder.kind==='payment-grace'?`Ziua ${reminder.graceDay} din 3 de grație. Alege un abonament pentru a rămâne gazdă.`:reminder.kind==='paid-ending'?`Abonamentul expiră în ${reminder.remainingDays} zile. Verifică abonamentul.`:'Alege abonamentul pentru continuarea accesului după perioada gratuită.';
   const reserved=await q('INSERT OR IGNORE INTO push_deliveries(subscription_id,day,kind,sent_at) VALUES(?,?,?,?)',sub.id,reminder.day,reminder.kind,now).run();if(!reserved.meta.changes)continue;
   try{
    const r=await sendPush(env,sub,{title:'Mawine',body:t(message),url:'/?notification=subscription',tag:'mawine-subscription-'+reminder.day});
    if(r.status===404||r.status===410)await q('DELETE FROM push_subscriptions WHERE id=?',sub.id).run();
    else if(!r.ok)throw Error('Push provider rejected');else sent++;
   }catch{await q('DELETE FROM push_deliveries WHERE subscription_id=? AND day=? AND kind=?',sub.id,reminder.day,reminder.kind).run();await q('UPDATE push_subscriptions SET next_check=? WHERE id=?',now+900000,sub.id).run()}
  }catch{console.error('push_dispatch_failed')}
 }
 return {configured:true,sent,checked:rows.length};
}
