'use client';
import {t as translate,locale} from './i18n';
import {useEffect,useRef,useState} from 'react';
import {Check,LockKeyhole,ArrowRight} from 'lucide-react';
export function EmailRecoveryForm({email='',onSave,onLater,requirePassword=false}:{email?:string;onSave:(email:string,current?:string)=>Promise<boolean>;onLater?:()=>void;requirePassword?:boolean}){
 const [value,setValue]=useState(email),[saving,setSaving]=useState(false),[error,setError]=useState('');
 return <form className="emailRecoveryForm" onSubmit={async e=>{e.preventDefault();setSaving(true);setError('');try{if(!await onSave(value.trim(),String(new FormData(e.currentTarget).get('current')||'')))setError('Adresa nu a fost salvată. Verifică adresa și conexiunea, apoi reîncearcă.')}finally{setSaving(false)}}}>
 <label className="field"><span>{translate("Adresă de e-mail")}</span><input type="email" name="email" autoComplete="email" maxLength={254} required placeholder={translate("exemplu@email.com")} value={value} onChange={e=>setValue(e.target.value)}/></label>
 {requirePassword&&<label className="field"><span>{translate("Parola actuală")}</span><input type="password" name="current" autoComplete="current-password" required maxLength={200}/></label>}
 <p className="emailPrivacy"><LockKeyhole size={18}/>{translate(" Adresa este destinată recuperării parolei.")}</p>
 <p className="emailAvailability">{translate("Recuperarea prin e-mail nu este încă activă. Adresa va fi păstrată în profil.")}</p>
 {translate(error&&<p role="alert" className="alert">{translate(error)}</p>)}
 <button className="btn full" type="submit" disabled={saving}>{translate(saving?'Se salvează…':'Salvează adresa de e-mail')} <ArrowRight size={18}/></button>
 {translate(onLater&&<button className="textbtn emailLater" type="button" disabled={saving} onClick={onLater}>{translate("Mai târziu")}</button>)}
 </form>
}
export function EmailRecoveryPrompt({onSave,onContinue}:{onSave:(email:string)=>Promise<boolean>;onContinue:()=>void}){
 const ref=useRef<HTMLDialogElement>(null);
 useEffect(()=>{ref.current?.showModal();const overflow=document.body.style.overflow;document.body.style.overflow='hidden';return()=>{ref.current?.close();document.body.style.overflow=overflow}},[]);
 return <dialog ref={ref} className="recoveryPrompt" aria-labelledby="email-prompt-title" onCancel={e=>{e.preventDefault();onContinue()}}><div className="recoveryPromptContent"><span className="recoverySuccess" aria-hidden="true"><Check size={32}/></span><strong className="recoveryCreated">{translate("Contul tău a fost creat")}</strong><h2 id="email-prompt-title">{translate("Recuperează ușor parola")}</h2><p>{translate("Adaugă adresa ta de e-mail pentru recuperarea parolei.")}</p><EmailRecoveryForm onSave={async email=>{const saved=await onSave(email);if(saved)onContinue();return saved}} onLater={onContinue}/><p className="recoveryLocation">{translate("Poți adăuga sau modifica adresa în Profil → Cont și preferințe.")}</p></div></dialog>
}
