import {countries} from './lib';
import grapeData from './grape-data.json';
import {importGrapes,type WineImportGroup} from './wine-import';
export const importFields={ignore:'Ignoră',winery:'Cramă',name:'Vin',year:'An',country:'Țara',grapes:'Soiuri',type:'Tip',alcohol:'Alcool',price:'Preț',event:'Nr. degustare',date:'Data degustării'} as const;
export type ImportField=keyof typeof importFields;
export type ImportMapping={fields:ImportField[];start:number};
const key=(v:unknown)=>String(v??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]/g,'');
const text=(v:unknown)=>v instanceof Date?v.toISOString().slice(0,10):String(v??'').trim();
const number=(v:unknown)=>Number(text(v).replace(/\s*(%|RON|LEI|EUR|EURO|€|\$)\s*$/i,'').replace(',','.'));
const countryKeys=new Set([...countries.map(key),'africades','nzeelanda','mbritanie','southafrica','usa']);
const grapeKeys=new Set(grapeData.flatMap(g=>[g.name,...g.aliases]).map(key));
const isGrape=(v:unknown)=>{const gs=importGrapes(v);return gs.length>0&&gs.every(g=>grapeKeys.has(key(g))||(gs.length===1&&key(g)!==key(v)&&/^[\p{L}. ]{1,8}$/u.test(text(v))));};
const isYear=(v:unknown)=>/^(NV|N\/V)$/i.test(text(v))||(/^\d{4}$/.test(text(v))&&number(v)>=1900&&number(v)<=new Date().getFullYear());
export function importDate(v:unknown):string{
 const s=text(v);let parts=s.match(/^(\d{4})-(\d{2})-(\d{2})(?:T.*)?$/);let iso=parts?`${parts[1]}-${parts[2]}-${parts[3]}`:'';
 if(!iso){parts=s.match(/^(\d{1,2})[./](\d{1,2})[./](\d{4})$/);if(parts)iso=`${parts[3]}-${parts[2].padStart(2,'0')}-${parts[1].padStart(2,'0')}`;}
 if(!iso)return '';const d=new Date(iso+'T12:00:00Z');return !Number.isNaN(d.getTime())&&d.toISOString().slice(0,10)===iso?iso:'';
}
export function detectImportColumns(rows:unknown[][]):ImportMapping{
 const start=rows.findIndex(r=>r.filter(v=>text(v)).length>=3);const from=Math.max(0,start);
 const width=Math.max(0,...rows.map(r=>r.length));const fields:ImportField[]=Array(width).fill('ignore');
 const sample=rows.slice(from).filter(r=>r.filter(v=>text(v)).length>=3).slice(0,150);
 const cols=fields.map((_,i)=>sample.map(r=>r[i]).filter(v=>text(v)));
 const ratio=(vs:unknown[],fn:(v:unknown)=>boolean)=>vs.length?vs.filter(fn).length/vs.length:0;
 const assign=(field:ImportField,score:(vs:unknown[])=>number,threshold=.75)=>{
  const candidates=cols.map((vs,i)=>({i,score:fields[i]==='ignore'&&vs.length>=2?score(vs):0})).sort((a,b)=>b.score-a.score);
  if(candidates[0]?.score>=threshold){fields[candidates[0].i]=field;}
 };
 assign('date',vs=>ratio(vs,v=>!!importDate(v)));
 assign('country',vs=>ratio(vs,v=>countryKeys.has(key(v))));
 assign('type',vs=>ratio(vs,v=>/^(alb|rosu|rose|roze|white|red|pink|spumant|brut|sec|demisec|demidulce|dulce|albsec|rosusec|sparkling)$/.test(key(v))));
 assign('grapes',vs=>ratio(vs,isGrape));
 assign('year',vs=>ratio(vs,isYear));
 assign('alcohol',vs=>ratio(vs,v=>number(v)>0&&number(v)<=22&&!isYear(v))*(vs.some(v=>/%/.test(text(v))||number(v)%1!==0)?1:.6));
 assign('price',vs=>ratio(vs,v=>number(v)>0&&number(v)<10000&&!isYear(v))*(vs.some(v=>number(v)>22||/RON|LEI|EUR|€|\$/i.test(text(v)))?1:.5));
 // Sparse, consecutive event numbers are distinct from a numbered row for every wine.
 assign('event',vs=>{const nums=vs.map(number);return nums.length<sample.length*.65&&nums.every((n,i)=>Number.isInteger(n)&&n>0&&(!i||n===nums[i-1]+1))?1:0;});
 const remaining=cols.map((vs,i)=>({i,vs})).filter(c=>fields[c.i]==='ignore'&&ratio(c.vs,v=>/[\p{L}]/u.test(text(v))&&!isYear(v))>.8&&ratio(c.vs,v=>/^(sec|brut|demisec|demidulce|dulce|alb|rosu|rose|roze)$/.test(key(v)))<.6&&c.vs.length>=Math.max(2,sample.length*.4));
 const wineryScore=(c:typeof remaining[number])=>ratio(c.vs,v=>/^(crama|domaine|dom\.|ch[âa]teau|ch\.|winery|quinta|bodega|weingut|tenuta)\b/i.test(text(v)))*3+(1-new Set(c.vs.map(key)).size/c.vs.length)*.25;
 const winery=[...remaining].sort((a,b)=>wineryScore(b)-wineryScore(a))[0];
 if(remaining.length>=2&&winery){fields[winery.i]='winery';const name=remaining.find(c=>c.i!==winery.i);if(name)fields[name.i]='name';}
 else if(remaining.length===1)fields[remaining[0].i]='name';
 return{fields,start:from};
}
export function mapImportRows(rows:unknown[][],mapping:ImportMapping):{rows:unknown[][];groups:WineImportGroup[]}{
 const {fields,start}=mapping;
 if(!fields.includes('name')&&!fields.includes('winery'))throw Error('Alege coloana pentru vin sau cramă.');
 if(fields.some(f=>f!=='ignore'&&f!=='grapes'&&fields.filter(x=>x===f).length>1))throw Error('Alege o singură coloană pentru fiecare câmp.');
 const wineFields=fields.filter(f=>!['ignore','event','date'].includes(f));const header=wineFields.map(f=>importFields[f]);
 const output:unknown[][]=[header],groups:WineImportGroup[]=[];let current:WineImportGroup|undefined;
 for(const row of rows.slice(start)){
  const values=row.map(text);if(!values.some(Boolean))continue;
  const marker=values[fields.indexOf('event')]||'';const event=/^\d+$/.test(marker)?marker:'';const d=importDate(row[fields.indexOf('date')]);
  const mapped=fields.flatMap((f,i)=>['ignore','event','date'].includes(f)?[]:[row[i]??'']);
  if(!mapped.some(v=>text(v)))continue;
  if((event&&event!==current?.number)||(d&&d!==current?.date)||!current){current={number:event||String(groups.length+1),date:d,rows:[header]};groups.push(current)}
  current.rows.push(mapped);output.push(mapped);
 }
 return{rows:output,groups:fields.includes('event')||fields.includes('date')?groups:[]};
}
