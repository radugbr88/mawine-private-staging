import type {CatalogWine} from './lib';
// Factual reference entries checked against the linked Vivino pages on 2026-10-29.
// General wine listings do not identify a bottle vintage: year/alcohol/price are deliberately blank.
const rows:[string,string,string,string,string[],string,string][]=[
 ['1984742','Chateau Purcari','Negru de Purcari','Republica Moldova',['Cabernet Sauvignon','Rară Neagră','Saperavi'],'Roșu sec','https://www.vivino.com/en/chateau-purcari-negru-de-purcari/w/1984742'],
 ['1195071','Chateau Purcari','1827 Rară Neagră','Republica Moldova',['Rară Neagră'],'Roșu sec','https://www.vivino.com/en/chateau-purcari-eighteen-twentyseven-rara-neagra/w/1195071'],
 ['2396038','SERVE','Terra Romana Fetească Neagră','România',['Fetească Neagră'],'Roșu','https://www.vivino.com/en/serve-terra-romana-feteasca-neagra/w/2396038?year=2022'],
 ['1240582','SERVE','Terra Romana Milenium Red','România',['Fetească Neagră','Cabernet Sauvignon','Merlot'],'Roșu','https://www.vivino.com/en/serve-terra-romana-milenium-red/w/1240582'],
 ['1233166','Lacerta','Cuvée IX','România',['Cabernet Sauvignon','Merlot','Fetească Neagră'],'Roșu','https://www.vivino.com/en/lacerta-cuvee-ix/w/1233166'],
 ['10906932','Lacerta','The Vintage Collection Fetească Neagră','România',['Fetească Neagră'],'Roșu','https://www.vivino.com/GB/en/lacerta-the-vintage-collection-feteasca-neagra/w/10906932'],
 ['3745978','Budureasca','Premium Sauvignon Blanc Sec','România',['Sauvignon Blanc'],'Alb sec','https://www.vivino.com/en/budureasca-premium-sauvignon-blanc-sec-dealu-mare/w/3745978'],
 ['1752473','Budureasca','Premium Fumé Sec','România',['Chardonnay','Sauvignon Blanc','Pinot Grigio'],'Alb sec','https://www.vivino.com/en/budureasca-premium-fume-sec-dealu-mare/w/1752473'],
 ['1243140','Sole de Recaș','Chardonnay Barrique','România',['Chardonnay'],'Alb','https://www.vivino.com/en/sole-de-recas-chardonnay-barrique/w/1243140'],
 ['1817852','Sole de Recaș','Chardonnay – Fetească Regală','România',['Chardonnay','Fetească Regală'],'Alb','https://www.vivino.com/en/sole-de-recas-chardonnay-feteasca-regala/w/1817852'],
 ['9490178','Sole de Recaș','Chardonnay – Tămâioasă Românească','România',['Chardonnay','Tămâioasă Românească'],'Alb','https://www.vivino.com/en/sole-de-recas-chardonnay-tamaioasa-romaneasca/w/9490178'],
 ['5404598','Sole de Recaș','Orange Wine','România',['Chardonnay','Viognier'],'Orange','https://www.vivino.com/en/sole-de-recas-orange-wine/w/5404598']
];
export const catalogSeed:CatalogWine[]=rows.map(([id,winery,name,country,grapes,type,sourceUrl])=>({id:'vivino-'+id,winery,name,country,grapes,type,year:id==='2396038'?2022:null,alcohol:id==='2396038'?'14,5':'',price:'',sourceUrl,checkedAt:'2026-10-29',region:country==='Republica Moldova'?'Ștefan Vodă':winery==='Sole de Recaș'?'Recaș':'Dealu Mare'}));
