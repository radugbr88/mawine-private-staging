// Server-only Stripe Billing integration. No secret or provider payload is returned to clients.
import Stripe from 'stripe';
import {validatePromotion,PromotionError} from './promotions';
import {trialStart,trialStatus,subscriptionAccess} from './subscription';
export type BillingEnv=Record<string,unknown>;
export type BillingProfile={id:string;username?:string|null;host?:number|boolean;blocked?:number;language?:string|null;trial_started_at?:number|null};
export const STRIPE_EVENTS=['checkout.session.completed','checkout.session.async_payment_succeeded','checkout.session.async_payment_failed','checkout.session.expired','customer.subscription.created','customer.subscription.updated','customer.subscription.deleted','customer.subscription.paused','customer.subscription.resumed','invoice.paid','invoice.payment_failed','invoice.payment_action_required','charge.refunded','charge.dispute.created','charge.dispute.closed','radar.early_fraud_warning.created'] as const;
export class BillingError extends Error {constructor(message:string,public status=400){super(message)}}
const busy=()=>new BillingError('O operație de facturare este în curs. Reîncearcă.',409);
const unavailable=()=>new BillingError('Plățile nu sunt încă disponibile. Reîncearcă mai târziu.',503);
export function billingConfig(e:BillingEnv){
 const mode=e.STRIPE_MODE;if(mode!=='test'&&mode!=='live')return null;
 if(mode==='live'&&e.STRIPE_LIVE_ENABLED!=='true')return null;
 const key=String(e.STRIPE_SECRET_KEY||''),account=String(e.STRIPE_ACCOUNT_ID||''),webhook=String(e.STRIPE_WEBHOOK_SECRET||'');
 if(!key.startsWith('rk_'+mode+'_')&&!key.startsWith('sk_'+mode+'_'))return null;
 if(!/^acct_[A-Za-z0-9]+$/.test(account)||!webhook.startsWith('whsec_'))return null;
 const prices={monthly:String(e.STRIPE_PRICE_MONTHLY||''),annual:String(e.STRIPE_PRICE_ANNUAL||'')};
 if(!Object.values(prices).every(p=>/^price_[A-Za-z0-9]+$/.test(p))||prices.monthly===prices.annual)return null;
 try{const u=new URL(String(e.MAWINE_PUBLIC_ORIGIN||''));if(u.protocol!=='https:'||u.username||u.password||u.pathname!=='/'||u.search||u.hash)return null;
 return{mode,key,account,webhook,prices,origin:u.origin,portal:String(e.STRIPE_PORTAL_CONFIGURATION_ID||''),testUsers:String(e.STRIPE_TEST_USERNAMES||'').toLowerCase().split(',').map(s=>s.trim()).filter(Boolean)};
 }catch{return null}
}
export async function resolvedBillingConfig(db:D1Database,e:BillingEnv){const c=billingConfig(e);if(!c)return null;const rows:any[]=(await db.prepare('SELECT id,plan,amount FROM managed_prices WHERE environment=? AND account=? AND active=1 ORDER BY created_at').bind(c.mode,c.account).all()).results as any[];for(const row of rows)if(row.plan==='monthly'||row.plan==='annual')c.prices[row.plan as 'monthly'|'annual']=row.id;return c}
export async function saleAmounts(db:D1Database,c:ReturnType<typeof billingConfig>){const amounts={monthly:999,annual:9900};if(c){const rows:any[]=(await db.prepare('SELECT plan,amount FROM managed_prices WHERE environment=? AND account=? AND active=1 ORDER BY created_at').bind(c.mode,c.account).all()).results as any[];for(const row of rows)if(row.plan==='monthly'||row.plan==='annual')amounts[row.plan as 'monthly'|'annual']=row.amount}return amounts}
export type BillingConfig=NonNullable<ReturnType<typeof billingConfig>>;
export const stripeClient=(c:BillingConfig)=>new Stripe(c.key,{apiVersion:'2026-09-30.endive',httpClient:Stripe.createFetchHttpClient(),timeout:10000,maxNetworkRetries:1});
const id=(o:any):string=>typeof o==='string'?o:o?.id||'';
const q=(db:D1Database,sql:string,...args:any[])=>db.prepare(sql).bind(...args);
const scope=(c:BillingConfig)=>[c.mode,c.account];
const locale=(p:BillingProfile)=>['ro','en','it','fr'].includes(p.language||'')?p.language as 'ro'|'en'|'it'|'fr':'en';
export function billingAllowed(c:BillingConfig,p:BillingProfile){return c.mode==='live'||c.testUsers.includes((p.username||'').toLowerCase())}
export async function billingLock(db:D1Database,profileId:string){
 const owner=crypto.randomUUID(),now=Date.now(),key='billing:'+profileId;
 const result=await q(db,'INSERT INTO billing_locks(id,owner,expires_at) VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET owner=excluded.owner,expires_at=excluded.expires_at WHERE billing_locks.expires_at<?',key,owner,now+300000,now).run();
 if(result.meta.changes!==1)throw busy();
 return{assert:async()=>{if(!await q(db,'SELECT id FROM billing_locks WHERE id=? AND owner=? AND expires_at>?',key,owner,Date.now()).first())throw busy()},release:()=>q(db,'DELETE FROM billing_locks WHERE id=? AND owner=?',key,owner).run()};
}
async function customer(db:D1Database,c:BillingConfig,p:BillingProfile,s:Stripe){
 let row:any=await q(db,"SELECT * FROM billing_customers WHERE profile_id=? AND provider='stripe' AND environment=? AND provider_account_id=?",p.id,...scope(c)).first();
 if(row)return row.provider_customer_id as string;
 // Persist a stable creation key before contacting Stripe; never blindly retry beyond its retention window.
 const key='customer:'+c.mode+':'+c.account+':'+p.id;
 await q(db,'INSERT OR IGNORE INTO billing_operations(id,created_at) VALUES(?,?)',key,Date.now()).run();
 const op:any=await q(db,'SELECT created_at FROM billing_operations WHERE id=?',key).first();
 if(Date.now()-op.created_at>23*3600000)throw unavailable();
 const created=await s.customers.create({preferred_locales:[locale(p)]},{idempotencyKey:key});
 if(created.livemode!==(c.mode==='live'))throw unavailable();
 await q(db,"INSERT INTO billing_customers(id,profile_id,provider,environment,provider_account_id,provider_customer_id,created_at,updated_at) VALUES(?,?,'stripe',?,?,?,?,?)",crypto.randomUUID(),p.id,...scope(c),created.id,Date.now(),Date.now()).run();return created.id;
}
async function verifyAccount(c:BillingConfig,s:Stripe){const a=await s.accounts.retrieve(c.account);if(a.id!==c.account)throw unavailable()}
export async function billingSummary(db:D1Database,e:BillingEnv,p:BillingProfile){
 const c=await resolvedBillingConfig(db,e),trial=trialStatus(trialStart(p)??Date.now());
 const grant:any=await q(db,'SELECT expires_at FROM complimentary_access WHERE profile_id=? AND expires_at>?',p.id,Date.now()).first();
 const complimentaryUntil=grant?.expires_at??null;
 if(!c){const grace=subscriptionAccess(trial.startedAt,null);return{enabled:false,mode:'off',hasCustomer:false,subscription:null,grace,complimentaryUntil,hostAccess:!!p.host&&!p.blocked&&(!!complimentaryUntil||(grace.hostAccess&&e.STRIPE_ENFORCE_ACCESS!=='true'))};}
 const row:any=await q(db,"SELECT * FROM billing_subscriptions WHERE profile_id=? AND provider='stripe' AND environment=? AND provider_account_id=? ORDER BY CASE WHEN provider_status NOT IN ('canceled','incomplete_expired') THEN 0 ELSE 1 END,updated_at DESC LIMIT 1",p.id,...scope(c)).first();
 const hasCustomer=!!await q(db,"SELECT id FROM billing_customers WHERE profile_id=? AND provider='stripe' AND environment=? AND provider_account_id=?",p.id,...scope(c)).first();
 const paid=!!row&&row.access_expires_at>Date.now()&&!row.risk_blocked&&['active','past_due','canceled','unpaid'].includes(row.provider_status);
 const grace=subscriptionAccess(trial.startedAt,row?.access_expires_at,Date.now(),!!row?.risk_blocked);
 // Stripe calls an anchored subscription active before its first invoice. It is still our free period.
 const status=row?.provider_status==='active'&&!row.access_expires_at&&trial.active?'trialing':row?.provider_status;
 return{prices:await saleAmounts(db,c),enabled:!!c.portal&&billingAllowed(c,p),mode:c.mode,hasCustomer,grace,complimentaryUntil,hostAccess:!!p.host&&!p.blocked&&!row?.risk_blocked&&(!!complimentaryUntil||grace.hostAccess),subscription:row?{amount:(await q(db,'SELECT amount FROM managed_prices WHERE id=? AND environment=? AND account=?',row.provider_price_id,...scope(c)).first<any>())?.amount??(row.billing_interval==='annual'?9900:999),plan:row.billing_interval,status,paid,accessUntil:row.access_expires_at,periodEnd:row.current_period_end,cancelAtPeriodEnd:!!row.cancel_at_period_end,riskBlocked:!!row.risk_blocked}:null};
}
export async function enforceHostAccess(db:D1Database,e:BillingEnv,p:BillingProfile){if(!p.host)throw new BillingError('Activează contul de gazdă.');if((await billingSummary(db,e,p)).hostAccess===false)throw new BillingError('Ai nevoie de un abonament activ pentru această acțiune.',402)}
export async function billingAction(db:D1Database,e:BillingEnv,p:BillingProfile,action:string,plan?:unknown,client?:Stripe,promotionCode?:unknown){
 const c=await resolvedBillingConfig(db,e);if(!c||!c.portal||!billingAllowed(c,p))throw unavailable();
 if(!p.host||!p.username||p.blocked)throw new BillingError('Activează contul de gazdă.',403);
 if(action==='stripeCheckout'&&plan!=='monthly'&&plan!=='annual')throw new BillingError('Selecție invalidă.');
 const lock=await billingLock(db,p.id);
 try{
  const current:any=await q(db,'SELECT * FROM profiles WHERE id=?',p.id).first();if(!current||current.blocked||!current.host)throw unavailable();
  const s=client??stripeClient(c);await verifyAccount(c,s);
  const rateId='billing-rate:'+p.id,now=Date.now();
  await q(db,'INSERT INTO attempts(id,count,since) VALUES(?,1,?) ON CONFLICT(id) DO UPDATE SET count=CASE WHEN ?-since>900000 THEN 1 ELSE count+1 END,since=CASE WHEN ?-since>900000 THEN ? ELSE since END',rateId,now,now,now,now).run();
  const attempts:any=await q(db,'SELECT count FROM attempts WHERE id=?',rateId).first();if(attempts.count>20)throw new BillingError('Prea multe încercări. Reîncearcă în 15 minute.',429);
  const customerId=await customer(db,c,current,s);
  await lock.assert();
  if(action==='stripePortal'){
   if(!c.portal)throw unavailable();
   const config=await s.billingPortal.configurations.retrieve(c.portal);
   const features=config.features;
   if(!config.active||!features.subscription_cancel.enabled||features.subscription_cancel.mode!=='at_period_end'||!features.subscription_update.enabled||features.subscription_update.proration_behavior!=='always_invoice'||features.subscription_update.billing_cycle_anchor!=='now'||!features.subscription_update.default_allowed_updates.includes('price')||features.subscription_update.schedule_at_period_end.conditions.length!==1||features.subscription_update.schedule_at_period_end.conditions[0].type!=='shortening_interval'||!features.subscription_update.products?.some(product=>product.prices.includes(c.prices.monthly)&&product.prices.includes(c.prices.annual)))throw new BillingError('Configurarea portalului de abonamente trebuie actualizată.',503);
   const session=await s.billingPortal.sessions.create({customer:customerId,configuration:c.portal,locale:locale(current),return_url:c.origin+'/?billing=portal'});
   return{billingUrl:session.url};
  }
  const grant:any=await q(db,'SELECT expires_at FROM complimentary_access WHERE profile_id=? AND expires_at>?',p.id,Date.now()).first();
  if(grant)throw new BillingError('Accesul gratuit este deja activ.');
  if(action==='applyPromotion'){
   const prices=await Promise.all([s.prices.retrieve(c.prices.monthly),s.prices.retrieve(c.prices.annual)]);
   const start=trialStart(current),initialAmount=start&&trialStatus(start).active?0:undefined;
   const promotion=await validatePromotion(s,promotionCode,customerId,prices,c.mode==='live',initialAmount);
   return {promotion:{code:promotion.code}};
  }
  const subscriptions=await s.subscriptions.list({customer:customerId,status:'all',limit:100});
  if(subscriptions.has_more||subscriptions.data.some(x=>!['canceled','incomplete_expired'].includes(x.status)))throw new BillingError('Ai deja un abonament. Folosește Gestionare abonament.');
  const priceId=c.prices[plan as 'monthly'|'annual'];
  const price=await s.prices.retrieve(priceId);
  if(!price.active||price.livemode!==(c.mode==='live')||price.currency!=='usd'||price.unit_amount!==(await saleAmounts(db,c))[plan as 'monthly'|'annual']||price.recurring?.interval!==(plan==='monthly'?'month':'year')||price.recurring.interval_count!==1)throw unavailable();
  const promotion=promotionCode?await validatePromotion(s,promotionCode,customerId,[price],c.mode==='live',trialStatus(trialStart(current)??0).active?0:undefined):null;
  let attempt:any=await q(db,'SELECT * FROM billing_checkouts WHERE profile_id=? AND environment=? AND provider_account_id=?',p.id,...scope(c)).first();
  // Recover a timed-out creation with its frozen key before changing any parameters.
  const discountId=(params:string)=>JSON.parse(params).discounts?.[0]?.promotion_code??null;
  if(attempt&&!attempt.session_id&&(attempt.plan!==plan||discountId(attempt.params)!==(promotion?.id??null))){
   if(Date.now()-attempt.created_at>23*3600000)throw unavailable();
   const recovered=await s.checkout.sessions.create(JSON.parse(attempt.params),{idempotencyKey:attempt.id});
   await q(db,'UPDATE billing_checkouts SET session_id=? WHERE id=?',recovered.id,attempt.id).run();attempt.session_id=recovered.id;
  }
  if(attempt?.session_id){
   const session=await s.checkout.sessions.retrieve(attempt.session_id);
   if(session.status==='complete'&&!subscriptions.data.some(x=>x.id===id(session.subscription)&&['canceled','incomplete_expired'].includes(x.status)))throw new BillingError('Plata se confirmă. Reîncearcă în câteva momente.');
   if(session.status==='open'){
    if(attempt.plan===plan&&discountId(attempt.params)===(promotion?.id??null))return{billingUrl:session.url};
    await s.checkout.sessions.expire(session.id);
   }
   attempt=null;
  }
  if(!attempt){
   const start=trialStart(current),end=start?Math.floor(trialStatus(start).endsAt/1000):0;
   // Checkout trials need 48 hours. A free initial billing period preserves shorter remaining trials.
   const remaining=end-Math.floor(Date.now()/1000);
   const subscriptionData=remaining>0?(remaining<172860?{billing_cycle_anchor:end,proration_behavior:'none' as const}:{trial_end:end}):undefined;
   const params={...(promotion?{discounts:[{promotion_code:promotion.id}]}:{}),mode:'subscription' as const,customer:customerId,client_reference_id:p.id,locale:locale(current),line_items:[{price:priceId,quantity:1}],success_url:c.origin+'/?billing=success',cancel_url:c.origin+'/?billing=cancel',expires_at:Math.floor(Date.now()/1000)+3600,integration_identifier:'mawine_host_'+Array.from(crypto.getRandomValues(new Uint8Array(8)),b=>String.fromCharCode(97+b%26)).join(''),...(subscriptionData?{subscription_data:subscriptionData}:{})};
   attempt={id:crypto.randomUUID(),plan,params:JSON.stringify(params),created_at:Date.now()};
   await q(db,'INSERT INTO billing_checkouts(profile_id,environment,provider_account_id,id,plan,params,created_at,session_id) VALUES(?,?,?,?,?,?,?,NULL) ON CONFLICT(profile_id,environment,provider_account_id) DO UPDATE SET id=excluded.id,plan=excluded.plan,params=excluded.params,created_at=excluded.created_at,session_id=NULL',p.id,...scope(c),attempt.id,plan,attempt.params,attempt.created_at).run();
  }
  if(Date.now()-attempt.created_at>23*3600000)throw unavailable();
  // Parameters are frozen across retries, including locale, period and trial end.
  const session=await s.checkout.sessions.create(JSON.parse(attempt.params),{idempotencyKey:attempt.id});
  await lock.assert();
  await q(db,'UPDATE billing_checkouts SET session_id=? WHERE id=?',session.id,attempt.id).run();
  return{billingUrl:session.url};
 }catch(err){if(err instanceof PromotionError)throw new BillingError(err.message);if(err instanceof BillingError)throw err;throw unavailable()}finally{await lock.release()}
}
// Caller holds the same profile lock as Checkout until profile deletion/downgrade commits.
export async function assertBillingCanClose(db:D1Database,e:BillingEnv,p:BillingProfile){
 const rows=(await q(db,"SELECT * FROM billing_customers WHERE profile_id=?",p.id).all()).results as any[];
 if(!rows.length)return;
 const c=billingConfig(e);if(!c)throw new BillingError('Gestionează și încheie abonamentul înainte de închiderea contului.');
 const s=stripeClient(c);await verifyAccount(c,s);
 for(const row of rows){
  if(row.provider!=='stripe'||row.environment!==c.mode||row.provider_account_id!==c.account)throw new BillingError('Contactează administratorul pentru închiderea facturării.');
  const subs=await s.subscriptions.list({customer:row.provider_customer_id,status:'all',limit:100});
  if(subs.has_more||subs.data.some(x=>!['canceled','incomplete_expired'].includes(x.status)))throw new BillingError('Anulează abonamentul și așteaptă încheierea lui înainte de închiderea contului.');
  const sessions=await s.checkout.sessions.list({customer:row.provider_customer_id,status:'open',limit:100});
  if(sessions.has_more||sessions.data.length)throw new BillingError('Închide sesiunea de plată înainte de închiderea contului.');
  const pending:any=await q(db,'SELECT id FROM billing_checkouts WHERE profile_id=? AND session_id IS NULL',p.id).first();if(pending)throw busy();
 }
}
export async function reconcileSubscription(db:D1Database,c:BillingConfig,s:Stripe,subscriptionId:string,risk?:{invoiceId:string;blocked:boolean;reason:string}){
 const initial=await s.subscriptions.retrieve(subscriptionId);
 const owner:any=await q(db,"SELECT profile_id FROM billing_customers WHERE provider='stripe' AND environment=? AND provider_account_id=? AND provider_customer_id=?",...scope(c),id(initial.customer)).first();
 if(!owner?.profile_id)return;
 const lock=await billingLock(db,owner.profile_id);
 try{
  const sub=await s.subscriptions.retrieve(subscriptionId,{expand:['latest_invoice']});
  if(sub.livemode!==(c.mode==='live')||id(sub.customer)!==id(initial.customer))throw unavailable();
  const item=sub.items.data[0],price=item?.price,historical:any=price?.id?await q(db,'SELECT plan FROM managed_prices WHERE id=? AND environment=? AND account=?',price.id,...scope(c)).first():null,interval=historical?.plan||(price?.id===c.prices.monthly?'monthly':price?.id===c.prices.annual?'annual':null);
  if(sub.items.has_more||sub.items.data.length!==1||!interval||item.quantity!==1)throw new Error('Unsupported subscription');
  const old:any=await q(db,"SELECT * FROM billing_subscriptions WHERE provider='stripe' AND environment=? AND provider_account_id=? AND provider_subscription_id=?",...scope(c),sub.id).first();
  const invoice=typeof sub.latest_invoice==='object'?sub.latest_invoice:null;
  let access=old?.access_expires_at??null;
  // Current authoritative paid invoice must belong to this subscription and cover this period.
  if(invoice?.status==='paid'&&id(invoice.customer)===id(sub.customer)&&id(invoice.parent?.subscription_details?.subscription)===sub.id&&['active','past_due'].includes(sub.status)){
   const lines=await s.invoices.listLineItems(invoice.id,{limit:100});
   const paidEnd=Math.max(0,...lines.data.filter(l=>id(l.pricing?.price_details?.price)===price.id&&id(l.parent?.subscription_item_details?.subscription_item)===item.id&&l.amount>=0).map(l=>l.period.end*1000));
   if(!lines.has_more&&paidEnd>0)access=Math.min(paidEnd,item.current_period_end*1000);
  }
  // Preserve the last verified paid-through date after cancellation or failed renewal.
  if(['incomplete','incomplete_expired'].includes(sub.status))access=null;
  const blocked=risk?risk.blocked:!!old?.risk_blocked;
  await lock.assert();
  await q(db,"INSERT INTO billing_subscriptions(id,profile_id,provider,environment,provider_account_id,provider_subscription_id,provider_customer_id,provider_price_id,plan_key,billing_interval,provider_status,current_period_start,current_period_end,access_expires_at,cancel_at_period_end,canceled_at,ended_at,last_synced_at,created_at,updated_at,risk_blocked,risk_reason) VALUES(?,?,'stripe',?,?,?,?,?,'host',?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(provider,environment,provider_account_id,provider_subscription_id) DO UPDATE SET provider_price_id=excluded.provider_price_id,billing_interval=excluded.billing_interval,provider_status=excluded.provider_status,current_period_start=excluded.current_period_start,current_period_end=excluded.current_period_end,access_expires_at=excluded.access_expires_at,cancel_at_period_end=excluded.cancel_at_period_end,canceled_at=excluded.canceled_at,ended_at=excluded.ended_at,last_synced_at=excluded.last_synced_at,updated_at=excluded.updated_at,risk_blocked=excluded.risk_blocked,risk_reason=excluded.risk_reason",crypto.randomUUID(),owner.profile_id,...scope(c),sub.id,id(sub.customer),price.id,interval,sub.status,item.current_period_start*1000,item.current_period_end*1000,access,sub.cancel_at_period_end?1:0,sub.canceled_at?sub.canceled_at*1000:null,sub.ended_at?sub.ended_at*1000:null,Date.now(),Date.now(),Date.now(),blocked?1:0,risk?.reason??old?.risk_reason??null).run();
 }finally{await lock.release()}
}
export async function processStripeEvent(db:D1Database,c:BillingConfig,event:Stripe.Event,s=stripeClient(c)){
 if(event.livemode!==(c.mode==='live')||event.account)throw new BillingError('Invalid event scope',400);
 if(!(STRIPE_EVENTS as readonly string[]).includes(event.type))return;
 await verifyAccount(c,s);
 const existing:any=await q(db,"SELECT processing_status FROM billing_events WHERE provider='stripe' AND environment=? AND provider_account_id=? AND provider_event_id=?",...scope(c),event.id).first();
 if(existing?.processing_status==='processed')return;
 const object:any=event.data.object;
 await q(db,"INSERT INTO billing_events(provider,environment,provider_account_id,provider_event_id,event_type,provider_object_id,provider_created_at,received_at,processing_status,attempts) VALUES('stripe',?,?,?,?,?,?,?,'pending',1) ON CONFLICT(provider,environment,provider_account_id,provider_event_id) DO UPDATE SET attempts=attempts+1",...scope(c),event.id,event.type,object.id,event.created*1000,Date.now()).run();
 try{
  if(event.type.startsWith('customer.subscription.'))await reconcileSubscription(db,c,s,object.id);
  else if(event.type.startsWith('invoice.')){
   const invoice=await s.invoices.retrieve(object.id);const subscription=id(invoice.parent?.subscription_details?.subscription);if(subscription)await reconcileSubscription(db,c,s,subscription);
  }else if(event.type.startsWith('checkout.')){
   const session=await s.checkout.sessions.retrieve(object.id);
   if(session.livemode!==(c.mode==='live'))throw new Error('Mode mismatch');
   // Checkout is not a payment receipt: reconcile uses the authoritative paid invoice.
   if(id(session.subscription))await reconcileSubscription(db,c,s,id(session.subscription));
  }else{
   const chargeId=event.type==='charge.refunded'?object.id:id(object.charge);
   const charge=await s.charges.retrieve(chargeId);
   const pi=id(charge.payment_intent);if(!pi)throw new Error('Unresolved payment');
   const payments=await s.invoicePayments.list({payment:{type:'payment_intent',payment_intent:pi},limit:100});
   if(payments.has_more)throw new Error('Pagination requires review');
   for(const pay of payments.data){
    const invoice=await s.invoices.retrieve(id(pay.invoice));const sub=id(invoice.parent?.subscription_details?.subscription);if(!sub)continue;
    // Conservative risk policy: record and suspend on full refund, dispute or fraud warning.
    // Partial refunds are recorded without suspension. A won dispute requires manual review
    // before restoration, so a late lifecycle notification cannot accidentally clear a hold.
    const blocked=event.type==='charge.refunded'?charge.refunded:true;
    if(blocked)await reconcileSubscription(db,c,s,sub,{invoiceId:invoice.id,blocked:true,reason:event.type});
    else await reconcileSubscription(db,c,s,sub);
   }
  }
  await q(db,"UPDATE billing_events SET processing_status='processed',processed_at=?,last_error_code=NULL WHERE provider='stripe' AND environment=? AND provider_account_id=? AND provider_event_id=?",Date.now(),...scope(c),event.id).run();
 }catch(err){await q(db,"UPDATE billing_events SET processing_status='failed',last_error_code='RETRY_REQUIRED' WHERE provider='stripe' AND environment=? AND provider_account_id=? AND provider_event_id=?",...scope(c),event.id).run();throw err}
}
