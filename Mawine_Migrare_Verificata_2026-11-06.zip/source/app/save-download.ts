// Keep file previews and download sheets out of the app's browsing context.
export async function saveDownload(blob:Blob,name:string){
 const file=new File([blob],name,{type:blob.type});
 if(navigator.canShare?.({files:[file]})&&navigator.share){
  try{await navigator.share({files:[file]});return}catch(error){
   if((error as DOMException).name==='AbortError')return;
  }
 }
 const url=URL.createObjectURL(blob),link=document.createElement('a');
 link.href=url;link.download=name;link.target='_blank';link.rel='noopener';
 link.hidden=true;document.body.appendChild(link);
 try{link.click()}finally{link.remove();setTimeout(()=>URL.revokeObjectURL(url),60000)}
}
