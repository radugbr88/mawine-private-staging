'use client';
import {t as translate,locale} from './i18n';
import React,{useEffect,useLayoutEffect,useState,useRef,useMemo} from 'react';
import {ChevronDown,Check,X} from 'lucide-react';
import {revealField} from './mobile-ui';
import {displayGrape,grapeKey,grapeChoices} from './grape-names';
const selectionKey=(name:string)=>grapeKey(displayGrape(name));
export function GrapeSelect({value,onChange,disabled=false}:any){
 const root=useRef<HTMLDivElement>(null);const searchInput=useRef<HTMLInputElement>(null);
 const[open,setOpen]=useState(false),[search,setSearch]=useState(''),[color,setColor]=useState(''),[offset,setOffset]=useState(0);
 const filtered=useMemo(()=>{const q=grapeKey(search);return grapeChoices.filter(g=>(!color||(color==='white'?g.color==='BLANC':color==='red'?['NOIR','ROUGE'].includes(g.color):!['BLANC','NOIR','ROUGE'].includes(g.color)))&&[g.name,...g.aliases].some(n=>grapeKey(n).includes(q))).sort((a,b)=>a.name.localeCompare(b.name,'ro'))},[search,color]);
 const items=filtered.slice(offset,offset+10),total=filtered.length;
 useLayoutEffect(()=>{if(open&&root.current)revealField(root.current,true)},[open,offset,search,color]);
 useEffect(()=>{
  if(!open)return;
  const outside=(event:PointerEvent)=>{if(event.target instanceof Node&&!root.current?.contains(event.target))setOpen(false)};
  const escape=(event:KeyboardEvent)=>{if(event.key==='Escape')setOpen(false)};
  document.addEventListener('pointerdown',outside);
  document.addEventListener('keydown',escape);
  return()=>{document.removeEventListener('pointerdown',outside);document.removeEventListener('keydown',escape)};
 },[open]);
 const has=(name:string)=>value.some((v:string)=>selectionKey(v)===selectionKey(name));
 const toggle=(name:string)=>onChange(has(name)?value.filter((v:string)=>selectionKey(v)!==selectionKey(name)):[...value,displayGrape(name)]);
 return <div className="grapes" ref={root}><button type="button" disabled={disabled} className="select" aria-expanded={open} onClick={()=>{if(!open){setSearch('');setColor('');setOffset(0)}setOpen(!open)}}>{translate(value.length?value.join(', '):'Selectează unul sau mai multe soiuri')}<ChevronDown size={18} className={open?'rotate':''}/></button>{translate(open&&<div className="options grapeOptions"><div className="grapeSearch"><input ref={searchInput} type="search" autoComplete="off" autoCorrect="off" spellCheck={false} onKeyDown={e=>{if(e.key==='Enter')e.preventDefault()}} placeholder={translate("Cu sau fără diacritice")} aria-label={translate("Caută un soi, cu sau fără diacritice")} value={search} onChange={e=>{setSearch(e.target.value);setOffset(0)}}/>{translate(search&&<button type="button" className="clearGrapeSearch" aria-label={translate("Șterge căutarea soiului")} onPointerDown={e=>e.preventDefault()} onClick={()=>{setSearch('');setOffset(0);searchInput.current?.focus({preventScroll:true})}}><X size={18}/></button>)}</div><div className="grapeFilters">{translate([['','Toate'],['white','Albe'],['red','Roșii'],['other','Altele']].map(([id,label])=><button type="button" key={id} className={color===id?'active':''} onClick={()=>{setColor(id);setOffset(0)}}>{translate(label)}</button>))}</div>{translate(value.length>0&&<div className="grapeSelected">{translate(value.map((v:string)=><button type="button" disabled={disabled} key={v} onClick={()=>toggle(v)}>{translate(v)}<X size={12}/></button>))}</div>)}{translate(<>{translate(items.map(g=><label key={g.id}><input type="checkbox" disabled={disabled} checked={has(g.name)} onChange={()=>toggle(g.name)}/><span>{g.name}</span></label>))}{translate(!items.length&&<p>{translate("Nu am găsit acest nume în lista de soiuri.")}</p>)}<div className="grapePaging"><button type="button" disabled={!offset} onClick={()=>setOffset(Math.max(0,offset-10))}>{translate("Înapoi")}</button><small>{translate(Math.min(offset+1,total))}{translate("–")}{translate(Math.min(offset+10,total))}{translate(" din ")}{translate(total)}</small><button type="button" disabled={offset+10>=total} onClick={()=>setOffset(offset+10)}>{translate("Mai multe")}</button></div></>)}<div className="grapeSource"><button type="button" className="textbtn" onClick={()=>setOpen(false)}>{translate("Gata ")}<Check size={16}/></button></div></div>)}</div>
}
