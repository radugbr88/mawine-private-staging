import type {Metadata} from 'next';
import './globals.css';
export const metadata:Metadata={title:'Mawine',description:'Vinurile, degustările și descoperirile tale, într-un singur loc.',manifest:'/manifest.webmanifest?v=200',icons:{icon:[{url:'/favicon.ico?v=200'},{url:'/icons/mawine-32.png?v=200',sizes:'32x32',type:'image/png'}],apple:[120,152,167,180].map(size=>({url:`/icons/mawine-${size}.png?v=200`,sizes:`${size}x${size}`,type:'image/png'}))},appleWebApp:{capable:true,title:'Mawine',statusBarStyle:'default'}};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
