import {env} from 'cloudflare:workers';
import {sampleWines} from '../../lib';
export const dynamic='force-dynamic';
// A fixed, clearly labelled demonstration. No user input or existing records are modified.
export async function POST(){try{const db=env.DB;if(!db)return Response.json({error:'Baza de date nu este disponibilă.'},{status:503});await db.batch([
 db.prepare('INSERT OR IGNORE INTO profiles(id,name,dob,gender,recovery) VALUES(?,?,?,?,?)').bind('system-demo-host','Gazdă demo','1990-01-01','',crypto.randomUUID()+crypto.randomUUID()),
 db.prepare('INSERT OR IGNORE INTO events(id,owner,title,date,mode,status,code,wines,revealed) VALUES(?,?,?,?,?,?,?,?,?)').bind('mawine-demo-tasting-2026','system-demo-host','Prima ta degustare · Demo (vinuri fictive)','2026-10-29','normal','active','DEMO2026',JSON.stringify(sampleWines),1),
 db.prepare('INSERT OR IGNORE INTO events(id,owner,title,date,mode,status,code,wines,revealed) VALUES(?,?,?,?,?,?,?,?,?)').bind('mawine-blind-demo-2026','system-demo-host','Descoperă vinul · Demo în orb (vinuri fictive)','2026-10-29','blind','active','ORB2026',JSON.stringify(sampleWines),0)
]);return Response.json({code:'DEMO2026',wines:sampleWines.length,status:'active',fictional:true,blind:{code:'ORB2026',wines:sampleWines.length,mode:'blind',revealed:false}});}catch{return Response.json({error:'Degustarea demo nu a putut fi creată.'},{status:500})}}
