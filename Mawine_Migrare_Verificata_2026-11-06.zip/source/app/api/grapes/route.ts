import {env} from 'cloudflare:workers';
import {grapeKey} from '../../grape-names';
export const dynamic='force-dynamic';
export async function GET(req:Request){try{
 if(!env.DB)return Response.json({error:'Lista de soiuri nu este disponibilă.'},{status:503});
 const url=new URL(req.url);const query=grapeKey((url.searchParams.get('q')||'').slice(0,100));
 const color=url.searchParams.get('color')||'';
 const colors:Record<string,string>={white:"color='BLANC'",red:"color IN ('NOIR','ROUGE')",other:"color NOT IN ('BLANC','NOIR','ROUGE')"};
 const where=`search_key LIKE ?${colors[color]?' AND '+colors[color]:''}`;
 const raw=Number(url.searchParams.get('offset')||0);const offset=Number.isFinite(raw)?Math.max(0,Math.floor(raw)):0;
 const count:any=await env.DB.prepare('SELECT COUNT(*) AS n FROM grape_varieties WHERE '+where).bind('%'+query+'%').first();
 const result=await env.DB.prepare('SELECT id,name,color FROM grape_varieties WHERE '+where+' ORDER BY name,id LIMIT 60 OFFSET ?').bind('%'+query+'%',offset).all();
 return Response.json({items:result.results,total:count.n,source:'University of Adelaide · suprafețe 2016',scope:'common-400',checkedAt:'2026-10-29'},{headers:{'Cache-Control':'no-cache'}});
 }catch{return Response.json({error:'Soiurile nu au putut fi încărcate.'},{status:500})}}
