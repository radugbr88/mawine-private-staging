import {pbkdf2Sync} from 'node:crypto';
import {normalizeEmail,validEmail} from '../../account-security';
import {readJson,RequestError} from '../../security';
import {resetEmailConfig,sendResetEmail} from '../../reset-email';
import {emailTranslator} from '../../email-language';
import {env} from 'cloudflare:workers';
export const dynamic='force-dynamic';
const reply=(data:unknown,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store'}});
const digest=async(s:string)=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)))).map(x=>x.toString(16).padStart(2,'0')).join('');
const random=()=>Array.from(crypto.getRandomValues(new Uint8Array(32))).map(x=>x.toString(16).padStart(2,'0')).join('');
const generic='Dacă există un cont pentru această adresă, vei primi un link valabil o oră. Verifică și folderul Spam.';
async function encodePassword(value:string){const salt='v2$'+crypto.randomUUID();return salt+':'+pbkdf2Sync(value,salt,600000,32,'sha256').toString('hex')}
export async function POST(req:Request){
 try{
 if(req.headers.get('origin')!==new URL(req.url).origin)return reply({error:'Cerere nepermisă.'},403);
 const body=await readJson(req,4096),db=env.DB;if(!db)return reply({error:'Serviciul nu este disponibil.'},503);
 const q=(sql:string,...args:any[])=>db.prepare(sql).bind(...args);
 const now=Date.now();
 const ip=await digest(req.headers.get('cf-connecting-ip')||req.headers.get('oai-authenticated-user-id')||'unknown');
 async function limit(key:string,max:number){const row:any=await q('INSERT INTO password_reset_limits(id,count,since) VALUES(?,1,?) ON CONFLICT(id) DO UPDATE SET count=CASE WHEN ?-since>=3600000 THEN 1 ELSE count+1 END,since=CASE WHEN ?-since>=3600000 THEN ? ELSE since END RETURNING count',key,now,now,now,now).first();return row.count<=max}
 if(!await limit('ip:'+ip,30))return reply({error:'Prea multe încercări. Reîncearcă peste o oră.'},429);
 if(body.action==='request'){
 const config=resetEmailConfig(env as unknown as import('../../reset-email').ResetEmailEnv);
 if(!config)return reply({error:'Trimiterea e-mailurilor de recuperare nu este încă disponibilă. Contactează administratorul.'},503);
 const username=normalizeEmail(body.email??body.username);
 if(!validEmail(username))return reply({error:'Introdu o adresă de e-mail validă.'},400);
 if(!await limit('user:'+await digest(username),3))return reply({message:generic});
 const profile:any=await q('SELECT id,password,primary_email,language FROM profiles WHERE primary_email=? AND username IS NOT NULL AND blocked=0',username).first();
 if(!profile?.primary_email)return reply({message:generic});
 const token=random(),tokenHash=await digest(token);
 await q('DELETE FROM password_resets WHERE expires<=?',now).run();
 await q('INSERT INTO password_resets(token_hash,profile_id,password_snapshot,email_snapshot,expires) VALUES(?,?,?,?,?)',tokenHash,profile.id,profile.password,profile.primary_email,now+3600000).run();
 const translate=emailTranslator(profile.language);
 const link=config.origin+'/#reset='+token;
 try{await sendResetEmail(config,profile.primary_email,translate('Mawine — Resetarea parolei'),translate('Ai solicitat resetarea parolei. Deschide acest link pentru a alege o parolă nouă:')+'\n\n'+link+'\n\n'+translate('Linkul este valabil o oră și poate fi folosit o singură dată. Dacă nu ai solicitat resetarea, ignoră acest mesaj.'))}catch{await q('DELETE FROM password_resets WHERE token_hash=?',tokenHash).run();/* Same response for existing and unknown accounts. */}
 return reply({message:generic});
 }
 if(!['validate','reset'].includes(body.action)||typeof body.token!=='string'||!(/^[a-f0-9]{64}$/).test(body.token))return reply({error:'Linkul este invalid sau a expirat. Solicită un link nou.'},400);
 const tokenHash=await digest(body.token);
 const found:any=await q('SELECT p.id FROM profiles p JOIN password_resets r ON r.profile_id=p.id WHERE r.token_hash=? AND r.expires>? AND p.password=r.password_snapshot AND p.primary_email=r.email_snapshot AND p.blocked=0 AND p.username IS NOT NULL',tokenHash,now).first();
 if(!found)return reply({error:'Linkul este invalid, a expirat sau a fost deja folosit. Solicită un link nou.'},400);
 if(body.action==='validate')return reply({valid:true});
 if(typeof body.password!=='string'||body.password.length<10||body.password.length>200)return reply({error:'Folosește o parolă de 10–200 de caractere.'},400);
 if(body.password!==body.confirm)return reply({error:'Parolele nu coincid.'},400);
 const encoded=await encodePassword(body.password);
 const result=await db.batch([
 q('UPDATE profiles SET password=?,recovery=?,recovery_code=NULL,recovery_cipher=NULL WHERE id=? AND blocked=0 AND username IS NOT NULL AND EXISTS(SELECT 1 FROM password_resets r WHERE r.profile_id=profiles.id AND r.token_hash=? AND r.expires>? AND r.password_snapshot=profiles.password AND r.email_snapshot=profiles.primary_email)',encoded,await digest(random()),found.id,tokenHash,Date.now()),
 q('DELETE FROM identities WHERE profile_id IN(SELECT id FROM profiles WHERE id=? AND password=?)',found.id,encoded),
 q('DELETE FROM password_resets WHERE profile_id IN(SELECT id FROM profiles WHERE id=? AND password=?)',found.id,encoded)
 ]);
 if(!result[0].meta.changes)return reply({error:'Linkul nu mai este valid. Solicită un link nou.'},400);
 return reply({message:'Parola a fost schimbată. Te poți autentifica.'});
 }catch(e){return reply({error:e instanceof RequestError?e.message:'Nu am putut procesa solicitarea. Reîncearcă.'},e instanceof RequestError?e.status:500)}
}
