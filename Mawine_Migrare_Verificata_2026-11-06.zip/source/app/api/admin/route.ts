import {pbkdf2Sync} from 'node:crypto';
import {ADMIN_EMAIL,sendAdminChallenge,confirmAdminChallenge,pendingCookie} from '../../admin-challenge';
import {adminStripe} from '../../admin-stripe';
import {emailFingerprint,type AccountEnv} from '../../account-security';
import {trialStart} from '../../subscription';
import {adminFeatures,complimentaryEligible} from '../../admin-features';
import {readJson,RequestError,rateLimit,requestSource,equalSecret} from '../../security';
import {billingLock,assertBillingCanClose,BillingError} from '../../billing';
import {env} from 'cloudflare:workers';
export const dynamic='force-dynamic';
const json=(data:unknown,status=200,cookie?:string)=>Response.json(data,{status,headers:{'Cache-Control':'no-store',...(cookie?{'Set-Cookie':cookie}:{})}});
const hash=async(s:string)=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)))).map(x=>x.toString(16).padStart(2,'0')).join('');
async function password(value:string,salt='v2$'+crypto.randomUUID()){return salt+':'+pbkdf2Sync(value,salt,salt.startsWith('v2$')?600000:100000,32,'sha256').toString('hex');}

const cookie=(value:string,age=86400)=>`__Host-mawine_admin=${value}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${age}`;
const str=(value:unknown,max=200)=>typeof value==='string'?value.trim().slice(0,max):'';
async function handle(req:Request){
 const db=env.DB;
 if(!db)return json({error:'Serviciul nu este disponibil.'},503);
 const q=(sql:string,...args:any[])=>db.prepare(sql).bind(...args);
 const raw=req.headers.get('cookie')?.match(/(?:^|;\s*)__Host-mawine_admin=([a-f0-9]{64})(?:;|$)/)?.[1];
 const sessionId=raw?await hash(raw):'';
 const runtimeEnv=env as unknown as Record<string,string>;
 const temporaryLogin=runtimeEnv.MAWINE_DEPLOYMENT!=='standalone'&&runtimeEnv.MAWINE_ADMIN_TEMPORARY_PASSWORD_LOGIN==='true';
 const session:any=sessionId?await q('SELECT username FROM admin_sessions WHERE id IN (?,?) AND expires>?',sessionId,temporaryLogin?'temporary:'+sessionId:'',Date.now()).first():null;
 const device=req.headers.get('cookie')?.match(/(?:^|;\s*)__Host-mawine_admin_pending=([a-f0-9]{64})(?:;|$)/)?.[1]||'';
 const pending=device?await q('SELECT username FROM admin_challenges WHERE device_hash=? AND expires>?',await hash(device),Date.now()).first():null;
 if(req.method==='GET')return json({authenticated:!!session,pending:!temporaryLogin&&!!pending,username:session?.username||null});
 if(req.headers.get('origin')!==new URL(req.url).origin)return json({error:'Cerere nepermisă.'},403);
 const body=await readJson(req,4096);
 if(body.action==='logout'){
  if(device)await q('DELETE FROM admin_challenges WHERE device_hash=?',await hash(device)).run();
  if(sessionId)await q('DELETE FROM admin_sessions WHERE id IN (?,?)',sessionId,'temporary:'+sessionId).run();
  return json({authenticated:false},200,cookie('',0));
 }
 if(body.action==='confirmLogin'){await rateLimit(db,'admin-confirm:'+await requestSource(req),20);const value=await confirmAdminChallenge(db,device,str(body.token,64));return json({authenticated:true,username:ADMIN_EMAIL},200,cookie(value))}
 if(body.action==='resendLogin'){if(!pending)return json({error:'Autentifică-te din nou cu contul de administrator.'},401);const value=await sendAdminChallenge(db,env as any,body.language,device);return json({pending:true},200,pendingCookie(value))}
 if(body.action==='login'||body.action==='activate'){
  const username=str(body.username,254).toLowerCase();
  const secret=typeof body.password==='string'?body.password:'';
  if(!username||secret.length<12||secret.length>200)return json({error:'Completează utilizatorul și o parolă de 12–200 de caractere.'},400);
  await rateLimit(db,'admin-source:'+await requestSource(req),30);
  const attemptId='admin-login:'+username,now=Date.now();
  await q('INSERT INTO attempts(id,count,since) VALUES(?,1,?) ON CONFLICT(id) DO UPDATE SET count=CASE WHEN ?-since>900000 THEN 1 ELSE count+1 END,since=CASE WHEN ?-since>900000 THEN ? ELSE since END',attemptId,now,now,now,now).run();
  const attempt:any=await q('SELECT count FROM attempts WHERE id=?',attemptId).first();
  if(attempt.count>8)return json({error:'Prea multe încercări. Reîncearcă în 15 minute.'},429);
  if(username!==ADMIN_EMAIL)return json({error:'Datele de autentificare nu sunt corecte.'},401);
  const account:any=await q('SELECT username,password FROM admin_accounts WHERE username=?',username).first();
  if(body.action==='activate'){
   const config=env as unknown as Record<string,string>;
   const token=str(body.token,128),expires=Number(config.MAWINE_ADMIN_SETUP_EXPIRES);
   if(!account||account.password||!config.MAWINE_ADMIN_SETUP_HASH||!expires||now>expires||!token||await hash(token)!==config.MAWINE_ADMIN_SETUP_HASH)return json({error:'Linkul de activare nu este valid, a expirat sau a fost deja folosit.'},403);
   const saved=await q('UPDATE admin_accounts SET password=? WHERE username=? AND password IS NULL',await password(secret),username).run();
   if(saved.meta.changes!==1)return json({error:'Contul este deja activat. Autentifică-te.'},409);
  }else{
   const expected=account?.password;
   const actual=await password(secret,expected?expected.split(':')[0]:'v2$unavailable-admin');
   if(!expected||!equalSecret(actual,expected))return json({error:'Datele de autentificare nu sunt corecte.'},401);
  }
  await q('DELETE FROM attempts WHERE id=?',attemptId).run();
  // Server-only development switch, after password and account verification.
  // Tagged sessions become unusable immediately when the switch is disabled.
  if(temporaryLogin&&body.action==='login'){
   const value=Array.from(crypto.getRandomValues(new Uint8Array(32))).map(b=>b.toString(16).padStart(2,'0')).join('');
   await q('INSERT INTO admin_sessions(id,username,expires) VALUES(?,?,?)','temporary:'+await hash(value),username,Date.now()+86400000).run();
   if(device)await q('DELETE FROM admin_challenges WHERE device_hash=?',await hash(device)).run();
   return json({authenticated:true,pending:false,username},200,cookie(value));
  }
  const value=await sendAdminChallenge(db,env as any,body.language,device||undefined);
  return json({authenticated:false,pending:true},200,pendingCookie(value));
 }
 if(!session)return json({error:'Autentifică-te cu contul separat de administrator.'},401);
 const stripeResult=await adminStripe(db,env as unknown as Record<string,unknown>,body);if(stripeResult)return json(stripeResult);
 const feature=await adminFeatures(db,env as unknown as Record<string,unknown>,session.username,body);if(feature)return json(feature);
 if(['blockUser','unblockUser','deleteUser'].includes(body.action)){
  const id=str(body.userId,100);
  if(!id||id==='system-demo-host')return json({error:'Profil nepermis.'},400);
  if(body.confirmed!==true)return json({error:'Confirmă mai întâi acțiunea.'},400);
  const target:any=await q('SELECT * FROM profiles WHERE id=?',id).first();
  if(!target)return json({error:'Utilizatorul nu mai există.'},404);
  if(body.action==='deleteUser'){
   if(body.confirmName!==target.name)return json({error:'Numele de confirmare nu coincide.'},400);
   const lock=await billingLock(db,id);try{await assertBillingCanClose(db,env as unknown as Record<string,unknown>,target);if(target.primary_email&&target.username)await q('INSERT OR IGNORE INTO trial_email_ledger(fingerprint,used_at) VALUES(?,?)',await emailFingerprint(env as AccountEnv,target.primary_email),trialStart(target)??Date.now()).run();await db.batch([
    q("UPDATE events SET status='ended',revealed=1 WHERE owner=? AND status<>'ended'",id),
    q('DELETE FROM reviews WHERE profile_id=?',id),
    q('DELETE FROM members WHERE profile_id=?',id),
    q('DELETE FROM identities WHERE profile_id=?',id),
    q('DELETE FROM email_verifications WHERE profile_id=?',id),
    q('DELETE FROM profiles WHERE id=?',id)
   ]);}finally{await lock.release()}
  }else await q('UPDATE profiles SET blocked=? WHERE id=?',body.action==='blockUser'?1:0,id).run();
  return json({ok:true});
 }
 if(body.action!=='users')return json({error:'Acțiune necunoscută.'},400);
  const query=str(body.query,80),role=['host','participant'].includes(body.role)?body.role:'all';
  const page=Number.isInteger(body.page)&&body.page>=0?Math.min(body.page,100000):0,limit=25;
  const where="p.id<>'system-demo-host' AND (?='' OR instr(lower(p.name),lower(?))>0 OR instr(lower(COALESCE(p.username,'')),lower(?))>0) AND (?='all' OR p.host=?)";
  const params=[query,query,query,role,role==='host'?1:0];
  const total:any=await q('SELECT COUNT(*) AS n FROM profiles p WHERE '+where,...params).first();
  const summary=await q("SELECT COUNT(*) AS total,COALESCE(SUM(CASE WHEN host=1 THEN 1 ELSE 0 END),0) AS hosts,COALESCE(SUM(CASE WHEN host=0 THEN 1 ELSE 0 END),0) AS participants FROM profiles WHERE id<>'system-demo-host'").first();
  const users=(await q("SELECT p.id,p.name,p.username,p.host,p.blocked,COALESCE(p.trial_started_at,CASE WHEN p.username IS NOT NULL THEN 1793456501369 ELSE NULL END) AS trialStartedAt,(SELECT expires_at FROM complimentary_access ca WHERE ca.profile_id=p.id) AS complimentaryUntil,(SELECT provider_status || ' / ' || environment FROM billing_subscriptions bs WHERE bs.profile_id=p.id ORDER BY updated_at DESC LIMIT 1) AS billingStatus,p.created_at AS createdAt,p.last_active_at AS lastActiveAt,(SELECT COUNT(*) FROM members m JOIN events e ON e.id=m.event_id WHERE m.profile_id=p.id AND e.owner<>'system-demo-host') AS tastings,(SELECT COUNT(*) FROM events e WHERE e.owner=p.id) AS organized FROM profiles p WHERE "+where+' ORDER BY lower(p.name),p.id LIMIT ? OFFSET ?',...params,limit,page*limit).all()).results;
  return json({users:await Promise.all(users.map(async(user:any)=>({...user,complimentaryEligible:await complimentaryEligible(db,env as any,{...user,trial_started_at:user.trialStartedAt}),active30Days:user.lastActiveAt===null?null:user.lastActiveAt>=Date.now()-30*86400000}))),summary,total:total.n,page,pageSize:limit});}
async function dispatch(req:Request){try{return await handle(req)}catch(e){return json({error:e instanceof BillingError||e instanceof RequestError?e.message:'Operația nu a putut fi finalizată. Încearcă din nou.'},e instanceof BillingError||e instanceof RequestError?e.status:500)}}
export const GET=dispatch;
export const POST=dispatch;
