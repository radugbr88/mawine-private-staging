import {pbkdf2Sync} from 'node:crypto';
import {purgeTrialLedger,normalizeEmail,validEmail,issueVerification,sealCode,openCode,emailFingerprint,type AccountEnv} from '../../account-security';
import {pushAction} from '../../push';
import {readJson,RequestError,rateLimit,requestSource,equalSecret} from '../../security';
import {billingAction,billingSummary,enforceHostAccess,billingLock,assertBillingCanClose,BillingError} from '../../billing';
import {languages,parseLanguage} from '../../i18n';
import {trialStart,dueReminders,reminderDay} from '../../subscription';
import {env} from 'cloudflare:workers';
import {displayGrape} from '../../grape-names';
import {wineIdentifier} from '../../identify-wine';
import {mergeWineCollection} from '../../wine-identity';
import {isAdult,validBirthDate,validTastingDate,criteria, type Wine, type Review,score} from '../../lib';
export const dynamic='force-dynamic';
const json=(x:unknown,status=200)=>Response.json(x,{status,headers:{'Cache-Control':'no-store'}});
const hash=async(s:string)=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)))).map(x=>x.toString(16).padStart(2,'0')).join('');
const token=()=>Array.from(crypto.getRandomValues(new Uint8Array(24))).map(x=>x.toString(16).padStart(2,'0')).join('').toUpperCase();
async function password(p:string,salt='v2$'+crypto.randomUUID()){return salt+':'+pbkdf2Sync(p,salt,salt.startsWith('v2$')?600000:100000,32,'sha256').toString('hex');}
function check(v:unknown,msg:string):asserts v{if(!v)throw new RequestError(msg)}
const str=(v:unknown,max=200)=>typeof v==='string'?v.trim().slice(0,max):'';
function wine(v:any):Wine {check(v&&(str(v.name)||str(v.winery)),'La fiecare vin completează numele sau crama.');check(v.year===null||v.year===''||v.year===undefined||(Number.isInteger(+v.year)&&+v.year>=1900&&+v.year<=new Date().getFullYear()),'Anul vinului nu este valid.');check(Array.isArray(v.grapes)&&v.grapes.length<20,'Lista de soiuri nu este validă.');return{...(typeof v.sourceUrl==='string'&&/^https:\/\/www\.vivino\.com\//.test(v.sourceUrl)?{sourceUrl:v.sourceUrl.slice(0,500),checkedAt:str(v.checkedAt,10)}:{}),id:str(v.id)||crypto.randomUUID(),winery:str(v.winery),name:str(v.name),year:v.year===null||v.year===undefined||v.year===''?null:+v.year,grapes:[...new Set<string>(v.grapes.map((x:any)=>displayGrape(str(x,80))))],country:str(v.country),type:str(v.type),alcohol:str(v.alcohol,8),price:str(v.price,12)};}
async function handle(req:Request,anonymousIdentity?:string){
 const db=env.DB; if(!db)return json({error:'Baza de date nu este disponibilă.'},503);
 const identity=anonymousIdentity;if(!identity)return json({error:'Conectează-te pentru a salva datele.',signIn:true},401);
 if(req.method==='POST'){const origin=req.headers.get('origin');check(origin&&origin===new URL(req.url).origin,'Cerere nepermisă.');check(Number(req.headers.get('content-length')||0)<2000000,'Fișierul este prea mare.');}
 const q=(s:string,...a:any[])=>db.prepare(s).bind(...a);
 let p:any=await q('SELECT p.* FROM profiles p JOIN identities i ON p.id=i.profile_id WHERE i.identity=?',identity).first();
 const body=req.method==='POST'?await readJson(req,2000000):{};const action=body.action;
 async function verifyCurrent(){await rateLimit(db,'reauth:'+p.id,8);check(typeof body.current==='string'&&body.current.length<=200&&p.password&&equalSecret(p.password,await password(body.current,p.password.split(':')[0])),'Parola actuală nu este corectă.');}
 if(p?.password&&['deleteProfile'].includes(action))await verifyCurrent();
 // Upgrade recoverable legacy plaintext without changing the guest's original code.
 if(p&&!p.username&&!p.recovery_cipher&&p.recovery_code&&!p.recovery_code.startsWith('sha256:')){
  const original=p.recovery_code;await q('UPDATE profiles SET recovery_cipher=?,recovery_code=? WHERE id=? AND recovery_cipher IS NULL',await sealCode(env as AccountEnv,p.id,original),'sha256:'+await hash(original),p.id).run();p=await q('SELECT * FROM profiles WHERE id=?',p.id).first();
 }
 let extra:any={};
 if(p?.blocked&&action!=='logout')return json({error:'Profilul tău este blocat. Contactează administratorul.',blocked:true},403);
 const waiting:any=p&&!p.password?await q('SELECT email FROM email_verifications WHERE profile_id=?',p.id).first():null;
 if(waiting&&!['login','logout','confirmEmail','resendVerification','activateHost'].includes(action)){if(!action)return json({profile:{id:p.id,name:p.name,dob:p.dob,host:false,termsAccepted:true,pendingEmail:waiting.email,catalog:[]},events:[],reviews:{},pendingVerification:{email:waiting.email}});return json({error:'Confirmă adresa de e-mail pentru a activa contul Mawine.',pendingVerification:{email:waiting.email}},403)}
 if(action==='adminUsers')return json({error:'Autentifică-te în pagina separată de administrare.'},403);
 if(['recover','login'].includes(action)){
  await rateLimit(db,'auth-source:'+await requestSource(req),60);
  await rateLimit(db,'auth-session:'+identity,8);
  const accountKey='auth-user:'+await hash(normalizeEmail(body.email??body.username));
  if(action==='login')await rateLimit(db,accountKey,8);
  let found:any;
  if(action==='recover'){const code=str(body.code,200).replace(/[^A-Z0-9]/gi,'').toUpperCase();found=await q('SELECT * FROM profiles WHERE username IS NULL AND (recovery=? OR recovery_code=? OR recovery_code=?)',await hash(code),'sha256:'+await hash(code),code).first();}
  else {check(typeof body.password==='string'&&body.password.length<=200,'Codul sau datele de acces nu sunt corecte.');found=await q('SELECT * FROM profiles WHERE primary_email=? OR username=?',normalizeEmail(body.email??body.username),normalizeEmail(body.email??body.username)).first();const actual=await password(body.password,found?.password?.split(':')[0]||'v2$unavailable-user');if(!found?.password||!equalSecret(found.password,actual))found=null;if(!found){const pending:any=await q('SELECT v.*,p.blocked,p.name,p.dob FROM email_verifications v JOIN profiles p ON p.id=v.profile_id WHERE v.email=? AND p.password IS NULL',normalizeEmail(body.email??body.username)).first();if(pending&&!pending.blocked&&equalSecret(pending.password_hash,await password(body.password,pending.password_hash.split(':')[0]))){await q('INSERT INTO identities(identity,profile_id) VALUES(?,?) ON CONFLICT(identity) DO UPDATE SET profile_id=excluded.profile_id',identity,pending.profile_id).run();return json({profile:{id:pending.profile_id,name:pending.name,dob:pending.dob,host:false,termsAccepted:true,catalog:[],pendingEmail:pending.email},events:[],reviews:{},pendingVerification:{email:pending.email}})}}}
  check(found,'Codul sau datele de acces nu sunt corecte.');if(action==='recover'&&!found.recovery_cipher){const original=str(body.code,200).replace(/[^A-Z0-9]/gi,'').toUpperCase();await q('UPDATE profiles SET recovery_cipher=? WHERE id=? AND recovery_cipher IS NULL',await sealCode(env as AccountEnv,found.id,original),found.id).run();}if(found.blocked)return json({error:'Profilul tău este blocat. Contactează administratorul.',blocked:true},403);const linked=await q('INSERT INTO identities(identity,profile_id) SELECT ?,id FROM profiles WHERE id=? AND blocked=0 AND password IS ? AND recovery=? AND recovery_code IS ? ON CONFLICT(identity) DO UPDATE SET profile_id=excluded.profile_id',identity,found.id,found.password,found.recovery,found.recovery_code).run();check(linked.meta.changes===1,'Codul sau datele de acces nu sunt corecte.');p=found;await q('DELETE FROM attempts WHERE id IN (?,?)','auth-session:'+identity,accountKey).run();
 }
 if(['createProfile','activateHost'].includes(action)){check(body.termsAccepted==='yes'||(action==='activateHost'&&p&&await q('SELECT profile_id FROM terms_acceptances WHERE profile_id=? AND version=?',p.id,'2026-11-04.2').first()),'Acceptă termenii și condițiile.');
 await q('CREATE TABLE IF NOT EXISTS terms_acceptances (profile_id TEXT NOT NULL, version TEXT NOT NULL, language TEXT NOT NULL, accepted_at INTEGER NOT NULL, PRIMARY KEY(profile_id,version))').run();
 }
 if(action==='createProfile'){check(body.termsAccepted==='yes','Acceptă termenii și condițiile.');
  check(!p,'Ai deja un profil.');check(str(body.name),'Completează numele.');check(validBirthDate(body.dob),'Data nașterii nu este validă.');check(isAdult(body.dob),'Ne pare rău, nu ai încă 18 ani');const id=crypto.randomUUID(),code=token(),cipher=await sealCode(env as AccountEnv,id,code);await db.batch([q('INSERT INTO profiles(id,name,dob,gender,recovery,recovery_code,recovery_cipher,created_at,last_active_at,language) VALUES(?,?,?,?,?,?,?,?,?,?)',id,str(body.name,60),body.dob,str(body.gender),await hash(code),null,cipher,Date.now(),Date.now(),parseLanguage(body.language)),q('INSERT INTO identities(identity,profile_id) VALUES(?,?)',identity,id)]);p=await q('SELECT * FROM profiles WHERE id=?',id).first();extra.recoveryCode=code;
 }
 if(p&&['createProfile'].includes(action)&&body.termsAccepted==='yes'){
 await q('INSERT INTO terms_acceptances(profile_id,version,language,accepted_at) VALUES(?,?,?,?) ON CONFLICT(profile_id,version) DO NOTHING',p.id,'2026-11-04.2',parseLanguage(body.language),Date.now()).run();
 }
 if(action&&!['createProfile','recover','login','confirmEmail'].includes(action))check(p,'Creează mai întâi un profil.');
 if(p&&action!=='logout'){const now=Date.now();await q('UPDATE profiles SET last_active_at=? WHERE id=? AND (last_active_at IS NULL OR last_active_at<?)',now,p.id,now-900000).run();}
 if(action==='logout'){
  await q('DELETE FROM push_subscriptions WHERE identity=?',identity).run();
  await q('DELETE FROM identities WHERE identity=?',identity).run();
  if(anonymousIdentity){await q('DELETE FROM guest_sessions WHERE id=?',anonymousIdentity.slice(6)).run();}
  const response=json({profile:null,events:[],reviews:{}});
  response.headers.set('Set-Cookie','__Host-mawine_session=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0');return response;
 }
 const billingEnv=env as unknown as Record<string,unknown>;
 if(['pushConfig','pushSubscribe','pushDisable','pushTest'].includes(action))return pushAction(db,billingEnv,p,identity,action,body);
 if(action==='claimInstallReminder'){
  const now=Date.now(),day=reminderDay(now),age=p.created_at?Math.round((Date.parse(day)-Date.parse(reminderDay(p.created_at)))/86400000):-1;
  if(age<0||age>2)return json({reminder:null,profileId:p.id});
  const claimed=await q("INSERT INTO profile_reminders(profile_id,kind,shown_day,shown_at) VALUES(?,'install-app',?,?) ON CONFLICT(profile_id,kind) DO UPDATE SET shown_day=excluded.shown_day,shown_at=excluded.shown_at WHERE profile_reminders.shown_day<>excluded.shown_day",p.id,day,now).run();return json({profileId:p.id,reminder:claimed.meta.changes===1?{kind:'install-app',day}:null});
 }
 if(action==='claimReminder'){
  check(body.profileId===p.id,'Cerere nepermisă.');
  const now=Date.now(),billing=await billingSummary(db,billingEnv,p);
  for(const reminder of dueReminders(p,billing.subscription,now).filter(r=>!billing.complimentaryUntil||!['trial-ending','paid-ending','payment-grace'].includes(r.kind))){
   const claimed=await q('INSERT INTO profile_reminders(profile_id,kind,shown_day,shown_at) VALUES(?,?,?,?) ON CONFLICT(profile_id,kind) DO UPDATE SET shown_day=excluded.shown_day,shown_at=excluded.shown_at WHERE profile_reminders.shown_day<>excluded.shown_day',p.id,reminder.kind,reminder.day,now).run();
   if(claimed.meta.changes===1)return json({reminder,profileId:p.id});
  }
  return json({reminder:null,profileId:p.id});
 }

 if(p&&['stripeCheckout','stripePortal','applyPromotion'].includes(action))extra={...extra,...await billingAction(db,billingEnv,p,action,body.plan,undefined,body.code)};
 if(p&&['saveEvent','start','catalog','importCollection','identifyWines'].includes(action))await enforceHostAccess(db,billingEnv,p);
 if(action==='favoriteHistory'){
  const membership:any=await q('SELECT e.status,m.completed FROM events e JOIN members m ON e.id=m.event_id WHERE e.id=? AND m.profile_id=?',str(body.id),p.id).first();
  check(membership&&(membership.status==='ended'||membership.completed),'Degustarea nu este în istoricul tău.');
  check(typeof body.favorite==='boolean','Selecție invalidă.');
  await q('UPDATE members SET history_favorite=? WHERE event_id=? AND profile_id=?',body.favorite?1:0,str(body.id),p.id).run();
 }
 if(action==='deleteDraft'){
  check(p.host,'Doar gazda poate șterge degustarea.');
  const id=str(body.id);
  check(await q("SELECT id FROM events WHERE id=? AND owner=? AND status='draft'",id,p.id).first(),'Poți șterge doar degustările tale în pregătire.');
  await db.batch([
   q("DELETE FROM members WHERE event_id IN (SELECT id FROM events WHERE id=? AND owner=? AND status='draft')",id,p.id),
   q("DELETE FROM reviews WHERE event_id IN (SELECT id FROM events WHERE id=? AND owner=? AND status='draft')",id,p.id),
   q("DELETE FROM events WHERE id=? AND owner=? AND status='draft'",id,p.id)
  ]);
 }
 if(action==='deleteHistory'){
  const membership:any=await q('SELECT e.status,m.completed FROM events e JOIN members m ON e.id=m.event_id WHERE e.id=? AND m.profile_id=?',str(body.id),p.id).first();
  check(membership&&(membership.status==='ended'||membership.completed),'Poți șterge din istoric doar participările încheiate.');
  await q('UPDATE members SET history_hidden=1 WHERE event_id=? AND profile_id=?',str(body.id),p.id).run();
 }
 if(action==='saveLanguage'){check(languages.includes(body.language),'Selecție invalidă.');check(body.profileId===p.id,'Cerere nepermisă.');await q('UPDATE profiles SET language=? WHERE id=?'+(body.initializeOnly===true?' AND language IS NULL':''),body.language,p.id).run();}
 if(action==='updateProfile'){check(str(body.name),'Completează numele.');const dob=body.dob||p.dob;check(validBirthDate(dob),'Data nașterii nu este validă.');check(isAdult(dob),'Ne pare rău, nu ai încă 18 ani');await q('UPDATE profiles SET name=?,dob=?,gender=? WHERE id=?',str(body.name,60),dob,str(body.gender),p.id).run();}
 if(action==='changePassword'){check(p.host&&p.password,'Nu există un cont de gazdă.');await verifyCurrent();check(typeof body.password==='string'&&body.password.length>=10&&body.password.length<=200,'Folosește o parolă de 10–200 de caractere.');const encoded=await password(body.password);const changed=await db.batch([q('UPDATE profiles SET password=?,recovery=?,recovery_code=NULL,recovery_cipher=NULL WHERE id=? AND password=?',encoded,await hash(token()),p.id,p.password),q('DELETE FROM identities WHERE profile_id=? AND identity<>? AND EXISTS(SELECT 1 FROM profiles WHERE id=? AND password=?)',p.id,identity,p.id,encoded),q('DELETE FROM password_resets WHERE profile_id=? AND EXISTS(SELECT 1 FROM profiles WHERE id=? AND password=?)',p.id,p.id,encoded)]);check(changed[0].meta.changes===1,'Parola actuală nu este corectă.');}
 if(action==='activateHost'){
  check(body.termsAccepted==='yes'||await q('SELECT profile_id FROM terms_acceptances WHERE profile_id=? AND version=?',p.id,'2026-11-04.2').first(),'Acceptă termenii și condițiile.');check(isAdult(p.dob),'Ne pare rău, nu ai încă 18 ani');
  const email=normalizeEmail(body.email);check(validEmail(email),'Introdu o adresă de e-mail validă.');check(!p.host&&!p.password,'Contul de gazdă este deja activ.');
  check(typeof body.password==='string'&&body.password.length>=10&&body.password.length<=200,'Folosește o parolă de 10–200 de caractere.');
  check(body.confirm===body.password,'Parolele nu coincid.');
  check(!await q('SELECT id FROM profiles WHERE (primary_email=? OR username=?) AND id<>?',email,email,p.id).first(),'Adresa de e-mail este deja folosită.');
  await purgeTrialLedger(db);
  check(!await q('SELECT profile_id FROM email_verifications WHERE email=? AND profile_id<>?',email,p.id).first(),'Adresa de e-mail este deja folosită.');
  extra.pendingVerification=await issueVerification(db,env as AccountEnv,p,identity,email,await password(body.password));
 }
 if(action==='resendVerification'){
  const pending:any=await q('SELECT * FROM email_verifications WHERE profile_id=?',p.id).first();check(pending&&!p.password,'Nu există o verificare în așteptare.');
  extra.pendingVerification=await issueVerification(db,env as AccountEnv,p,identity,pending.email,pending.password_hash);
 }
 if(action==='confirmEmail'){
  await rateLimit(db,'verify-source:'+await requestSource(req),30);check(typeof body.token==='string'&&/^[a-f0-9]{64}$/.test(body.token),'Linkul nu mai este valabil. Solicită un link nou.');
  const verification:any=await q('SELECT v.*,p.blocked FROM email_verifications v JOIN profiles p ON p.id=v.profile_id WHERE token_hash=?',await hash(body.token)).first();
  check(verification&&!verification.blocked,'Linkul este invalid sau a fost deja utilizat. Solicită un link nou.');
  check(verification.expires>Date.now(),'Linkul a expirat. Solicită un link nou.');
  if(identity!==verification.identity){
   if(typeof body.password!=='string')return json({requiresPassword:true,needsPassword:true});
   await rateLimit(db,'verify-password:'+verification.profile_id,8);
   check(body.password.length<=200&&equalSecret(verification.password_hash,await password(body.password,verification.password_hash.split(':')[0])),'Parola nu este corectă.');
  }
  const now=Date.now(),fingerprint=await emailFingerprint(env as AccountEnv,verification.email);
  await purgeTrialLedger(db,now);
  const ledger:any=await q('SELECT used_at FROM trial_email_ledger WHERE fingerprint=?',fingerprint).first();
  const trialAt=ledger?Math.min(Number(ledger.used_at),now-33*86400000):now;
  const results=await db.batch([
   q('UPDATE profiles SET primary_email=?,email_verified_at=?,username=?,password=?,host=1,recovery_email=?,trial_started_at=COALESCE(trial_started_at,?) WHERE id=? AND password IS NULL AND EXISTS(SELECT 1 FROM email_verifications WHERE profile_id=profiles.id AND token_hash=? AND expires>?)',verification.email,now,verification.email,verification.password_hash,verification.email,trialAt,verification.profile_id,verification.token_hash,now),
   q('INSERT OR IGNORE INTO trial_email_ledger(fingerprint,used_at) SELECT ?,? WHERE EXISTS(SELECT 1 FROM profiles WHERE id=? AND email_verified_at=?)',fingerprint,now,verification.profile_id,now),
   q('INSERT INTO identities(identity,profile_id) SELECT ?,profile_id FROM email_verifications WHERE profile_id=? AND token_hash=? AND EXISTS(SELECT 1 FROM profiles WHERE id=? AND email_verified_at=?) ON CONFLICT(identity) DO UPDATE SET profile_id=excluded.profile_id',identity,verification.profile_id,verification.token_hash,verification.profile_id,now),
   q('DELETE FROM email_verifications WHERE profile_id=? AND token_hash=?',verification.profile_id,verification.token_hash)
  ]);check(results[0].meta.changes===1,'Linkul nu mai este valabil. Solicită un link nou.');
  p=await q('SELECT * FROM profiles WHERE id=?',verification.profile_id).first();extra.emailConfirmed=true;
 }
 if(p&&['activateHost'].includes(action)&&body.termsAccepted==='yes'){
 await q('INSERT INTO terms_acceptances(profile_id,version,language,accepted_at) VALUES(?,?,?,?) ON CONFLICT(profile_id,version) DO NOTHING',p.id,'2026-11-04.2',parseLanguage(body.language),Date.now()).run();
 }
 if(action==='deactivateHost'){const lock=await billingLock(db,p.id);try{try{await assertBillingCanClose(db,billingEnv,p)}catch(e){if(e instanceof BillingError)throw e;throw new BillingError('Operația nu a putut fi finalizată. Încearcă din nou.',503)}check(p.host,'Rolul de gazdă nu este activ.');check(!await q("SELECT id FROM events WHERE owner=? AND status='active'",p.id).first(),'Încheie degustarea în desfășurare înainte de a reveni la participant.');await q('UPDATE profiles SET host=0 WHERE id=?',p.id).run();}finally{await lock.release()}}
 if(action==='reactivateHost'){check(isAdult(p.dob),'Ne pare rău, nu ai încă 18 ani');check(!p.host&&p.username&&p.password,'Activează mai întâi contul de gazdă.');await q('UPDATE profiles SET host=1 WHERE id=?',p.id).run();}
 if(action==='saveRecoveryEmail')throw new RequestError('Adresa principală de e-mail nu poate fi modificată.',403);
 if(action==='recovery'){
  check(!p.username,'Codul unic este disponibil doar profilurilor fără cont.');
  if(!p.recovery_cipher&&typeof body.code==='string'){
   const code=str(body.code,200).replace(/[^A-Z0-9]/gi,'').toUpperCase();const value=await hash(code);
   await rateLimit(db,'restore-code:'+p.id,8);check(equalSecret(p.recovery,value)||p.recovery_code===code||p.recovery_code==='sha256:'+value,'Codul de recuperare nu este corect.');
   await q('UPDATE profiles SET recovery_cipher=? WHERE id=? AND recovery_cipher IS NULL',await sealCode(env as AccountEnv,p.id,code),p.id).run();p=await q('SELECT * FROM profiles WHERE id=?',p.id).first();
  }
  extra.recoveryCode=await openCode(env as AccountEnv,p.id,p.recovery_cipher);
  extra.recoveryCodeUnavailable=!extra.recoveryCode;
 }

 if(action==='identifyWines'){
  check(p.host,'Identificarea vinurilor este disponibilă doar gazdelor.');check(Array.isArray(body.wines)&&body.wines.length<=1000,'Maximum 1.000 de vinuri.');
  const rows=(await q('SELECT name FROM grape_varieties').all()).results as {name:string}[];
  const owned=(await q('SELECT wines FROM events WHERE owner=?',p.id).all()).results as any[];
  const wineries=[...JSON.parse(p.catalog),...owned.flatMap(e=>JSON.parse(e.wines))].map((w:Wine)=>w.winery);
  const identify=wineIdentifier(rows,wineries,body.preserveNames===true);extra.identifiedWines=body.wines.map(wine).map(identify);
 }
 if(action==='catalog'){check(p.host,'Doar gazdele pot gestiona colecția.');check(Array.isArray(body.wines)&&body.wines.length<=1000,'Maximum 1.000 de vinuri.');await q('UPDATE profiles SET catalog=? WHERE id=?',JSON.stringify(body.wines.map(wine)),p.id).run();}
 if(action==='importCollection'){check(p.host,'Activează contul de gazdă.');check(Array.isArray(body.wines)&&body.wines.length<=1000,'Maximum 1.000 de vinuri pe import.');const merged=mergeWineCollection(JSON.parse(p.catalog),body.wines.map(wine));check(merged.length<=1000,'Colecția poate conține maximum 1.000 de vinuri.');await q('UPDATE profiles SET catalog=? WHERE id=?',JSON.stringify(merged),p.id).run();}
 if(action==='saveEvent'){
  check(p.host,'Activează contul de gazdă.');check(str(body.title),'Completează tema degustării.');check(Array.isArray(body.wines)&&body.wines.length<=60,'Maximum 60 de vinuri.');const wines=body.wines.map(wine);check(new Set(wines.map((w:Wine)=>w.id)).size===wines.length,'Vinurile trebuie să fie distincte.');check(validTastingDate(body.date),'Alege data de azi sau o dată viitoare.');
  const writes=[];
  if(body.id){const e:any=await q('SELECT * FROM events WHERE id=? AND owner=?',body.id,p.id).first();check(e&&e.status==='draft','Poți modifica doar o degustare în pregătire.');writes.push(q('UPDATE events SET title=?,date=?,mode=?,wines=? WHERE id=?',str(body.title),body.date,body.mode==='blind'?'blind':'normal',JSON.stringify(wines),body.id));extra.eventId=body.id;}
  else {const id=crypto.randomUUID();writes.push(q('INSERT INTO events(id,owner,title,date,mode,status,code,wines) VALUES(?,?,?,?,?,?,?,?)',id,p.id,str(body.title),body.date,body.mode==='blind'?'blind':'normal','draft',token().slice(0,12),JSON.stringify(wines)),q('INSERT INTO members(event_id,profile_id) VALUES(?,?)',id,p.id));extra.eventId=id;}
  const previous:any=body.id?await q('SELECT collection_wine_ids FROM events WHERE id=? AND owner=?',body.id,p.id).first():null;
  const transferIds=[...new Set([...(previous?JSON.parse(previous.collection_wine_ids):[]),...(Array.isArray(body.collectionWineIds)?body.collectionWineIds:[])])].filter(id=>typeof id==='string'&&wines.some((w:Wine)=>w.id===id));
  writes.push(q('UPDATE events SET collection_wine_ids=? WHERE id=? AND owner=?',JSON.stringify(transferIds),extra.eventId,p.id));
  await db.batch(writes);
 }
 if(['start','end','reveal','revealWine'].includes(action)){
  const e:any=await q('SELECT * FROM events WHERE id=? AND owner=?',str(body.id),p.id).first();check(e,'Degustarea nu este disponibilă.');
  if(action==='start'){if(e.mode==='blind'){check(JSON.parse(e.wines).every((w:Wine)=>w.year&&w.country&&w.grapes.length),'Pentru degustarea în orb, completează anul, țara și soiurile fiecărui vin înainte de pornire.');}check(e.status==='draft'&&JSON.parse(e.wines).length>0,'Adaugă vinuri înainte de pornire.');const results=await db.batch([q("UPDATE events SET status='active' WHERE id=? AND status='draft' AND NOT EXISTS(SELECT 1 FROM events WHERE owner=? AND status='active')",e.id,p.id),q("UPDATE profiles SET catalog=(SELECT COALESCE(json_group_array(json(value)), '[]') FROM json_each(profiles.catalog) WHERE json_extract(value,'$.id') NOT IN (SELECT value FROM json_each(?))) WHERE id=? AND EXISTS(SELECT 1 FROM events WHERE id=? AND status='active')",e.collection_wine_ids,p.id,e.id)]);check(results[0].meta.changes===1,'Ai deja o degustare în desfășurare.');}
  if(action==='end'){check(e.status==='active','Degustarea nu este activă.');await q("UPDATE events SET status='ended',revealed=1 WHERE id=?",e.id).run();}
  if(action==='revealWine'){check(e.status==='active'&&e.mode==='blind','Dezvăluirea este disponibilă doar într-o degustare în orb activă.');check(JSON.parse(e.wines).some((w:Wine)=>w.id===body.wineId),'Vin inexistent.');await q("UPDATE events SET revealed_wine_ids=json_insert(revealed_wine_ids,'$[#]',?) WHERE id=? AND NOT EXISTS(SELECT 1 FROM json_each(revealed_wine_ids) WHERE value=?)",body.wineId,e.id,body.wineId).run();}
  if(action==='reveal'){check(e.status==='active','Degustarea nu este activă.');await q('UPDATE events SET revealed=1 WHERE id=?',e.id).run();}
 }
 if(action==='join'){check(isAdult(p.dob),'Ne pare rău, nu ai încă 18 ani');await rateLimit(db,'join:'+p.id,60);const e:any=await q("SELECT * FROM events WHERE code=? AND status='active'",str(body.code).toUpperCase()).first();check(e,'Cod invalid sau degustare încheiată.');await q('INSERT OR IGNORE INTO members(event_id,profile_id) SELECT ?,? WHERE (SELECT COUNT(*) FROM members WHERE event_id=?)<60',e.id,p.id,e.id).run();check(await q('SELECT 1 FROM members WHERE event_id=? AND profile_id=?',e.id,p.id).first(),'Degustarea a atins limita de 60 de persoane.');extra.eventId=e.id;}
 if(action==='finishParticipation'){
  const membership:any=await q('SELECT e.status FROM members m JOIN events e ON e.id=m.event_id WHERE m.event_id=? AND m.profile_id=?',str(body.id),p.id).first();check(membership&&membership.status!=='draft','Nu ai acces la această degustare.');
  await q('UPDATE members SET completed=1 WHERE event_id=? AND profile_id=?',str(body.id),p.id).run();
 }
 if(action==='review'){check(isAdult(p.dob),'Ne pare rău, nu ai încă 18 ani');
  const e:any=await q('SELECT e.*,m.completed AS participation_completed FROM events e JOIN members m ON e.id=m.event_id WHERE e.id=? AND m.profile_id=?',body.eventId,p.id).first();check(e&&e.status!=='draft','Nu ai acces la această degustare.');check(JSON.parse(e.wines).some((w:Wine)=>w.id===body.wineId),'Vin inexistent.');const r=body.review as Review;check(r&&Array.isArray(r.scores)&&r.scores.length===5&&r.scores.every((n,i)=>n===null||(Number.isInteger(n)&&n>=0&&n<=criteria[i][2])),'Punctaj invalid.');
  const old:any=await q('SELECT data FROM reviews WHERE event_id=? AND profile_id=? AND wine_id=?',e.id,p.id,body.wineId).first();const previous=old?JSON.parse(old.data):null;
  const data={scores:(e.status==='ended'||e.participation_completed)?(previous?.scores||[null,null,null,null,null]):r.scores,notes:str(r.notes,3000),favorite:!!r.favorite,favoriteAt:r.favorite?(previous?.favorite?(previous.favoriteAt||Date.now()):Date.now()):null,country:str(r.country),year:str(r.year,4),grapes:Array.isArray(r.grapes)?[...new Set(r.grapes.map(x=>str(x,80)))].slice(0,20):[]};
  if(e.revealed||JSON.parse(e.revealed_wine_ids).includes(body.wineId)||e.status==='ended'||e.participation_completed){data.country=previous?.country||'';data.year=previous?.year||'';data.grapes=previous?.grapes||[];}
  if(e.mode==='blind'&&e.owner===p.id){data.country='';data.year='';data.grapes=[];}
  await q('INSERT INTO reviews(event_id,profile_id,wine_id,data) VALUES(?,?,?,?) ON CONFLICT(event_id,profile_id,wine_id) DO UPDATE SET data=excluded.data',e.id,p.id,body.wineId,JSON.stringify(data)).run();
 }
 if(action==='deleteProfile'){if(p.primary_email&&p.username)await q('INSERT OR IGNORE INTO trial_email_ledger(fingerprint,used_at) VALUES(?,?)',await emailFingerprint(env as AccountEnv,p.primary_email),trialStart(p)??Date.now()).run();const lock=await billingLock(db,p.id);try{try{await assertBillingCanClose(db,billingEnv,p)}catch(e){if(e instanceof BillingError)throw e;throw new BillingError('Operația nu a putut fi finalizată. Încearcă din nou.',503)}await db.batch([q('DELETE FROM reviews WHERE profile_id=?',p.id),q('DELETE FROM members WHERE profile_id=?',p.id),q("UPDATE events SET owner='',status='ended',revealed=1 WHERE owner=?",p.id),q('DELETE FROM identities WHERE profile_id=?',p.id),q('DELETE FROM email_verifications WHERE profile_id=?',p.id),q('DELETE FROM profiles WHERE id=?',p.id)]);return json({profile:null,events:[],reviews:{}});}finally{await lock.release()}}
 if(!p)return json({profile:null,events:[],reviews:{},...extra});
 p=await q('SELECT * FROM profiles WHERE id=?',p.id).first();const ev=(await q('SELECT DISTINCT e.*,e.rowid AS creationOrder FROM events e LEFT JOIN members m ON e.id=m.event_id WHERE e.owner=? OR m.profile_id=? ORDER BY e.date DESC,e.rowid DESC',p.id,p.id).all()).results;
 const out=[];for(const e of ev as any[]){const own=e.owner===p.id;const rr=(await q('SELECT wine_id,data FROM reviews WHERE event_id=?',e.id).all()).results as any[];const progress:Record<string,number>={},sums:Record<string,number>={};rr.forEach(x=>{const n=score(JSON.parse(x.data));if(n!==null){progress[x.wine_id]=(progress[x.wine_id]||0)+1;sums[x.wine_id]=(sums[x.wine_id]||0)+n;}});const part=(await q('SELECT p.name FROM profiles p JOIN members m ON p.id=m.profile_id WHERE m.event_id=?',e.id).all()).results;const host:any=await q('SELECT name FROM profiles WHERE id=?',e.owner).first();const membership:any=await q('SELECT completed,history_hidden,history_favorite FROM members WHERE event_id=? AND profile_id=?',e.id,p.id).first();const isDemo=e.owner==='system-demo-host'&&['mawine-demo-tasting-2026','mawine-blind-demo-2026'].includes(e.id);const revealed=!!e.revealed||(isDemo&&!!membership?.completed);const revealedWineIds:string[]=JSON.parse(e.revealed_wine_ids);out.push({...e,revealedWineIds,historyHidden:!!membership?.history_hidden,historyFavorite:!!membership?.history_favorite,isDemo,participationCompleted:!!membership?.completed,hostName:host?.name||'Organizator',wines:JSON.parse(e.wines).map((w:Wine)=>e.mode==='blind'&&!revealed&&!revealedWineIds.includes(w.id)&&!own?{id:w.id}:w),revealed,count:part.length,participants:own?part.map((x:any)=>x.name):undefined,progress:own?progress:undefined,averages:own||e.status==='ended'?Object.fromEntries(Object.keys(sums).map(k=>[k,sums[k]/progress[k]])):undefined});}
 const rr=(await q('SELECT event_id,wine_id,data FROM reviews WHERE profile_id=?',p.id).all()).results as any[];
 const billing=await billingSummary(db,billingEnv,p);
 const pending:any=await q('SELECT email FROM email_verifications WHERE profile_id=?',p.id).first();
 const visibleCode=!p.username?await openCode(env as AccountEnv,p.id,p.recovery_cipher):null;
 return json({profile:{termsAccepted:!!await q('SELECT profile_id FROM terms_acceptances WHERE profile_id=? AND version=?',p.id,'2026-11-04.2').first(),billing,language:languages.includes(p.language)?p.language:null,trialStartedAt:p.host?trialStart(p):undefined,id:p.id,name:p.name,dob:p.dob,gender:p.gender,host:!!p.host&&billing.hostAccess,username:p.username,email:p.primary_email,emailVerified:!!p.email_verified_at,pendingEmail:pending?.email,pendingVerification:pending?{email:pending.email}:undefined,recoveryCode:visibleCode,recoveryCodeUnavailable:!p.username&&!visibleCode,catalog:p.host&&billing.hostAccess?JSON.parse(p.catalog):[]},pendingVerification:pending?{email:pending.email}:undefined,events:out,reviews:Object.fromEntries(rr.map(r=>[r.event_id+':'+r.wine_id,JSON.parse(r.data)])),...extra});
}
// Hosts and guests share persistent device sessions, independent of proxy sign-in.
const SESSION_SECONDS=31536000;
const SESSION_MS=SESSION_SECONDS*1000;
const ACCOUNT_SESSION_SECONDS=30*86400;
const sessionCookie=(raw:string,seconds=SESSION_SECONDS)=>'__Host-mawine_session='+raw+'; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age='+seconds;
async function dispatch(req:Request){
 let cookie='';try{
  if(req.method==='POST'&&req.headers.get('origin')!==new URL(req.url).origin)return json({error:'Cerere nepermisă.'},400);
  let anonymousIdentity:string|undefined;
  {
   if(!env.DB)return json({error:'Baza de date nu este disponibilă.'},503);
   const raw=req.headers.get('cookie')?.match(/(?:^|;\s*)__Host-mawine_session=([A-F0-9]{64})(?:;|$)/)?.[1];
   const key=raw?await hash(raw):'';
   const session=key?await env.DB.prepare('SELECT id,expires FROM guest_sessions WHERE id=? AND expires>?').bind(key,Date.now()).first():null;
   if(session){
    anonymousIdentity='guest:'+key;
    // Guest persistence is separate from the shorter credential-account session.
    const account=await env.DB.prepare('SELECT p.password FROM profiles p JOIN identities i ON p.id=i.profile_id WHERE i.identity=?').bind(anonymousIdentity).first();
    const seconds=account?.password?ACCOUNT_SESSION_SECONDS:SESSION_SECONDS;
    const duration=seconds*1000;
    // Renew at most daily; also shorten older one-year account sessions.
    if(Number(session.expires)<Date.now()+duration-86400000||Number(session.expires)>Date.now()+duration){
     const renewed=await env.DB.prepare('UPDATE guest_sessions SET expires=? WHERE id=? AND expires>?').bind(Date.now()+duration,key,Date.now()).run();
     if(renewed.meta.changes===1)cookie=sessionCookie(raw!,seconds);
    }
   }
   else{await rateLimit(env.DB,'new-session:'+await requestSource(req),120);const secret=Array.from(crypto.getRandomValues(new Uint8Array(32))).map(x=>x.toString(16).padStart(2,'0')).join('').toUpperCase();const id=await hash(secret);await env.DB.prepare('INSERT INTO guest_sessions(id,expires) VALUES(?,?)').bind(id,Date.now()+SESSION_MS).run();anonymousIdentity='guest:'+id;cookie=sessionCookie(secret);}
  }
  // Carry a legacy authenticated proxy profile into this device once.
  // An existing device login always wins over a different proxy identity.
  const deploymentEnv=env as unknown as Record<string,string>;
  const legacy=deploymentEnv.MAWINE_DEPLOYMENT!=='standalone'&&deploymentEnv.MAWINE_TRUST_PROXY_IDENTITY==='true'?req.headers.get('oai-authenticated-user-id'):null;
  if(legacy&&anonymousIdentity)await env.DB!.prepare('UPDATE identities SET identity=? WHERE identity=? AND NOT EXISTS (SELECT 1 FROM identities WHERE identity=?)').bind(anonymousIdentity,legacy,anonymousIdentity).run();
  const action=req.method==='POST'?(await readJson(req.clone(),2000000)).action:undefined;
  const response=await handle(req,anonymousIdentity);
  if(response.ok&&anonymousIdentity&&['login','recover','changePassword','confirmEmail'].includes(action)){
   const secret=Array.from(crypto.getRandomValues(new Uint8Array(32))).map(x=>x.toString(16).padStart(2,'0')).join('').toUpperCase(),id=await hash(secret);
   const account=await env.DB!.prepare('SELECT p.password FROM profiles p JOIN identities i ON p.id=i.profile_id WHERE i.identity=?').bind(anonymousIdentity).first();
   const seconds=account?.password?ACCOUNT_SESSION_SECONDS:SESSION_SECONDS;
   await env.DB!.batch([env.DB!.prepare('INSERT INTO guest_sessions(id,expires) VALUES(?,?)').bind(id,Date.now()+seconds*1000),env.DB!.prepare('UPDATE identities SET identity=? WHERE identity=?').bind('guest:'+id,anonymousIdentity),env.DB!.prepare('UPDATE push_subscriptions SET identity=? WHERE identity=? AND profile_id=(SELECT profile_id FROM identities WHERE identity=?)').bind('guest:'+id,anonymousIdentity,'guest:'+id),env.DB!.prepare('DELETE FROM guest_sessions WHERE id=?').bind(anonymousIdentity.slice(6))]);
   cookie=sessionCookie(secret,seconds);
  }
  if(action==='logout'&&response.ok)cookie='';
  if(cookie)response.headers.set('Set-Cookie',cookie);return response;
 }catch(e){const response=json({error:e instanceof RequestError||e instanceof BillingError?e.message:'Operația nu a putut fi finalizată. Încearcă din nou.'},e instanceof BillingError||e instanceof RequestError?e.status:500);if(cookie)response.headers.set('Set-Cookie',cookie);return response}
}
export const GET=dispatch;
export const POST=dispatch;
