import {env} from 'cloudflare:workers';
import {catalogSeed} from '../../catalog-seed';
export const dynamic='force-dynamic';
// Public reference data only. No caller-supplied records or profile data are accepted.
// POST imports this fixed, researched release dataset idempotently; it cannot modify existing records.
export async function POST(){try{if(!env.DB)return Response.json({error:'Baza de date nu este disponibilă.'},{status:503});await env.DB.batch(catalogSeed.map(w=>env.DB!.prepare('INSERT OR IGNORE INTO wine_catalog(id,data,source_url,checked_at) VALUES(?,?,?,?)').bind(w.id,JSON.stringify(w),w.sourceUrl,w.checkedAt)));return Response.json({importedDataset:catalogSeed.length});}catch{return Response.json({error:'Catalogul nu a putut fi importat.'},{status:500})}}
export async function GET(){try{if(!env.DB)return Response.json({error:'Baza de date nu este disponibilă.'},{status:503});const result=await env.DB.prepare('SELECT data FROM wine_catalog ORDER BY id').all();return Response.json({wines:result.results.map((r:any)=>JSON.parse(r.data))},{headers:{'Cache-Control':'no-store'}})}catch{return Response.json({error:'Catalogul nu a putut fi încărcat.'},{status:500})}}
