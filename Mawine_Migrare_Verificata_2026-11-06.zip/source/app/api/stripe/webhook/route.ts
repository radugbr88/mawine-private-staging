import {env} from 'cloudflare:workers';
import Stripe from 'stripe';
import {billingConfig,stripeClient,processStripeEvent} from '../../../billing';
export const dynamic='force-dynamic';
export async function POST(req:Request){
 const config=billingConfig(env as unknown as Record<string,unknown>);
 if(!env.DB||!config)return new Response('Unavailable',{status:503});
 if(Number(req.headers.get('content-length')||0)>262144)return new Response('Too large',{status:413});
 const reader=req.body?.getReader();if(!reader)return new Response('Missing body',{status:400});
 const chunks:Uint8Array[]=[];let size=0;
 while(true){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>262144){await reader.cancel();return new Response('Too large',{status:413})}chunks.push(value)}
 const bytes=new Uint8Array(size);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.byteLength}
 const raw=new TextDecoder().decode(bytes);
 const s=stripeClient(config);let event:Stripe.Event;
 try{event=await s.webhooks.constructEventAsync(raw,req.headers.get('stripe-signature')||'',config.webhook,300,Stripe.createSubtleCryptoProvider())}catch{return new Response('Invalid signature',{status:400})}
 try{await processStripeEvent(env.DB,config,event,s);return Response.json({received:true})}catch{return new Response('Retry required',{status:503})}
}
