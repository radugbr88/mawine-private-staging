// Existing credential accounts begin their first trial with this rollout.
// Keep this timestamp stable across later deployments and role changes.
export const TRIAL_ROLLOUT_AT = 1793456501369;
export const TRIAL_DAYS = 30;
const DAY = 86_400_000;
export function trialStatus(startedAt:number, now=Date.now()) {
 const elapsed=Math.max(0,now-startedAt);
 const remainingDays=Math.max(0,Math.ceil((TRIAL_DAYS*DAY-elapsed)/DAY));
 return {startedAt,endsAt:startedAt+TRIAL_DAYS*DAY,remainingDays,day:Math.min(TRIAL_DAYS,Math.floor(elapsed/DAY)+1),active:remainingDays>0,progress:Math.min(100,elapsed/(TRIAL_DAYS*DAY)*100)};
}
export function trialStart(profile:{trial_started_at?:number|null;username?:string|null}) {
 return profile.trial_started_at ?? (profile.username ? TRIAL_ROLLOUT_AT : null);
}

export type ReminderKind='install-app'|'recovery-code'|'trial-ending'|'payment-grace'|'paid-ending';
export type AppReminder={kind:ReminderKind;day:string;remainingDays?:number;endsAt?:number;graceDay?:number};
// A stable calendar prevents duplicate reminders after travel or clock changes.
export function reminderDay(now:number){return new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/Bucharest',year:'numeric',month:'2-digit',day:'2-digit'}).format(now)}
export function trialReminderDue(remainingDays:number){return [15,12,9,6,3,2,1].includes(remainingDays)}
export function dueReminders(profile:{created_at:number;username?:string|null;password?:string|null;host?:number|boolean;recovery_email?:string|null;trial_started_at?:number|null},subscription:{paid:boolean;status:string;accessUntil?:number|null;riskBlocked?:boolean;cancelAtPeriodEnd?:boolean}|null,now=Date.now()):AppReminder[]{
 const day=reminderDay(now),result:AppReminder[]=[];
 const account=!!profile.username;
 const created=account?(profile.trial_started_at??profile.created_at):profile.created_at;
 const age=Number.isFinite(created)?Math.round((Date.parse(day)-Date.parse(reminderDay(created)))/DAY):-1;
 if(created<=now&&age>=0&&age<3){
  if(!account)result.push({kind:'recovery-code',day});
 }
 if(profile.host&&account&&subscription?.accessUntil&&subscription.cancelAtPeriodEnd&&!subscription.riskBlocked){
  const remainingDays=Math.ceil((subscription.accessUntil-now)/DAY);
  if(remainingDays>=1&&remainingDays<=3)result.push({kind:'paid-ending',day,remainingDays,endsAt:subscription.accessUntil});
 }
 const start=trialStart(profile);
 if(profile.host&&account&&start!=null&&!subscription?.paid){
  const access=subscriptionAccess(start,subscription?.accessUntil,now,subscription?.riskBlocked);
  const trial=trialStatus(start,now);
  if(now>=start&&trial.active&&trialReminderDue(trial.remainingDays)&&!subscription?.accessUntil&&subscription?.status!=='trialing'&&!subscription?.riskBlocked)result.push({kind:'trial-ending',day,remainingDays:trial.remainingDays,endsAt:trial.endsAt});
  if(access.inGrace)result.push({kind:'payment-grace',day,endsAt:access.graceEndsAt,graceDay:access.graceDay});
 }
 return result;
}

export const GRACE_DAYS=3;
// Grace extends access, never the paid period or the next billing date.
export function subscriptionAccess(startedAt:number,paidUntil:number|null|undefined,now=Date.now(),riskBlocked=false){
 const hasPaidPeriod=!!paidUntil;
 const expiresAt=hasPaidPeriod?paidUntil!:trialStatus(startedAt,now).endsAt;
 const graceEndsAt=expiresAt+GRACE_DAYS*DAY;
 const inGrace=!riskBlocked&&now>=expiresAt&&now<graceEndsAt;
 return {expiresAt,graceEndsAt,inGrace,graceDay:inGrace?Math.floor((now-expiresAt)/DAY)+1:0,hostAccess:!riskBlocked&&now<graceEndsAt};
}
// Calendar billing avoids treating every month as 30 days or every year as 365 days.
export function nextBillingDate(at:number,plan:'monthly'|'annual'){
 const d=new Date(at),day=d.getUTCDate();d.setUTCDate(1);
 if(plan==='annual')d.setUTCFullYear(d.getUTCFullYear()+1);else d.setUTCMonth(d.getUTCMonth()+1);
 const last=new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth()+1,0)).getUTCDate();d.setUTCDate(Math.min(day,last));return d.getTime();
}
