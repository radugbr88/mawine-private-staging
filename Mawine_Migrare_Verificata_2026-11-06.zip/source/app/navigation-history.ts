// Only opaque entry IDs go into browser history; screen context stays in memory.
export type NavigationEntry<T>={view:T;scroll:number};
export class NavigationHistory<T>{
 private entries=new Map<number,NavigationEntry<T>>();
 private cursor=0;private next=0;private root:T;
 readonly scope=crypto.randomUUID();
 constructor(private browser:Pick<History,'state'|'pushState'|'replaceState'|'back'>,initial:T,private restore:(entry:NavigationEntry<T>)=>void|boolean){
  this.root=initial;
  this.write(false,0); // Same-URL boundary: Back at the first menu stays in the app.
  this.entries.set(1,{view:initial,scroll:0});this.cursor=this.next=1;this.write(true,1);
 }
 private write(push:boolean,id:number){this.browser[push?'pushState':'replaceState']({...this.browser.state,mawineNavigation:{scope:this.scope,id}},'')}
 update(view:T){const current=this.entries.get(this.cursor);if(JSON.stringify(current?.view)===JSON.stringify(view))return false;this.cursor=++this.next;this.entries.set(this.cursor,{view,scroll:0});this.write(true,this.cursor);return true}
 scroll(top:number){const entry=this.entries.get(this.cursor);if(entry)entry.scroll=top}
 pop(state:any){const marker=state?.mawineNavigation;const entry=marker?.scope===this.scope?this.entries.get(marker.id):undefined;
  if(entry){const previous=this.cursor;if(this.restore(entry)===false){this.write(true,previous);return}this.cursor=marker.id;return}
  this.cursor=1;this.entries.set(1,{view:this.root,scroll:0});this.write(true,1);this.restore(this.entries.get(1)!);
 }
 back(){this.browser.back()}
}
