'use client';
import {useEffect,useRef} from 'react';
import {NavigationHistory} from './navigation-history';
import {appScrollTop,scrollAppTo} from './mobile-ui';
export function useNavigationHistory<T>(ready:boolean,account:string,view:T,restore:(view:T)=>void|boolean,onNavigate?:(view:T)=>void){
 const controller=useRef<NavigationHistory<T>|null>(null);
 const latest=useRef({view,restore,onNavigate});latest.current={view,restore,onNavigate};
 const frame=useRef(0);
 useEffect(()=>{
  if(!ready)return;
  const oldRestoration=history.scrollRestoration;history.scrollRestoration='manual';
  const current=new NavigationHistory(history,latest.current.view,entry=>{
   if(latest.current.restore(entry.view)===false)return false;
   cancelAnimationFrame(frame.current);frame.current=requestAnimationFrame(()=>scrollAppTo({top:entry.scroll,behavior:'instant'}));
  });controller.current=current;
  const pop=(event:PopStateEvent)=>current.pop(event.state);
  const scroll=()=>current.scroll(appScrollTop());
  window.addEventListener('popstate',pop);document.addEventListener('scroll',scroll,true);
  return()=>{window.removeEventListener('popstate',pop);document.removeEventListener('scroll',scroll,true);cancelAnimationFrame(frame.current);controller.current=null;history.scrollRestoration=oldRestoration};
 },[ready,account]);
 useEffect(()=>{if(ready&&controller.current?.update(view)){cancelAnimationFrame(frame.current);frame.current=requestAnimationFrame(()=>{if(latest.current.onNavigate)latest.current.onNavigate(view);else scrollAppTo({top:0,behavior:'instant'})})}},[ready,view]);
 return ()=>controller.current?.back();
}
