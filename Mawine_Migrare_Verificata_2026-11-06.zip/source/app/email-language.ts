import {languages,translateForLanguage,type Language} from './i18n';
// Email locale comes from the recipient's stored profile, never from an unauthenticated caller.
export function emailLanguage(value:unknown):Language {
 return languages.includes(value as Language)?value as Language:'en';
}
export function emailTranslator(preference:unknown) {
 const language=emailLanguage(preference);
 return (text:string)=>{
  const translated=translateForLanguage(language,text);
  // Romanian is the source language; missing translations in other locales use English.
  return language!=='ro'&&translated===text?translateForLanguage('en',text):translated;
 };
}
