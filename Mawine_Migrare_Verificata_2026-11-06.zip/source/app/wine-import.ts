import en from './i18n-en.json';
import it from './i18n-it.json';
import fr from './i18n-fr.json';
import {splitWineName} from './wine-identity';
import {countries,type Wine} from './lib';
const normalize=(s:unknown)=>String(s??'').replace(/^\uFEFF/,'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]/g,'');
const aliases:Record<string,string[]>={name:['vin','nume','denumire','nume vin','numele vinului','denumire vin','denumirea vinului','wine','wine name','name','product','product name','produs'],winery:['crama','nume crama','denumire crama','denumirea cramei','numele cramei','producator','producător vin','winery','producer','estate','domaine','brand'],year:['an','anul','an recolta','anul recoltei','recolta','vintage','year','harvest year'],country:['tara','tara origine','tara de origine','country','origin'],grapes:['soi','soiuri','soi/soiuri','soi struguri','soiuri struguri','soiuri de struguri','struguri','grape','grapes','grape varieties','grape variety','grape/grapes','variety/varieties','variety','varieties','cepage','cupaj'],type:['tip','tip vin','culoare','wine type','type','color','colour','stil'],alcohol:['alchool','alchool %','alcool','alcool %','alc','alc %','alcohol','abv','alcohol content'],price:['pret','pret lei','pret lei (euro)','pret ron','pret eur','pret euro','pret sticla','pret pe sticla','price','price lei','price ron','price eur','cost']};
// Accept natural column names from all four application languages.
const localizedHeaders:Record<string,string[]>={name:['nom','nom du vin','vino','nome','nome vino','nome del vino'],winery:['producteur','cantina','produttore','azienda'],year:['année','millesime','anno','annata'],country:['pays','paese','origine'],grapes:['cépages','cépage','cépage/cépages','vitigni','vitigno','vitigno/vitigni','uve','uva'],type:['type de vin','couleur','tipo','tipo di vino','colore'],alcohol:['alcol','gradazione','gradazione alcolica','degré alcoolique'],price:['prix','prix eur','prix euro','prezzo','prezzo eur','prezzo euro','costo']};
for(const [field,labels] of Object.entries(localizedHeaders))aliases[field].push(...labels);
const fieldFor=(v:unknown)=>{const key=normalize(v);return Object.keys(aliases).find(field=>aliases[field].some(a=>normalize(a)===key))||( /^(soi|grape|variety)\d+$/.test(key)?'grapes':undefined)};
export const hasWineHeaders=(rows:unknown[][])=>rows.slice(0,20).some(r=>r.some(c=>['name','winery'].includes(fieldFor(c)||'')));
// RFC-style quoting: separators and newlines inside quotes are preserved.
export function parseDelimited(text:string):string[][]{
 text=text.replace(/^\uFEFF/,'');let forced='';if(/^sep=([;,\t])\r?\n/i.test(text)){forced=text[4];text=text.slice(text.indexOf('\n')+1)}
 function read(separator:string){const rows:string[][]=[];let row:string[]=[],cell='',quoted=false;
 for(let i=0;i<text.length;i++){const c=text[i];if(c==='"'){if(quoted&&text[i+1]==='"'){cell+='"';i++}else if(quoted||!cell.length)quoted=!quoted;else cell+=c}else if(c===separator&&!quoted){row.push(cell);cell=''}else if((c==='\n'||c==='\r')&&!quoted){if(c==='\r'&&text[i+1]==='\n')i++;row.push(cell);rows.push(row);row=[];cell=''}else cell+=c}
 if(quoted)throw Error('Fișier CSV invalid: există ghilimele neînchise.');if(cell||row.length){row.push(cell);rows.push(row)}return rows;
 }
 if(forced)return read(forced);
 const candidates=[';',',','\t'].map(separator=>{try{const rows=read(separator);const score=Math.max(0,...rows.slice(0,20).map(r=>r.map(fieldFor).filter(Boolean).length));return{rows,score}}catch{return{rows:[] as string[][],score:-1}}}).sort((a,b)=>b.score-a.score||Math.max(0,...b.rows.slice(0,20).map(r=>r.length))-Math.max(0,...a.rows.slice(0,20).map(r=>r.length)));
 if(candidates[0].score<0)throw Error('Fișier CSV invalid: verifică ghilimelele.');return candidates[0].rows;
}
// Country context comes only from the preamble or filename, never from wine names.
const contextWords=(value:unknown)=>String(value??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z]+/g,' ').trim();
export function importCountryContext(preamble:unknown[][],filename=''):string{
 const alternatives:Record<string,string[]>={'Portugalia':['portugheze','portughez','portugueses'],'Africa de Sud':['South Africa'],'Republica Moldova':['Moldova'],'SUA':['USA','United States','Statele Unite'],'Regatul Unit':['United Kingdom'],'Țările de Jos':['Netherlands']};
 const find=(text:string)=>countries.filter(country=>[country,...(alternatives[country]||[])].some(label=>(' '+contextWords(text)+' ').includes(' '+contextWords(label)+' ')));
 const mentioned=[...new Set(preamble.flatMap(row=>row.flatMap(cell=>find(String(cell??'')))))];
 // An ambiguous preamble must not silently fall back to a single-country filename.
 if(mentioned.length)return mentioned.length===1?mentioned[0]:'';
 const fromFile=find(filename.replace(/\.(xlsx|csv|tsv)$/i,''));
 return fromFile.length===1?fromFile[0]:'';
}
// Explicit aliases only: unknown varieties remain editable rather than being guessed.
const grapeAbbreviations:Record<string,string>={
 cs:'Cabernet Sauvignon',fn:'Fetească Neagră',m:'Merlot',ml:'Merlot',merl:'Merlot',
 ch:'Chardonnay',chard:'Chardonnay',pn:'Pinot Noir',sy:'Syrah',sh:'Shiraz',shz:'Shiraz',
 cf:'Cabernet Franc',cfr:'Cabernet Franc',rr:'Riesling',rhr:'Riesling',ries:'Riesling',rd:'Riesling',ri:'Riesling Italian',
 pm:'Pinot Meunier',sb:'Sauvignon Blanc',pv:'Petit Verdot',gr:'Grenache',gn:'Grenache',
 pb:'Pinot Blanc',fa:'Fetească Albă',fr:'Fetească Regală',ta:'Tămâioasă Românească',
 mo:'Muscat Ottonel',gb:'Grasă de Cotnari',pg:'Pinot Gris',pgs:'Pinot Grigio',
 gw:'Gewürztraminer',gew:'Gewürztraminer',alig:'Aligoté',bus:'Busuioacă de Bohotin',bab:'Băbească Neagră',
 mb:'Malbec',zn:'Zinfandel',tp:'Tempranillo',sg:'Sangiovese',cm:'Carménère',tn:'Tannat',
 gm:'Gamay',nb:'Nebbiolo',ba:'Barbera',cb:'Chenin Blanc',vi:'Viognier',gv:'Grüner Veltliner',ab:'Albariño',mt:'Muscat',
 tnacional:'Touriga Nacional',tempr:'Tempranillo',mourv:'Mourvèdre',cheninb:'Chenin Blanc',grblanc:'Grenache Blanc',grgris:'Grenache Gris',sauvgris:'Sauvignon Gris'
};
export function importGrapes(value:unknown):string[]{
 const text=String(value??'').replace(/\(\s*[\d.,%+\s]+\)/g,'').replace(/\(\s*majoritar(?:a|e|i)?\s*\)/gi,'').replace(/\b\d+(?:[.,]\d+)?\s*%\s*(?:\(soi\s+(?:alb|rosu|roșu|roze)\))?\s*/gi,';');
 return [...new Set(text.split(/[,;+&\/\n]/).map(g=>g.trim()).filter(Boolean).flatMap(g=>normalize(g)==='gsm'?['Grenache','Syrah','Mourvèdre']:[grapeAbbreviations[normalize(g)]||g]))];
}
const countryAliases:Record<string,string>={africades:'Africa de Sud',nzeelanda:'Noua Zeelandă',mbritanie:'Regatul Unit'};
// Store translated spreadsheet values under their canonical application labels.
const typeLabels=['Vin desert','Porto','Sherry','Madeira','Marsala','Spumant','Spumant brut nature','Spumant extra brut','Spumant brut','Spumant extra dry','Spumant sec','Spumant demisec','Spumant dulce',...['Alb','Orange','Rosé','Roșu'].flatMap(c=>[c,...['sec','demisec','demidulce','dulce'].map(s=>`${c} ${s}`)])];
const typeAliases:Record<string,string>={desert:'Vin desert',dessert:'Vin desert',dessertwine:'Vin desert',vinodadessert:'Vin desert',vindedessert:'Vin desert'};
for(const dictionary of [en,it,fr] as Record<string,string>[]){
 for(const country of countries)if(dictionary[country])countryAliases[normalize(dictionary[country])]=country;
 for(const type of typeLabels)if(dictionary[type])typeAliases[normalize(dictionary[type])]=type;
}
const importType=(v:string)=>typeAliases[normalize(v)]||v;
const importCountry=(v:unknown)=>countryAliases[normalize(v)]||countries.find(c=>normalize(c)===normalize(v))||String(v??'').trim();
export type WineImportGroup={number:string;date:string;rows:unknown[][]};
const journalHeader=['Cramă','Țara','Tip','Soiuri','Vin','An','Alcool','Preț'];
// Headerless tasting journal: A=event, B=producer, C=country, D/E=style,
// F=grapes, G=wine, H=vintage, I=ABV, N=price, Q=date. Never import attendees.
export function wineImportGroups(rows:unknown[][]):WineImportGroup[]{
 const recognized=rows.filter(r=>String(r[1]??'').trim()&&countries.includes(importCountry(r[2]))&&/^(alb|rosu|rose|roze|white|red|pink)$/.test(normalize(r[3])));
 if(recognized.length<2)return [];
 const groups:WineImportGroup[]=[];let current:WineImportGroup|undefined;
 for(const r of rows){
  // Ignore blank/format-only rows, titles and cells outside the wine columns.
  if(!r.slice(1,9).some(v=>String(v??'').trim()))continue;
  if(!r.slice(2,9).some(v=>String(v??'').trim()))continue;
  const marker=String(r[0]??'').trim();
  if(!current||/^\d+$/.test(marker)){
   const d=r[16];const iso=d instanceof Date?d.toISOString().slice(0,10):String(d??'');
   current={number:/^\d+$/.test(marker)?marker:String(groups.length+1),date:/^\d{4}-\d{2}-\d{2}$/.test(iso)?iso:'',rows:[journalHeader]};groups.push(current);
  }
  const solera=/^(\d{4})\s+solera$/i.exec(String(r[7]??'').trim());
  current.rows.push([r[1],importCountry(r[2]),[r[3],r[4]].filter(Boolean).join(' '),r[5],solera?[r[6],`(Solera ${solera[1]})`].filter(Boolean).join(' '):r[6],solera?'NV':r[7],r[8],r[13]]);
 }
 return groups;
}
export function parseWineRows(rows:unknown[][],limit:number,knownWineries:string[]=[],filename=''):Wine[]{
 const groups=wineImportGroups(rows);if(groups.length)rows=[journalHeader,...groups.flatMap(g=>g.rows.slice(1))];
 const headerIndex=rows.slice(0,20).findIndex(r=>r.some(c=>['name','winery'].includes(fieldFor(c)||'')));
 if(headerIndex<0)throw Error('Nu am identificat coloana cu vinul sau crama. Adaugă un antet „Vin”, „Nume vin”, „Cramă” sau „Winery”. Ordinea coloanelor este liberă.');
 const fields=rows[headerIndex].map(fieldFor);const duplicates=Object.keys(aliases).filter(f=>f!=='grapes'&&fields.filter(x=>x===f).length>1);
 if(duplicates.length)throw Error('Coloane ambigue: '+duplicates.map(f=>aliases[f][0]).join(', ')+'. Păstrează o singură coloană pentru fiecare câmp.');
 const defaultCountry=importCountryContext(rows.slice(0,headerIndex),filename);
 // A repeated Wine Name / Year / Price layout uses 'label – producer'.
 // Require at least three consistently separated wine rows; isolated hyphens stay ambiguous.
 const labelled=rows.slice(headerIndex+1).filter(r=>String(r[fields.indexOf('name')]??'').trim()&&/^\d{4}$/.test(String(r[fields.indexOf('year')]??'')));
 const combinedNames=!fields.includes('winery')&&normalize(rows[headerIndex][fields.indexOf('name')])==='winename'&&labelled.length>=3&&labelled.every(r=>String(r[fields.indexOf('name')]).split(/\s+[-–—]\s+/).length===2);
 const wines:Wine[]=[];const errors:string[]=[];
 rows.slice(headerIndex+1).forEach((row,index)=>{
  if(!row.some(v=>String(v??'').trim()))return;
  const get=(field:string)=>String(row[fields.indexOf(field)]??'').trim();
  let name=get('name');let yearText=get('year');let year:number|null=null;
  if(!fields.includes('year')){const vintage=name.match(/\s+((?:19|20)\d{2})$/);if(vintage){yearText=vintage[1];name=name.slice(0,vintage.index).trim()}}
  // Spreadsheet footers are statistics, not wines. Keep real labelled wines
  // even if their name is a reserved word, when vintage/producer/grapes exist.
  const footer=/^(summary|rezumat|total|totalgeneral|grandtotal|subtotal|average|avg|mean|medie|media|toate|all|count|numarvinuri)$/.test(normalize(name));
  const summaryOnly=!name&&!get('winery')&&!yearText&&!get('grapes')&&!get('country')&&!get('type')&&row.some(v=>/^(pretmediu|pretmedie|averageprice|total|subtotal|grandtotal|medie|media|average|summary|rezumat)$/.test(normalize(v)));
  if(summaryOnly)return;
  if(!name&&!get('winery')&&!yearText&&!get('grapes')&&!get('country')&&!get('type')&&!get('alcohol'))return;
  if(footer&&!get('winery')&&!yearText&&!get('grapes')&&!get('country')&&!get('type'))return;

  const solera=yearText.match(/^(\d{4})\s+solera$/i);if(solera){name=[name,`(Solera ${solera[1]})`].filter(Boolean).join(' ');yearText='NV'}
  if(yearText&&!/^(nv|n\/?v|fara an|non vintage|—|-)$/i.test(yearText)){year=Number(yearText);if(!Number.isInteger(year)||year<1900||year>new Date().getFullYear()){errors.push(`Rândul ${headerIndex+index+2}: anul „${yearText}” nu este valid`);return}}
  if(!name&&!get('winery')){errors.push(`Rândul ${headerIndex+index+2}: lipsește numele vinului sau crama`);return}
  const grapes=[...new Set(fields.flatMap((f,i)=>f==='grapes'?importGrapes(row[i]):[]))];
  const priceHeader=normalize(rows[headerIndex][fields.indexOf('price')]);
  const rawPrice=row[fields.indexOf('price')];let price=typeof rawPrice==='number'?String(Math.round(rawPrice*100)/100):get('price');
  const rawAlcohol=get('alcohol'),alcoholNumber=Number(rawAlcohol.replace(',','.'));
  const alcohol=rawAlcohol&&Number.isFinite(alcoholNumber)&&(typeof row[fields.indexOf('alcohol')]==='number'||(alcoholNumber>0&&alcoholNumber<1))?String(Math.round(alcoholNumber*(alcoholNumber>0&&alcoholNumber<1?100:1)*100)/100):rawAlcohol;
  const dualCurrency=/lei.*euro/.test(priceHeader);
  if(dualCurrency){const primary=price.match(/^\s*(\d+(?:[.,]\d+)?)/);if(primary)price=primary[1].replace(',','.')}
  const currency=dualCurrency?'RON':/eur|euro/.test(priceHeader)?'EUR':'';
  let identity=splitWineName(name,get('winery'),knownWineries);
  if(combinedNames&&!identity.winery){const parts=name.split(/\s+[-–—]\s+/);if(parts.length===2)identity={name:parts[0].trim(),winery:parts[1].trim()};}
  wines.push({id:crypto.randomUUID(),...identity,year,country:importCountry(get('country'))||defaultCountry,grapes,type:importType(get('type')),alcohol,price:price&&currency&&!/[a-z€$]/i.test(price)?`${price} ${currency}`:price});
 });
 if(errors.length)throw Error(errors.join('; '));
 if(wines.length>limit)throw Error(`Mai poți adăuga ${Math.max(0,limit)} vinuri în această listă.`);
 if(!wines.length)throw Error('Nu am găsit vinuri în datele introduse.');return wines;
}

// Each plain-text line is one wine; commas separate its details.
export function parsePastedWines(text:string):unknown[][]{
 const rows=parseDelimited(text);
 if(rows.slice(0,20).some(r=>r.some(c=>['name','winery'].includes(fieldFor(c)||''))))return rows;
 return [['Vin','Cramă','An','Alcool','Preț','Țara'],...text.split(/\r?\n/).filter(line=>line.trim()).map(line=>{
  const parts:string[]=[];let cell='',quoted=false;
  for(let i=0;i<line.length;i++){
   const c=line[i];
   if(c==='"'){if(quoted&&line[i+1]==='"'){cell+='"';i++}else quoted=!quoted;continue}
   const decimal=c===','&&/(?:^|\D)\d{1,3}$/.test(cell)&&/^\d{1,2}\s*(?:%|RON\b|LEI\b|EUR\b|EURO\b|USD\b)/i.test(line.slice(i+1));
   if(c===','&&!quoted&&!decimal){parts.push(cell.trim());cell=''}else cell+=c;
  }
  if(quoted)throw Error('Verifică ghilimelele din lista de vinuri.');parts.push(cell.trim());
  let year='',alcohol='',price='',country='';const names:string[]=[];
  for(let part of parts){
   const foundCountry=countries.find(c=>normalize(c)===normalize(part));if(foundCountry){country=foundCountry;continue}
   const y=part.match(/\b(?:19|20)\d{2}\b/);
   const a=part.match(/\b(\d+(?:[.,]\d+)?)\s*%/);
   const p=part.match(/\b(?:pre[tț]\s*:?\s*)(\d+(?:[.,]\d+)?)\s*(RON|LEI|EUR|EURO|USD)?/i)||part.match(/\b(\d+(?:[.,]\d+)?)\s*(RON|LEI|EUR|EURO|USD)\b/i);
   if(p){price=p[1]+(p[2]?' '+p[2]:'');part=part.replace(p[0],'')}
   if(a){alcohol=a[1];part=part.replace(a[0],'')}
   if(y){year=y[0];part=part.replace(y[0],'')}
   part=part.replace(/^\s*\d+[.)]\s*/,'').replace(/^[\s;,|–-]+|[\s;,|–-]+$/g,'').trim();
   if(part)names.push(part);
  }
  return [names.length>1?names.slice(1).join(', '):names[0]||'',names.length>1?names[0]:'',year,alcohol,price,country];
 })];
}
