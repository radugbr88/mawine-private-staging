'use client';
import {t as translate,locale} from './i18n';
import React, {useEffect, useRef, useState} from 'react';
import {CalendarDays, ChevronDown, Eye, EyeOff} from 'lucide-react';

export function BrandLogo(){return <div className="welcomeLogo"><svg viewBox="0 0 1015 248" role="img" aria-label="Mawine" preserveAspectRatio="xMidYMid meet"><image href="/brand/mawine-wordmark-hd.png?v=200" x="9" y="8" width="997" height="231" preserveAspectRatio="xMidYMid meet"/></svg></div>}


// Mobile pages scroll inside the app so Safari does not collapse its browser bars.
function appScrollContainer(){
 return window.matchMedia('(max-width:760px)').matches?document.querySelector<HTMLElement>('.appShell .mainArea'):null;
}
export function appScrollTop(){return appScrollContainer()?.scrollTop??window.scrollY}
export function scrollAppTo(options:ScrollToOptions){const container=appScrollContainer();if(container)container.scrollTo(options);else window.scrollTo(options)}
export function scrollAppBy(options:ScrollToOptions){const container=appScrollContainer();if(container)container.scrollBy(options);else window.scrollBy(options)}

// App-owned calendar keeps the selected day in the brand color on every browser.
export function DateInput({id,value,min,onValueChange}:{id:string;value:string;min:string;onValueChange:(value:string)=>void}){
 const dialog=useRef<HTMLDialogElement>(null);
 const parse=(v:string)=>{const [y,m,d]=v.split('-').map(Number);return new Date(y,m-1,d)};
 const [month,setMonth]=useState(()=>parse(value||min));
 const [selected,setSelected]=useState(value);
 const label=value?parse(value).toLocaleDateString(locale(),{day:'2-digit',month:'short',year:'numeric'}):'Alege data';
 const iso=(day:number)=>`${month.getFullYear()}-${String(month.getMonth()+1).padStart(2,'0')}-${String(day).padStart(2,'0')}`;
 const offset=(new Date(month.getFullYear(),month.getMonth(),1).getDay()+6)%7;
 const count=new Date(month.getFullYear(),month.getMonth()+1,0).getDate();
 const canBack=iso(1).slice(0,7)>min.slice(0,7);
 const open=()=>{setMonth(parse(value||min));setSelected(value);dialog.current?.showModal()};
 return <><button id={id} type="button" className="dateControl" aria-haspopup="dialog" aria-label={translate(`Data: ${label}`)} onClick={open}>{translate(label)}</button>
 <dialog ref={dialog} className="dateCalendar" aria-label={translate("Alege data degustării")} onClick={e=>{if(e.target===e.currentTarget){const r=e.currentTarget.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)dialog.current?.close()}}}>
 <header><strong>{translate(month.toLocaleDateString(locale(),{month:'long',year:'numeric'}))}</strong><button type="button" disabled={!canBack} aria-label={translate("Luna precedentă")} onClick={()=>setMonth(new Date(month.getFullYear(),month.getMonth()-1,1))}>{translate("‹")}</button><button type="button" aria-label={translate("Luna următoare")} onClick={()=>setMonth(new Date(month.getFullYear(),month.getMonth()+1,1))}>{translate("›")}</button></header>
 <div className="calendarDays">{translate(['Lu','Ma','Mi','Jo','Vi','Sâ','Du'].map(d=><span key={d}>{translate(d)}</span>))}{translate(Array.from({length:offset},(_,i)=><span key={`empty${i}`}/>))}{translate(Array.from({length:count},(_,i)=>{const date=iso(i+1);return <button type="button" key={date} disabled={date<min} aria-label={translate(parse(date).toLocaleDateString(locale(),{day:'numeric',month:'long',year:'numeric'}))} aria-pressed={selected===date} onClick={()=>setSelected(date)}>{translate(i+1)}</button>}))}</div>
 <footer><button type="button" onClick={()=>dialog.current?.close()}>{translate("Renunță")}</button><button type="button" className="calendarConfirm" disabled={!selected||selected<min} onClick={()=>{onValueChange(selected);dialog.current?.close()}}>{translate("Confirmă")}</button></footer>
 </dialog></>;
}

export function PasswordInput(props:React.InputHTMLAttributes<HTMLInputElement>){
 const [visible,setVisible]=useState(false);const input=useRef<HTMLInputElement>(null);
 return <div className="passwordControl"><input {...props} ref={input} type={visible?'text':'password'}/><button type="button" aria-label={translate(visible?'Ascunde parola':'Arată parola')} aria-pressed={visible} onPointerDown={e=>e.preventDefault()} onClick={()=>{setVisible(v=>!v);requestAnimationFrame(()=>{input.current?.focus({preventScroll:true});if(input.current)revealField(input.current)})}}>{translate(visible?<EyeOff size={20}/>:<Eye size={20}/>)}</button></div>;
}

// Use the actual visible viewport, including the space taken by the keyboard.
export function revealField(el:HTMLElement,selection=false){
 const grapes=el.closest<HTMLElement>('.grapes');
 if(grapes&&el.matches?.('input[type=search]')){el=grapes;selection=true}
 const v=window.visualViewport,modal=el.closest<HTMLElement>('.modal');
 const bounds=modal?.getBoundingClientRect();
 const viewportTop=v?.offsetTop||0;
 const header=modal?.querySelector<HTMLElement>(':scope > h2');
 const headerSpace=!selection&&el.matches?.('input,textarea,select')&&header?header.getBoundingClientRect().height+16:0;
 const top=Math.max(bounds?.top??viewportTop,viewportTop)+16+headerSpace;
 const bottom=bounds?Math.min(bounds.bottom,viewportTop+(v?.height||window.innerHeight))-16:(v?.offsetTop||0)+(v?.height||window.innerHeight)-(window.matchMedia('(max-width:760px)').matches?88:24);
 const input=el.getBoundingClientRect();
 const delta=selection?input.top-top:input.bottom>bottom?input.bottom-bottom:input.top<top?input.top-top:0;
 if(Math.abs(delta)>2){if(modal)modal.scrollTop+=delta;else scrollAppBy({top:delta,behavior:'instant'});}
}
// Reveal the selected import panel after layout; short manual content naturally clamps to the page bottom.
export function revealImportTabs(el:HTMLElement,mode:string){
 const container=appScrollContainer();
 // Align the source tabs, not the preceding heading. Excel has the larger
 // top inset shown in the reference; collection starts just inside the viewport.
 const target=(container?.getBoundingClientRect().top??window.visualViewport?.offsetTop??0)+(mode==='excel'?48:12);
 const delta=el.getBoundingClientRect().top-target;
 if(Math.abs(delta)>2)scrollAppBy({top:delta,behavior:'instant'});
}
export function useVisibleField(){
 useEffect(()=>{
  const viewport=window.visualViewport;let timer:ReturnType<typeof setTimeout>;let userScrolling=false;
  const editable=(el:Element|null):el is HTMLElement=>el instanceof HTMLElement&&el.matches('input:not([type=radio]):not([type=checkbox]):not([type=hidden]),textarea,select');
  function metrics(){
   document.documentElement.style.setProperty('--visible-top',`${viewport?.offsetTop||0}px`);
   document.documentElement.style.setProperty('--visible-height',`${viewport?.height||window.innerHeight}px`);
   document.documentElement.classList.toggle('editingField',editable(document.activeElement));
  }
  function focus(e:FocusEvent){
   clearTimeout(timer);metrics();userScrolling=false;
   const el=e.target;if(!(el instanceof HTMLElement)||!editable(el))return;
   timer=setTimeout(()=>{if(!userScrolling&&document.activeElement===el)revealField(el)},450);
  }
  function manual(){userScrolling=true;clearTimeout(timer)}
  function blur(){clearTimeout(timer);setTimeout(metrics,0)}
  metrics();viewport?.addEventListener('resize',metrics);viewport?.addEventListener('scroll',metrics);
  document.addEventListener('focusin',focus);document.addEventListener('focusout',blur);document.addEventListener('touchmove',manual,{passive:true});document.addEventListener('wheel',manual,{passive:true});
  return()=>{clearTimeout(timer);viewport?.removeEventListener('resize',metrics);viewport?.removeEventListener('scroll',metrics);document.removeEventListener('focusin',focus);document.removeEventListener('focusout',blur);document.removeEventListener('touchmove',manual);document.removeEventListener('wheel',manual);document.documentElement.classList.remove('editingField')};
 },[]);
}

export function BirthDate({defaultValue=''}:{defaultValue?:string}){
 const [value,setValue]=useState(defaultValue),[open,setOpen]=useState(false);
 const today=new Date(),currentYear=today.getFullYear();
 const [year,setYear]=useState(defaultValue?Number(defaultValue.slice(0,4)):currentYear-30);
 const [month,setMonth]=useState(defaultValue?Number(defaultValue.slice(5,7))-1:0);
 const trigger=useRef<HTMLInputElement>(null);
 const months=['Ianuarie','Februarie','Martie','Aprilie','Mai','Iunie','Iulie','August','Septembrie','Octombrie','Noiembrie','Decembrie'];
 const count=new Date(year,month+1,0).getDate(),offset=(new Date(year,month,1).getDay()+6)%7;
 return <div className="birthDate"><label className="field"><span>{translate("Data nașterii")}</span><div className="birthTrigger"><input ref={trigger} aria-label={translate("Data nașterii")} aria-expanded={open} aria-controls="birth-calendar" value={value?value.split('-').reverse().join(' / '):''} placeholder={translate("ZZ / LL / AAAA")} inputMode="none" required onChange={()=>{}} onClick={()=>setOpen(!open)} onKeyDown={e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();setOpen(!open)}if(e.key==='Escape')setOpen(false)}} onInvalid={()=>setOpen(true)}/><CalendarDays size={20}/></div></label><input type="hidden" name="dob" value={value}/>{translate(open&&<div className="birthCalendar" id="birth-calendar" role="group" aria-label={translate("Alege data nașterii")} onKeyDown={e=>{if(e.key==='Escape'){setOpen(false);trigger.current?.focus()}}}><p>{translate("Alege anul, luna, apoi ziua.")}</p><div className="twoCol"><label>{translate("Anul")}<select aria-label={translate("Anul nașterii")} value={year} onChange={e=>setYear(Number(e.target.value))}>{translate(Array.from({length:currentYear-1900+1},(_,i)=>currentYear-i).map(y=><option key={y} value={y}>{translate(y)}</option>))}</select></label><label>{translate("Luna")}<select aria-label={translate("Luna nașterii")} value={month} onChange={e=>setMonth(Number(e.target.value))}>{translate(months.map((m,i)=><option key={m} value={i}>{translate(m)}</option>))}</select></label></div><div className="calendarDays">{translate(['Lu','Ma','Mi','Jo','Vi','Sâ','Du'].map(d=><span key={d}>{translate(d)}</span>))}{translate(Array.from({length:offset},(_,i)=><span key={'blank'+i}/>))}{translate(Array.from({length:count},(_,i)=>i+1).map(day=>{const iso=`${year}-${String(month+1).padStart(2,'0')}-${String(day).padStart(2,'0')}`;return <button key={day} type="button" aria-label={translate(`${day} ${months[month]} ${year}`)} aria-pressed={value===iso} disabled={new Date(year,month,day)>today} onClick={()=>{setValue(iso);setOpen(false);trigger.current?.focus()}}>{translate(day)}</button>}))}</div></div>)}</div>
}

// Still-wine sweetness: OIV I.3.2; sparkling categories: Comité Champagne.
export const wineTypeGroups=[
 {name:'Spumant',values:['Spumant brut nature','Spumant extra brut','Spumant brut','Spumant extra dry','Spumant sec','Spumant demisec','Spumant dulce']},
 ...['Alb','Orange','Rosé','Roșu'].map(name=>({name,values:['sec','demisec','demidulce','dulce'].map(s=>`${name} ${s}`)})),
 {name:'Vin desert',values:['Vin desert']},
 {name:'Fortificat',values:['Porto','Sherry','Madeira','Marsala']}
];
export function wineTypeOptionLabel(value:string){
 const labels:Record<string,string>={'Spumant brut nature':'Brut nature','Spumant extra brut':'Extra brut','Spumant brut':'Brut','Spumant extra dry':'Extra dry','Spumant sec':'Sec','Spumant demisec':'Demi-sec','Spumant dulce':'Dulce'};
 return translate(labels[value]||value);
}
export function WineTypeSelect({value,onChange}:{value:string;onChange:(value:string)=>void}){
 const [open,setOpen]=useState(false);const root=useRef<HTMLDivElement>(null);
 useEffect(()=>{
  if(!open)return;
  const outside=(event:PointerEvent)=>{if(event.target instanceof Node&&!root.current?.contains(event.target))setOpen(false)};
  const escape=(event:KeyboardEvent)=>{if(event.key==='Escape')setOpen(false)};
  const focusOutside=(event:FocusEvent)=>{if(event.target instanceof Node&&!root.current?.contains(event.target))setOpen(false)};
  document.addEventListener('pointerdown',outside);document.addEventListener('keydown',escape);document.addEventListener('focusin',focusOutside);
  return()=>{document.removeEventListener('pointerdown',outside);document.removeEventListener('keydown',escape);document.removeEventListener('focusin',focusOutside)};
 },[open]);
 useEffect(()=>{if(open&&root.current)requestAnimationFrame(()=>revealField(root.current!,true))},[open]);
 return <div className="wineTypeSelect" ref={root}><button type="button" className="select" aria-expanded={open} onClick={()=>setOpen(!open)}>{translate(value||'Nespecificat')}<ChevronDown size={18}/></button>{translate(open&&<div className="wineTypeOptions" role="group" aria-label={translate("Tipul vinului")}><button type="button" aria-pressed={!value} onClick={()=>{onChange('');setOpen(false)}}>{translate("Nespecificat")}</button>{translate(wineTypeGroups.map(g=><section key={g.name}>{g.values.length>1&&<strong>{translate(g.name)}</strong>}{translate(g.values.map(v=><button type="button" key={v} className={g.values.length===1?'wineTypeSingle':undefined} aria-pressed={value===v} onClick={()=>{onChange(v);setOpen(false)}}>{wineTypeOptionLabel(v)}{translate(value===v?' ✓':'')}</button>))}</section>))}</div>)}</div>
}
