import {emailTranslator} from './email-language';
import {RequestError,digest,equalSecret,rateLimit} from './security';
import {resetEmailConfig,sendResetEmail,type ResetEmailEnv} from './reset-email';
export type AccountEnv=ResetEmailEnv&{MAWINE_RECOVERY_ENCRYPTION_KEY?:string};
const bytes=(s:string)=>new TextEncoder().encode(s);
export const normalizeEmail=(value:unknown)=>typeof value==='string'?value.trim().toLowerCase():'';
export const validEmail=(email:string)=>email.length<=254&&/^[^\s<>@]+@[^\s<>@]+\.[^\s<>@]+$/.test(email);
async function keyBytes(env:AccountEnv){try{const raw=Uint8Array.from(atob(env.MAWINE_RECOVERY_ENCRYPTION_KEY||''),c=>c.charCodeAt(0));if(raw.length===32)return raw}catch{}throw new RequestError('Protecția codurilor de recuperare nu este configurată. Contactează administratorul.',503)}
const b64=(v:Uint8Array)=>btoa(String.fromCharCode(...v));
export async function sealCode(env:AccountEnv,profileId:string,code:string){const key=await crypto.subtle.importKey('raw',await keyBytes(env),'AES-GCM',false,['encrypt']);const iv=crypto.getRandomValues(new Uint8Array(12));const cipher=await crypto.subtle.encrypt({name:'AES-GCM',iv,additionalData:bytes(profileId)},key,bytes(code));return 'v1:'+b64(iv)+':'+b64(new Uint8Array(cipher))}
export async function openCode(env:AccountEnv,profileId:string,value:string|null){if(!value)return null;const [version,iv,cipher]=value.split(':');if(version!=='v1')throw new Error('Invalid recovery encryption');const key=await crypto.subtle.importKey('raw',await keyBytes(env),'AES-GCM',false,['decrypt']);const raw=(s:string)=>Uint8Array.from(atob(s),c=>c.charCodeAt(0));return new TextDecoder().decode(await crypto.subtle.decrypt({name:'AES-GCM',iv:raw(iv),additionalData:bytes(profileId)},key,raw(cipher)))}
export async function emailFingerprint(env:AccountEnv,email:string){const key=await crypto.subtle.importKey('raw',await keyBytes(env),{name:'HMAC',hash:'SHA-256'},false,['sign']);return b64(new Uint8Array(await crypto.subtle.sign('HMAC',key,bytes('mawine-trial-v1:'+normalizeEmail(email)))))}
export async function issueVerification(db:any,env:AccountEnv,profile:any,identity:string,email:string,passwordHash:string){
 const config=resetEmailConfig(env);if(!config)throw new RequestError('Verificarea prin e-mail nu este încă disponibilă. Contactează administratorul.',503);
 await rateLimit(db,'verify-resend:'+profile.id,1,60000);await rateLimit(db,'verify-daily:'+profile.id,10,86400000);
 const token=Array.from(crypto.getRandomValues(new Uint8Array(32))).map(x=>x.toString(16).padStart(2,'0')).join('');const now=Date.now();const hash=await digest(token);
 await db.prepare('INSERT INTO email_verifications(profile_id,email,password_hash,token_hash,identity,expires) VALUES(?,?,?,?,?,?) ON CONFLICT(profile_id) DO UPDATE SET email=excluded.email,password_hash=excluded.password_hash,token_hash=excluded.token_hash,identity=excluded.identity,expires=excluded.expires').bind(profile.id,email,passwordHash,hash,identity,now+600000).run();
 const t=emailTranslator(profile.language);
 try{await sendResetEmail(config,email,t('Mawine — Confirmă adresa de e-mail'),t('Confirmă adresa de e-mail pentru a activa contul Mawine:')+'\n\n'+config.origin+'/#verify='+token+'\n\n'+t('Linkul este valabil 10 minute și poate fi folosit o singură dată. Dacă nu ai solicitat crearea contului, ignoră acest mesaj.'))}catch{await db.prepare('DELETE FROM email_verifications WHERE profile_id=? AND token_hash=?').bind(profile.id,hash).run();throw new RequestError('E-mailul nu a putut fi trimis. Încearcă din nou.',503)}
 return {email};
}

export async function purgeTrialLedger(db:any,now=Date.now()){await db.prepare("DELETE FROM trial_email_ledger WHERE used_at<=?").bind(now-365*86400000).run()}
