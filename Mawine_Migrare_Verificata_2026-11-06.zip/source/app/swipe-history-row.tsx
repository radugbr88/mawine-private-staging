'use client';
import {t as translate,locale} from './i18n';
import React,{useEffect,useRef,useState} from 'react';
import {Trash2,Star} from 'lucide-react';
export function SwipeHistoryRow({children,title,favorite,onFavorite,onDelete}:{children:React.ReactNode;title:string;favorite?:boolean;onFavorite?:()=>void;onDelete:()=>void}){
 const actionWidth=84;
 const [offset,setOffset]=useState(0),[dragging,setDragging]=useState(false);
 const root=useRef<HTMLDivElement>(null);
 useEffect(()=>{if(!offset)return;const close=(e:PointerEvent)=>{if(!root.current?.contains(e.target as Node))setOffset(0)};document.addEventListener('pointerdown',close);return()=>document.removeEventListener('pointerdown',close)},[offset]);
 const gesture=useRef({x:0,y:0,start:0,axis:'',moved:false});
 const begin=(x:number,y:number)=>{gesture.current={x,y,start:offset,axis:'',moved:false}};
 const move=(x:number,y:number)=>{const g=gesture.current,dx=x-g.x,dy=y-g.y;if(!g.axis&&Math.max(Math.abs(dx),Math.abs(dy))>10)g.axis=Math.abs(dx)>Math.abs(dy)*1.3?'x':'y';if(g.axis==='x'){g.moved=true;setDragging(true);setOffset(Math.max(-actionWidth,Math.min(onFavorite?actionWidth:0,g.start+dx)))}};
 const end=()=>{setDragging(false);setOffset(v=>v<-40?-actionWidth:v>40?actionWidth:0)};
 return <div ref={root} className="swipeHistory" data-revealed={offset!==0} data-direction={offset>0?'favorite':offset<0?'delete':undefined} tabIndex={0} aria-label={translate(title+' — glisează la stânga pentru ștergere'+(onFavorite?' sau la dreapta pentru favorite':''))} onKeyDown={e=>{if(e.key==='ArrowLeft'){e.preventDefault();setOffset(-actionWidth)}if(e.key==='ArrowRight'&&onFavorite){e.preventDefault();setOffset(actionWidth)}if(e.key==='Escape')setOffset(0)}}>
  <button className="historyFavorite" style={{visibility:offset>0?'visible':'hidden'}} tabIndex={offset>0?0:-1} aria-pressed={favorite} aria-label={translate((favorite?'Elimină din favorite: ':'Adaugă la favorite: ')+title)} onClick={()=>{onFavorite?.();setOffset(0)}}><Star size={18} fill={favorite?'currentColor':'none'}/><span>{translate(favorite?'Elimină favorita':'Adaugă la favorite')}</span></button>
  <button className="historyDelete" style={{visibility:offset<0?'visible':'hidden'}} tabIndex={offset<0?0:-1} aria-label={translate((onFavorite?'Șterge din istoric: ':'Șterge degustarea: ')+title)} onClick={onDelete}><Trash2 size={18}/>{translate("Șterge")}</button>
  <div className="historySlide" style={{width:'100%',transform:`translateX(${offset}px)`,transition:dragging?'none':undefined}}
   onTouchStart={e=>begin(e.touches[0].clientX,e.touches[0].clientY)} onTouchMove={e=>move(e.touches[0].clientX,e.touches[0].clientY)} onTouchEnd={end} onTouchCancel={end}
   onPointerDown={e=>{if(e.pointerType==='mouse'){begin(e.clientX,e.clientY)}}} onPointerMove={e=>{if(e.pointerType==='mouse'&&e.buttons===1){move(e.clientX,e.clientY);if(gesture.current.axis==='x')e.currentTarget.setPointerCapture(e.pointerId)}}} onPointerUp={e=>{if(e.pointerType==='mouse')end()}}
   onClickCapture={e=>{if(gesture.current.moved){e.preventDefault();e.stopPropagation();gesture.current.moved=false;return}if(offset!==0){e.preventDefault();e.stopPropagation();setOffset(0)}}}>
   {translate(children)}
  </div>
 </div>
}
