'use client';
import {useEffect,useRef,useState} from 'react';
import {CalendarDays,KeyRound,Smartphone} from 'lucide-react';
import {t,locale} from './i18n';
import type {Profile} from './lib';
import {trialReminderDue,reminderDay,type AppReminder} from './subscription';
import {PaidExpiryNotice} from './paid-expiry-notice';
import {GraceNotice} from './grace-notice';
import {RecoveryPrompt} from './recovery-prompt';

export function installPlatform(){if(typeof navigator==='undefined')return '';if(/iPhone|iPad|iPod/.test(navigator.userAgent)||(navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1))return 'ios';return /Android/.test(navigator.userAgent)?'android':''}
export function installed(){return window.matchMedia('(display-mode: standalone)').matches||(navigator as Navigator&{standalone?:boolean}).standalone===true}
export function reminderCanOpen(blocked:boolean){
 return !blocked&&document.visibilityState==='visible'&&!document.querySelector('dialog[open],.modalBackdrop')&&!['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName||'');
}
export function AppReminders({profile,blocked,code,initial,onInitialDone,onNavigate}:{profile:Profile;blocked:boolean;code:string;initial:boolean;onInitialDone:()=>void;onNavigate:(page:string)=>void;onSaveEmail?:(email:string,current?:string)=>Promise<boolean>}){
 const [pending,setPending]=useState<AppReminder|null>(null),[visible,setVisible]=useState(false),[now,setNow]=useState(Date.now());
 const current=useRef({profile,blocked,pending,visible,initial});current.current={profile,blocked,pending,visible,initial};
 const nextCheck=useRef(0);
 useEffect(()=>{
  let alive=true,inFlight=false;
  async function check(){
   if(!alive)return;
   const c=current.current;
   if(c.visible){if(document.visibilityState==='visible')setNow(Date.now());return;}
   if(!reminderCanOpen(c.blocked))return;
   if(c.pending){setNow(Date.now());setVisible(true);return;}
   if(inFlight||Date.now()<nextCheck.current)return;
   inFlight=true;nextCheck.current=Date.now()+60_000;
   try{
    const response=await fetch('/api/app',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'claimReminder',profileId:profile.id})});
    if(!response.ok)return;
    let result=await response.json() as {profileId:string;reminder:AppReminder|null};
    if(!alive||result.profileId!==profile.id)return;
    if(!result.reminder&&installPlatform()&&!installed()){const r=await fetch('/api/app',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'claimInstallReminder'})});if(r.ok)result=await r.json();if(!alive||result.profileId!==profile.id)return;}
    if(result.reminder){setPending(result.reminder);setNow(Date.now());if(reminderCanOpen(current.current.blocked))setVisible(true);}
   }catch{/* Retry on the next visible minute; never block the app for a reminder. */}
   finally{inFlight=false;}
  }
  const interval=setInterval(()=>void check(),15_000);
  const wake=()=>{if(document.visibilityState==='visible')void check()};
  document.addEventListener('visibilitychange',wake);window.addEventListener('focus',wake);void check();
  return()=>{alive=false;clearInterval(interval);document.removeEventListener('visibilitychange',wake);window.removeEventListener('focus',wake)};
 },[profile.id]);
 useEffect(()=>{nextCheck.current=0},[initial,profile.username]);
 function close(){setVisible(false);setPending(null);nextCheck.current=Date.now()+1500;if(initial)onInitialDone()}
 // Discard stale responses after account changes, renewal changes or expiry, including a backgrounded modal.
 const days=pending?.endsAt?Math.max(0,Math.ceil((pending.endsAt-now)/86_400_000)):0;
 const valid=pending&&pending.day===reminderDay(now)&&(pending.kind==='install-app'?!installed():pending.kind==='recovery-code'?!profile.username:pending.kind==='paid-ending'?!!profile.host&&!!profile.billing?.subscription?.cancelAtPeriodEnd&&days>0&&days<=3&&profile.billing?.subscription?.accessUntil===pending.endsAt:pending.kind==='payment-grace'?!!profile.host&&!!profile.billing?.grace?.inGrace&&days>0:!!profile.host&&!profile.billing?.subscription?.paid&&profile.billing?.subscription?.status!=='trialing'&&trialReminderDue(days));
 useEffect(()=>{if(pending&&!valid){setPending(null);setVisible(false);nextCheck.current=0}},[pending,valid]);
 if(!pending||!visible||!valid||blocked)return null;
 if(pending.kind==='install-app')return <ReminderDialog kind={pending.kind} onClose={close}><h2 id="app-reminder-title">{t('Adaugă Mawine pe ecranul principal')}</h2><p>{t('Pentru o experiență mai bună și acces rapid la toate funcțiile, recomandăm să adaugi Mawine pe ecranul principal.')}</p><p>{t(installPlatform()==='ios'?'Pe iPhone sau iPad: deschide Mawine în Safari, apasă Distribuie, apoi Adaugă pe ecranul principal.':'Pe Android: deschide meniul browserului (⋮), apoi Instalează aplicația sau Adaugă pe ecranul principal.')}</p><button className="btn full" onClick={close}>{t('Am înțeles')}</button></ReminderDialog>;
 if(pending.kind==='recovery-code'&&code)return <RecoveryPrompt code={code} reminder={!initial} onContinue={close}/>;
 if(pending.kind==='paid-ending')return <ReminderDialog kind={pending.kind} onClose={close}><h2 id="app-reminder-title">{t('Reamintire abonament')}</h2><PaidExpiryNotice endsAt={pending.endsAt!} days={days} cancelled={!!profile.billing?.subscription?.cancelAtPeriodEnd} onManage={()=>{close();onNavigate('subscription')}}/><button className="textbtn reminderLater" onClick={close}>{t('Mai târziu')}</button></ReminderDialog>;
 if(pending.kind==='payment-grace')return <ReminderDialog kind={pending.kind} onClose={close}><h2 id="app-reminder-title">{t('Perioadă de grație')}</h2><GraceNotice day={profile.billing?.grace?.graceDay||pending.graceDay||1} endsAt={pending.endsAt!} onPay={()=>{close();onNavigate('subscription')}}/><button className="textbtn reminderLater" onClick={close}>{t('Mai târziu')}</button></ReminderDialog>;
 return <ReminderDialog kind={pending.kind} onClose={close}>
 {pending.kind==='recovery-code'?<><h2 id="app-reminder-title">{t('Salvează codul de acces')}</h2><p>{t('Codul tău unic de recuperare este disponibil în Profil. Păstrează-l pentru a reveni la profil dacă te deconectezi sau schimbi telefonul.')}</p><button className="btn full" onClick={()=>{close();onNavigate('recovery')}}>{t('Deschide codul de recuperare')}</button></>:<><h2 id="app-reminder-title">{t(days===1?'Mai ai o zi gratuită':`Mai ai ${days} zile gratuite`)}</h2><p>{t('Perioada gratuită se încheie pe')} <strong>{new Date(pending.endsAt!).toLocaleDateString(locale(),{day:'numeric',month:'long',year:'numeric'})}</strong>.</p><p>{t('Alege un abonament pentru a continua să organizezi degustări după această dată.')}</p><button className="btn full" onClick={()=>{close();onNavigate('subscription')}}>{t('Vezi abonamentele')}</button></>}
 <button type="button" className="textbtn reminderLater" onClick={close}>{t('Mai târziu')}</button>
 </ReminderDialog>;
}
function ReminderDialog({kind,onClose,children}:{kind:AppReminder['kind'];onClose:()=>void;children:React.ReactNode}){
 const ref=useRef<HTMLDialogElement>(null);
 useEffect(()=>{const dialog=ref.current,focused=document.activeElement as HTMLElement|null;dialog?.showModal();const previous=document.body.style.overflow;document.body.style.overflow='hidden';return()=>{dialog?.close();document.body.style.overflow=previous;focused?.focus?.({preventScroll:true})}},[]);
 const Icon=kind==='install-app'?Smartphone:(kind==='trial-ending'||kind==='payment-grace'||kind==='paid-ending')?CalendarDays:KeyRound;
 return <dialog ref={ref} className="recoveryPrompt appReminder" aria-labelledby="app-reminder-title" onCancel={event=>{event.preventDefault();onClose()}}><div className="recoveryPromptContent"><span className="reminderIcon" aria-hidden="true"><Icon size={28}/></span>{children}</div></dialog>;
}
