import {ArrowRight} from 'lucide-react';
import {t} from './i18n';
export function ParticipantHostInvite({onHost,hasUsername=false}:{onHost:()=>void;hasUsername?:boolean}){
 return <section className="profileSection"><h2>{t('Vrei să organizezi degustări?')}</h2><p>{t('Invită prietenii și gestionează propriile degustări.')}</p><button className="btn full" onClick={onHost}>{t(hasUsername?'Reactivează rolul de gazdă':'Devino gazdă')} <ArrowRight size={18}/></button><small>{t('Istoricul și favoritele rămân în același profil.')}</small></section>;
}
