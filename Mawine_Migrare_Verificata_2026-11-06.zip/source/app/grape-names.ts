import grapeData from './grape-data.json';
export const grapeKey=(s:string)=>s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]/g,'');
const aliases:Record<string,string>={grenache:'Grenache',grenachenoir:'Grenache',garnachatinta:'Grenache',malbec:'Malbec',cot:'Malbec',merlotnoir:'Merlot',merlot:'Merlot',pinotgrigio:'Pinot Gris',shiraz:'Syrah',gewuerztraminer:'Gewürztraminer',feteascaalba:'Fetească Albă',feteascaneagra:'Fetească Neagră',feteascaregala:'Fetească Regală'};
for(const grape of grapeData)for(const name of [grape.name,...grape.aliases])aliases[grapeKey(name)]=grape.name;
export const canonicalGrape=(s:string)=>aliases[grapeKey(s)]||s.trim();
export const sameGrapes=(a:string[],b:string[])=>{const keys=(v:string[])=>[...new Set(v.map(s=>grapeKey(canonicalGrape(s))))].sort();return a.length>0&&b.length>0&&JSON.stringify(keys(a))===JSON.stringify(keys(b))};

// Approved country-specific labels: selectable independently, scored by cultivar.
export const separateGrapeLabels:Record<string,string[]>={
 'Syrah':['Shiraz'],'Tempranillo':['Tinta Roriz'],
 'Tribidrag':['Zinfandel','Primitivo'],'Grenache':['Garnacha'],
 'Monastrell':['Mourvèdre'],'Pinot Gris':['Pinot Grigio'],'Mazuelo':['Carignan'],
 'Macabeo':['Viura'],'Malbec':['Côt'],'Trebbiano Toscano':['Ugni Blanc'],
 'Alvarinho':['Albariño'],'Graševina':['Welschriesling'],'Durif':['Petite Sirah'],
 'Sauvignonasse':['Friulano']
};
const displayLabels=new Map(Object.entries(separateGrapeLabels).flatMap(([primary,names])=>[primary,...names].map(name=>[grapeKey(name),name] as const)));
export const displayGrape=(name:string)=>grapeKey(name)==='garnachatinta'?'Garnacha':displayLabels.get(grapeKey(name))||canonicalGrape(name);
export const grapeChoices=grapeData.flatMap(g=>{
 const labels=separateGrapeLabels[g.name];
 if(!labels)return [g];
 return [g.name,...labels].map((name,i)=>({...g,id:i?-g.id*10-i:g.id,name,aliases:i?(name==='Garnacha'?['Garnacha Tinta']:[]):g.aliases.filter(a=>!labels.some(n=>grapeKey(n)===grapeKey(a))&&!(g.name==='Grenache'&&grapeKey(a)==='garnachatinta'))}));
});
