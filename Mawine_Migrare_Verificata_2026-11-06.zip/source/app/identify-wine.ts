import type {Wine} from './lib';
import {splitWineName} from './wine-identity';
import {canonicalGrape,grapeKey} from './grape-names';
const words=(s:string)=>s.match(/[\p{L}\p{N}]+/gu)||[];
const phrase=(s:string)=>words(s).map(grapeKey).join(' ');
export function wineIdentifier(varieties:{name:string}[],knownWineries:string[]=[],preserveName=false){
 const names=new Map<string,string>();for(const g of varieties){if(/\p{L}{3}/u.test(g.name)){names.set(phrase(g.name),canonicalGrape(g.name));names.set(phrase(canonicalGrape(g.name)),canonicalGrape(g.name))}}
 for(const [alias,canonical] of [['Pinot Grigio','Pinot Gris'],['Shiraz','Syrah'],['Garnacha Tinta','Grenache'],['Grenache Noir','Grenache'],['Côt','Malbec']])if(names.has(phrase(canonical)))names.set(phrase(alias),canonical);
 const wineryNames=[...new Set(knownWineries.filter(Boolean))].sort((a,b)=>b.length-a.length);
 return (wine:Wine):Wine=>{
  const split=splitWineName(wine.name,wine.winery,knownWineries);let name=split.name,winery=split.winery;
  // Match known winery at either edge, also without a dash. Do not infer an unknown producer.
  if(!winery){for(const candidate of wineryNames){const source=words(name),known=words(candidate);const n=known.length;
   if(source.length<=n)continue;
   if(phrase(source.slice(0,n).join(' '))===phrase(candidate)){winery=candidate;name=source.slice(n).join(' ');break}
   if(phrase(source.slice(-n).join(' '))===phrase(candidate)){winery=candidate;name=source.slice(0,-n).join(' ');break}
  }}
  const labelName=name;
  const tokens=[...name.matchAll(/[\p{L}\p{N}]+/gu)];const matches:{start:number;end:number;name:string}[]=[];
  for(let i=0;i<tokens.length;i++){for(let n=Math.min(8,tokens.length-i);n>0;n--){const text=tokens.slice(i,i+n).map(t=>grapeKey(t[0])).join(' ');const found=names.get(text);if(found){matches.push({start:tokens[i].index!,end:tokens[i+n-1].index!+tokens[i+n-1][0].length,name:found});i+=n-1;break}}}
  const supplied=wine.grapes.length>0;const grapes=supplied?wine.grapes:[...new Set(matches.map(m=>m.name))];
  // Only remove recognized varietal text when it agrees with the explicit grape column.
  const remove=matches.filter(m=>!supplied||grapes.some(g=>grapeKey(canonicalGrape(g))===grapeKey(m.name)));
  let remaining=name;for(const m of [...remove].reverse())remaining=remaining.slice(0,m.start)+remaining.slice(m.end);
  remaining=remaining.replace(/\s*[-–—,;+&/]\s*(?=[-–—,;+&/]|$)/g,' ').replace(/^[\s–—,;+&/-]+|[\s–—,;+&/-]+$/g,'').replace(/\s+/g,' ').trim();
  // A varietal-only label is a legitimate wine name; never turn it into an empty name.
  if(remaining&&/[\p{L}]/u.test(remaining))name=remaining;
  return{...wine,name:preserveName?labelName:name,winery,grapes};
 };
}
