import {digest,RequestError,rateLimit} from './security';
import {resetEmailConfig,sendResetEmail,type ResetEmailEnv} from './reset-email';
import {emailTranslator} from './email-language';
export const ADMIN_EMAIL='radugbr88@gmail.com';
const random=()=>Array.from(crypto.getRandomValues(new Uint8Array(32))).map(b=>b.toString(16).padStart(2,'0')).join('');
export const pendingCookie=(value:string)=>`__Host-mawine_admin_pending=${value}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=600`;
export async function sendAdminChallenge(db:D1Database,env:ResetEmailEnv,language:string,device?:string){
 const config=resetEmailConfig(env);if(!config)throw new RequestError('Verificarea prin e-mail nu este încă disponibilă. Contactează administratorul.',503);
 await rateLimit(db,'admin-email-minute',1,60000);await rateLimit(db,'admin-email-day',10,86400000);
 const secret=device||random(),key=await digest(secret),token=random(),tokenHash=await digest(token),now=Date.now();
 await db.prepare('DELETE FROM admin_challenges WHERE expires<=?').bind(now).run();
 await db.prepare('INSERT INTO admin_challenges(device_hash,username,token_hash,expires) VALUES(?,?,?,?) ON CONFLICT(device_hash) DO UPDATE SET token_hash=excluded.token_hash,expires=excluded.expires').bind(key,ADMIN_EMAIL,tokenHash,now+600000).run();
 const t=emailTranslator(language);
 try{await sendResetEmail(config,ADMIN_EMAIL,t('Mawine — Confirmă autentificarea administratorului'),t('Confirmă autentificarea în același browser în care ai introdus parola:')+'\n\n'+config.origin+'/admin#confirm='+token+'\n\n'+t('Linkul expiră în 10 minute și poate fi folosit o singură dată. Dacă nu ai solicitat autentificarea, ignoră mesajul.'))}catch{await db.prepare('DELETE FROM admin_challenges WHERE device_hash=? AND token_hash=?').bind(key,tokenHash).run();throw new RequestError('E-mailul nu a putut fi trimis. Încearcă din nou.',503)}
 return secret;
}
export async function confirmAdminChallenge(db:D1Database,device:string,token:string){
 if(!/^[a-f0-9]{64}$/.test(device)||!/^[a-f0-9]{64}$/.test(token))throw new RequestError('Linkul este invalid, expirat sau deschis în alt browser.',403);
 const key=await digest(device),hash=await digest(token),now=Date.now(),secret=random();
 // Atomic claim: a replay cannot create another session.
 const claimed:any=await db.prepare('DELETE FROM admin_challenges WHERE device_hash=? AND token_hash=? AND expires>? RETURNING username').bind(key,hash,now).first();
 if(!claimed)throw new RequestError('Linkul este invalid, expirat sau deschis în alt browser.',403);
 await db.prepare('INSERT INTO admin_sessions(id,username,expires) VALUES(?,?,?)').bind(await digest(secret),claimed.username,now+86400000).run();
 return secret;
}
