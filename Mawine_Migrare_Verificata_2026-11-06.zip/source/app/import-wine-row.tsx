import {Pencil,X} from 'lucide-react';
import {t} from './i18n';
import {countryCode} from './country-code';
import type {Wine} from './lib';
export function ImportWineRow({wine:w,onEdit,onRemove}:{wine:Wine;onEdit:()=>void;onRemove:()=>void}){
 return <div className="listRow importWineRow">
  <div className="wineInfo"><strong>{w.name||w.winery}</strong><small>{t([w.year,w.grapes?.join(' & '),w.type].filter(Boolean).join(' · ')||'Detalii necompletate')}</small></div>
  <small className="importWinePrice">{t(w.price?`Preț: ${w.price}`:'Preț necompletat')}</small>
  <small className="importWineWinery">{w.winery&&<>{t('Cramă: ')}{w.winery}</>}</small>
  <small className="importWineCountry" title={w.country}>{countryCode(w.country)}</small>
  <div className="importWineActions"><button type="button" aria-label={t('Corectează')+' '+w.name} onClick={onEdit}><Pencil size={17}/></button><button type="button" aria-label={t('Elimină')+' '+w.name} onClick={onRemove}><X size={17}/></button></div>
 </div>;
}
