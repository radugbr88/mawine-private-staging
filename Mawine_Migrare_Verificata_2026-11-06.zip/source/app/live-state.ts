import type {State} from './lib';
// Polling must refresh webhook-derived billing without overwriting unsaved reviews.
export function mergeLiveState(current:State,incoming:State):State{
 if(!current.profile||current.profile.id!==incoming.profile?.id)return current;
 return {...current,events:incoming.events,profile:{...current.profile,billing:incoming.profile.billing,host:incoming.profile.host}};
}
