'use client';
import React,{useState} from 'react';
import {t} from './i18n';
import {detectImportColumns,importFields,mapImportRows,type ImportField} from './import-detection';
export function ImportColumnReview({rows,onConfirm,onCancel}:{rows:unknown[][];onConfirm:(result:ReturnType<typeof mapImportRows>)=>void;onCancel:()=>void}){
 const [mapping,setMapping]=useState(()=>detectImportColumns(rows));const [error,setError]=useState('');
 return <div className="modalBackdrop"><form className="modal" role="dialog" aria-modal="true" aria-label={t('Verifică coloanele')} onSubmit={e=>{e.preventDefault();try{onConfirm(mapImportRows(rows,mapping))}catch(e){setError((e as Error).message)}}}><button className="close" type="button" aria-label={t('Închide')} onClick={onCancel}>×</button><h2>{t('Verifică coloanele')}</h2><p>{t('Fișierul nu are antet. Am propus coloanele după conținut. Verifică în special vinul și crama înainte de import.')}</p><label className="field"><span>{t('Primul rând cu vinuri')}</span><input type="number" min={1} max={rows.length} value={mapping.start+1} onChange={e=>setMapping({...mapping,start:Math.max(0,Math.min(rows.length-1,Number(e.target.value)-1))})}/></label>{mapping.fields.map((field,i)=>{
 const examples=rows.slice(mapping.start).map(r=>r[i]).filter(v=>v!==null&&v!==undefined&&String(v).trim()).slice(0,3).map(v=>v instanceof Date?v.toISOString().slice(0,10):String(v));if(!examples.length)return null;
 return <label className="field" key={i}><span>{t('Coloana')} {i+1}</span><small style={{overflowWrap:'anywhere'}}>{examples.join(' · ')}</small><select value={field} onChange={e=>{setError('');setMapping({...mapping,fields:mapping.fields.map((f,j)=>j===i?e.target.value as ImportField:f)})}}>{Object.entries(importFields).map(([value,label])=><option value={value} key={value}>{t(label)}</option>)}</select></label>;
 })}{error&&<p role="alert">{t(error)}</p>}<button type="submit" className="btn">{t('Confirmă coloanele')}</button></form></div>;
}
