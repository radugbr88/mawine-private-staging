import {t,locale} from './i18n';
export function PaidExpiryNotice({endsAt,days,cancelled,onManage}:{endsAt:number;days:number;cancelled:boolean;onManage:()=>void}){
 if(!cancelled)return null;
 return <section className="quietNote" role="alert"><h2>{t('Abonamentul se apropie de expirare')}</h2><p>{t('Zile rămase:')} {days}</p><p>{t('Perioada plătită se încheie pe')} <strong>{new Date(endsAt).toLocaleString(locale())}</strong>.</p><p>{t(cancelled?'Reînnoirea este anulată. După expirare ai 3 zile de grație, apoi revii automat la participant.':'Verifică abonamentul și metoda de plată pentru următoarea reînnoire.')}</p><button className="btn full" onClick={onManage}>{t('Gestionează abonamentul')}</button></section>;
}
