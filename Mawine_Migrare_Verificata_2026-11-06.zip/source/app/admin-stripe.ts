import {billingConfig,stripeClient,billingLock,BillingError} from './billing';
import {rateLimit} from './security';
function promotionSummary(p:any,fallback?:any){const candidate=p.promotion?.coupon||p.coupon;const coupon=candidate&&typeof candidate==='object'?candidate:fallback;return {id:p.id,code:p.code,active:p.active,percent:coupon?.percent_off,amount:coupon?.amount_off,currency:coupon?.currency,duration:coupon?.duration,timesRedeemed:p.times_redeemed}}
export async function adminStripe(db:D1Database,env:Record<string,unknown>,body:any,client?:any){
 if(!['adminPrice','adminPromotion','adminPromotionList','adminPromotionCreate','adminPromotionDelete'].includes(body.action))return null;
 if(body.action!=='adminPromotionList'&&body.confirmed!==true)throw new BillingError('Confirmă modificarea în Stripe.');
 const c=billingConfig(env);if(!c||!c.portal)throw new BillingError('Plățile nu sunt încă disponibile. Reîncearcă mai târziu.',503);
 await rateLimit(db,'admin-stripe',20);
 const s=client||stripeClient(c);const account=await s.accounts.retrieve(c.account);if(account.id!==c.account)throw new BillingError('Contul Stripe nu corespunde.',503);
 const lock=await billingLock(db,'admin-prices:'+c.mode+':'+c.account);
 try{
 if(body.action==='adminPromotionList'){
  const items:any[]=[];let cursor=typeof body.cursor==='string'?body.cursor:undefined;
  const page=await s.promotionCodes.list({limit:100,starting_after:cursor,expand:['data.promotion.coupon']});
  for(const p of page.data){if(p.livemode!==(c.mode==='live')||p.metadata?.mawine_deleted==='true')continue;const coupon=p.promotion?.coupon||p.coupon;items.push({id:p.id,code:p.code,active:p.active,percent:coupon?.percent_off,amount:coupon?.amount_off,currency:coupon?.currency,duration:coupon?.duration,timesRedeemed:p.times_redeemed})}
  return {ok:true,items,nextCursor:page.has_more?page.data.at(-1)?.id:null};
 }
 if(body.action==='adminPromotionCreate'){
  if(!/^[A-Z0-9]{1,100}$/.test(body.code||'')||!Number.isFinite(body.percent)||body.percent<1||body.percent>100||!['once','forever'].includes(body.duration)||! /^[a-f0-9-]{36}$/.test(body.operationId||''))throw new BillingError('Introdu un cod cu majuscule și o reducere între 1 și 100%.');
  const existing=await s.promotionCodes.list({code:body.code,active:true,limit:100});
  if(existing.data.length){const same=existing.data.find((p:any)=>p.metadata?.operation===body.operationId);if(same)return {ok:true,item:promotionSummary(same,{percent_off:body.percent,duration:body.duration})};throw new BillingError('Există deja un cod activ cu această denumire.')}
  const price=await s.prices.retrieve(c.prices.monthly);if(price.livemode!==(c.mode==='live'))throw new BillingError('Prețul Stripe nu este compatibil.');
  const coupon=await s.coupons.create({percent_off:body.percent,duration:body.duration,applies_to:{products:[typeof price.product==='string'?price.product:price.product.id]},metadata:{mawine:'true',operation:body.operationId}},{idempotencyKey:'admin-coupon:'+body.operationId});
  const created=await s.promotionCodes.create({code:body.code,promotion:{type:'coupon',coupon:coupon.id},metadata:{mawine:'true',operation:body.operationId}},{idempotencyKey:'admin-promotion:'+body.operationId});return {ok:true,item:promotionSummary(created,coupon)};
 }
 if(body.action==='adminPromotionDelete'){
  if(!/^promo_[a-zA-Z0-9]+$/.test(body.id||''))throw new BillingError('Cod de reducere invalid.');
  const p=await s.promotionCodes.retrieve(body.id);if(p.livemode!==(c.mode==='live'))throw new BillingError('Cod de reducere invalid.');
  // Stripe retains promotion history. Remove from our list only after disabling it.
  await s.promotionCodes.update(p.id,{active:false,metadata:{mawine_deleted:'true'}});return {ok:true,deletedId:p.id};
 }
 if(body.action==='adminPromotion'){
  if(typeof body.code!=='string'||!body.code.trim()||body.code.length>100||typeof body.active!=='boolean')throw new BillingError('Cod de reducere invalid.');
  const list=body.id?{data:[await s.promotionCodes.retrieve(body.id)],has_more:false}:await s.promotionCodes.list({code:body.code.trim(),limit:2});if(list.data.length!==1||list.has_more)throw new BillingError('Cod de reducere invalid.');
  const code=list.data[0];if(code.metadata?.mawine_deleted==='true')throw new BillingError('Cod de reducere invalid.');if(code.livemode!==(c.mode==='live'))throw new BillingError('Cod de reducere invalid.');
  if(body.active&&((code.expires_at&&code.expires_at*1000<=Date.now())||(code.max_redemptions&&code.times_redeemed>=code.max_redemptions)))throw new BillingError('Codul este expirat sau epuizat.');
  const updated=await s.promotionCodes.update(code.id,{active:body.active});return {ok:true,item:promotionSummary(updated)};
 }
 const plan=body.plan;if(!['monthly','annual'].includes(plan)||!Number.isSafeInteger(body.amount)||body.amount<50||body.amount>1000000||! /^[a-f0-9-]{36}$/.test(body.operationId||''))throw new BillingError('Introdu un preț valid în USD.');
 const prior:any[]=[];
 for(const key of ['monthly','annual'] as const){const row:any=await db.prepare('SELECT id FROM managed_prices WHERE environment=? AND account=? AND plan=? AND active=1 ORDER BY created_at DESC LIMIT 1').bind(c.mode,c.account,key).first();const price=await s.prices.retrieve(row?.id||c.prices[key]);if(!price.active||price.livemode!==(c.mode==='live')||price.currency!=='usd'||price.recurring?.interval!==(key==='monthly'?'month':'year')||price.recurring?.interval_count!==1||price.unit_amount===null)throw new BillingError('Prețul Stripe nu este compatibil.');prior.push(price)}
 const product=(p:any)=>typeof p.product==='string'?p.product:p.product.id;
 if(product(prior[0])!==product(prior[1]))throw new BillingError('Prețurile trebuie să aparțină aceluiași produs.');
 const index=plan==='monthly'?0:1,old=prior[index];
 const price=await s.prices.create({product:product(old),currency:'usd',unit_amount:body.amount,recurring:{interval:plan==='monthly'?'month':'year'},tax_behavior:old.tax_behavior},{idempotencyKey:'admin-price:'+body.operationId});
 // Register historical prices before exposing the new one in the portal.
 for(let i=0;i<2;i++)await db.prepare('INSERT OR IGNORE INTO managed_prices(id,environment,account,plan,amount,active,created_at) VALUES(?,?,?,?,?,0,?)').bind(prior[i].id,c.mode,c.account,i?'annual':'monthly',prior[i].unit_amount,Date.now()).run();
 await db.prepare('INSERT OR IGNORE INTO managed_prices(id,environment,account,plan,amount,active,created_at) VALUES(?,?,?,?,?,0,?)').bind(price.id,c.mode,c.account,plan,body.amount,Date.now()).run();
 const ids=prior.map(p=>p.id);ids[index]=price.id;
 await s.billingPortal.configurations.update(c.portal,{features:{subscription_update:{products:[{product:product(old),prices:ids}]}}});
 await lock.assert();await db.batch([db.prepare('UPDATE managed_prices SET active=0 WHERE environment=? AND account=? AND plan=?').bind(c.mode,c.account,plan),db.prepare('UPDATE managed_prices SET active=1 WHERE id=? AND environment=? AND account=?').bind(price.id,c.mode,c.account)]);
 return {ok:true,priceId:price.id,amount:body.amount};
 }catch(e){if(e instanceof BillingError)throw e;throw new BillingError('Stripe nu a confirmat modificarea. Verifică și reîncearcă.',503)}finally{await lock.release()}
}
