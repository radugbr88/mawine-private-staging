import {t,locale} from './i18n';
export function GraceNotice({day,endsAt,onPay}:{day:number;endsAt:number;onPay:()=>void}){
 return <section className="quietNote" role="alert"><h2>{t('Alege un abonament')}</h2><p>{t('Ziua {0} din cele 3 zile de grație.').replace('{0}',String(day))}</p><p>{t('Rămâi gazdă până la')} <strong>{new Date(endsAt).toLocaleString(locale())}</strong>. {t('Fără plată, profilul devine automat participant. Istoricul și datele rămân salvate.')}</p><button className="btn full" onClick={onPay}>{t('Vezi abonamentele')}</button></section>;
}
