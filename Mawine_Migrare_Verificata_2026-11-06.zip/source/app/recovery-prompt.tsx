'use client';
import {t as translate,locale} from './i18n';
import {useEffect,useRef,useState} from 'react';
import {Check,Copy,Download,LockKeyhole,ArrowRight} from 'lucide-react';
import {copyRecoveryCode,saveRecoveryCode} from './recovery-export';

export function RecoveryPrompt({code,onContinue,reminder=false}:{code:string;onContinue:()=>void;reminder?:boolean}){
 const dialog=useRef<HTMLDialogElement>(null);
 const [feedback,setFeedback]=useState('');
 const [pending,setPending]=useState(false);
 const inFlight=useRef(false);
 const heading=useRef<HTMLHeadingElement>(null);
 useEffect(()=>{const element=dialog.current;if(element&&!element.open)element.showModal();heading.current?.focus({preventScroll:true});return()=>{element?.close()}},[]);
 async function copy(){
  if(inFlight.current)return;inFlight.current=true;setPending(true);setFeedback('Se copiază…');
  try{await copyRecoveryCode(code);setFeedback('Codul a fost copiat.')}
  catch{setFeedback('Copierea nu este disponibilă. Ține apăsat pe cod pentru a-l copia manual.')}
  finally{inFlight.current=false;setPending(false)}
 }
 async function save(){
  if(inFlight.current||!dialog.current)return;inFlight.current=true;setPending(true);setFeedback('');
  try{const result=await saveRecoveryCode(code,dialog.current);setFeedback(result==='cancelled'?'Salvarea a fost anulată. Poți încerca din nou.':result==='shared'?'Codul a fost trimis către opțiunea aleasă.':'Verifică fișierul în descărcările tale.')}
  catch{setFeedback('Salvarea nu este disponibilă. Poți copia codul sau face o captură de ecran.')}
  finally{inFlight.current=false;setPending(false)}
 }
 return <dialog ref={dialog} className="recoveryPrompt" aria-labelledby="recovery-prompt-title" aria-describedby="recovery-prompt-description" onCancel={e=>e.preventDefault()}>
 <div className="recoveryPromptContent">
 <span className="recoverySuccess" aria-hidden="true"><Check size={32}/></span>
 {!reminder&&<strong className="recoveryCreated">{translate("Profilul tău a fost creat")}</strong>}
 <h2 ref={heading} tabIndex={-1} autoFocus id="recovery-prompt-title">{translate("Salvează codul de acces")}</h2>
 <p id="recovery-prompt-description">{translate("Cu acest cod poți reveni la profilul tău dacă te deconectezi sau schimbi telefonul.")}</p>
 <div className="recoverySecret"><span>{translate("Codul tău unic")}</span><code>{translate(code.match(/.{1,6}/g)?.join('-'))}</code></div>
 <div className="recoveryPromptActions"><button type="button" className="btn secondary" disabled={pending} onClick={copy}><Copy size={20}/>{translate(" Copiază")}</button><button type="button" className="btn secondary" disabled={pending} onClick={save}><Download size={20}/>{translate(" Salvează")}</button></div>
 <p className="recoveryFeedback" role="status">{translate(feedback)}</p>
 <p className="recoveryPrivacy"><LockKeyhole size={17}/>{translate(" Păstrează codul doar pentru tine.")}</p>
 <button type="button" className="btn recoveryContinue" onClick={onContinue}><strong>{translate("Am salvat codul")}</strong><span>{translate("Continuă ")}<ArrowRight size={18}/></span></button>
 <p className="recoveryLocation">{translate("Codul rămâne același și este disponibil în Profil.")}</p>
 {reminder&&<button type="button" className="textbtn reminderLater" onClick={onContinue}>{translate("Mai târziu")}</button>}
 </div></dialog>
}
