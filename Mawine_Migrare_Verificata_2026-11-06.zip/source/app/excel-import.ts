import Excel from 'exceljs';
import JSZip from 'jszip';
// ExcelJS expects unprefixed SpreadsheetML tags. Office exports may legally
// use a namespace prefix; normalize only tags bound to that same namespace.
export async function readWineWorkbook(buffer:ArrayBuffer){
 const zip=await JSZip.loadAsync(buffer);let changed=false,total=0;
 for(const file of Object.values(zip.files)){
  if(file.dir||!file.name.endsWith('.xml'))continue;
  let xml=await file.async('string');total+=xml.length;
  if(total>20000000)throw Error('Workbook too large');
  const declarations=[...xml.matchAll(/xmlns:([A-Za-z_][\w.-]*)=["']http:\/\/schemas.openxmlformats.org\/spreadsheetml\/2006\/main["']/g)];
  for(const match of declarations){
   const prefix=match[1].replace(/[.*+?^$\{\}()|[\]\\]/g,'\\$&');
   xml=xml.replace(new RegExp('(<\\/?'+prefix+':)([A-Za-z_][\\w.-]*)','g'),(_m,start,name)=>start.startsWith('</')?'</'+name:'<'+name);
   xml=xml.replace(match[0],xml.includes('xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"')?'':'xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"');
   changed=true;
  }
  if(declarations.length)zip.file(file.name,xml);
 }
 const workbook=new Excel.Workbook();
 await workbook.xlsx.load(changed?await zip.generateAsync({type:'arraybuffer'}):buffer);
 const rows:unknown[][]=[];
 workbook.worksheets[0]?.eachRow({includeEmpty:true},r=>rows.push((r.values as any[]).slice(1).map(v=>v instanceof Date?v.toISOString().slice(0,10):typeof v==='object'&&v!==null?('result'in v?v.result:'richText'in v?v.richText.map((t:any)=>t.text).join(''):'text'in v?v.text:''):v)));
 return rows;
}
