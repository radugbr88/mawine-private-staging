import type Stripe from 'stripe';
// Stripe remains the redemption authority. The browser never supplies a coupon/price ID.
export class PromotionError extends Error {}
export async function validatePromotion(s:Stripe,code:unknown,customer:string,prices:Stripe.Price[],live:boolean,initialAmount?:number){
 const value=typeof code==='string'?code.trim():'';
 const invalid=()=>new PromotionError('Codul nu este valid pentru acest abonament.');
 if(!/^[a-zA-Z0-9]{1,64}$/.test(value))throw invalid();
 const list=await s.promotionCodes.list({code:value,active:true,limit:100,expand:['data.promotion.coupon']});
 const promo=list.data.find(p=>p.livemode===live&&p.code.toLowerCase()===value.toLowerCase()&&(!p.customer|| (typeof p.customer==='string'?p.customer:p.customer.id)===customer)&&!p.customer_account);
 if(!promo||!promo.active||(promo.expires_at&&promo.expires_at*1000<=Date.now())||(promo.max_redemptions!==null&&promo.times_redeemed>=promo.max_redemptions))throw invalid();
 const ref=promo.promotion.coupon, coupon=typeof ref==='string'?await s.coupons.retrieve(ref):ref;
 if(!coupon||!coupon.valid||(coupon.redeem_by&&coupon.redeem_by*1000<=Date.now()))throw invalid();
 const eligible=prices.filter(price=>price.active&&price.livemode===live&&(!coupon.applies_to?.products?.length||coupon.applies_to.products.includes(typeof price.product==='string'?price.product:price.product.id))&&(coupon.percent_off!==null||coupon.currency==='usd'||!!coupon.currency_options?.usd));
 if(!eligible.length)throw invalid();
 const restrictions=promo.restrictions;
 if(restrictions.first_time_transaction){
  const [invoices,payments]=await Promise.all([s.invoices.list({customer,limit:100}),s.paymentIntents.list({customer,limit:100})]);
  if(invoices.has_more||payments.has_more||invoices.data.some(i=>i.status!=='void')||payments.data.some(i=>i.status==='succeeded'))throw invalid();
 }
 const minimum=restrictions.currency_options?.usd?.minimum_amount??(restrictions.minimum_amount_currency==='usd'?restrictions.minimum_amount:null);
 if(restrictions.minimum_amount&&minimum===null)throw invalid();
 if(minimum&&!(eligible.some(price=>(initialAmount??price.unit_amount??0)>=minimum)))throw invalid();
 return {id:promo.id,code:promo.code};
}
