'use client';
import {t, type Language} from './i18n';
export const languageNames:Record<Language,string>={ro:'Română',en:'English',it:'Italiano',fr:'Français'};
export function LanguageSettings({language,onChange,disabled=false}:{disabled?:boolean;language:Language;onChange:(language:Language)=>void}){
 return <div className="languageOptions" role="radiogroup" aria-label={t('Limba aplicației')}>
  {(Object.keys(languageNames) as Language[]).map(code=><label key={code} className={'languageOption'+(language===code?' chosen':'')}>
   <input type="radio" name="app-language" disabled={disabled} value={code} checked={language===code} onChange={()=>{}} onClick={()=>onChange(code)}/>
   <strong lang={code}>{languageNames[code]}</strong>
  </label>)}
 </div>;
}
