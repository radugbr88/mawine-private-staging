import {t as translate,locale} from './i18n';
import React from 'react';
import {grapeGuessScore,guessScore,type Wine,type Review} from './lib';
export function GuessDetails({wine,review}:{wine:Wine;review:Review}){
 const rows=[{label:'Țara',answer:review.country,actual:wine.country,points:Number(!!wine.country&&review.country===wine.country)},{label:'Anul',answer:review.year,actual:wine.year?String(wine.year):'',points:Number(!!wine.year&&review.year===String(wine.year))},{label:'Soiuri',answer:review.grapes.join(', '),actual:wine.grapes.join(', '),points:grapeGuessScore(review.grapes,wine.grapes)}];
 return <div className="guessDetails">{translate(rows.map(row=><section key={row.label} className="guessCriterion"><header><strong>{translate(row.label)}</strong><span>{translate(row.points.toLocaleString(locale()))}{translate("/1")}</span></header><dl><div><dt>{translate("Ai ales")}</dt><dd>{translate(row.answer||'Nu ai răspuns')}</dd></div><div><dt>{translate("Răspuns corect")}</dt><dd>{translate(row.actual||'Necompletat')}</dd></div></dl>{translate(row.label==='Soiuri'&&wine.grapes.length>1&&<small>{translate("Un soi corect: 0,5 puncte. Cel puțin două soiuri corecte: 1 punct.")}</small>)}</section>))}<p className="resultTotal">{translate(guessScore(review,wine).toLocaleString(locale()))}{translate(" din 3 puncte")}</p></div>
}
