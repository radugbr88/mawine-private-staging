# Security review — 2 November 2026

Reviewed application authentication, anonymous device cookies, separate administrator authentication, password reset, account operations, ownership checks, public reference endpoints, and Stripe server integration. This is a source review with automated regression tests, not a penetration-test certification.

## Changes

- Atomic attempt counters bound to login account and request source, in addition to device identity; deleting a cookie cannot reset the account counter. Administrator login also has a source limit. New device sessions and invitation guesses are bounded.
- Successful anonymous login, recovery and password change rotate the device cookie and delete the old session. Password changes revoke other profile identities and outstanding email-reset tokens. Password changes and email resets invalidate saved recovery codes.
- Recovery codes are now returned only when generated and newly issued codes are stored only as SHA-256 digests. Normal profile responses no longer contain a recovery bearer. Legacy plaintext display codes are converted in bounded batches of 25 during application requests, preserving both old saved-code paths until explicit rotation. This conversion is incremental, not a claim that every old row was already migrated at deployment.
- Recovery-code generation, recovery-email changes and host-account deletion require the current password. Password verification attempts are rate limited. Deactivated host accounts cannot replace their credentials through signup.
- Credential login uses a dummy password derivation for unknown accounts, bounded passwords and a fixed-work comparison. Authentication linkage checks the credential snapshot again before granting identity access.
- JSON size limits measure streamed bytes even without Content-Length; malformed/non-object JSON is rejected. Internal database exceptions no longer appear in application error responses.
- The password-change flow conditionally revokes other sessions only after successfully replacing the expected password. Email reset retains its atomic single-use and expiry checks.
- Recovery instructions updated in Romanian, English, Italian and French. Sensitive confirmation dialogs and recovery-email forms now request a password.

## Existing protections retained and checked

Salted PBKDF2 password storage, HTTPS Secure/HttpOnly cookies, same-origin checks on mutations, parameterized SQL, separate administrator credentials/sessions, ownership and participant checks, blind-wine redaction. Stripe uses server-selected prices, authenticated customer ownership, verified webhook signatures, idempotency/locking, live/test separation and paid-invoice-based access; redirect query parameters never grant paid access.

## Validation and limits

Passed route/flow regression tests (including cookie rotation, code revocation/migration, reauthentication, atomic parallel throttling, malformed bodies and error redaction), administrator tests, Stripe mocked-provider/signature tests, billing schema tests, localization component rendering and menu authorization tests. TypeScript check passed. Production build is part of publishing.

Browser QA is unavailable because the managed preview daemon mailbox is missing. Live Stripe Sandbox checkout and actual recovery-email delivery remain unverified: STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET and CLOUDFLARE_EMAIL_API_TOKEN are not configured. No payment was made and no production user password was changed manually.

## Deployment follow-up

- Configure server secrets through a secure secret manager and run a real Sandbox checkout, renewal/cancellation, webhook delivery and email-reset test before enabling billing enforcement or live payments.
- Recovery emails are not ownership-verified yet. Email activation/verification needs an available mail provider and a separately tested verification flow; merely saving an email address is not verification.
- The current deployment trusts Sites-injected identity headers. A migration to another host must replace that trust boundary or strip untrusted identity headers; do not expose the Worker directly with the same header trust.
- Review administrator MFA, operational access, backups and dependency advisories for the final hosting environment. Recovery plaintext in historical backups is not rewritten by this release; treat those backups as sensitive.
