# Pregătire migrare — 2 noiembrie 2026

## Stare

Codul aplicației, imaginile, traducerile, dependențele blocate, migrările bazei de date și testele sunt incluse în arhiva sursă a acestei versiuni. Arhiva NU este un backup complet al serviciului live și NU conține baza de date live sau secretele serverului.

Exportul disponibil prin vizualizatorul Sites a returnat 4 profiluri, dar a trunchiat o valoare. Acest rezultat nu a fost folosit drept backup restaurabil. Nu a fost modificat niciun cont sau hash de parolă. Valorile istorice ale genului rămân păstrate în bază; opțiunea eliminată nu mai este oferită în formulare.

## Condiții înainte de mutare

1. Obține un export integral și consistent al bazei D1 DB din infrastructura care o deține, cu schema, toate datele, indexurile și istoricul migrărilor. Nu folosi paginile trunchiate din vizualizator drept backup. Oprește scrierile pentru exportul final sau folosește un snapshot consistent cu procedură de sincronizare până la cutover.
2. Păstrează integral hashurile și salturile parolelor din profiles și admin_accounts; nu este necesară și nu trebuie făcută recuperarea parolelor în clar. Include toate cele 19 tabele inventariate mai jos. Protejează exportul ca date confidențiale; nu îl pune în public/ sau Git.
3. Restaurează într-o bază izolată, compară numărul de înregistrări și integritatea relațiilor, verifică autentificarea unui cont controlat și datele degustărilor. Nu importa pe baza activă înainte de verificare. Nu reaplica migrările deja executate.
4. Confirmă platforma finală. Aplicația actuală folosește Cloudflare Workers și D1; un server Node/VPS necesită adaptarea accesului la stocare și a runtime-ului. Nu este suficientă copierea fișierelor.
5. Rezolvă încrederea în headerele de identitate Sites pentru noul host: elimină headerele injectate de vizitatori și implementează autentificarea corespunzătoare. Nu expune direct serverul cu încredere în headere neverificate. Cookie-urile de pe domeniul vechi nu se transferă automat; utilizatorii se vor autentifica sau vor folosi codul de recuperare.
6. Configurează secretele pe noul server și HTTPS. Actualizează MAWINE_PUBLIC_ORIGIN la domeniul aplicației confirmat și testează resetarea parolei în fiecare limbă.
7. Actualizează adresa webhook Stripe și URL-urile de revenire; testează Sandbox înainte de o lansare Live separată. Păstrează asocierile client/abonament din baza de date. Nu trece automat la Live.
8. Păstrează vechiul deployment și exportul pentru rollback; evită două baze independente care primesc scrieri. Validează aplicația pe noul domeniu înainte de schimbarea traficului și retragerea celui vechi.

## Mail și Stripe: verificare configurație live

Expeditorul confirmat este no-reply@mawine.app, configurat la 2026-11-04. Domeniul final confirmat este mawine.app. Verificarea DNS și activarea furnizorului de e-mail rămân necesare. Vezi raportul actualizat mawine-app-launch.md.

Nu sunt configurate în mediul verificat: CLOUDFLARE_EMAIL_API_TOKEN, STRIPE_SECRET_KEY și STRIPE_WEBHOOK_SECRET. Trimiterea reală de email și plățile complete nu pot fi declarate validate. Există două secrete administrative mascate, MAWINE_ADMIN_SETUP_HASH și MAWINE_ADMIN_SETUP_EXPIRES; acestea nu au putut fi exportate. Nu reactiva un bootstrap administrativ expirat la migrare; verifică procedura de administrare a conturilor existente.

Numele celorlalte variabile existente: CLOUDFLARE_ACCOUNT_ID, MAWINE_EMAIL_FROM, MAWINE_PUBLIC_ORIGIN, STRIPE_ACCOUNT_ID, STRIPE_ENFORCE_ACCESS, STRIPE_LIVE_ENABLED, STRIPE_MODE, STRIPE_PORTAL_CONFIGURATION_ID, STRIPE_PRICE_ANNUAL, STRIPE_PRICE_MONTHLY, STRIPE_TEST_USERNAMES. Configurează valorile potrivite mediului final, fără a publica secrete în cod.

## Inventar D1

admin_accounts, admin_sessions, attempts, billing_checkouts, billing_customers, billing_events, billing_locks, billing_operations, billing_subscriptions, events, grape_varieties, guest_sessions, identities, members, password_reset_limits, password_resets, profiles, reviews, wine_catalog.

Manifestul nu declară stocare R2 separată. Datele live nu se află în arhiva de build sau în istoricul Git. Migrarea nu este complet pregătită până când exportul integral, restaurarea de probă, autentificarea pe noul host, mailul și Stripe nu sunt verificate.
