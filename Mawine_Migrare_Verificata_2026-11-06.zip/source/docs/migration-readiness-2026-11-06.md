# Mawine — verificare și pregătire pentru migrare, 6 noiembrie 2026

## Concluzie
Codul și kitul de instalare au fost întărite și verificate. Lansarea finală este
BLOCATĂ de configurația externă incompletă, nu este certificată ca operațională.
Documentele juridice propuse separat nu au fost publicate sau înlocuite.

## Serverul verificat
Sursă: configurația runtime și citiri limitate, netrunchiate, ale bazei Sites;
versiunea inițială 249. Valorile secrete nu au fost citite sau exportate.

| Componentă | Constatare |
| --- | --- |
| VAPID | Cheie publică și secret privat înregistrate; secretul este mascat. Perechea reală și livrarea nu pot fi confirmate doar din metadate. |
| Push | Un dispozitiv înregistrat; zero reamintiri în push_deliveries la verificare. Această tabelă nu dovedește absența notificărilor de activare/test. |
| Criptare recuperare | MAWINE_RECOVERY_ENCRYPTION_KEY înregistrată ca secret; trebuie păstrată identic la migrarea datelor. |
| Stripe | Mod test, live dezactivat, controlul accesului plătit neactivat în mediul de dezvoltare. |
| Identificatori Stripe | Cont, preț lunar/anual și portal sunt configurate; nu au putut fi validate la furnizor. |
| Secrete Stripe | STRIPE_SECRET_KEY și STRIPE_WEBHOOK_SECRET lipsesc din configurația serverului. |
| E-mail | Adresă expeditor și cont Cloudflare prezente; CLOUDFLARE_EMAIL_API_TOKEN lipsește. |
| Administrator | Un singur cont: radugbr88@gmail.com; parolă existentă. Bypass-ul temporar este activ pe Sites. |
| Date facturare | Zero billing_subscriptions, billing_events și managed_prices la verificare. |
| Cont Stripe conectat aici | Diferit de contul declarat de Mawine; nu a fost folosit pentru citiri sau modificări. |

## Corecții implementate
- Identitatea din antete este ignorată implicit. Standalone o ignoră chiar dacă
  opțiunea pentru migrare proxy ar fi activată accidental.
- Standalone respinge autentificarea/sesiunile temporare admin indiferent de flag.
  Bypass-ul de dezvoltare de pe Sites nu a fost oprit înainte de configurarea e-mailului.
- Noile parole și resetările: PBKDF2-SHA256 600.000 iterații, verificat și în workerd;
  hash-urile vechi la 100.000 rămân compatibile până la schimbarea parolei.
  Referință: https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html
- Sesiuni cu parolă: 30 de zile de inactivitate; guest: persistența existentă;
  administrator: maximum 24h. Resetarea/schimbarea parolei revocă celelalte identități
  și elimină inclusiv copia criptată a codului invalidat.
- Standalone: frame-ancestors none, X-Frame-Options DENY, HSTS pe HTML.
  Răspunsurile API sunt private/no-store.
- Verificarea de migrare testează VAPID prin semnare/verificare, cheia AES,
  dezactivarea bypass/proxy, cron-ul, prețurile, portalul, citirea promoțiilor și webhook-ul.
- Dependențe actualizate și fixate în lockfile. Scanarea tuturor dependențelor:
  zero advisories raportate la această verificare, inclusiv cele de dezvoltare.
- Corectat un test de traducere rămas în urmă după eliminarea opțiunilor duplicate.
- Include politica de retenție a colecției 365 zile, cu teste și cron; nu șterge
  retroactiv colecțiile existente la introducerea politicii.

## Pași externi obligatorii
1. Conectarea contului Stripe corect și instalarea secretelor în server, nu în GitHub.
   Mai întâi test/sandbox; identificatorii live trebuie verificați separat.
2. Configurarea serviciului de e-mail și testarea efectivă a verificării contului,
   resetării parolei și loginului admin. Apoi dezactivarea bypass-ului de dezvoltare.
3. Test Stripe complet: Checkout, cod valid/invalid/expirat, confirmare webhook,
   anulare, reînnoire eșuată și reconciliere. Prețurile/reducerile din admin au teste
   cu furnizor simulat; nu s-au creat coduri sau încasări în contul real.
4. Pe noul host: domeniu HTTPS, D1, toate secretele originale necesare, cron la
   10 minute, rularea preflight. Testarea cron-ului fără trafic și a push real
   pe iOS și Android, cu aplicația închisă. Consimțământ nou pe noul domeniu.
5. Export consistent și complet D1, import de probă, comparație înregistrări,
   copie securizată a cheilor și exercițiu de revenire. Kitul NU conține baza reală.

## Limite funcționale de reținut
Codul de acces este în continuare destinat profilurilor fără parolă. Varianta
în care un fost abonat cu e-mail și parolă se autentifică alternativ prin cod
nu este implementată aici; nu trebuie descrisă în termeni ca funcție existentă.
Nu s-a realizat un test de penetrare exhaustiv sau un test de încărcare pe noul host.

## Confirmarea automată la activarea push
După permisiunea browserului și salvarea abonării, aplicația cere o notificare
push reală către dispozitivul curent: „Notificările sunt acum active.”, tradusă
în limba profilului. Nu există buton de test separat. Refuzul permisiunii sau
eșecul salvării nu trimite notificarea. Dacă furnizorul respinge confirmarea,
interfața păstrează starea activată și explică faptul că mesajul nu a fost trimis.
Sunt prevenite apăsările duble; endpoint-ul păstrează limita anti-abuz existentă.

## Rezultatele verificării locale
- 48 suite automate: autentificare/recuperare, admin, izolare, Stripe, promoții,
  push/activare, importuri, traduceri, retenție și verificările de migrare.
- TypeScript fără erori; build de producție reușit.
- Audit pachete: 0 low, 0 moderate, 0 high, 0 critical la verificarea curentă.
- Teste cripto native workerd și test de restaurare a schemei curate.
- Plățile și e-mailurile reale, notificarea pe telefon și restaurarea bazei reale
  nu sunt acoperite de aceste rezultate locale.
