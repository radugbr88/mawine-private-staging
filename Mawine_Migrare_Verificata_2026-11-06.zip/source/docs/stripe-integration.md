# Mawine Stripe integration — Sandbox first

Implemented with Stripe Node SDK 23.0.0 / API 2026-09-30.endive. Checkout and Customer
Portal run on Stripe. No Stripe.js, publishable key, card fields or card data are
needed in this application. Existing Sites identities and HttpOnly guest sessions
are used for authorization; profile IDs from request bodies are never credentials.

## Configuration

Store configuration in the server runtime, never in frontend code or Git. Use the
Sites environment tool while hosted on Sites, or Cloudflare Worker secrets after
migration. Do not paste keys into chat. Prefer a restricted test API key.

| Key | Sandbox value / purpose |
| --- | --- |
| STRIPE_MODE | test |
| STRIPE_ACCOUNT_ID | Exact acct_... of FIBER COM SRL sandbox, not the live account |
| STRIPE_SECRET_KEY | Secret: restricted rk_test_... with minimum required permissions |
| STRIPE_WEBHOOK_SECRET | Secret: whsec_... for the endpoint below |
| STRIPE_PRICE_MONTHLY | price_1UXM97PCFCfe1MffEJWBmSgB |
| STRIPE_PRICE_ANNUAL | price_1UXMBFPCFCfe1MffqTxlVOcK |
| STRIPE_PORTAL_CONFIGURATION_ID | bpc_... of the configured sandbox Customer Portal |
| STRIPE_TEST_USERNAMES | Comma-separated existing Mawine host usernames allowed to test; empty disables checkout |
| MAWINE_PUBLIC_ORIGIN | https://mawine-private-tastings.bdnsrl.chatgpt.site |
| STRIPE_LIVE_ENABLED | false; change only as a separate approved launch |
| STRIPE_ENFORCE_ACCESS | false during preparation; true at approved paid launch |

Only test prices and disabled-launch settings are currently saved. No key, account
ID, webhook secret, tester allowlist or Portal configuration has been invented.
The connector available during implementation targets an unrelated live account;
it was not used to create/modify Stripe resources.

Restricted-key permissions: read account identity, Prices, Subscriptions, Invoices,
Invoice Payments, Charges; write Customers, Checkout Sessions and Customer Portal
Sessions. Check Stripe request logs in Sandbox for any denied permission and grant
only that missing capability. Customer Portal configuration is done in the Dashboard,
not dynamically by the application's key. Keep API and webhook secrets separate.

## Stripe Sandbox steps remaining

1. Confirm monthly price is USD 9.99/month and annual is USD 99/year, recurring,
   one unit, interval_count 1. The app checks these details before every new checkout.
2. Configure Customer Portal: payment method changes, invoice history, cancellation
   at end of period. Enable monthly/annual switching for the supplied products/prices
   only after deciding the effective date and proration policy. Two separate products
   are supported by the app; configure both in the Portal if keeping this structure.
3. In Workbench → Webhooks, create a snapshot event destination for **your account**:
   `https://mawine-private-tastings.bdnsrl.chatgpt.site/api/stripe/webhook`
   Use API version **2026-09-30.endive**, not thin events or connected-account events.
4. Subscribe to the exact event list below. Store its signing secret server-side.
5. Add the sandbox account ID, restricted key, Portal configuration ID and tester
   username allowlist. Deploy to apply the environment revision.
6. Run the real Sandbox test matrix below. Local mocked-provider tests do NOT replace
   testing the user's actual account, Portal settings, authentication and webhook delivery.

Events:
- checkout.session.completed
- checkout.session.async_payment_succeeded
- checkout.session.async_payment_failed
- checkout.session.expired
- customer.subscription.created
- customer.subscription.updated
- customer.subscription.deleted
- customer.subscription.paused
- customer.subscription.resumed
- invoice.paid
- invoice.payment_failed
- invoice.payment_action_required
- charge.refunded
- charge.dispute.created
- charge.dispute.closed
- radar.early_fraud_warning.created

## Behavior and conservative defaults

- Checkout and Portal require an authenticated, unblocked host. Same-origin POST
  checks and per-profile rate limiting apply. Return URLs come from trusted config.
- Profile locale (ro/en/it/fr, fallback en) selects Checkout and Portal language.
  Product names/descriptions are controlled in Stripe and not auto-translated.
- Existing 30-day trial end is retained: choosing a plan does not restart the trial.
  If at least 48 hours remain, Stripe receives that original trial_end. During the
  final 48 hours, checkout waits until the free period ends (Stripe's trial minimum).
  With no remaining trial, Stripe charges on confirmation. The free app trial alone
  never creates a Stripe subscription or automatic charges.
- Checkout creation is serialized per profile. Frozen parameters + a persisted
  idempotency key allow safe retries after a timeout. The same open session is reused;
  selecting another period expires the open session first. An existing nonterminal
  subscription must be managed in the Portal instead of buying a duplicate.
- If customer/session creation is uncertain beyond 23 hours, fail closed. An operator
  must reconcile the object in Stripe request logs before clearing the corresponding
  billing_operations/billing_checkouts row; never delete such rows blindly.
- Signed raw webhook bodies are verified with 300-second tolerance. Provider account
  and live/test modes must match. Object ownership uses the stored Customer mapping,
  never event metadata or email matching.
- Events are deduplicated; failed handlers return non-2xx and remain retryable. The
  handler rereads authoritative subscription state under a profile lease, so old event
  payloads cannot reinstate a canceled subscription. Writes are absolute/idempotent;
  a crash after updating a subscription but before marking its event processed is safe
  to retry. Access expiry is derived from paid invoice lines, not redirects or status alone.
- Past-due renewals retain only the verified paid expiry. Trial and paid expiry both
  allow 72 hours of application grace, then effective participant mode. Cancellation
  stops renewal, not the already-paid period. Grace never changes billing dates.
  Risk holds override grace. No subscription event deletes profile or history.
- Daily in-app reminders run throughout an unselected 30-day trial, in the final
  three days before paid expiry, and during grace. Claims persist once per calendar
  day per reminder kind across devices. Annual-to-monthly changes begin at annual end.
- Full refunds, disputes and fraud warnings put the related subscription on a persistent
  risk hold. Partial refunds are recorded without a hold. Holds require administrator
  review; even a won dispute does not automatically clear an unrelated risk. The admin
  list shows status; detailed failed/risk events are in billing_events and Stripe Workbench.
  Clearing a hold is an operator procedure after examining all related payments, not
  a client action. This conservative policy must be confirmed before live launch.
- Sandbox payments never grant live paid privileges. Test operations are allowlisted;
  live authorization filters by configured account/environment. During preparation
  existing free host behavior is unchanged. At launch set STRIPE_ENFORCE_ACCESS=true:
  creating/starting tastings and modifying collections require trial or verified access.
  Users can still read their history and finish an already-started tasting.
- Deleting or downgrading a billing customer is blocked while Stripe has any nonterminal
  subscription, open checkout or unresolved creation attempt. The same lock prevents
  checkout/deletion races. This applies to administrator deletion too. Cancellation
  scheduled for period end must actually finish first. Data is not deleted on expiry.
- No automatic tax has been enabled. Before live launch confirm tax-inclusive vs
  exclusive prices, legal obligations and active registrations; configure Stripe Tax
  only after verification. Switching policy, dunning emails, cancellation text and
  privacy/terms must be reviewed for the actual business.
- Let Stripe send configured receipts, invoice and failed-payment notifications to the
  billing address collected in Checkout; do not duplicate them with Cloudflare. Mawine
  recovery emails remain a separate flow. Stripe billing email language/content depends
  on its settings and supported templates; product text stays in its configured language.

## Verification

Local: `node tests/stripe-billing.mjs`, `node tests/flows.mjs`,
`node tests/admin-auth.mjs`, `node tests/billing-schema.mjs`,
`node tests/localization.cjs`, `node node_modules/typescript/bin/tsc --noEmit`, build.

Real Sandbox matrix (pending secrets/account access):
- allowlisted host checkout; other host and participant cannot use test billing;
- monthly/annual successful payments, declined payment, 3DS and asynchronous payment;
- double click, refresh, canceled Checkout, return before webhook, retry after timeout;
- same profile on a second device; no user can open another customer's Portal;
- original trial_end, final-48-hour restriction, trial ending without a payment method;
- renew via test clocks, failed renewal, successful retry, cancellation at period end;
- monthly/annual switch under the chosen Portal policy and matching paid invoice;
- duplicate/out-of-order events, webhook retry after temporary failure, invalid signature;
- refund, partial refund, dispute and early fraud warning; persistent hold;
- delete/downgrade blocked until billing fully ended; existing user data preserved;
- all four languages and mobile return navigation.

For live launch use a separate deployment/Stripe environment configuration, live
prices and matching credentials/webhook. Explicit approval is required before changing
STRIPE_MODE=live, STRIPE_LIVE_ENABLED=true and STRIPE_ENFORCE_ACCESS=true. Complete real
Sandbox QA first. Changing the hostname later requires new trusted return URLs and
webhook destination configuration, not new app logic.
