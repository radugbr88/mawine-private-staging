# Billing database foundation

Migration 0025 adds three empty, server-owned tables. It does not enroll anyone,
contact a provider, charge money, alter trials, or enforce paid access. Existing
subscription buttons deliberately remain unavailable until the integration is complete.
The generated snapshot also captures the existing manual migrations 0003–0024;
their already-applied DDL was removed from the new generated SQL after review.

## Data contract

- `billing_customers`: maps a profile to a provider Customer. Stripe uses `cus_…`.
- `billing_subscriptions`: maps a verified provider subscription to its owner,
  remote Price ID, internal plan key, monthly/annual interval, raw provider status,
  current period, cancellation flags, and separately verified access expiry.
- `billing_events`: deduplicates notifications by provider, environment, merchant/app
  scope and event ID. Stores processing state and timestamps, not full payloads.

All timestamps are Unix **milliseconds** (convert Stripe seconds at the boundary).
`provider_account_id` is mandatory: Stripe account ID, Apple application identity,
or Google package identity. Stripe sandboxes use their distinct account IDs.
`environment` is `test` or `live`; no defaults may silently make test data live.
Production authorization must filter provider scope AND `environment = 'live'`.
Apple/Google values are schema extension points only, not working integrations.
Mobile transaction identifiers and tokens require provider-specific validation and
possibly further schema additions when those integrations are implemented.

Subscription IDs are unique within scope. Multiple subscriptions per profile are
allowed for historical records and reconciliation; this does **not** prevent a
second paid subscription by itself. Checkout must check existing access across
providers and use a retry-safe creation workflow before allowing another purchase.
An `active` provider status alone is not a payment receipt or permission grant.
Only verified fulfillment sets `access_expires_at`; keep it null before verification.
Price IDs and internal plan mappings must come from trusted server configuration.

On profile deletion, foreign keys set the owner link to NULL and preserve minimal
provider reconciliation records. No name, email, address, card details, API keys,
client secrets or raw webhook body is copied into these tables. Unlinked records
must never grant access or recreate a deleted profile. Define retention and
provider-side cancellation/account-deletion behavior before enabling paid accounts;
database deletion alone does not cancel a Stripe subscription.

## Required before payment launch

1. Configure separate Stripe sandbox and live credentials, Products/Prices and
   authenticated server-side Checkout (subscription mode) and Customer Portal.
2. Resolve ownership through trusted provider IDs and authenticated profiles.
   Verify webhook signatures over the raw request body before recording events.
3. Handle lifecycle notifications, invoices paid/failed, completed Checkout and
   asynchronous payment success, refunds, disputes and early fraud warnings.
4. An event row is not proof of successful processing. Retry pending/failed rows;
   update subscriptions and mark an event processed atomically in a D1 batch.
   A unique event ID prevents duplicate rows, not duplicate side effects by itself.
   Use conditional writes/serialization and fetch authoritative provider state to
   reconcile out-of-order notifications; retries must not extend access twice.
5. Enforce paid access on the server only after sandbox tests and explicit launch.
   Never activate access from a success-page redirect, browser price or role flag.
6. Reconcile cancellation, expiry and refund policy; implement provider management
   links, safe account deletion, and prevention of concurrent duplicate Checkout.
7. Configure applicable tax registrations and invoicing. If Stripe Tax is chosen,
   verify active registrations before enabling automatic tax.

No payment launch, keys, webhooks, invoices or Stripe account configuration is part
of this database-only change. Existing UI and trial behavior remain unchanged.
