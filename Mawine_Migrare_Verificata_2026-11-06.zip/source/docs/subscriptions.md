# Mawine subscription rules

One Host plan: USD 9.99/month or USD 99/year. Stripe Checkout creates new
subscriptions; Manage subscription opens an authenticated Stripe Customer Portal
session. App buttons never change a real subscription or charge a card directly.
Verified invoices, not browser redirects, grant paid access.

## Changes through the portal

- Annual → monthly: scheduled at the end of the paid year; no automatic refund.
- Monthly → annual: immediate on confirmation, with invoiced prorations crediting
  unused monthly time. Stripe displays the actual amount before confirmation.
  The annual cycle starts at the change. A failed payment does not grant a new
  paid year; existing verified coverage is retained.
- Cancellation stops renewal at period end, retaining the paid period.
- The simulator uses these dates without calling Stripe. Its confirmation is a
  simulated successful payment, not a Stripe quote or a real receipt.

Required portal subscription_update settings:
`enabled=true`, `default_allowed_updates=["price"]`,
`proration_behavior=always_invoice`, `billing_cycle_anchor=now`,
`schedule_at_period_end.conditions=[{"type":"shortening_interval"}]`.
Both configured prices must be offered on the same product. Cancellation must be
 enabled with `mode=at_period_end`. The server refuses incompatible configurations;
the migration preflight checks them too. No external configuration is changed by
publishing this code. Verify these settings in the correct Stripe Sandbox before
live launch.

Reference: https://docs.stripe.com/customer-management/configure-portal
and https://docs.stripe.com/billing/subscriptions/change-price .

## Trial, reminders and access

The 30-day trial starts once at first host activation. Reactivation and login do
not restart it. Existing legacy accounts retain their rollout timestamp.
Checkout preserves the remaining trial, including its final 48 hours using a
free initial billing period anchored to the original trial end.

Both trial expiry and paid expiry receive 72 hours of app-level grace. This never
changes Stripe invoice dates or forgives unpaid invoices. After grace, the API
returns the effective Participant role and host actions are denied server-side.
Credentials, stored host intent, collection, history and favourites are retained.
Risk holds bypass grace.

In-app reminders are claimed once per Bucharest calendar day across devices:
daily during the unselected trial, the final three days of paid coverage, and
the three grace days. They are not background push messages or automatic emails.

Live payments remain dependent on verified account configuration and secrets.
