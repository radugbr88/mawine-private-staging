# Notificări push Mawine

Implementare Web Push cu acord explicit, dezactivare în Profil → Notificări, fără buton de test în meniul utilizatorului, service worker fără cache de cont, VAPID ES256 și payload criptat aes128gcm (RFC 8291/8292). Mesajele nu includ nume, sume, coduri sau alte date personale. Apăsarea reamintirii deschide pagina Abonament a profilului autentificat.

Reamintiri: cu 15, 12, 9, 6, 3, 2 și 1 zile gratuite rămase, fără abonament ales, ultimele trei zile ale perioadei plătite și fiecare dintre cele trei zile de grație, conform motorului existent `dueReminders`. Accesul gratuit acordat de administrator suspendă reamintirile de plată. Maximum o trimitere acceptată de furnizor per dispozitiv, tip și zi Europe/Bucharest. Livrarea efectivă depinde de browser, conexiune și permisiune; acceptarea HTTP de către furnizor nu dovedește afișarea pe telefon. Încercările eșuate se reiau; endpointurile 404/410 se șterg.

Abonările sunt legate de profil și sesiune. Deconectarea le elimină pentru sesiunea respectivă; ștergerea profilului le elimină prin cascadă. Sesiunile expirate/revocate nu mai primesc notificări. Istoricul tehnic de deduplicare se șterge după 7 zile. Browserul poate păstra permisiunea după deconectare, dar noul profil trebuie să activeze explicit notificările.

## Configurare

Variabile server (niciodată în Git): `MAWINE_PUSH_PUBLIC_KEY` (cheia publică P-256 base64url) și `MAWINE_PUSH_PRIVATE_JWK` (cheia privată JWK, secret). Cheile trebuie păstrate stabile. La schimbarea domeniului, utilizatorii trebuie să accepte din nou notificările; abonările browserului aparțin originii.

Workerul exportă `scheduled`. Generatorul `migration/prepare.py` adaugă automat `triggers.crons = ["*/10 * * * *"]` în `wrangler.migration.json` pentru serverul final Cloudflare Workers + D1. După deploy verificați în Cloudflare că triggerul este activ și logurile nu conțin `push_cron_failed`. Batching: până la 100 dispozitive/run; fiecare se verifică maximum o dată/oră. Pentru volume mai mari, creșteți frecvența sau folosiți o coadă.

Pe hostingul Sites, interogările aplicației declanșează suplimentar loturi mici în `waitUntil`. Acest fallback nu garantează trimiterea când nu există trafic. API-ul Sites nu expune configurarea unui Cron Trigger; nu declarăm un cron activ pe Sites. Migrarea include configurația lui pentru serverul final.

iPhone/iPad: iOS/iPadOS 16.4+ și aplicația adăugată pe ecranul principal. Acceptul se cere numai după apăsarea „Activează notificările”. Refuzul nu blochează aplicația. Verificarea finală pe dispozitiv: activare → test cu aplicația închisă → apăsare notificare → dezactivare → confirmare absență trimiteri ulterioare.
