# Coduri de reducere, acces gratuit și evenimente

## Coduri Stripe

În Abonament, înaintea selecției perioadei, câmpul și butonul au contur și text gri. „Aplică” verifică în server un **Promotion Code** Stripe (codul introdus de client, nu ID-ul unui Coupon). Numai un răspuns valid afișează „Aplicat” și bifa. Editarea codului anulează starea aplicată. În ecranul de alegere a perioadei se păstrează codul; fără aplicare sau golirea câmpului nu se poate continua.

Serverul folosește contul, mediul, clientul și prețurile configurate. Verifică activarea, expirarea, numărul de utilizări, clientul, produsul, moneda, prima tranzacție și suma minimă. Un cod cu sumă minimă pozitivă nu poate fi aplicat unei plăți inițiale gratuite. Restricțiile se verifică din nou pentru planul ales. Checkout primește `discounts: [{promotion_code: id}]`; nu primește un preț sau un discount calculat de browser. Stripe confirmă reducerea și totalul final. Aplicarea în meniu nu încasează bani și nu rezervă utilizările codului. Un cod poate expira între verificare și Checkout. Abonamentele existente se gestionează în portal; acest câmp este pentru o nouă subscriere.

Configurarea în contul Stripe corect: creați Coupon-ul (procent/sumă, durată și produse), apoi un Promotion Code activ. Cheia restricționată trebuie să permită citirea Promotion Codes, Coupons, Prices, Invoices și Payment Intents, plus drepturile existente de Checkout/Customer. Nu introduceți chei în browser. Verificarea live rămâne condiționată de configurarea secretelor și de testarea în contul țintă. Documentație: https://docs.stripe.com/billing/subscriptions/coupons și https://docs.stripe.com/payments/advanced/discounts.

## Gratuitate acordată din admin

În lista utilizatorilor, conturile cu perioada de probă începută au un selector de dată și oră locală. După alegerea datei, „Acordă acces gratuit” cere confirmare explicită. „Confirmă” salvează momentul exact de expirare și autorul în audit. Rolul de gazdă este disponibil până la acel moment. Expirarea sau revocarea păstrează toate datele; accesul ulterior este calculat din drepturile rămase (o perioadă de probă încă valabilă nu este anulată). Nu se restartează perioada de probă și nu se adaugă automat alte zile la gratuitatea administrativă.

Acesta este un drept intern, fără abonament/factură/reînnoire Stripe. Acordarea este refuzată cât timp există abonamente Stripe neîncheiate sau sesiuni Checkout deschise/neconfirmate. Astfel, eticheta gratuită nu ascunde o facturare existentă. Conturile blocate și suspendările de risc nu sunt deblocate. Reamintirile de plată/probă nu apar cât timp gratuitatea este activă.

Gratuitatea poate începe numai în primele 30 de zile de probă sau după momentul de încheiere a unei perioade plătite verificate. Nu se suprapune peste o perioadă plătită și nu poate începe doar pe baza unei perioade de probă expirate. Serverul verifică din nou eligibilitatea și confirmarea la salvare. Nu se programează în avans o gratuitate care să înlocuiască facturarea Stripe.

Funcția de intrare specială la evenimente, configurarea din admin și tabelele sale sunt eliminate prin migrarea 0030. Profilurile, participările, evaluările și degustările existente rămân salvate. Participarea obișnuită continuă prin profil și invitație.
