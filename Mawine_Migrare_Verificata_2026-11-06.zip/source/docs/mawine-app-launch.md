# mawine.app — readiness audit (2026-11-04)

Source review and local regression tests, not a completed real Stripe payment test.

## Confirmed

- Hosted Checkout and Customer Portal are server-created and require an authenticated host.
- Prices are validated server-side: USD 9.99 monthly / USD 99 annually.
- Raw-body webhook signatures, retries, deduplication, subscription lifecycle and risk events are implemented.
- Test/live environments are separated. Real payments are disabled.
- Legal links exist for Romanian, English, Italian and French. Relative links survive a hostname change.
- Invitations and QR codes use the current origin. Password recovery and Stripe return URLs use MAWINE_PUBLIC_ORIGIN.
- Fixed polling: webhook-derived billing now refreshes the displayed subscription without replacing local review edits.

## Production configuration still required

The current deployment has no STRIPE_SECRET_KEY or STRIPE_WEBHOOK_SECRET. The current origin remains the chatgpt.site hostname. No custom domain is attached to this Site.

1. Attach mawine.app to the intended hosting platform, validate DNS ownership and HTTPS. If moving hosting, migrate D1 records and server bindings; DNS alone does not move data.
2. Once HTTPS serves the app, set MAWINE_PUBLIC_ORIGIN=https://mawine.app and redeploy. Do not change it before the new origin works: it also controls password reset emails.
3. Store STRIPE_SECRET_KEY as a server secret, preferably a restricted rk_test_ key for Sandbox. Store STRIPE_WEBHOOK_SECRET separately as a server secret. Never use NEXT_PUBLIC_ or put secrets in chat, source or frontend bundles.
4. Confirm account, monthly/annual Prices, Portal configuration and tester allowlist belong to the same Stripe Sandbox. Follow docs/stripe-integration.md for exact events and permissions.
5. Create the webhook destination https://mawine.app/api/stripe/webhook, snapshot events, API 2026-09-30.endive. Add its own signing secret.
6. Verify Checkout success/cancel, Portal, actual webhook delivery/retries, renewals, failed payments and cancellations with the real Sandbox account. Local provider mocks do not prove remote configuration.
7. Use live account/Prices/Portal/secrets only after successful Sandbox testing; set STRIPE_MODE=live, STRIPE_LIVE_ENABLED=true and STRIPE_ENFORCE_ACCESS=true for the deliberate launch.

## URLs on the new domain

- Checkout success: https://mawine.app/?billing=success
- Checkout cancel: https://mawine.app/?billing=cancel
- Customer Portal return: https://mawine.app/?billing=portal
- Webhook: https://mawine.app/api/stripe/webhook
- Terms: https://mawine.app/terms-ro.html (also en, it, fr)
- Privacy: https://mawine.app/privacy-ro.html (also en, it, fr)
- Invitation: https://mawine.app/?join=CODE
- Password reset: configured origin plus the application's reset hash token.

Host-only cookies do not transfer from chatgpt.site to mawine.app. Existing hosts must log in on the new domain; participants need their recovery code. Previously shared QR codes continue to point at the old origin: keep it available during migration or arrange an appropriate redirect.

Stripe Tax is not enabled. Confirm tax treatment and applicable registrations before configuring automatic tax. No real charge, secret insertion, DNS switch or live-mode activation was performed in this audit.


## Runtime audit update — 2026-11-04

Status: NOT READY for production migration / real payments.

Verified via Sites runtime configuration (revision 13):
- Sender corrected to `no-reply@mawine.app`. Cloudflare account ID is configured.
- `CLOUDFLARE_EMAIL_API_TOKEN` absent: password-reset delivery cannot work yet.
- `STRIPE_SECRET_KEY` and `STRIPE_WEBHOOK_SECRET` absent: payment/webhook integration cannot run yet.
- Test mode, live payments disabled, access-enforcement launch flag false.
- No custom domains attached; public origin remains current hosting domain intentionally.

Configured Stripe references (not remotely verified):
- Account: `acct_1UWKZuPCFCfe1Mff`
- Monthly Price: `price_1UXM97PCFCfe1MffEJWBmSgB`
- Annual Price: `price_1UXMBFPCFCfe1MffqTxlVOcK`
- Portal: `bpc_1UXOTIPCFCfe1MfflvC4nihJ`

The connected Stripe tool exposes only a DIFFERENT live account, BestFoodImporters.
No unrelated account objects were read or changed. Connect the configured Sandbox
account to verify the two Prices, their Products, active state, currency/amount,
recurrence and Portal's allowed products/prices. Product IDs cannot be inferred from
Price IDs. Live mode needs its own verified identifiers; test IDs cannot be reused.
The code rejects a Portal without cancellation at period end and scheduled shortening
of the billing interval (annual to monthly).

Before changing DNS/origin:
1. Backup/export D1 and verify restoration, bindings and migrations on target hosting.
2. Attach and verify mawine.app; test DNS and HTTPS, including any www redirect.
3. Authorize mawine.app in email sending provider; verify SPF, DKIM and DMARC.
   These DNS/provider settings were not verified in this session. Store sending token
   server-side and test a requested reset end-to-end for an owned test profile.
4. Supply Stripe secrets securely in runtime settings, then test actual Sandbox Checkout,
   Portal, webhook, renewal, failure, cancellation and scheduled annual-to-monthly change.
5. Change trusted origin and webhook destination only after final HTTPS works.
6. Verify new-domain login, recovery, invitation/QR links, terms/privacy in four languages,
   preserve old invitation links and ensure rollback and database continuity.

Latest application policy: 30-day trial with daily foreground reminders when no
subscription is selected; daily reminders 3/2/1 days before paid expiry; 72-hour grace
after trial/paid expiry; then participant mode. Cancellation preserves the paid period.
No subscription cancellation/deletion/expiry deletes user data. Annual-to-monthly
billing is scheduled at annual end, with no automatic refund. Explicit user-requested
profile deletion is a separate action and is not triggered by billing.

Local regression tests and local simulation do not establish provider connectivity.
No live payment, DNS migration or password-reset email was sent by this audit.
