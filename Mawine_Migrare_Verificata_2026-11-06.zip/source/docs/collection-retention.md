# Personal collection retention

After trial plus 72-hour grace, paid access plus 72-hour grace, and any administrator grant expire, preserve the personal catalogue for 365 days. A renewed entitlement extends the deadline automatically. Pending cancellation does not shorten paid access. The migration timestamp is a lower bound for existing accounts: no retroactive deletion.

Migration 0034 creates the policy start date. The existing Worker scheduled handler clears expired catalogues in atomic batches of 100. Keep the migration Cloudflare cron enabled (every 10 minutes). No scheduler is assumed active on Sites. This change is prepared locally; deploying code, applying migrations and enabling the cron are needed for production operation.

Deletion clears only profiles.catalog. Credentials, personal recovery material, event wine snapshots, membership and reviews are untouched. Expired host catalogues are excluded from the application API response. Backup expiry is a separate operator policy; restoring backups must preserve the original policy timestamp and rerun cleanup before serving traffic.

Billing locks and pending/failed webhook events pause deletion to avoid racing an entitlement update. Monitor collection_cleanup_failed and unresolved billing events; prolonged failures delay deletion rather than risk deleting an eligible collection. Entitlements across environments conservatively extend retention. The clock is based on recorded entitlement end dates; manual early role deactivation does not shorten this deadline.

Run node tests/collection-retention.mjs. Before production rollout inform users of the retention rule and publish the reviewed terms/privacy policy. This change does not send warning emails or publish legal content automatically.
