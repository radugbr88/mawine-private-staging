# Password reset delivery — Cloudflare Email Sending

The existing recovery flow sends a **single-use link**, not a numeric code. The link expires after one hour. No UI or account data migration is required.

## Runtime configuration

Configure these server-side values in Sites runtime settings or, after migration, in the Cloudflare Worker's Variables and Secrets. Do not place them in client code or the hosting manifest.

| Name | Value / purpose |
| --- | --- |
| `CLOUDFLARE_EMAIL_API_TOKEN` | **Secret**; token with Account → Email Sending → Edit for the sending account. Not yet configured. |
| `CLOUDFLARE_ACCOUNT_ID` | Cloudflare account owning the verified sending domain. |
| `MAWINE_EMAIL_FROM` | `no-reply@mawine.app` (bare email; display name is Mawine). |
| `MAWINE_PUBLIC_ORIGIN` | `https://mawine-private-tastings.bdnsrl.chatgpt.site` while hosted on Sites. |

All four settings are required; invalid or missing settings disable requests with a generic 503 before a reset token is created. The API token must be saved as a secret. No Resend account or key is used.

Cloudflare must have the sending domain onboarded with its required DNS records and the account must be entitled to Email Sending. Configuration in this project does not verify account entitlement, DNS, quotas or mailbox delivery.

## Delivery and safety

Server calls `POST https://api.cloudflare.com/client/v4/accounts/{account_id}/email/sending/send` with Bearer authentication, a ten-second timeout and redirects disabled. Both the HTTP status and Cloudflare's recipient delivery result are checked. Delivered and queued recipients are accepted; a permanent bounce, malformed response or API failure revokes the newly created reset link. Queued status does not guarantee final inbox delivery. Responses to the requester remain generic to avoid exposing registered usernames. No provider payloads, credentials or reset tokens are logged or returned to the browser.

Reset links use the configured HTTPS origin, never the request Host header. Tokens are random, stored only as SHA-256 hashes, expire after one hour and become invalid when the password or recovery email changes. Successful reset atomically changes the password, invalidates reset links and removes authenticated identity mappings. Rate limits apply per IP and username. A reset never automatically logs the requester in.

Recovery addresses are user-entered, not separately verified; mail possession is checked by redeeming the link.

## Activation and migration

1. Save `CLOUDFLARE_EMAIL_API_TOKEN` through a secure server-secret entry mechanism. Do not send it in chat, screenshots, source files or shell arguments.
2. Redeploy so the runtime receives the settings.
3. Use a controlled account with a mailbox you own to request a reset. Check inbox/spam, sender and destination URL; change the password, verify old sessions stop working, and verify the used link fails. Also test an expired link.
4. When `mawine.app` serves the migrated app with HTTPS, set `MAWINE_PUBLIC_ORIGIN=https://mawine.app`, copy the other runtime settings securely and redeploy. Keep the same database (including password-reset tables) if retaining accounts. Repeat the mailbox test.
5. Remove the email secret from the old deployment when retiring it. Do not leave two independent copies processing real users.

Preparation tests use mocked delivery and an in-memory database. They do not send real emails. A live delivery test remains required after the secret is configured.

API reference: https://developers.cloudflare.com/email-service/api/send-emails/rest-api/

## Recipient language

Profile language is persisted in `profiles.language` (migration 0026, nullable to preserve existing accounts). New profiles save their selected app language. The Profile language selector saves the preference on the server before switching. Login restores the saved language on another device. Existing profiles with a NULL language initialize it from the device preference upon opening the app; the conditional update never overwrites a previously stored choice. Users who have not reopened the app yet have no server preference available.

Reset email subject and body use the recipient profile, ignoring the language submitted by the unauthenticated reset requester. Supported languages are Romanian, English, Italian and French. Missing/unsupported profile preferences use English. Missing individual translations fall back to English. `app/email-language.ts` is reusable by future transactional email flows; an account-activation email flow is not implemented or enabled by this change.

To add a language, extend the supported locale registry/UI and translation dictionary, including all email keys, and add it to the email tests. No schema migration is needed for another language code.
