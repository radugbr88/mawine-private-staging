# Verificare Mawine v235

- TypeScript: fără erori.
- 39/39 suite trecute: 37 la rularea integrală, apoi cele două suite corectate și rerulate (flows, menu-access).
- Testele vechi au fost actualizate pentru absența reamintirilor la începutul gratuității și ștergerea mesajului la navigare; meniul Notificări este inclus în cele 90 de cazuri de acces.
- Plăți: prețuri permise, izolare test/live, Checkout duplicat și retry, proprietar portal, facturi plătite, anulări, reînnoiri eșuate, webhook duplicat/ordine inversă/semnătură.
- Cupoane: validare, expirare, restricții client/produs, limită utilizări, sumă minimă, prima achiziție, transmitere discount în Checkout.
- Notificări: criptare/VAPID, transport workerd, acord, dezactivare, deduplicare, sesiuni revocate, zilele 15/12/9/6/3/2/1 și grație 1–3.
- Simulare: planuri lunar/anual, schimbări, anulări, cupoane, revenire la participant.

## Limite externe

Serverul Sites rămâne STRIPE_MODE=test, STRIPE_LIVE_ENABLED=false, STRIPE_ENFORCE_ACCESS=false. Cheile STRIPE_SECRET_KEY și STRIPE_WEBHOOK_SECRET nu sunt prezente în configurația serverului. Contul configurat este acct_1UWKZuPCFCfe1Mff; conectorul disponibil oferă doar alt cont (BestFoodImporters, live). Nu s-au efectuat plăți reale și nu s-a confirmat live produsul, portalul sau livrarea webhook-ului în contul Mawine. Testele Stripe folosesc fixture-uri controlate.

Programarea push fără trafic necesită Cron Trigger pe serverul final. Nu s-a verificat vizual pe telefon această mutare de buton; previzualizarea gestionată nu este disponibilă.
