import {purgeExpiredCollections} from '../app/collection-retention';
import {purgeTrialLedger} from '../app/account-security';
import {dispatchPush} from '../app/push';
import handler from "vinext/server/fetch-handler";
import { runWithConnectorBinding } from "../lib/connector-context";
import type { ConnectorBinding } from "../lib/connector-contract.mjs";

const worker = {
  async scheduled(_event: ScheduledController, env: Cloudflare.Env, ctx: ExecutionContext) {
    if(env.DB)ctx.waitUntil(purgeExpiredCollections(env.DB).catch(()=>console.error("collection_cleanup_failed")));
    if(env.DB)ctx.waitUntil(purgeTrialLedger(env.DB).catch(()=>console.error("trial_cleanup_failed")));
    if(env.DB)ctx.waitUntil(dispatchPush(env.DB,env as unknown as Record<string,unknown>,100).catch(()=>console.error("push_cron_failed")));
  },
  async fetch(request: Request, env: Cloudflare.Env, ctx: ExecutionContext<{ CONNECTORS?: ConnectorBinding }>) {
    // On standalone hosting no incoming ChatGPT proxy identity is trusted.
    if ((env as unknown as Record<string,string>).MAWINE_DEPLOYMENT === 'standalone' || (env as unknown as Record<string,string>).MAWINE_TRUST_PROXY_IDENTITY !== 'true') {
      const headers = new Headers(request.headers);
      headers.delete('oai-authenticated-user-id');
      request = new Request(request, {headers});
    }
    let binding = ctx.props?.CONNECTORS;
    // Local preview emulates the same request-scoped capability. This branch and
    // the auxiliary service binding are absent from production builds.
    if (import.meta.env.DEV && !binding && env.CONNECTORS) {
      const preview = env.CONNECTORS;
      const expiresAt = Date.now() + 60_000;
      binding = {
        async getContext() {
          if (Date.now() >= expiresAt) return { status: "request_context_expired" };
          return preview.getContext?.() ?? { status: "binding_unavailable" };
        },
        async invoke(connectorId, actionName, args) {
          if (Date.now() >= expiresAt) {
            return { status: "request_context_expired", message: "This request has expired. Please try again." };
          }
          return preview.invoke(connectorId, actionName, args);
        },
      };
    }
    if(env.DB && new URL(request.url).pathname === "/api/app")ctx.waitUntil(dispatchPush(env.DB,env as unknown as Record<string,unknown>,5).catch(()=>console.error("push_dispatch_failed")));
    const response = await runWithConnectorBinding(binding, () => handler.fetch(request, env, ctx));
    // A cached document must not reference chunks removed by a later deployment.
    if ((response.headers.get("content-type") || "").includes("text/html")) {
      const headers = new Headers(response.headers);
      headers.set("Cache-Control", "private, no-store, max-age=0");
      if ((env as unknown as Record<string,string>).MAWINE_DEPLOYMENT === 'standalone') {
        const policy = headers.get('Content-Security-Policy') || "default-src 'self'";
        headers.set('Content-Security-Policy', policy + "; frame-ancestors 'none'");
        headers.set('X-Frame-Options', 'DENY');
        headers.set('Strict-Transport-Security', 'max-age=31536000');
      }
      return new Response(response.body, {status: response.status, statusText: response.statusText, headers});
    }
    if (new URL(request.url).pathname.startsWith('/api/')) {
      const headers = new Headers(response.headers);
      headers.set('Cache-Control', 'private, no-store');
      return new Response(response.body, {status: response.status, statusText: response.statusText, headers});
    }
    return response;
  },
};

export default worker;
